/**
 * 大陆接口
 */

import { post , get } from "@/utils/request";

const baseUrl = "/activity/Wbqj_xijing";

// 登录
export function login(params,headers){
    return post(baseUrl+"/login",params,headers)
}
// 获取角色列表
export function get_role_lists(params,headers){
    return post(baseUrl+"/get_role_lists",params,headers)
}
// 绑定角色
export function bind_role(params,headers){
    return post(baseUrl+"/bind_role",params,headers)
}
// 添加地址
export function add_addr(params,headers){
    return post(baseUrl+"/add_addr",params,headers)
}
// 修改地址
export function edit_addr(params,headers){
    return post(baseUrl+"/edit_addr",params,headers)
}
// 获取地址列表
export function get_addr(params,headers){
    return post(baseUrl+"/get_addr",params,headers)
}
// 激活分享
export function share(params,headers){
    return post(baseUrl+"/share",params,headers)
}
// 获取获奖信息
export function get_prize_log(params,headers){
    return post(baseUrl+"/get_prize_log",params,headers)
}
// 获取用户信息
export function get_user_info(params,headers){
    return post(baseUrl+"/get_user_info",params,headers)
}
// 提交领奖地址
export function sub_addr(params,headers){
    return post(baseUrl+"/sub_addr",params,headers)
}
// 领奖
export function sub_prize(params,headers){
    return post(baseUrl+"/sub_prize",params,headers)
}
// 反馈
export function feeback(params,headers){
    return post(baseUrl+"/feeback",params,headers)
}
// 获取活动时间
export function getActivityTime(params,headers){
    return get(baseUrl+"/getActivityTime",params,headers)
}
// 快捷登录
export function xy_login(params,headers){
    return post(baseUrl+"/xy_login",params,headers)
}
// 快捷登录
export function lunbo(params,headers){
    return get(baseUrl+"/lunbo",params,headers)
}

