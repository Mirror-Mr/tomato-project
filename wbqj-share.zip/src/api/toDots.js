import axios from "axios";
import qs from "qs";
import md5 from "js-md5";

const url = "https://api.xianyuyouxi.com/service/common/clicklog/click";

const time = Date.now();

// 基本参数
const baseParams = {
  time,
  project_id: "30", // 项目id
  project: "wbqj-xjdds ", // 项目名称
  type:"",
  from: 1, // 来源
  dev: getDeviceType(), // 设备类型：ios/android
  page_index: "1",
  state: "", //是否登录
  tag: "",
  uid:"",
  extra: "",
};

const key = "0391591aafc5db68b08787645b837b4f";

// 埋点，日志上报
export default function clickLog(params) {
  params = qs.stringify(Object.assign(baseParams, params));
  const headers = {};
  headers["Access-s"] = md5(key + time);
  return new Promise((resolve, reject) => {
    axios.post(url, params, { headers }).then(
      (res) => {
        resolve(res.data);
      },
      (err) => {
        reject(err);
      }
    );
  });
}

function isWeiXinClient() {
  const userAgent = navigator.userAgent.toLowerCase();
  if (userAgent.match(/micromessenger/i) == "micromessenger") {
    return 2;
  } else {
    return 1;
  }
}

function getDeviceType() {
  const userAgent = navigator.userAgent.toLowerCase();
  const isIos =
    userAgent.match(/iphone os/i) == "iphone os" ||
    userAgent.match(/ipad/i) == "ipad";
  const isAndroid = userAgent.match(/android/i) == "android";
  if (isIos) {
    return 1;
  } else if (isAndroid) {
    return 2;
  } else {
    return 3;
  }
}
