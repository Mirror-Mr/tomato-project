import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

const routes = [
  {
    path:"/",
    redirect:"/enter"
  },
  {
    path: "/enter",
    name: "Enter",
    component:() => import("../views/Enter.vue")
  },
  {
    path: "/unlock",
    name: "Page1",
    component:() => import("../views/Page1.vue")
  },
  {
    path: "/openBox",
    name: "Page2",
    component: () =>
      import( "../views/Page2.vue"),
  },
  {
    path: "/drama",
    name: "Page3",
    component: () =>
      import( "../views/Page3.vue"),
  },
  {
    path: "/friend",
    name: "Page4",
    component: () =>
      import( "../views/Page4.vue"),
  },
  {
    path: "/blank",
    name: "Blank",
    component: () =>
      import( "../views/Blank.vue"),
  },
];

const router = new VueRouter({
  routes,
});

export default router;
