<template>
  <div class="content-mask flexColumnCenter">
    <!-- 弹框内容 -->
    <!-- <transition name="fade"> -->
    <!-- 规则 -->
    <div class="rule flexColumnCenter" v-if="maskShow == 'rule'">
      <div class="contents">
        <div class="content1 content">
          <div class="innerCenter">活动时间：</div>
          <span>2022年1月27日-2月9日</span>
        </div>
        <div
          class="content"
          :class="`content${index + 2}`"
          v-for="(item, index) in ruleMsg"
          :key="index"
        >
          <div class="innerCenter">{{ item[0] }}</div>
          <ol>
            <li v-for="(content, index) in item.slice(1)" :key="index">
              {{ content }}
            </li>
          </ol>
        </div>
      </div>
    </div>
    <!-- 客服中心 -->
    <div class="service flexColumnCenter" v-if="maskShow == 'service'">
      <div class="innerCenter" @click="contact_server">联系客服</div>
      <div
        class="innerCenter"
        @click="
          setIsMaskShow('feedback');
          detail = '';
        "
      >
        反馈有奖
      </div>
    </div>
    <!-- 反馈 -->
    <div class="feedback flexColumnCenter" v-if="maskShow == 'feedback'">
      <van-field
        v-model="detail"
        rows="2"
        autosize
        type="textarea"
        placeholder="请输入您对本次活动的建议或意见."
      />
      <div
        class="btn-push innerCenter"
        :class="{ ban: !detail }"
        @click="submitFeedback"
      >
        提交
      </div>
    </div>
    <!-- 中奖记录 -->
    <div
      class="gift-record flexColumnCenter"
      v-if="maskShow == 'giftRecord' || maskShow == 'giftRecordTop'"
      :class="{ record1: maskShow == 'giftRecordTop' }"
    >
      <div class="title">
        <span>时间</span>
        <span>奖励内容</span>
        <span v-if="maskShow == 'giftRecordTop'">获得奖励</span>
      </div>
      <ul v-if="giftRecordList.length != 0">
        <li v-for="(item, index) in giftRecordList" :key="index">
          <span>{{ item.createtime.split(" ")[0] }}</span>
          <!-- <span v-if="maskShow == 'giftRecordTop'">{{ item.content }}</span> -->
          <span class="innerCenter" v-if="maskShow == 'giftRecordTop'">{{
            prizeList[`prizeGroup${item.type - 1}`][item.rid - 1].name
          }}</span>
          <div class="innerCenter">
            <template v-if="maskShow == 'giftRecordTop'">
              <span
                v-for="(item, index) in prizeList[`prizeGroup${item.type - 1}`][
                  item.rid - 1
                ].prize"
                :key="index"
                >{{ item }}
              </span>
            </template>
            <template v-else>
              <span>
                <!-- {{ item.start }} -->
                {{
                  item.type == 6
                    ? normalGiftList[item.start - 1].name
                    : highGiftList[item.start * 1 + 1].name
                }}*{{
                  item.type == 6
                    ? normalGiftList[item.start - 1].num
                    : highGiftList[item.start * 1 + 1].num
                }}
              </span>
            </template>
          </div>
          <span
            v-if="
              maskShow == 'giftRecord' &&
              item.type == '7' &&
              item.rid != '6' &&
              !item.addr
            "
            @click="completeAddr(item)"
            >完善地址信息</span
          >
        </li>
      </ul>
      <div class="no-gift-record innerCenter" v-else>暂无中奖记录</div>
    </div>
    <!-- 盲盒概率展示+中奖名单 纯展示 -->
    <div
      class="probably flexColumnCenter"
      v-if="
        maskShow == 'probably' || maskShow == 'winnerList' || maskShow == 'lead'
      "
    >
      <!-- 盲盒概率展示 -->
      <div class="probably-container" v-if="maskShow == 'probably'">
        <div class="btn-group">
          <div
            class="btn-normal innerCenter"
            :class="{ click: boxIndex == 1 }"
            @click="boxIndex = 1"
          >
            普通盲盒
          </div>
          <div
            class="btn-high innerCenter"
            :class="{ click: boxIndex == 2 }"
            @click="boxIndex = 2"
          >
            高级盲盒
          </div>
        </div>
        <div class="content">
          <div>
            <span>道具</span>
            <span>道具名称</span>
            <span>获取概率</span>
          </div>
          <ul>
            <li
              v-for="item in boxIndex == 1 ? normalGiftList : highGiftList"
              :key="item.id"
            >
              <div class="img innerCenter">
                <img
                  :src="`https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/${item.icon}.png`"
                  alt=""
                />
              </div>
              <div class="name innerCenter">
                {{ item.name }} * {{ item.num }}
              </div>
              <div class="percent innerCenter">{{ item.percent }}</div>
            </li>
          </ul>
        </div>
      </div>
      <!-- 中奖名单 -->
      <div class="winner-list-container" v-if="maskShow == 'winnerList'">
        <swiper
          :options="swiperOption_winnerList"
          class="winner_swiper"
          ref="winnerSwiper"
        >
          <swiper-slide
            class="winner_slide innerCenter"
            v-for="item in winnerList"
            :key="item.id"
          >
            恭喜
            <span>{{ item.phone }}</span>
            获得了
            <span>{{ item.gift }}</span>
          </swiper-slide>
        </swiper>
      </div>
      <!-- 引导页 -->
      <div class="lead-container flexColumnCenter" v-if="maskShow == 'lead'">
        <span>1.通过【剧本奖励】完成任务获取盲盒和剧本碎片。</span>
        <span>2.在【开启盲盒】开启任务获取的盲盒，可获得道具和实物奖励。</span>
        <span>3.收集碎片可在【剧本解锁】中解锁不同剧本，领取剧本大礼包。</span>
      </div>
    </div>
    <!-- 普通盲盒开启成功 -->
    <div class="open-normal flexColumnCenter" v-if="maskShow == 'openNormal'">
      <div class="gift innerCenter">
        <img
          :src="`https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/${normalBoxGift.icon}.png`"
          alt=""
        />
      </div>
      <span>{{ normalBoxGift.name }}*{{ normalBoxGift.num }}</span>
      <div
        class="innerCenter"
        @click="
          setIsMaskShow('');
          $emit('setMaskTitle', '');
        "
      >
        好的
      </div>
      <span>请到游戏内查看</span>
    </div>
    <!-- 地址簿 -->
    <div
      class="address-list flexColumnCenter"
      v-if="maskShow == 'addressList' || maskShow == 'addressList1'"
      :style="{ marginTop: maskShow == 'addressList1' ? '4vw' : '0vw' }"
    >
      <ul v-if="addressList.length != 0">
        <li v-for="(item, index) in addressList" :key="index">
          <div class="content">
            <div>
              <span>{{
                item.name.length > 5 ? item.name.slice(0, 5) + "..." : item.name
              }}</span>
              <span>{{ item.phone }}</span>
            </div>
            <span>{{ item.addr }}</span>
          </div>
          <div
            class="btn-check-address innerCenter"
            @click="clickAddressBtn(maskShow, item)"
          >
            <template v-if="maskShow == 'addressList'">修改地址</template>
            <template v-else>选择该地址</template>
          </div>
        </li>
      </ul>
      <div class="no-address innerCenter" v-else>暂无地址信息</div>
      <div
        class="create-address innerCenter"
        @click="addAddress"
        v-if="maskShow == 'addressList'"
      >
        新建地址
      </div>
    </div>
    <!-- 新建/修改地址 -->
    <div
      class="update-address flexColumnCenter"
      v-if="maskShow == 'updateAddress' || maskShow == 'addAddress'"
    >
      <div class="name">
        <span>电话</span>
        <van-field v-model="userMsg.phone" type="tel" />
      </div>
      <div class="phone">
        <span>姓名</span>
        <van-field v-model="userMsg.name" />
      </div>
      <div class="address">
        <span>地址</span>
        <van-field
          v-model="userMsg.addr"
          rows="2"
          placeholder="(详细地址 如xx省xx市(州)xx区(县)XX乡(镇)xx街道xx小区xx门牌号)"
          autosize
          type="textarea"
        />
      </div>
      <div class="innerCenter" @click="toUpdateAddress(maskShow)">确认</div>
    </div>
    <!-- 高级盲盒开启成功 -->
    <div class="open-high flexColumnCenter" v-if="maskShow == 'openHigh'">
      <div class="gift">
        <img
          :src="`https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/${
            tempHighGift.prize
              ? highGiftList[tempHighGift.prize * 1 + 1].icon
              : highGiftList[highBoxGift.prize * 1 + 1].icon
          }.png`"
          alt=""
        />
      </div>
      <span
        >{{
          tempHighGift.prize
            ? highGiftList[tempHighGift.prize * 1 + 1].name
            : highBoxGift.prize
            ? highGiftList[highBoxGift.prize * 1 + 1].name
            : ""
        }}*1</span
      >
      <div class="msg-container flexColumnCenter">
        <span>请填写您的姓名、电话、地址方便我们寄送奖励哦~</span>
        <div>
          <div class="flexColumnCenter">
            <div class="name">
              <span>姓名</span>
              <van-field v-model="checkMsg.name" />
            </div>
            <div class="phone">
              <span>电话</span>
              <van-field v-model="checkMsg.phone" type="tel" />
            </div>
            <div class="address">
              <span>地址</span>
              <van-field
                v-model="checkMsg.addr"
                rows="2"
                autosize
                type="textarea"
              />
            </div>
          </div>
          <span @click="showAddress">【地址簿】</span>
        </div>
      </div>
      <div class="btn-submit innerCenter" @click="judgeAddress">确认提交</div>
    </div>
    <!-- 分类奖励预览 -->
    <div class="preview" v-if="maskShow == 'preview'">
      <div
        class="innerCenter"
        v-for="item in previewList"
        :key="item.id"
        @click="scrollTo(item)"
      >
        {{ item }}
      </div>
    </div>
    <!-- 分享海报 -->
    <div
      class="share-post flexColumnCenter"
      :class="{ 'single-code': maskShow == 'sharePost1' }"
      v-if="maskShow == 'sharePost1' || maskShow == 'sharePost2'"
    >
      <img src="./img/share-post.png" alt="" />
      <div class="text innerCenter" v-html="slogan"></div>
      <span v-if="maskShow == 'sharePost1'">扫我进入游戏哦~</span>
      <div class="code-group">
        <div class="innerCenter code1">
          <span class="tag" v-if="maskShow == 'sharePost2'">下载游戏</span>
          <canvas class="downloadGame"></canvas>
        </div>
        <div class="innerCenter code2">
          <span class="tag">分享活动</span>
          <canvas class="shareActivity"></canvas>
        </div>
      </div>
      <span class="save">长按保存图片分享</span>
    </div>
    <!-- 选择登录方式 -->
    <div
      class="choose-login-way flexColumnCenter"
      v-if="maskShow == 'chooseLoginWay'"
    >
      <div class="btn-group">
        <!-- 1手机号 默认方式1手机号 -->
        <div>
          <span
            class="phone"
            @click="
              setIsMaskShow('phoneLogin1');
              $emit('setMaskTitle', '手机登录');
              phoneLogin1.timer
                ? ''
                : (phoneLogin1 = {
                    ...phoneLogin1,
                    phoneNum: '',
                    phoneCode: '',
                    codeMsg: '获取验证码',
                  });
            "
          ></span>
          <span>手机登录</span>
        </div>
        <!--  2账号  -->
        <div>
          <span
            class="account"
            @click="
              setIsMaskShow('accountLogin');
              $emit('setMaskTitle', '账号登录');
              accountLogin = { ...accountLogin, accountNum: '', password: '' };
            "
          ></span>
          <span>账号登录</span>
        </div>
      </div>
    </div>
    <!-- 手机登录方式1 -->
    <div class="phone-login1 flexColumnCenter" v-if="maskShow == 'phoneLogin1'">
      <input
        class="phoneNum"
        type="tel"
        placeholder="请输入手机号"
        v-model="phoneLogin1.phoneNum"
      />
      <div class="codeGroup">
        <input
          class="phoneCode"
          type="tel"
          placeholder="请输入验证码"
          v-model="phoneLogin1.phoneCode"
        />
        <div class="getCode innerCenter" @click="getCode(phoneLogin1)">
          {{ phoneLogin1.codeMsg }}
        </div>
      </div>
      <!-- <span
        @click="
          setIsMaskShow('phoneLogin2');
          phoneLogin1.timer
            ? ''
            : (phoneLogin1 = {
                ...phoneLogin1,
                phoneNum: '',
                phoneCode: '',
                codeMsg: '获取验证码',
              });
          phoneLogin2 = { ...phoneLogin2, phoneNum: '', password: '' };
        "
        >密码登录</span
      > -->
      <div class="btn_group">
        <div
          class="innerCenter"
          @click="
            setIsMaskShow('chooseLoginWay');
            $emit('setMaskTitle', '选择登录方式');
          "
        >
          返回
        </div>
        <div class="innerCenter" @click="login(phoneLogin1)">确认</div>
      </div>
    </div>
    <!-- 手机登录方式2 -->
    <div class="phone-login2 flexColumnCenter" v-if="maskShow == 'phoneLogin2'">
      <input
        class="phoneNum"
        type="tel"
        placeholder="请输入手机号"
        v-model="phoneLogin2.phoneNum"
      />
      <input
        class="password"
        type="password"
        placeholder="请输入密码"
        v-model="phoneLogin2.password"
      />
      <span
        @click="
          setIsMaskShow('phoneLogin1');
          phoneLogin2 = { ...phoneLogin2, phoneNum: '', password: '' };
        "
        >验证码登录</span
      >
      <div class="btn_group">
        <div
          class="innerCenter"
          @click="
            setIsMaskShow('chooseLoginWay');
            $emit('setMaskTitle', '选择登录方式');
          "
        >
          返回
        </div>
        <div class="innerCenter" @click="login(phoneLogin2)">确认</div>
      </div>
    </div>
    <!-- 账号登录 -->
    <div
      class="account-login flexColumnCenter"
      v-if="maskShow == 'accountLogin'"
    >
      <input
        class="phoneNum"
        type="text"
        placeholder="请输入账号"
        v-model="accountLogin.accountNum"
      />
      <input
        class="password"
        type="password"
        placeholder="请输入密码"
        v-model="accountLogin.password"
      />
      <div class="btn_group">
        <div
          class="innerCenter"
          @click="
            setIsMaskShow('chooseLoginWay');
            $emit('setMaskTitle', '选择登录方式');
          "
        >
          返回
        </div>
        <div class="innerCenter" @click="login(accountLogin)">确认</div>
      </div>
    </div>
    <!-- 绑定角色 -->
    <div class="bind-role flexColumnCenter" v-if="maskShow == 'bindRole'">
      <!-- <div class="platform" @click="showBtmMask('platform')">
        <b>平台：</b>
        <div>
          {{ roleMsg.platform }}
          <span></span>
        </div>
      </div> -->
      <div class="role_id" @click="showBtmMask('roleId')">
        <b>区服：</b>
        <div>
          {{ roleMsg.server_name }}
          <span></span>
        </div>
      </div>
      <div class="role_name">
        <b>角色：</b>
        <div>
          <!-- {{ roleMsg.server_name ? roleMsg.server_name : "" }} -->
          {{ roleMsg.role_name }}
          <span></span>
        </div>
      </div>
      <div class="innerCenter" @click="checkBindRole(roleMsg)">确认</div>
    </div>
    <!-- 奖励展示1个 -->
    <div class="preview-one" v-if="maskShow == 'previewOne'">
      <div class="gift innerCenter">
        <img
          src="https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/logo.png"
          alt=""
        />
      </div>
      <span>{{ showOnePreview.name }}*{{ showOnePreview.num }}</span>
    </div>
    <!-- 奖励展示6个 -->
    <div class="preview-mid" v-if="maskShow == 'previewMid'">
      <div
        v-for="item in showMidPreview"
        :key="item.id"
        class="flexColumnCenter"
      >
        <div class="gift innerCenter">
          <img :src="item.imgUrl" alt="" />
        </div>
        <span>{{ item.name }}*{{ item.num }}</span>
      </div>
    </div>
    <!-- 奖励展示9个 -->
    <div class="preview-more" v-if="maskShow == 'previewMore'">
      <div v-for="item in morePreview" :key="item.id" class="flexColumnCenter">
        <div class="gift innerCenter">
          <img :src="item.imgUrl" alt="" />
        </div>
        <span>{{ item.name }}*{{ item.num }}</span>
      </div>
    </div>

    <!-- 公共弹框 有一个或两个按钮 -->
    <div class="common flexColumnCenter" v-if="isCommonMaskShow">
      <span>{{ commonMaskMsg.content }}</span>
      <div class="role-msg" v-if="maskShow == 'showRoleMsg'">
        <div class="innerCenter">角色ID：{{ loginUserMsg.info.rid }}</div>
        <div class="innerCenter">咸鱼ID：{{ loginUserMsg.info.uid }}</div>
      </div>
      <div
        class="btn-single innerCenter"
        v-if="!commonMaskMsg.btn2"
        @click="confirm(maskShow)"
        :style="{ marginTop: maskShow == 'showRoleMsg' ? '5vw' : '7vw' }"
      >
        {{ commonMaskMsg.btn1 }}
      </div>
      <div class="btn-group-common" v-else>
        <div class="innerCenter" @click="cancel(maskShow)">
          {{ commonMaskMsg.btn2 }}
        </div>
        <div class="innerCenter" @click="confirm(maskShow, null, 1)">
          {{ commonMaskMsg.btn1 }}
        </div>
      </div>
    </div>
    <!-- </transition> -->
  </div>
</template>
<script>
import QRCode from "qrcode";
import { validatePhone } from "@/utils/validate";
import {
  login,
  get_role_lists,
  bind_role,
  add_addr,
  edit_addr,
  feeback,
  sub_addr,
  get_user_info,
  sub_prize,
  get_prize_log,
} from "@/api";
import clickLog from "@/api/toDots.js";
import sendCode from "@/api/sendCode";
import {
  midPreview,
  morePreview,
  normalGiftList,
  highGiftList,
} from "./awards.js";
import { mapState, mapMutations } from "vuex";
import { Swiper, SwiperSlide } from "vue-awesome-swiper";
import "swiper/dist/css/swiper.css";
export default {
  name: "ContentMask",
  props: {
    maskShow: {
      type: String,
      default: "",
    },
    addressList: {
      type: Array,
    },
    previewList: {
      type: Array,
    },
    maskShow_btm: {
      type: String,
      default: "",
    },
    winnerList: {
      type: Array,
    },
    prizeList: {
      type: Object,
    },
  },
  components: {
    Swiper,
    SwiperSlide,
  },
  data() {
    return {
      time: Date.now(),
      // 请求是否回来了
      responseDone: true,
      project_id: 30,
      //   调起游戏url
      jumpUrl: "",
      ruleMsg: [
        [
          `剧本奖励：`,
          `奖励分为日常奖励、个人成就奖励、新用户邀请奖励三个部分， 玩家可点击【查看领奖记录】查询自己的领奖记录，玩家需要绑 定自己的账号后领取。`,
          `日常奖励每日0点刷新，若刷新之前未领取奖励，奖励将不给发。`,
          `个人成就奖励和新用户邀请奖励整个活动期间仅可领取一次。 `,
          `新用户邀请奖励部分，被邀请玩家注册时间必须在活动开始之后， 被邀请玩家完成对应章节剧情后，邀请人可领取奖励。`,
          `玩家可通过完成【剧本奖励】的任务，领取盲盒和剧本碎片。`,
          `剧本碎片可用于解锁剧本，每解锁一个剧本可获得对应的道具奖励 和高级盲盒奖励。`,
          `盲盒可参与抽奖，打开盲盒后可随机获取奖励。`,
          `获取的剧情碎片可以在【剧本解锁】处确认现有剧本碎片情况，现有 盲盒数可以在【开启盲盒】处查看。`,
        ],
        [
          `剧本解锁：`,
          `使用剧本碎片解锁剧本，每个剧本需要的碎片不同，解锁后可观看剧 本，并且同时获得道具奖励和高级盲盒抽奖券。`,
          `同时解锁3个剧本可获取【限定时装】1套。（待定）`,
        ],
        [
          `开启盲盒：`,
          `玩家可开启已获取的盲盒，盲盒分为普通盲盒和高级盲盒。`,
          `打开普通盲盒可获取游戏内道具；打开高级盲盒可获取京东卡、游戏 周边等奖励。`,
          `抽中实物奖励的玩家需要填写个人姓名、电话、地址信息，方便寄 送，活动结束后3天内未填写将视为放弃领取，我们将会在活动结束后14个工作日内寄送礼物。`,
        ],
        [
          `好友进度：`,
          `玩家可以通过【玩家进度】查询自己邀请的玩家的剧情完成进度，可以在活动结束前督促好友完成任务，完成任务后双方都可以在【剧本奖励】页面领取奖励。`,
        ],
        [
          `其他事项：`,
          `所有游戏奖励将自动发放至绑定的账号，请玩家在参与活动前务必确认绑定的账号是否正确，因绑定错误导致奖励发放错误的情况，奖励不给予补发。`,
          `所有实物奖励将在活动结束后14个工作日内寄送礼物，3天内未填写信息的中奖玩家我们奖不给予补发。`,
          `玩家可通过点击游戏内的【特别活动】图标跳转本次活动页面，游戏内跳转将会自动读取游戏内角色信息。`,
          `最终解释权归《我本千金》运营团队所有。`,
        ],
      ],
      // 反馈信息
      detail: "",
      // 用户收货地址信息
      userMsg: {
        name: "",
        phone: "",
        addr: "",
        id: "",
      },
      // 确认领取奖励地址
      checkMsg: {
        name: "",
        phone: "",
        addr: "",
        id: "",
      },
      // 手机登录信息1
      phoneLogin1: {
        id: 1,
        phoneNum: "",
        phoneCode: "",
        timer: null,
        codeMsg: "获取验证码",
      },
      // 手机登录信息2
      phoneLogin2: {
        id: 2,
        phoneNum: "",
        password: "",
      },
      // 账号登录信息
      accountLogin: {
        id: 3,
        accountNum: "",
        password: "",
      },
      // 平台
      platform: ["安卓", "IOS"],
      // 角色信息
      roleMsg: {
        platform: "IOS",
        role_id: "",
        server_name: "",
        role_name: "",
      },
      // 一个的奖励展示
      onePreview: [
        {},
        {
          imgUrl:
            "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/logo.png",
          name: "钻石",
          num: 30,
        },
        {},
        {
          imgUrl:
            "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/logo.png",
          name: "钻石",
          num: 50,
        },
        {},
        {
          imgUrl:
            "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/logo.png",
          name: "钻石",
          num: 100,
        },
      ],
      // 中等数量的奖励展示
      midPreview: midPreview,
      // 要展示的6个的奖励展示
      showMidPreview: [],
      showOnePreview: {},
      // 很多数量的奖励展示
      morePreview: morePreview,
      // 公共弹框要显示的内容
      commonMaskMsg: {
        content: "",
        btn1: "",
        btn2: "",
      },
      // 选择的哪个剧本
      script: {},
      // 选择盲盒id
      blindBox: 0,
      // 领取的哪个奖励
      gift: [],
      // 中奖记录
      giftRecordList: [],
      // 盲盒中奖看哪个
      boxIndex: 1,
      // 中将记录轮播图
      swiperOption_winnerList: {
        direction: "vertical",
        slidesPerView: "auto",
        //自动切换
        autoplay: {
          delay: 0, //自动切换时间间隔
          stopOnLastSlide: false, //切换到最后一个slide时 不会 自动停止
          disableOnInteraction: false, //用户操作swiper后自动切换不会停止 每次都会重新启动
        },
        centeredSlides: true,
        allowTouchMove: false, //不允许触摸滑动
        spaceBetween: 10,
        loop: true,
        watchSlidesProgress: true,
        speed: 2000, //切换速度
        // observer:true,
        // observerParents:true
      },
      // 生成海报标语
      posterSlogans: [
        `百因必有果，下个富婆就是我`,
        `为爱所困，不是姐的风格`,
        `有人吗？<br>我一个人在2000平米的衣帽间好害怕`,
        ` 想成为姐的扣1，不想的请5秒内从我1000亩的大别墅出去`,
        ` 什么时候能流行沙貂的女孩子，貂我已经准备好了，就差沙了`,
        ` 我失眠了，因为我在苦恼，我怎么样才能把我这几百亿资产花完`,
        `只有貂的爱情就像一盘金沙，吹散了，还能花`,
        `无厘头女孩最好命，一个月花光十个亿`,
        `为了防止自己乱花钱，我把黑卡都剪掉了，现在用金子生活`,
        `我喜欢的东西要么很贵，要么特别贵，要么无敌贵`,
        `好烦！<br>昨晚又双叒叕在家里迷路了，<br>什么时候才能摸清我家到底有多大？`,
        `是千金总会花钱的`,
        `别人总说我是靠家里的，胡说，我明明是靠在我的金库上的`,
        `不要再说我是花瓶了，其实我是花心大萝卜`,
        `金床银床不如自己的200平大床`,
        `别的女孩都是对你撒娇，而我只想对你发飙`,
        `别人都要我对他们温柔贴心，只有你要我叫你爸爸`,
        `世界上美女那么多，而最会托马斯螺旋踢的富婆只有我一个`,
        `别人约会西餐玫瑰，我的约会嗦粉流泪`,
        `罗马，我去到过；牛马，我没见识过`,
      ],
      slogan: "",
      // 普通盲盒奖励
      normalGiftList: normalGiftList,
      // 高级盲盒奖励
      highGiftList: highGiftList,
      //普通盲盒奖励
      normalBoxGift: {},
      //通过查看中奖记录进入的高级盲盒奖励
      tempHighGift: {},
    };
  },
  methods: {
    setIsMaskShow(n) {
      this.$emit("setIsMaskShow", n);
    },
    // 提交反馈
    submitFeedback() {
      const {
        token,
        info: { uid },
      } = this.loginUserMsg;
      if (!token) {
        this.setIsMaskShow("chooseLoginWay");
        this.$emit("setMaskTitle", "选择登录方式");
        this.$toast.fail("请先登录");
        return;
      }
      let { time, detail, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      // 判断是否为空
      if (!detail) return;
      feeback({ time, token, detail, uid }, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          this.setIsMaskShow("submitSuccess");
          this.setCommonMaskMsg(["提交成功，感谢您的反馈", "前往领奖", ""]);
          this.$emit("setMaskTitle", "");
          // 获取新的用户信息
          this.$emit("get_user_info");
        } else {
          this.$toast.fail("提交反馈失败！");
        }
      });
    },
    // 点击地址簿里的按钮
    clickAddressBtn(maskShow, item) {
      if (maskShow == "addressList") {
        // 修改地址
        this.userMsg = { ...item };
        this.setIsMaskShow("updateAddress");
        this.$emit("setMaskTitle", "修改地址");
      } else {
        // 选择地址
        this.checkMsg = { ...item };
        this.$emit("setMaskTitle", "恭喜您从盲盒中获得了以下奖励");
        this.setIsMaskShow("openHigh");
      }
    },
    // 确认更改/新建地址
    toUpdateAddress(maskShow) {
      // 判断为空
      if (
        maskShow != "saveAddr" &&
        !this.userMsg.name &&
        !this.userMsg.phone &&
        !this.userMsg.addr
      ) {
        this.$toast.fail("信息不能为空！");
        return;
      }
      if (maskShow != "saveAddr" && !this.checkPhone(this.userMsg.phone)) {
        this.$toast.fail("请填写正确的手机号");
        return;
      }
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const { name, phone, addr, id } =
        maskShow != "saveAddr" ? this.userMsg : this.checkMsg;
      const {
        token,
        info: { uid },
      } = this.loginUserMsg;
      if (maskShow == "updateAddress") {
        // 更改
        const params = { time, token, id, name, addr, phone, uid };
        edit_addr(params, { time, token }).then((res) => {
          responseDone = true;
          if (res.status == 1) {
            this.$toast.success("更改地址成功！");
          } else {
            this.$toast.fail("更改地址失败！");
          }
        });
        // 清空 并 关闭
      } else {
        // 新建
        const params = { time, token, name, addr, phone, uid };
        add_addr(params, { time, token }).then((res) => {
          responseDone = true;
          if (res.status == 1) {
            if (maskShow != "saveAddr") {
              // 正常的新增地址
              this.$toast.success("添加地址成功！");
              return;
            }
            // 提交领奖地址前默认新增手动输入地址
            // 存入新建地址的id
            this.checkMsg = { ...this.checkMsg, id: res.data };
            // 提交领奖地址
            this.toSubmitAddress();
          } else {
            this.$toast.fail("添加地址失败！");
          }
        });
      }
      this.userMsg = { ...this.userMsg, name: "", phone: "", addr: "" };
      // this.checkMsg = { ...this.checkMsg, name: "", phone: "", addr: "" };
      this.setIsMaskShow("");
    },
    // 去新建地址
    addAddress() {
      this.setIsMaskShow("addAddress");
      this.$emit("setMaskTitle", "新建地址");
    },
    // 判断地址是否有效 且是否需要存入地址簿
    judgeAddress() {
      const { name, phone, addr } = this.checkMsg;
      // 判断是否为空
      if (!name || !phone || !addr) {
        this.$toast.fail("地址信息不能为空");
        return;
      }
      if (!this.checkPhone(phone)) {
        this.$toast.fail("请填写正确的手机号");
        return;
      }
      // 确认是否将该地址存入地址簿
      const prizeName = this.tempHighGift.prize
        ? this.highGiftList[this.tempHighGift.prize * 1 + 1].name
        : this.highGiftList[this.highBoxGift.prize * 1 + 1].name;
      this.setCommonMaskMsg([
        `确认将奖励 ${prizeName}*1 邮寄到 ${addr}？`,
        "确认",
        "取消",
      ]);
      this.setIsMaskShow("saveAddr");
      this.$emit("setMaskTitle", "");
    },
    // 领取线下奖励 提交地址
    toSubmitAddress() {
      // 确认提交
      let { time, responseDone } = this;
      const {
        token,
        info: { uid },
      } = this.loginUserMsg;
      const { id } = this.tempHighGift.id
        ? this.tempHighGift
        : this.highBoxGift;
      const { id: addr_id } = this.checkMsg;
      console.log(id);
      // return;
      if (!responseDone) return;
      responseDone = false;
      // 提交领奖地址
      sub_addr({ time, token, id, addr_id, uid }, { time, token }).then(
        (res) => {
          responseDone = true;
          if (res.status == 1) {
            this.$toast.success("提交成功！");
            // 将地址id存入localhost
            let addressPrevList = JSON.parse(
              localStorage.getItem("addressPrevList")
            );
            if (!!addressPrevList) {
              // 如果有存在本地的地址列表 则判断是否有该用户的地址信息
              const same = addressPrevList.some((addr) => {
                return addr.uid == uid;
              });
              // 有该用户的地址信息
              if (same) {
                const tempAddressList = addressPrevList.map((addr) => {
                  if (addr.uid == uid) {
                    return { ...addr, addr_id };
                  }
                  return addr;
                });
                addressPrevList = [...tempAddressList];
              } else {
                addressPrevList.push({ uid, addr_id });
              }
            } else {
              // 如果没有存在本地的地址列表
              addressPrevList = [];
              addressPrevList.push({ uid, addr_id });
            }
            localStorage.setItem(
              "addressPrevList",
              JSON.stringify(addressPrevList)
            );
            if (this.tempHighGift.id) {
              if (this.tempHighGift.id == this.highBoxGift.id)
                this.$store.commit("SET_HIGHBOXGIFT", {});
              this.tempHighGift = {};
            } else {
              this.$store.commit("SET_HIGHBOXGIFT", {});
            }
            this.checkMsg = { ...this.checkMsg, name: "", phone: "", addr: "" };
            this.setIsMaskShow("");
          } else {
            this.$toast.fail("提交失败！");
          }
        }
      );
    },
    // 判断该地址和地址簿内的是否有相同的
    addrSame(n) {
      const { addressList } = this;
      return addressList.some((item) => {
        return (
          n.name == item.name && n.phone == item.phone && n.addr == item.addr
        );
      });
    },
    // 查看用户地址簿
    showAddress() {
      this.setIsMaskShow("addressList1");
      this.$emit("getAddressList");
      this.$emit("setMaskTitle", "地址簿");
    },
    // 滚动到
    scrollTo(item) {
      this.$emit("scrollTo", item);
    },
    // 生成二维码
    createQRcode(url, url1) {
      let canvas = document.getElementsByClassName("shareActivity")[0];
      let canvas1 = document.getElementsByClassName("downloadGame")[0];
      QRCode.toCanvas(canvas, url, { margin: 1.5 }, function (error) {
        if (error) console.error(error);
      });
      QRCode.toCanvas(canvas1, url1, { margin: 1.5 }, function (error) {
        if (error) console.error(error);
      });
      canvas.style.display = "block"; //显示canvas
      canvas1.style.display = "block"; //显示canvas
      this.qrcode = canvas.toDataURL("image/png");
      this.qrcode1 = canvas1.toDataURL("image/png");
    },
    // 获取验证码
    getCode(msg) {
      let { responseDone } = this;
      // console.log(msg.timer);
      if (!responseDone || msg.timer) {
        return;
      }
      responseDone = false;
      // console.log(responseDone)
      if (this.checkPhone(msg.phoneNum)) {
        sendCode(msg.phoneNum).then((res) => {
          if (res.status == 1) {
            this.$toast.success(res.msg);
            let num = 90;
            msg.timer = setInterval(() => {
              msg.codeMsg = `${num--}s后重新发送`;
              if (num == 0) {
                responseDone = true;
                msg.codeMsg = "重新发送";
                clearInterval(msg.timer);
                msg.timer = null;
              }
            }, 1000);
          } else {
            this.$toast.fail(res.msg);
          }
        });
      }
    },
    // 登录
    login(msg) {
      msg.phoneNum = msg.phoneNum ? msg.phoneNum.trim() : "";
      msg.phoneCode = msg.phoneCode ? msg.phoneCode.trim() : "";
      msg.accountNum = msg.accountNum ? msg.accountNum.trim() : "";
      msg.password = msg.password ? msg.password.trim() : "";
      if (
        (msg.id == 3 || this.checkPhone(msg.phoneNum)) &&
        (msg.id != 1 || this.checkCode(msg.phoneCode)) &&
        (msg.id != 2 || this.checkNull(msg.password)) &&
        (msg.id != 3 ||
          (this.checkNull(msg.accountNum) && this.checkNull(msg.password)))
      ) {
        let { time, project_id, fcode, responseDone } = this;
        // alert("login-fcode:" + fcode);
        if (!responseDone) {
          return;
        }
        responseDone = false;
        const account = msg.id == 3 ? msg.accountNum : msg.phoneNum;
        const password = msg.id == 1 ? "" : msg.password;
        const code = msg.id == 1 ? msg.phoneCode : "";
        const type = msg.id == 1 ? 2 : 1;
        const params = {
          time,
          project_id,
          account,
          password,
          fcode,
          type,
          code,
        };
        const headers =
          type == 1
            ? { time, account, password, fcode }
            : { time, account, code, fcode };
        login(params, headers).then((res) => {
          const timer = setTimeout(() => {
            responseDone = true;
            clearTimeout(timer);
          }, 1000);
          if (res.status == 1) {
            // 成功登录
            this.$toast.success(res.msg);
            this.$store.commit("SET_lOGINUSERMSG", res.data);
            // this.$store.commit("SET_FCODE", "");
            localStorage.setItem(
              "loginUserMsg",
              JSON.stringify(this.loginUserMsg)
            );
            // 获取用户信息
            this.get_user_info();
            // // 获取角色列表
            // this.getRoleList();
            // // 进入绑定角色弹框
            // this.roleMsg = {
            //   ...this.roleMsg,
            //   platform: "IOS",
            //   role_id: "",
            //   server_name: "",
            //   role_name: "",
            // };
            // this.setIsMaskShow("bindRole");
            // this.$emit("setMaskTitle", "绑定角色");
          } else {
            this.$toast.fail(res.msg);
          }
        });
      }
    },
    // 判断手机号是否合规
    checkPhone(phoneNum) {
      try {
        if (!phoneNum) throw "请输入手机号";
        if (!validatePhone(phoneNum)) throw "请输入正确的手机号";
      } catch (err) {
        this.$toast(err);
        return false;
      }
      return true;
    },
    // 判断验证码是否合规
    checkCode(phoneCode) {
      try {
        if (!phoneCode) throw "请输入验证码";
        if (phoneCode.length != 6) throw "请输入6位数验证码";
      } catch (err) {
        this.$toast(err);
        return false;
      }
      return true;
    },
    // 判断传入数值是否为空
    checkNull(msg) {
      if (!msg) this.$toast.fail("信息不能为空");
      return !!msg;
    },
    // 弹出选择平台和角色id的弹框
    showBtmMask(msg) {
      this.$emit("setIsMaskShow_btm", msg);
    },
    // 确定绑定角色
    checkBindRole(roleMsg) {
      const { platform, role_id, server_id, server_name, role_name } = roleMsg;
      if (!platform || !role_id || !server_name || !role_name) {
        this.$toast.fail("信息不能为空");
        return;
      }
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const {
        token,
        info: { uid },
      } = this.loginUserMsg;
      const channel = platform == "安卓" ? 2 : 1;
      const sid = server_id;
      const sname = server_name;
      const rolename = role_name;
      const roleid = role_id;
      const params = {
        time,
        token,
        channel,
        sid,
        sname,
        rolename,
        roleid,
        uid,
      };
      bind_role(params, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          // 绑定角色成功
          this.$toast.success("绑定角色成功！");
          this.$store.commit("SET_ROLEMSG", this.roleMsg);
          this.roleMsg = {
            ...this.roleMsg,
            platform: "IOS",
            role_id: "",
            server_name: "",
            role_name: "",
          };
          // 获取新的用户信息
          this.$emit("get_user_info");
          this.setIsMaskShow("");
        } else {
          this.$toast.fail("绑定角色失败！");
        }
      });
    },
    // 获取角色列表
    getRoleList() {
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const {
        token,
        info: { uid },
      } = this.loginUserMsg;
      get_role_lists({ time, token, uid }, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          this.$store.commit("SET_ROLELIST", res.data);
        } else {
          let errMsg =
            res.status == 4040
              ? "登录过期，请重新登录"
              : "获取角色列表信息失败";
          this.$toast.fail(errMsg);
          res.status == 4040
            ? this.logOut()
            : this.$store.commit("SET_ROLELIST", []);
        }
      });
    },
    // 获取用户信息
    get_user_info() {
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const { token, uid } = this.loginUserMsg;
      get_user_info({ time, token, uid }, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          this.$store.commit("SET_lOGINUSERMSG", res.data);
          localStorage.setItem(
            "loginUserMsg",
            JSON.stringify(this.loginUserMsg)
          );
          if (res.data.info.rid) {
            // 有已绑定的角色 则直接绑定
            const { channel, rid, rname, sid, sname } = res.data.info;
            this.roleMsg = {
              ...this.roleMsg,
              platform: channel == "1" ? "IOS" : "安卓",
              role_id: rid,
              role_name: rname,
              server_id: sid,
              server_name: sname,
            };
            this.checkBindRole(this.roleMsg);
            return;
          }
          // 若无则获取角色列表
          this.getRoleList();
          // 进入绑定角色弹框
          this.roleMsg = {
            ...this.roleMsg,
            platform: "IOS",
            role_id: "",
            server_name: "",
            role_name: "",
          };
          this.setIsMaskShow("bindRole");
          this.$emit("setMaskTitle", "绑定角色");
        } else {
          let errMsg =
            res.status == 4040 ? "登录过期，请重新登录" : "获取用户信息失败";
          this.$toast.fail(errMsg);
          res.status == 4040 ? this.logOut() : "";
        }
      });
    },
    // 公共弹框的确认按钮
    confirm(maskShow, script = null, type = 0) {
      if (maskShow == "confirmPayChip") {
        const { info } = this.loginUserMsg;
        // 进入确认该角色获取奖励弹框
        this.setCommonMaskMsg([
          `是否使用当前角色 ${info.rname} 获取奖励？`,
          "确认",
          "取消",
        ]);
        this.setIsMaskShow("confirmRoleGetGift-script");
      } else if (maskShow == "tocConfirmPayChip") {
        // 进入是否花碎片解锁弹框
        this.script = script;
        this.setCommonMaskMsg([
          `是否花费${script.limit}碎片解锁剧本《${script.title}》？`,
          "确认",
          "取消",
        ]);
        // this.setIsMaskShow("confirmPayChip");
      } else if (maskShow == "confirmRoleGetGift-script") {
        // 领剧本奖励
        const { id } = this.script;
        this.sub_prize(type, id);
      } else if (maskShow == "confirmRoleGetGift-box") {
        //   开启盲盒 参数为标识高级盲盒或普通盲盒
        this.sub_prize(this.blindBox);
      } else if (maskShow == "confirmRoleGetGift-gift") {
        // 领取奖励
        this.sub_prize(...this.gift);
      } else if (
        maskShow == "showRoleMsg" ||
        maskShow == "noChip" ||
        maskShow == "noBox"
      ) {
        // 关闭展示id信息/无足够碎片/无足够盲盒
        this.setIsMaskShow("");
      } else if (maskShow == "submitSuccess") {
        this.$router.push("/drama");
      } else if (maskShow == "gameDownload") {
        // 跳转至应用商店
        this.$router.push("/blank");
      } else if (maskShow == "tagHighBox") {
        // 提示之前的高级盲盒奖励未领取
        this.$emit("setMaskTitle", "恭喜您从盲盒中获得了以下奖励");
        this.setIsMaskShow("openHigh");
        this.$emit("getAddressList");
      } else if (maskShow == "saveAddr") {
        // 将地址存入地址簿
        this.toUpdateAddress(maskShow);
        // 安卓跳转
      } else if (maskShow == "jumpGameA" || maskShow == "jumpGameB") {
        window.location.href = this.jumpUrl;
      }
    },
    // 公共弹框的取消按钮
    cancel(maskShow) {
      if (maskShow == "saveAddr") {
        this.setIsMaskShow("openHigh");
        this.$emit("setMaskTitle", "恭喜您从盲盒中获得了以下奖励");
        return;
      }
      this.setIsMaskShow("");
    },
    // 设置公共弹框展示内容
    setCommonMaskMsg(arr) {
      this.commonMaskMsg = {
        content: arr[0],
        btn1: arr[1],
        btn2: arr[2],
      };
    },
    // 领取奖励
    sub_prize(type, rid = 1) {
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const {
        token,
        info: { uid },
      } = this.loginUserMsg;
      const params = { time, token, type, rid, uid };
      // 确认该角色获取奖励
      sub_prize(params, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          // 获取奖励成功 重新获取用户信息
          this.$emit("get_user_info");
          if (type == 1) {
            // 剧本领取成功
            this.setIsMaskShow(`script${rid}`);
          } else if (type == 2 || type == 4) {
            // 领取日常奖励
            this.setIsMaskShow("noChip");
            this.setCommonMaskMsg(["奖励领取成功!", "确认", ""]);
          } else if (type == 3) {
            // 新用户邀请奖励
            // console.log("sub_prize1", type, rid);
            if (rid == 1 || rid == 3 || rid == 5) {
              // console.log("sub_prize2", type, rid);
              this.setIsMaskShow("previewOne");
              this.showOnePreview = {
                ...this.onePreview[rid],
              };
            } else {
              this.setIsMaskShow("previewMid");
              this.showMidPreview =
                rid == 2
                  ? this.midPreview.slice(18, 24)
                  : this.midPreview.slice(24, 30);
            }
            this.$emit("setMaskTitle", "恭喜获得");
          } else if (type == 5) {
            // 新用户通关奖励
            if (rid == 6) {
              this.setIsMaskShow("previewMore");
              this.$emit("setMaskTitle", "恭喜获得");
              return;
            }
            this.setIsMaskShow("noChip");
            this.setCommonMaskMsg(["奖励领取成功!", "确认", ""]);
          } else if (type == 6) {
            // 普通盲盒开启成功 展示对应奖励
            this.setIsMaskShow("openNormal");
            this.$emit("setMaskTitle", "恭喜您从盲盒中获得了以下奖励");
            const { name, num, icon } = this.normalGiftList[res.data.prize - 1];
            this.normalBoxGift = {
              ...this.normalBoxGift,
              name,
              num,
              icon,
            };
          } else if (type == 7) {
            // 高级盲盒开启成功 判断是否是实体奖励
            if (res.data.prize == 6) {
              // 非实体奖励
              this.setIsMaskShow("openNormal");
              this.$emit("setMaskTitle", "恭喜您从盲盒中获得了以下奖励");
              this.normalBoxGift = {
                ...this.normalBoxGift,
                name: "普通盲盒",
                num: 5,
                icon: "normal-box",
              };
              return;
            }
            // 实体奖励
            this.$emit("setMaskTitle", "恭喜您从盲盒中获得了以下奖励");
            this.setIsMaskShow("openHigh");
            // 获取上次提交时的地址信息
            this.$emit("getAddressList");
            this.$store.commit("SET_HIGHBOXGIFT", res.data);
          }
        } else {
          this.$toast.fail(res.msg);
        }
      });
    },
    // 联系客服
    contact_server() {
      window.open(
        "https://wpa1.qq.com/lK29QkQe?_type=wpa&qidian=true",
        "_blank"
      );
    },
    // 获取中奖记录
    getGiftRecord(flag) {
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const {
        token,
        info: { uid },
      } = this.loginUserMsg;
      get_prize_log({ time, token, flag, uid }, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          this.giftRecordList = res.data;
          if (flag == 1) {
            this.giftRecordList = this.giftRecordList.filter((data) => {
              return data.type > 1 && data.type < 6;
            });
          }
        } else {
          let errMsg =
            res.status == 4040 ? "登录过期，请重新登录" : "获取中奖记录失败";
          this.$toast.fail(errMsg);
          res.status == 4040 ? this.logOut() : "";
        }
      });
    },
    // 在中奖记录里完善地址信息
    completeAddr(item) {
      this.$emit("setMaskTitle", "恭喜您从盲盒中获得了以下奖励");
      this.setIsMaskShow("openHigh");
      //   不能直接修改highBoxGift
      //   this.highBoxGift.prize = item.start;
      //  赋值奖励的序号 从1开始
      this.tempHighGift.prize = item.rid;
      //  抽奖返回的id
      this.tempHighGift.id = item.id;
      // 获取上次提交时的地址信息
      this.$emit("getAddressList");
    },
    // 注销
    logOut() {
      this.$store.commit("SET_lOGINUSERMSG", {});
      localStorage.removeItem("loginUserMsg");
      this.$store.commit("SET_FCODE", "");
    },
  },
  computed: {
    ...mapState(["loginUserMsg", "roleList", "fcode", "highBoxGift"]),
    // 公共弹框是否展示
    isCommonMaskShow() {
      let commonMask = [
        "submitSuccess",
        "noChip",
        "confirmPayChip",
        "confirmRoleGetGift-script",
        "confirmRoleGetGift-box",
        "confirmRoleGetGift-gift",
        "noBox",
        "showRoleMsg",
        "gameDownload",
        "tagHighBox",
        "saveAddr",
        "jumpGameA",
        "jumpGameB",
      ];
      return commonMask.includes(this.maskShow);
    },
    // 中奖记录轮播图
    winnerSwiper() {
      return this.$refs.winnerSwiper.$swiper;
    },
  },
  mounted() {
    if (this.maskShow == "jumpGameA" || this.maskShow == "jumpGameB") {
      this.setCommonMaskMsg([
        `若出现无法打开游戏的情况，请手动前往游戏`,
        "好的",
        "",
      ]);
    }
    this.jumpUrl =
      this.maskShow == "jumpGameA"
        ? "xhhdand://com.tomatogame.wbqj/open"
        : this.maskShow == "jumpGameB"
        ? "https://market.tomatogames.com/click/v2/customer?isSdk=1&cid=1076&gameId=1100050&channel=wbjqios_ios_qjxjds01_1&customMedia=web_yxhd"
        : "";
    this.$bus.$off(event).$on("createQRcode", (n) => {
      // 随机选择一个海报标语
      const index = Math.floor(Math.random() * 20);
      this.slogan = this.posterSlogans[index];
      // 生成二维码
      const code =
        Object.keys(this.loginUserMsg) != 0 && this.loginUserMsg.info
          ? this.loginUserMsg.info.code
          : null;
      if (code) {
        // console.log(location.href.split("#")[0] + "?fcode=" + code);
        this.createQRcode(
          location.href.split("#")[0] + "?fcode=" + code + "&type=1",
          `${location.href.split("#")[0]}#/blank?type=${n}`
        );
      } else {
        // console.log(location.href.split("#")[0]);
        this.createQRcode(
          location.href.split("#")[0] + "?type=1",
          `${location.href.split("#")[0]}#/blank?type=${n}`
        );
      }
    });
    this.$bus.$off(event).$on("checkPlatform", (platform) => {
      // 选择了平台
      this.roleMsg = {
        ...this.roleMsg,
        platform,
        role_id: "",
        server_name: "",
        role_name: "",
      };
    });
    this.$bus.$off(event).$on("setCommonMaskMsg", (commonMaskMsg) => {
      // 设置公共弹框展示的内容
      this.setCommonMaskMsg(commonMaskMsg);
    });
    this.$bus.$off(event).$on("confirmBtn", (args) => {
      // 点击确认按钮
      this.confirm(...args);
    });
    this.$bus.$off(event).$on("sub_prize", (id) => {
      // 标识是开启高级还是普通盲盒
      this.blindBox = id;
    });
    this.$bus.$off(event).$on("setGift", (args) => {
      // 设置领取奖励id
      this.gift = [args[0] + 1, args[1]];
      // console.log("setGift", ...this.gift);
    });
    this.$bus.$off(event).$on("getGiftRecord", (flag) => {
      // 获取领奖记录
      this.getGiftRecord(flag);
    });
    this.$bus.$off(event).$on("setPreviewMidId", (id) => {
      this.showMidPreview = this.midPreview.slice(
        (id - 1) * 6,
        (id - 1) * 6 + 6
      );
    });
    // 获取上次提交时的地址信息
    this.$bus.$off(event).$on("getAddressPrevMsg", () => {
      const { uid } = this.loginUserMsg.info;
      // 从localstorage获取记录的用户地址列表
      const addressPrevList = JSON.parse(
        localStorage.getItem("addressPrevList")
      );
      // 如果本地不存在用户地址列表或该用户没有地址信息 则置空
      if (!addressPrevList || this.addressList.length == 0) {
        this.checkMsg = { name: "", phone: "", addr: "", id: "" };
        return;
      }
      // 如果有本地地址记录表 则找到对应用户信息的元素
      const addressPrev = addressPrevList.find((addr) => {
        return addr.uid == uid;
      });
      // 如果没有对应的用户信息则置空
      if (!addressPrev) {
        this.checkMsg = { name: "", phone: "", addr: "", id: "" };
        return;
      }
      // 本地有对应的用户信息 则获取
      const address = this.addressList.find((addr) => {
        return addr.id == addressPrev.addr_id;
      });
      this.checkMsg = address
        ? { ...address }
        : { name: "", phone: "", addr: "", id: "" };
    });
    this.$bus.$off(event).$on("showNowRole", (n) => {
      // 显示当前角色
      const { channel, rid, sname, rname, sid } = this.loginUserMsg.info;
      this.roleMsg.platform = channel == 1 ? "IOS" : "安卓";
      this.roleMsg.role_id = rid;
      this.roleMsg.server_name = sname;
      this.roleMsg.role_name = rname;
      this.roleMsg.server_id = sid;
    });
    this.$bus.$off(event).$on("checkRoleServer", (server_name) => {
      // 选择了角色id
      this.roleMsg.server_name = server_name;
      // 确定角色(名)
      this.roleList.forEach((role) => {
        if (role.server_name == server_name) {
          this.roleMsg = Object.assign({}, this.roleMsg, role);
        }
      });
    });
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.content-mask{
    width:100%;
  @mixin commonBtn{
    width: 27.6vw;
    height: 8.5vw;
    font-size: 4vw;
    color: #FFFFFF;
    background-image: imgUrl("bg-btn1.png");
  }
  // .fade-enter-active, .fade-leave-active {
  //   transition: opacity .3s;
  // }
  // .fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  //   opacity: 0;
  // }
  /**
    弹出框内容样式
    */
  // 弹出框规则部分
  .rule{
    width: 90%;
    transition: all 1s linear;
    /*定义滚动条高宽及背景 高宽分别对应横竖滚动条的尺寸*/
      ::-webkit-scrollbar {
          width: 1.6vw;
          height: 1.6vw;
          background-color: #F5F5F5;
      }

      /*定义滚动条轨道 内阴影+圆角*/
      ::-webkit-scrollbar-track {
          /* -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3); */
          border-radius: 1.5vw;
          background-color: #E0E0E0;
      }

      
      /*定义滑块 内阴影+圆角*/
      ::-webkit-scrollbar-thumb {
          border-radius: 1.5vw;
          /* -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, .3); */
          background-color: #8467D9;
      }
    .contents{
      height: 117vw;
      font-size:3.2vw;
      color:#5D5476 ;
      text-align: left;
      margin:3vw 0 0 0;
      overflow-y: scroll;
      .content{
        display: flex;
        flex-direction: column;
        align-items: center;
        &:not(.content1){
          margin:3vw 0 0 0;
        }
        div{
          width: 20vw;
          height: 6.53vw;
          align-self: flex-start;
          background-image: imgUrl("bg-title-content.png");
        }
        span{
          font-size:2.4vw;
          margin: 0 0 0 2vw;
          align-self: flex-start;
        }
        ol{
          width: 90%;
          line-height: 4vw;
          margin:0 0 0 3vw;
          font-size:2.4vw;
          li{
            list-style:decimal !important;
            list-style-position:outside;
          }
        }
      }
    }
  }
  // 弹出框客服中心部分
  .service{
    margin: 5vw 0 0 0;
    div{
      width: 45.6vw;
      height: 10.5vw;
      flex-shrink: 0;
      font-size: 4.68vw;
      color: #FFFFFF;
      background-image: imgUrl("bg-btn.png");
      &:nth-of-type(2){
        margin: 2vw 0 0 0;
      }
    }
  }
  // 反馈弹框部分
  .feedback{
    margin: 2vw 0 0 0;
    /deep/ .van-cell{
      width: 55vw;
      height: 24vw;
      background-color: #EC82B2;
      .van-field__control{
        color: #fff;
        font-size: 3.45vw;
        opacity: 0.74;
      }
      textarea::-webkit-input-placeholder {
        color: #fff;
        font-size: 3.45vw;
        opacity: 0.74;
      }

      textarea:-moz-placeholder {
        color: #fff;
        font-size: 3.45vw;
        opacity: 0.74;
      }

      textarea::-moz-placeholder {
        color: #fff;
        font-size: 3.45vw;
        opacity: 0.74;
      }

      textarea:-ms-input-placeholder {
        color: #fff;
        font-size: 3.45vw;
        opacity: 0.74;
      }
    }
    .btn-push{
      @include commonBtn;
      margin:2vw 0 0 0;
      &.ban{
        filter: grayscale(100%);
      }
    }
  }
  // 中奖记录
  .gift-record{
    margin:6vw 0 0 0;
    &.record1{
      .title{
        span{
          &:nth-of-type(2){
            margin:0 0 0 12.5vw;
          }
          &:nth-of-type(3){
            margin:0 0 0 16vw;
          }
        }
      }
      ul{
        li{
          &>span{
            flex-shrink: 0;
            &:nth-of-type(2){
              width:22vw;
              display: flex;
              margin: 0 0 0 4.3vw;
            }
          }
          &>div{
            width: 35vw;
            flex-shrink: 0;
            margin: 0 0 0 2vw ;
            span{
              margin: 0 1vw !important;
            }
          }
        }
      }
    }
    .title{
      color: #676767;
      font-size: 3.2vw;
      align-self: flex-start;
      span{
        &:nth-of-type(1){
          margin:0 0 0 5vw;
        }
        &:nth-of-type(2){
          margin:0 0 0 22vw;
        }
      }
    }
    ul{
      max-height: 38vw;
      margin:2.67vw 0 0 0;
      font-size: 2.3vw;
      color: #949494;
      overflow: scroll;
      li{
        width: 78vw;
        height: 5.95vw;
        margin:0 0 1.47vw 0;
        display: flex;
        align-items: center;
        background-color:#FCF2FA;
        &>span{
          margin:0 0 0 2.93vw;
        }
        &>div{
          width:35vw;
          margin:0 0 0 8vw;
          span{
              line-height: 3vw;
          }
        }
      }
    }
    .no-gift-record{
      width: 100%;
      height: 39vw;
      font-size: 6vw;
    }
  }
  // 概率展示
  .probably{
    .probably-container{
      width:60vw;
      height: 70vw;
      margin:8vw 0 0 0;
      // background-image: imgUrl("probably-normal.png");
      .btn-group{
        width: 100%;
        display: flex;
        justify-content: space-around;
        div{
          width: 25vw;
          height: 8vw;
          color: #FF6FA8;
          background-image: imgUrl("btn-unclick.jpg");
          &.click{
            color: #fff;
            background-image: imgUrl("btn-click.jpg");
          }
        }
      }
      .content{
        width: 100%;
        height: 57vw;
        margin: 4vw 0 0 0;
        border-top: 0.1vw solid #FCF2FB;
        // background-image: imgUrl("highBox-content.jpg");
        &>div{
          display: flex;
          justify-content: flex-start;
          margin:1.6vw 0 0 0;
          font-size: 3.2vw;
          color: #676767;
          span{
            &:nth-of-type(1){
              margin: 0 0 0 3.2vw;
            }
            &:nth-of-type(2){
              margin: 0 0 0 12.4vw;
            }
            &:nth-of-type(3){
              margin: 0 0 0 9vw;
            }
          }
        }
        ul{
          height: 49vw;
          margin:3.07vw 0 0 0;
          overflow-y: scroll;
          li{
            height: 11vw;
            margin:0 0 2vw 0;
            display: flex;
            align-items: center;
            font-size: 3vw;
            line-height: 3.5vw;
            color: #949494;
            background-color:#FCF2FA;
            .img{
              width: 8vw;
              height: 8vw;
              position:relative;
              margin:0 0 0 3vw;
              border: 0.1vw solid #8E6883;
              img{
                  position: absolute;
              }
            }
            .name{
              width: 27vw;
              margin:0 0 0 5vw;
            }
            .percent{
              width: 10vw;
              margin:0 0 0 3vw;
            }
          }
        }
        &.high{
          // background-image: imgUrl("highBox-content.jpg");
        }
      }
    }
    .winner-list-container{
      .winner_swiper{
        width:70vw;
        height: 63vw;
        margin: 4vw 0 0 0;
        /deep/.swiper-wrapper {
          -webkit-transition-timing-function: linear;    /*之前是ease-out*/
          -moz-transition-timing-function: linear;
          -ms-transition-timing-function: linear;
          -o-transition-timing-function: linear;
          transition-timing-function: linear;
          margin: 0 auto;
          .winner_slide{
            width: 100%;
            height: 9vw;
            font-size: 3.5vw;
            background-color: #FCF2FA;
            span{
              &:nth-of-type(1){
                color:#696FE3 ;
              }
              &:nth-of-type(2){
                color:#FF3000 ;
              }
            }
          }
        }
        
      }
    }
    .lead-container{
      width:75%;
      margin:6vw 0 0 0;
      font-size:4vw;
      text-align: left;
      span{
        margin:0 0 4.5vw 0;
        text-align: justify;
        line-height: 5vw;
      }
    }
  }
  
  // 普通盲盒开启成功
  .open-normal{
    div{
      &.gift{
        width: 25vw;
        height: 25vw;
        position: relative;
        margin: 3vw 0 0 0;
        background-image: imgUrl("bg-script-gift.png");
        img{
            position: absolute;
        }
      }
      &:nth-of-type(2){
        @include commonBtn;
        margin:3vw 0 0 0;
      }
    }
    span{
      &:nth-of-type(1){
        font-size: 4.54vw;
        color: #5A5A5A;
      }
      &:nth-of-type(2){
        margin: 2vw 0 0 0;
        font-size: 4vw;
        color: #863860;
      }
    }
  }
  // 地址簿
  .address-list{
    ul{
      width: 70vw;
      height: 33vw;
      overflow: scroll;
      li{
        width: 100%;
        height: 15vw;
        margin:0 0 2vw 0;
        display: flex;
        align-items: center;
        background-color:#FCF2FA;
        .content{
          width: 65%;
          margin:0 3vw 0 0 ;
          text-align: left;
          div{
            span{
              &:nth-of-type(1){
                margin:0 0 0 3vw;
                font-size: 3.47vw;
                color: #434343;
              }
              &:nth-of-type(2){
                margin:0 0 0 1vw;
                font-size: 2.67vw;
                color: #8A8A8A;
              }
            }
          }
          &>span{
            margin:1vw 0 0 3vw;
            font-size: 2.67vw;
            color: #363636;
            /* 关键代码 ！！！！ 以下5行 */
            overflow: hidden;
            /* 超出部分设为... */
            text-overflow: ellipsis;
            /* 盒子模型 */
            display: -webkit-box;
            /* 最多2行文本 多余部分隐藏*/
            -webkit-line-clamp: 1;
            /* 从顶部向底部垂直布置子元素 */
            -webkit-box-orient: vertical;
          }
        } 
        .btn-check-address{
          width: 19.23vw;
          height: 6.5vw;
          font-size: 2.79vw;
          color: #FFFFFF;
          background-image: imgUrl("bg-check-address.png");
        }
      }
    }
    .no-address{
      width: 70vw;
      height: 33vw;
      font-size: 5vw;
    }
    .create-address{
      @include commonBtn;
      margin:2vw 0 0 0;
    }
  }
  // 新建/修改地址
  .update-address{
    margin:2.5vw 0 0 0;
    div{
      &:not(:nth-of-type(4)){
        display: flex;
        align-items: center;
        margin: 0 0 2vw 0;
        font-size: 3.45vw;
        color: #474747;
      }
      /deep/ .van-cell{
        background-color: #F3DBEE;
        margin:0 0 0 2vw;
        padding: 0 0 0 2vw;
        .van-cell__value{
          width: 100%;
          height: 100%;
        }
      }
      &.name{
        margin-top: 2vw ;
      }
      &.name,
      &.phone{
        /deep/ .van-cell{
          width: 39.19vw;
          height: 6.53vw;
        }
      }
      &.phone{
        /deep/ .van-cell{
        }
      }
      &.address{
        /deep/ .van-cell{
          width: 39.2vw;
          height: 21.87vw;
        }
      }
      &:nth-of-type(4){
        @include commonBtn;
        margin:2vw 0 0 0;
      }
    }
  }
  // 高级盲盒开启成功
  .open-high{
    margin: 2vw 0 0 0;
    span{
      font-size: 4.54vw;
      color: #5A5A5A;
    }
    .gift{
      width: 25vw;
      height: 25vw;
      margin: 3vw 0 0 0;
      background-image: imgUrl("bg-script-gift.png");
    }
    .msg-container{
      width: 84%;
      margin:4.4vw 0 0 0;
      padding-top: 2.8vw;
      border-top: 0.1vw solid rgba($color: #EC82B2, $alpha: 0.2);
      // 一行字
      &>span{
        width: 95%;
        text-align: left;
        font-size: 3.73vw;
        color: #863860;
      }
      // 填信息的 + 地址簿
      &>div{
        display: flex;
        margin: 6vw 0 0 4vw;
        // 填信息的
        div{
          flex-shrink: 0;
          div{
            &:not(:nth-of-type(4)){
              display: flex;
              align-items: center;
              margin: 0 0 2vw 0;
              /deep/ .van-cell{
                margin: 0 0 0 2vw;
                padding: 0 0 0 2vw;
              }
            }
            span{
              color: #474747;
              font-size: 3.45vw;
            }
            &.name,
            &.phone{
              /deep/ .van-cell{
                width: 39.19vw;
                height: 6.53vw;
                background: #F3DBEE;
              }
            }
            &.phone{

            }
            &.address{
              /deep/ .van-cell{
                width: 39.2vw;
                height: 15.87vw;
                background: #F3DBEE;
              }
            }
          }
        }
        // 地址簿
        &>span{
          width: 17.5vw;
          display: block;
          color: #3C76F8;
          font-size: 3.45vw;
          flex-shrink: 0;
        }
      }
      
    }
    .btn-submit{
      @include commonBtn;
      margin:3vw 0 0 0;
    }
  }
  // 奖励预览
  .preview{
    padding-top: 6vw;
    div{
      width: 50vw;
      height: 11.5vw;
      margin: 0 0 3vw 0;
      font-size: 4.68vw;
      color: #FFFFFF;
      background-image:imgUrl("bg-btn.png");
    }
  }
  // 分享海报
  .share-post{
    width: 100%;
    position: relative;
    &.single-code{
      .text{
        margin: 107vw 0 10vw 0;
      }
      .code2{
        display: none;
      }
      &>span{
        &:nth-of-type(1){
          margin: 128vw 0 0 0 ;
        }
      }
    }
    img{
      width:100%;
      // height: 183vw;
      // position: absolute;
      top: 0;
      left: 0;
      pointer-events:none;
    }
    .text{
      width: 79%;
      height:16vw;
      position: absolute;
      top: 0;
      margin:107vw 0 0 1vw;
      font-size: 5vw;
      line-height: 6vw;
      color: #000000;
      text-align: justify;
      z-index: 2;
    }
    .code-group{
      width:75vw;
      position: absolute;
      top: 0;
      display: flex;
      justify-content: space-around;
      margin:133vw 0 3vw 0;
      z-index: 2;
      div{
        width: 27.96vw;
        height: 28vw;
        position: relative;
        background: #FB6E8E;
        .save{
          width: 24vw;
          height: 24vw;
          display: block;
        }
        .tag{
            position: absolute;
            top: -5vw;
            font-size: 3.5vw;
        }
        &.code1{
          .downloadGame{
            width: 24vw !important;
            height: 24vw !important;
          }
        }
        &.code2{
          .shareActivity{
              width: 24vw !important;
              height: 24vw !important;
          }
        }
      }
    }
    &>span{
      position: absolute;
      top: 0;
      margin: 166vw 0 0 0 ;
      font-size: 4vw;
      z-index: 2;
    }
  }
  // 选择登录方式
  .choose-login-way{
    .btn-group{
      display: flex;
      margin: 5vw 0 0 0;
      color: #FCB2DB;
      font-size: 4vw;
      div{
        margin: 0 4vw;
        span{
          &:nth-of-type(1){
            width: 20vw;
            height: 20vw;
            display: block;
            margin: 0 0 2vw 0;
          }
        }
        .phone{
          background-image: imgUrl("btn-phone-login.png");
        } 
        .account{
          background-image: imgUrl("btn-account-login.png");
        }
      }
    }
  }
  // 手机登录1
  .phone-login1,
  .phone-login2,
  .account-login{
    margin:4vw 0 0 0;
    // 输入框placeholder字体颜色
    input::-webkit-input-placeholder {
      /* WebKit browsers */
      color: #fff;
    }
    input:-moz-placeholder {
      /* Mozilla Firefox 4 to 18 */
      color: #fff;
    }
    input::-moz-placeholder {
      /* Mozilla Firefox 19+ */
      color: #fff;
    }
    input:-ms-input-placeholder {
      /* Internet Explorer 10+ */
      color: #fff;
    }
    input{
      width: 58vw;
      height: 9vw;
      padding: 0 0 0 2vw;
      margin: 0 0 2vw 0;
      background: #EC82B2;
      font-size: 4vw;
      color: #fff;
      border: 0.01vw solid #EEF7FF;
    }
    // & > div{
    //   width: 100%;
    //   height: 100%;
    //   display: flex;
    //   flex-direction: column;
    //   align-items: center;
    // }
    .codeGroup{
      display: flex;
      .phoneCode{
          width: 37vw;
          border-right: none;
        }
      .getCode{
        width: 21vw;
        height: 9vw;
        font-size:3vw;
        color: #FFFFFF;
        background-color:#f3abcc;
        border: 0.01vw solid #EEF7FF;
        border-left: none;
      }
    }
    span{
      margin: 0 1vw 0 0;
      align-self: flex-end;
      font-size: 3.5vw;
      color: #f3abcc;
    }
    .btn_group{
      width: 100%;
      display: flex;
      justify-content: space-around;
      margin:2vw 0 0  0;
      div{
        width: 23.6vw;
        height: 10vw;
        color: #FFFFFF;
        font-size: 4vw;
        &:nth-of-type(1){
          background-image: imgUrl("btn-confirm.png");
        }
        &:nth-of-type(2){
          background-image: imgUrl("btn-cancel.png");
        }
      }
    }
  }
  // 绑定角色
  .bind-role{
    margin: 4vw 0 0 0;
    & > div{
      width: 70%;
      display: flex;
      align-items: center;
      b{
        width: 40%;
        color: #EC82B2;
        text-align: left;
        font-size: 4vw;
      }
      div{
        width: 75vw;
        height: 8.5vw;
        padding:0 0 0 2vw;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        font-size: 4vw;
        color: #fff;
        background: #EC82B2;
        border: 0.01vw solid #EEF7FF;
        span{
          width: 3.2vw;
          height: 1.6vw;
          position:absolute;
          right: 1.2vw;
          display: block;
          background-image: imgUrl("arrow.png");
        }
      }
      &:nth-of-type(1),
      &:nth-of-type(2){
        margin: 2vw 0 0 0;
      }
      &:nth-of-type(2){
          span{
            display: none;
          }
      }
      &:nth-of-type(3){
        margin: 5vw 0 0 0;
        border:none;
        @include commonBtn;
      }
    }
  }
  //奖励展示1个 
  .preview-one,
  .preview-mid,
  .preview-more{
    font-size: 3.5vw;
    .gift{
      width: 23vw;
      height: 23vw;
      margin: 2vw  0;
      background-image: imgUrl("bg-script-gift.png");
      img{
        width: 80%;
      }
    }
    span{
      width:25vw;
      margin: -2vw 0 0 0;
    }
  }
  .preview-more{
    &>div{
      margin:0 2.5vw !important;
    }
    .gift{
      width: 20vw;
      height: 20vw;
      margin: 2vw 0;
      background-image: imgUrl("bg-script-gift.png");
    }
  }
   .preview-mid,
   .preview-more{
     display: flex;
     justify-content: space-between;
     flex-wrap: wrap;
     margin:0 0 0 3vw;
     &>div{
      margin: 0 1vw;
      flex-grow:1;
     }
   }
  // 公共弹框部分
  .common{
    width:100%;
    margin:11vw 0 10vw 0;
    span{
      max-width: 75%;
      font-size: 5.24vw;
      color: #EC82B2;
      line-height: 6vw;
      word-break:break-all;
    }
    .role-msg{
      font-size: 4vw;
      color: #565656;
      div{
        width: 62vw;
        height: 10vw;
        // padding:0 0 0 2vw;
        // justify-content: flex-start;
        background-color: #FCF2FA;
        &:nth-of-type(1){
          margin:-5vw 0 2vw 0;
        }
      }
    }
    .btn-single{
      width: 27.6vw;
      height: 8.5vw;
      margin:7vw 0 0 0;
      font-size: 4vw;
      color: #FFFFFF;
      background-image: imgUrl("bg-btn1.png");
    }
    .btn-group-common{
      width: 80%;
      display: flex;
      justify-content: space-around;
      margin:5vw 0 0 0 ;
      div{
        width: 23.6vw;
        height: 10vw;
        color: #FFFFFF;
        font-size: 4vw;
        &:nth-of-type(1){
          background-image: imgUrl("btn-cancel.png");
        }
        &:nth-of-type(2){
          background-image: imgUrl("btn-confirm.png");
        }
      }
    }
  }
  
}
</style>
