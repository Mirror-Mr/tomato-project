<template>
  <transition name="fade">
    <van-popup
      v-model="isShowMask"
      @close="closeMask"
      @closed="closedMask"
      @open="openMask"
      :lock-scroll="true"
      get-container="#app"
    >
      <div
        class="post"
        v-if="maskShow == 'sharePost1' || maskShow == 'sharePost2'"
        style="backgroundsize: 100%"
      >
        <img id="post" src="#" />
      </div>
      <div
        class="btn-close-post"
        v-if="maskShow == 'sharePost1' || maskShow == 'sharePost2'"
        @click="closeMask"
      ></div>
      <span class="tag-share" v-if="maskShow == 'sharePost2'">【海报需至少一人扫码进入活动才算分享成功哦~】</span>
      <div
        class="bg-maskBox"
        :class="[{ special: showCloseBtn }, `${maskShow}`]"
        ref="postContainer"
      >
        <!-- 关闭按钮 -->
        <div class="btn-close flexColumnCenter" v-if="showCloseBtn">
          <div @click="closeMask"></div>
          <div></div>
        </div>
        <!-- 不是所以弹框都有标题 -->
        <div
          class="title innerCenter"
          :class="{
            'long-title': maskShow == 'openNormal' || maskShow == 'openHigh',
          }"
          v-if="title"
        >
          {{ title }}
        </div>
        <slot />
        <div
          class="btn-close-btm flexColumnCenter"
          v-if="
            maskShow == 'script1' ||
            maskShow == 'script2' ||
            maskShow == 'script3'
          "
        >
          <div></div>
          <div @click="closeMask"></div>
        </div>
      </div>
    </van-popup>
  </transition>
</template>
<script>
// import html2canvas from "html2canvas";
import { mapState } from "vuex";
import html2canvas from "@/assets/js/html2canvas.js";
import clickLog from "@/api/toDots.js";
export default {
  name: "MasBox",
  components: {},
  props: {
    maskShow: {
      type: String,
      default: "",
    },
    title: {
      type: String,
      default: "",
    },
  },
  data() {
    return {
      // 控制弹框是否显示
      isShowMask: false,
    };
  },
  methods: {
    // 关闭弹框开始时
    closeMask() {
      // console.log("弹框关闭")
      let maskShow,
        maskTitle = "";
      if (this.maskShow == "lead") {
        // 如果关闭的是引导页 出现遮罩层 页面滚动到底部
        this.$emit("toLead");
        return;
      }
      if (this.maskShow == "allMask") {
        // 关闭的是只有获取碎片剧本按钮亮着的弹框
        this.$emit("cancelLead");
        if (!this.loginUserMsg.data) {
          maskShow = "chooseLoginWay";
          maskTitle = "选择登录方式";
        }
      }
      // 弹框的关闭是通过修改父组件的变量传值来控制的
      this.$emit("setIsMaskShow", maskShow);
      this.$emit("setMaskTitle", maskTitle);
    },
    // 关闭弹框完成后
    closedMask() {},
    // 打开弹框
    openMask() {
      const uid = this.loginUserMsg.code ? this.loginUserMsg.code : "";
      if (this.maskShow == "sharePost1") {
        clickLog({ type: 3, tag: this.fcode, uid });
        ta.track(
          "web_wbqj_xjds_sharepage2_click" //追踪事件的名称 - 【进入 分享页2 的人数】
        );
      }
      if (this.maskShow == "sharePost2") {
        clickLog({ type: 2, tag: this.fcode, uid });
        ta.track(
          "web_wbqj_xjds_sharepage1_click" //追踪事件的名称 - 【进入 分享页1 的人数】
        );
      }
    },
    // html转换为img图片
    htmlToimg() {
      let dom = document.getElementsByClassName("bg-maskBox")[0];
      // let scale = window.devicePixelRatio;
      let scale = 2;
      html2canvas(dom, {
        useCORS: true,
        allowTaint: false,
        height: dom.offsetHeight, //画布高度
        width: dom.offsetWidth, //画布宽度
        scrollX: 0,
        scrollY: 0,
        // 页面下拉时会导致生成的图片整体偏移
        // scrollX: -scrollX,
        // scrollY: -scrollY,
        dpi: window.devicePixelRatio,
        scale: scale,
        backgroundColor: null, //去掉白边
      }).then((canvas) => {
        canvas.toBlob((blob) => {
          var imgUrl = canvas.toDataURL("image/png", 1); // 获取生成的图片的url
          document.getElementById("post").src = imgUrl;
        });
      });

      // 方法2
      // let dom = document.getElementsByClassName("bg-maskBox")[0];
      // let width = dom.offsetWidth;
      // let height = dom.offsetHeight;
      // let canvas = document.createElement("canvas");
      // let scale = 2;
      // //画布实际宽度和高度
      // canvas.width = width * scale;
      // canvas.height = height * scale;
      // // 浏览器中被渲染的高度和宽度
      // canvas.style.width = width * scale + "px";
      // canvas.style.height = height * scale + "px";
      // canvas.getContext("2d");
      // let opts = {
      //   useCORS: true,
      //   backgroundColor: "transparent", //去掉白边
      //   scrollX: 0,
      //   scrollY: 0,
      //   scale: scale,
      //   canvas: canvas,
      //   dpi: window.devicePixelRatio,
      // };
      // html2canvas(dom, opts).then((canvas) => {
      //   canvas.toBlob((blob) => {
      //     var imgUrl = canvas.toDataURL("image/png", 1); // 获取生成的图片的url
      //     // let newImg = document.createElement("img");
      //     // newImg.src = imgUri;
      //     // this.$refs.post.append(newImg);
      //     document.getElementById("post").src = imgUrl;
      //   });
      // });
    },
    // 处理手指触屏的回调函数
    handler(e) {
      e.preventDefault();
    },
  },
  computed: {
    ...mapState(["loginUserMsg", "fcode"]),
    showCloseBtn() {
      let list = [
        "sharePost1",
        "sharePost2",
        "script1",
        "script2",
        "script3",
        "allMask",
        "jumpGameA",
        "jumpGameB"
      ];
      return !list.includes(this.maskShow);
    },
  },
  watch: {
    maskShow: {
      handler(newVal) {
        this.isShowMask = !!newVal;
        // console.log("isShowMask:",this.isShowMask)
      },
      // 初始化时立即执行
      immediate: true,
      // deep 深度监听 - 监听对象的对象属性变化
    },
  },
  mounted() {
    // console.log("mounted")
    this.$bus.$off(event).$on("htmlToimg", () => {
      // 生成海报
      this.htmlToimg();
    });
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.fade-enter-active, .fade-leave-active {
  transition: opacity .3s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
.van-popup{
  max-height: 90vh;
  overflow: scroll;
  background-color: transparent;
  .post{
    position: absolute;
    top: 0;
    left: 0;
    overflow: visible;
    z-index: 2000;
    img{
      border: none;
    }
    img[src="#"]{
      display: none ;
    }
  }
  .btn-close-post{
    width: 5.61vw;
    height: 5.61vw;
    position: absolute;
    top: 3vw;
    right: 3vw;
    background-image: imgUrl("btn-close.png");
    z-index: 2001;
  }
  .tag-share{
      width: 100%;
      margin:0 auto;
      position: absolute;
      top: 172vw;
      right: -1vw;
      font-size: 0.3rem;
      z-index: 2001;
  }
  .bg-maskBox{
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    &.special{
      margin: 11vw 0 0 0;
    }
    .btn-close{
      position: absolute;
      top:-10.5vw;
      div{
        &:nth-of-type(1){
          width: 5.61vw;
          height: 5.61vw;
          background-image: imgUrl("btn-close.png");
        } 
        &:nth-of-type(2){
          width: 0.6vw;
          height:6.67vw;
          background-color: #BF0088;
        }
      }
    }
    .btn-close-btm{
      height: 12.5vw;
      position: absolute;
      bottom:-8vw;
      div{
        &:nth-of-type(1){
          width: 0.6vw;
          height:6.67vw;
          background-color: #fff;
        } 
        &:nth-of-type(2){
          width: 5.61vw;
          height: 5.61vw;
          background-image: imgUrl("btn-close-btm.png");
          background-color: transparent;
        }
      }
    }
    
    .title{
      width: 36.27vw;
      height: 9.6vw;
      margin:7vw 0 0 0;
      font-size: 5.24vw;
      color: #FFFFFF;
      background-image: imgUrl("bg-title-rule.png");
      flex-shrink: 0;
      &.long-title{
        width: 70vw;
        height: 9vw;
        font-size: 4vw;
        background-image: imgUrl("bg-longtitle-rule.png");
      }
    }
    &.rule{
      width: 90vw;
      height: 148vw;
      background-image: imgUrl("bg-rule.png");
    }
    &.service,
    &.feedback,
    &.previewOne,
    &.jumpGameA,
    &.jumpGameB{
      width: 74.27vw;
      height: 58.81vw;
      background-image: imgUrl("bg-service.png");
    }
    &.submitSuccess,
    &.noChip,
    &.confirmPayChip,
    &.confirmRoleGetGift-script,
    &.confirmRoleGetGift-box,
    &.confirmRoleGetGift-gift,
    &.gameDownload,
    &.tagHighBox,
    &.saveAddr,
    &.noBox{
      width: 74.24vw;
      min-height: 45.85vw;
      background-image:imgUrl("bg-submit-success.png");
      background-size: 100% 100%;
    }
    &.giftRecord,
    &.giftRecordTop{
      width: 87vw;
      height: 56vw;
      background-image: imgUrl("bg-gift-record.png");
    }
    &.probably,
    &.winnerList,
    &.lead{
      width: 82.27vw;
      height: 90.9vw;
      background-image: imgUrl("bg-previewMore.png");
    }
    &.openNormal{
      width: 80vw;
      height: 75vw;
      background-image: imgUrl("bg-openNormal.png");
    }
    &.addressList,
    &.addressList1,
    &.chooseLoginWay,
    &.phoneLogin1,
    &.phoneLogin2,
    &.accountLogin,
    &.showRoleMsg{
      width: 84.27vw;
      height: 66vw;
      background-image: imgUrl("bg-service.png");

    }
    &.updateAddress,
    &.addAddress{
      width: 80vw;
      height: 80vw;
      background-image: imgUrl("bg-update-address.png");
    }
    &.openHigh{
      width: 80vw;
      height: 129vw;
      background-image:imgUrl("bg-openHigh.png");
    }
    &.preview{
      width: 80vw;
      height: 93vw;
      background-image:imgUrl("bg-preview.png")
    }
    &.sharePost1,
    &.sharePost2{
      width:90vw;
      height: 183vw;
      // background-image: imgUrl("share-post.png");
    }
    &.script1,
    &.script2,
    &.script3{
      width: 101vw;
      height: 180vw;
      &.script1{
        background-image: imgUrl("script1.png");
      }
      &.script2{
        background-image: imgUrl("script2.png");
      }
      &.script3{
        background-image: imgUrl("script3.png");
      }
    }
    &.bindRole{
      width: 90vw;
      height: 71vw;
      background-image: imgUrl("bg-service.png");
    }
    &.previewMid{
      width: 97vw;
      height: 90vw;
      background-image: imgUrl("bg-previewMid.png");
    }
    &.previewMore{
      width: 99vw;
      height: 110vw;
      background-image: imgUrl("bg-previewMore.png");
    }
    
  }
}
</style>
