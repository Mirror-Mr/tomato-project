import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    // 登录用户信息
    loginUserMsg:{},
    // 当前用户的角色列表信息
    roleList:[],
    // 绑定的角色信息
    roleMsg:{},
    // 邀请码
    fcode:"",
    // 未领取的高级盲盒奖励
    highBoxGift:{},
    
  },
  getters:{
    GET_lOGINUSERMSG:state=>state.loginUserMsg,
    GET_ROLELIST:state=>state.roleList,
    GET_ROLEMSG:state=>state.roleMsg,
    GET_FCODE:state=>state.fcode,
    GET_HIGHBOXGIFT:state=>state.highBoxGift,
  },
  mutations: {
    // 设置登录用户信息
    SET_lOGINUSERMSG(state,loginUserMsg){
      state.loginUserMsg = Object.keys(loginUserMsg).length == 0?{}:Object.assign({},state.loginUserMsg,loginUserMsg);
    },
    // 设置当前用户的角色列表信息
    SET_ROLELIST(state,roleList){
      state.roleList = roleList;
    },
    // 设置绑定的角色信息
    SET_ROLEMSG(state,roleMsg){
      state.roleMsg = {...roleMsg};
    },
    // 设置邀请码
    SET_FCODE(state,fcode){
      state.fcode = fcode;
    },
    // 设置未领取的高级盲盒奖励
    SET_HIGHBOXGIFT(state,highBoxGift){
      state.highBoxGift = {...highBoxGift};
    },
  },
  actions: {},
  modules: {},
});
