<template>
  <div class="page4">
    <div class="prize-group flexColumnCenter">
      <div class="no-friend innerCenter" v-if="prizeList.length == 0">
        暂未邀请好友
      </div>
      <div class="prize-item" v-for="item in prizeList" :key="item.id">
        <div class="content">
          <div class="top">
            {{ item.role_name }} - {{ item.server_name["zh-ch"] }}
          </div>
          <div class="btm">剧情通关进度 （{{ item.role_bmap }}/9）</div>
        </div>
        <div class="btn-get innerCenter" @click="toShare">喊TA通关</div>
      </div>
    </div>
    <MaskBox :maskShow="maskShow" @setIsMaskShow="setIsMaskShow">
      <ContentMask :maskShow="maskShow" @setIsMaskShow="setIsMaskShow" />
    </MaskBox>
  </div>
</template>
<script>
import { mapState } from "vuex";
import { get_user_info } from "@/api";
export default {
  name: "Page4",
  components: {
    MaskBox: (resolve) => require(["@/components/MaskBox.vue"], resolve),
    ContentMask: (resolve) =>
      require(["@/components/ContentMask.vue"], resolve),
  },
  data() {
    return {
      time: Date.now(),
      // 当前显示的是哪个弹框 ""则不显示弹框
      maskShow: "",
      timer: null,
      // 请求是否回来了
      responseDone: true,
    };
  },
  methods: {
    // 展示弹框
    showMask(n) {
      this.setIsMaskShow(n);
    },
    // 设置弹框是否展示
    setIsMaskShow(n) {
      this.maskShow = n;
    },
    // 喊他通关
    async toShare() {
      this.setIsMaskShow("sharePost1");
      // 生成二维码
      await this.$nextTick(() => {
        this.$bus.$emit("createQRcode",2);
      });
      // 生成海报
      this.$nextTick(() => {
        this.$bus.$emit("htmlToimg");
      });
    },
    // 获取用户信息
    get_user_info() {
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const { token, uid  } = this.loginUserMsg;
      get_user_info({ time, token,uid }, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          this.$store.commit("SET_lOGINUSERMSG", res.data);
          // if(res.data.info.rid){
          // 登录用户曾经绑定过角色 则直接绑定
          // }
        } else {
          let errMsg =
            res.status == 4040 ? "登录过期，请重新登录" : "获取用户信息失败";
          this.$toast.fail(errMsg);
          res.status == 4040 ? this.logOut() : "";
        }
      });
    },
    // 注销
    logOut() {
      this.$store.commit("SET_lOGINUSERMSG", {});
      localStorage.removeItem("loginUserMsg");
      this.$store.commit("SET_FCODE", "");
    },
  },
  computed: {
    ...mapState(["loginUserMsg"]),
    prizeList() {
      return this.loginUserMsg.data && this.loginUserMsg.data.friend_process
        ? this.loginUserMsg.data.friend_process.slice(0, 10)
        : [];
    },
  },
  mounted() {
    const { token } = this.loginUserMsg;
    if (token) {
      this.timer = setInterval(() => {
        this.get_user_info();
      }, 2000);
    }
  },
  destroyed() {
    clearInterval(this.timer);
  },
  watch: {
    maskShow: {
      handler(newVal) {
        if (newVal) {
          document
            .getElementsByTagName("body")[0]
            .addEventListener("touchmove", this.handler, { passive: true });
        } else {
          document
            .getElementsByTagName("body")[0]
            .removeEventListener("touchmove", this.handler, { passive: true });
        }
      },
      // 初始化时立即执行
      immediate: true,
    },
  },
};
</script>
<style lang="scss" scoped>
.page4{
  width: 100%;
  height: 216.5vw;
  padding:1vw 0 0 0;
  background-image: imgUrl("bg-page4.png");
  .prize-group {
    height: 137vw;
    margin: 34vw 0 0 0;
    overflow: scroll;
    .no-friend{
      height: 130vw;
      margin: 3vw 0 0 0;
      font-size: 6vw;
    }
    .prize-item{
      width: 79.6vw;
      height: 11.47vw;
      margin: 0 0 2vw 0;
      padding-left: 2vw;
      display: flex;
      align-items: center;
      background: #FCF2FA;
      &:nth-of-type(1){
        margin-bottom: 2vw;
      }
      .content{
        width: 54.4vw;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        margin:0 4.5vw 0 0;
        text-align: left;
        .top{
          padding:0 0 0.9vw 0;
          font-size: 3.39vw;
          color: #8467D9;
          border-bottom:0.13vw dashed #949494;
        }
        .btm{
          padding:0.9vw 0 0 0;
          font-size: 2.3vw;
          color: #949494;
        }
      }
      .btn-get{
        width: 15.85vw;
        height:6.9vw;
        font-size: 2.9vw;
        color: #FFFFFF;
        background-image: imgUrl("btn-get.png");
      }
    }
  }
  
}
</style>
