<template>
  <transition name="toPage" @after-leave="afterLeave">
    <div class="enter flexColumnCenter" v-show="run">
      <div class="enter-star-group"></div>
      <div class="enter-gift"></div>
      <div class="enter-ring"></div>
      <div class="enter-star"></div>
      <div class="btn-enterPage1" @click="changePage"></div>
    </div>
  </transition>
</template>
<script>
import { getQueryValue } from "@/utils/getQueryValue";
import { share } from "@/api";
import clickLog from "@/api/toDots.js";
import { mapState } from "vuex";
export default {
  name: "Enter",
  data() {
    return {
      time: Date.now(),
      run: true,
    };
  },
  methods: {
    changePage() {
      //   this.$router.push("/unlock");
      this.run = false;
    },
    // transition动效结束触发
    afterLeave() {
      this.$router.push({ name: "Page1", params: { flag: 1 } });
    },
  },
  mounted() {
    // 判断链接上是否有携带分享者的fcode 一定不是游戏内进入
    const fcode = getQueryValue("fcode");
    // 判断是否是通过分享页进来的
    const type = getQueryValue("type");
    // 游戏内进入
    const xyid = getQueryValue("xyId");
    const channel = getQueryValue("pt");
    const rid = getQueryValue("roleId");
    if (!!type) {
      const uid = this.loginUserMsg.code ? this.loginUserMsg.code : "";
      clickLog({ type: 4, tag: this.fcode, uid });
      ta.track(
      "web_wbqj_xjds_frompage2_enterh5" //追踪事件的名称 - 【扫描了分享页1-二维码2进入页面】
    );
    }
    if (!!fcode) {
      // 存储fcode
      this.$store.commit("SET_FCODE", fcode);
      // sessionStorage.setItem("store", JSON.stringify(this.$store.state));
      // 存在则激活分享
      const { time } = this;
      share({ time, fcode }, { time, fcode }).then((res) => {
        if (res.status == 1) {
          this.$toast.success("激活分享成功");
          // 删除url上的参数fcode
          // location.href = location.href.split("?")[0];
          // 更新url 但不刷新页面 适配浏览器
          // history.replaceState({}, "", location.href.split("?")[0]);
        } else {
          this.$toast.fail("激活分享失败");
        }
      });
    }
    if (xyid) {
      // 携带快速登录参数 则 将快速登录所需参数保存到sessionStorage内 并 删除链接中参数
      sessionStorage.setItem("xyLogin", JSON.stringify({ xyid, channel, rid }));
      // location.href = location.href.split("?")[0];
      // 更新url 但不刷新页面 适配浏览器
      // history.replaceState({}, "", location.href.split("?")[0]);
    }
    // 更新url 但不刷新页面 适配浏览器
    history.replaceState({}, "", location.href.split("?")[0]);
  },
  computed: {
    ...mapState(["fcode", "loginUserMsg"]),
  },
};
</script>
<style scoped lang='scss'>
.toPage-enter-active, .toPage-leave-active {
  transition: opacity 1s;
}
.toPage-enter, .toPage-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
.enter{
    width: 100%;
    height:216.5vw;
    position: relative;
    background-image: imgUrl("bg-enter.png");
    &.run{
        animation: run-changePage 2s linear;
    }
    .enter-star-group{
        width: 100%;
        height: 100vw;
        position: absolute;
        top: 0;
        background-image: imgUrl("enter-star-group.png");
        animation: run-star 1s linear infinite;
        animation-delay: 1s;
        animation-direction: alternate;
    }
    .enter-gift{
        width: 75%;
        height:69vw;
        position: absolute;
        top:47vw;
        background-image: imgUrl("enter-gift.png");
        z-index: 2;
        animation: run-gift 1s linear infinite;
        animation-direction: alternate;
    }
    @keyframes run-gift {
        0%{
            top:47vw;
        }
        100%{
            top:49vw;
        }
    }
    .enter-ring{
        width:95%;
        height: 63vw;
        position:absolute;
        top: 56vw;
        transform: translateX(1vw) rotateZ(-16deg);
        background-image: imgUrl("enter-ring.png");
        z-index:1;
    }
    .enter-star{
        width:83%;
        height: 63vw;
        position:absolute;
        top: 52vw;
        background-image: imgUrl("enter-star.png");
        z-index:1;
        animation: run-star 1s linear infinite;
        animation-direction: alternate;
    }
    @keyframes run-star {
        0%{
            opacity: 0;
        }
        100%{
            opacity: 1;
        }
    }
    .btn-enterPage1{
        width: 65vw;
        height: 14vw;
        margin: 125vw 0 0 0;
        background-image: imgUrl("btn-enterPage1.png");
    }
}
@keyframes run-changePage{
    0%{
        opacity: 1;
    }   
    100%{
        opacity: 0;
    }
}
</style>