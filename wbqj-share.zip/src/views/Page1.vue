<template>
  <div class="page1" :class="{ run: run }">
    <!-- 标题描述 -->
    <div class="desc-title innerCenter">
      时装10连抽、京东卡、游戏周边等你来拿
    </div>
    <!-- 侧边栏 -->
    <div class="slide-bar">
      <div
        class="innerCenter rule"
        @click="
          setIsMaskShow('rule');
          setMaskTitle('活动规则');
        "
      >
        查看规则
      </div>
      <div
        class="innerCenter service"
        @click="
          setIsMaskShow('service');
          setMaskTitle('客服中心');
        "
      >
        客服中心
      </div>
    </div>
    <!-- 女主 -->
    <!-- <div class="queen"></div> -->
    <!-- 三个剧本 -->
    <div class="script-group">
      <div class="script achieve" v-for="item in scriptMsg" :key="item.id">
        <!-- 可领取剧本时展示 -->
        <div
          class="fly"
          v-if="
            loginUserMsg.num &&
            loginUserMsg.num.snum >= item.limit &&
            (!loginUserMsg.prize['1'] || !loginUserMsg.prize['1'][item.id])
          "
        ></div>
        <div
          class="tag-achieve"
          v-if="
            loginUserMsg.prize &&
            loginUserMsg.prize['1'] &&
            !!loginUserMsg.prize['1'][item.id]
          "
        ></div>
        <div class="script-title innerCenter">{{ item.title }}</div>
        <!-- 剧本奖励 -->
        <div class="script-gift">
          <div v-for="(gift, index) in item.gift" :key="index">
            <div @click="showPreview(index, item.id)" class="innerCenter">
              <div :class="`gift${item.id}_${index + 1}`"></div>
            </div>
            <span>{{ gift }}</span>
          </div>
        </div>
        <!-- 限领 -->
        <div class="limit innerCenter">
          <span>
            剧情碎片 {{ loginUserMsg.num ? loginUserMsg.num.snum : 0 }}/{{ item.limit }}
          </span>
          <span @click="getScript(item)">解锁</span>
        </div>
      </div>
    </div>
    <!-- 两个按钮 -->
    <div class="btn-group">
      <div
        class="btn1 btn"
        :class="{ lead: lead }"
        @click="
          $router.push({
            name: 'Page3',
            params: { lead: loginUserMsg.data ? false : true },
          })
        "
      >
        获取剧本碎片
      </div>
      <div class="btn2 btn">
        <span class="tag" v-if="!loginUserMsg.is_first_share"
          >—— 分享奖励X3 ——</span
        >
        <span class="real-btn" @click="toShare(loginUserMsg.is_first_share)">{{
          loginUserMsg.is_first_share ? "分享" : "首次分享"
        }}</span>
      </div>
    </div>
    <!-- 登录提示 -->
    <div class="login-msg innerCenter">
      <div
        class="no-login"
        v-if="Object.keys(loginUserMsg).length == 0 || !loginUserMsg.info"
      >
        欢迎您，请
        <span
          class="red"
          @click="
            setIsMaskShow('chooseLoginWay');
            setMaskTitle('选择登录方式');
          "
          v-if="Object.keys(loginUserMsg).length == 0"
          >【登录】</span
        >
        <div v-else class="no-bind">
          <span class="red" @click="changeRole(0)">【绑定角色】</span>
          <span @click="logOut">【注销】 </span>
        </div>
      </div>
      <div class="logined" v-else>
        欢迎您，{{ loginUserMsg.info.sname }} -
        {{ loginUserMsg.info.rname }}
        <br />
        <span @click="showIdMsg">【查看ID信息】 </span>
        <span @click="changeRole(1)" v-if="!xyLogin">【切换角色】 </span>
        <span @click="logOut" v-if="!xyLogin">【注销】 </span>
      </div>
    </div>
    <MaskBox
      :maskShow="maskShow"
      @setIsMaskShow="setIsMaskShow"
      @setMaskTitle="setMaskTitle"
      :title="maskTitle"
      @toLead="toLead"
      @cancelLead="cancelLead"
    >
      <ContentMask
        ref="contentMask"
        :maskShow="maskShow"
        @setIsMaskShow="setIsMaskShow"
        @setMaskTitle="setMaskTitle"
        @setIsMaskShow_btm="setIsMaskShow_btm"
        @get_user_info="get_user_info"
      />
    </MaskBox>
    <MaskBoxBtm
      :maskShow_btm="maskShow_btm"
      @setIsMaskShow_btm="setIsMaskShow_btm"
    >
    </MaskBoxBtm>
  </div>
</template>

<script>
// import MaskBox from "@/components/MaskBox.vue";
import { xy_login, get_user_info, get_role_lists } from "@/api";
import clickLog from "@/api/toDots.js";
import { getQueryValue, getAllQueryValue } from "@/utils/getQueryValue";
import { urlDelParams } from "@/utils/urlDelParams.js";
import { mapState } from "vuex";
export default {
  name: "Page1",
  components: {
    MaskBox: (resolve) => require(["@/components/MaskBox.vue"], resolve),
    MaskBoxBtm: (resolve) => require(["@/components/MaskBox_btm.vue"], resolve),
    ContentMask: (resolve) =>
      require(["@/components/ContentMask.vue"], resolve),
  },
  data() {
    return {
      time: Date.now(),
      lead: false,
      // 请求是否回来了
      responseDone: true,
      // 三个剧本
      scriptMsg: [
        {
          id: 1,
          title: "言情甜宠剧",
          gift: ["言情甜宠礼包", "高级盲盒*1"],
          limit: 10,
        },
        {
          id: 2,
          title: "狗血苦情剧",
          gift: ["狗血苦情礼包", "高级盲盒*3"],
          limit: 20,
        },
        {
          id: 3,
          title: "沙雕情景剧",
          gift: ["沙雕情景礼包", "高级盲盒*3"],
          limit: 30,
        },
      ],
      // 当前显示的是哪个弹框 ""则不显示弹框
      maskShow: "",
      // 弹框标题
      maskTitle: "",

      // 底部弹框显示哪个 ""则不显示弹框
      maskShow_btm: "",
      run: false,
      // 快捷登录所需参数
      xyLogin: JSON.parse(sessionStorage.getItem("xyLogin")),
    };
  },
  methods: {
    // 展示弹框
    showMask(n) {
      this.setIsMaskShow(n);
    },
    // 设置弹框是否展示
    setIsMaskShow(n) {
      this.maskShow = n;
    },
    // 设置底部弹框是否显示
    setIsMaskShow_btm(n) {
      this.maskShow_btm = n;
    },

    // 解锁剧本获得奖励
    getScript(script) {
      // this.setIsMaskShow(`script1`);
      // return;
      const { num, prize } = this.loginUserMsg;
      if (!num) {
        this.setIsMaskShow("chooseLoginWay");
        this.setMaskTitle("选择登录方式");
        this.$toast.fail("请先登录");
        return;
      }
      if (prize["1"] && prize["1"][script.id]) {
        this.$toast("该剧本已解锁");
        this.setIsMaskShow(`script${script.id}`);
        return;
      }
      // 判断碎片够不够
      if (num.snum < script.limit) {
        // if (num.snum > script.limit) {
        // 不够
        this.setIsMaskShow("noChip");
        this.$nextTick(() => {
          this.$bus.$emit("setCommonMaskMsg", [
            `您的碎片不足，快去获取碎片解锁剧本吧！`,
            "好的",
            "",
          ]);
        });
      } else {
        // 够 确认
        this.setIsMaskShow("confirmPayChip");
        this.$nextTick(() => {
          this.$bus.$emit("confirmBtn", ["tocConfirmPayChip", script]);
        });
      }
    },

    // 设置弹框标题
    setMaskTitle(title) {
      this.maskTitle = title;
    },

    // 分享
    async toShare(n) {
      !n
        ? ta.track(
            "web_wbqj_xjds_first_share_click" //追踪事件的名称 - 【首次分享按钮点击】
          )
        : "";
      this.setIsMaskShow("sharePost2");
      // 生成二维码
      await this.$nextTick(() => {
        this.$bus.$emit("createQRcode", 1);
      });
      // 生成海报
      this.$nextTick(() => {
        this.$bus.$emit("htmlToimg");
      });
    },
    // 展示大礼包有啥
    showPreview(index, id) {
      if (index) return;
      // this.setIsMaskShow("previewOne");
      this.setIsMaskShow("previewMid");
      this.$nextTick(() => {
        this.$bus.$emit("setPreviewMidId", id);
      });
      // this.setIsMaskShow("previewMore");
      this.setMaskTitle("奖励预览");
    },
    // 展示id信息
    showIdMsg() {
      this.setIsMaskShow("showRoleMsg");
      this.$nextTick(() => {
        this.$bus.$emit("setCommonMaskMsg", ["", "确认", ""]);
      });
      this.setMaskTitle("ID信息");
    },
    // 切换/绑定角色
    changeRole(n) {
      this.setIsMaskShow("bindRole");
      this.getRoleList();
      const title = n ? "切换角色" : "绑定角色";
      this.setMaskTitle(title);
      if (n) {
        this.$nextTick(() => {
          this.$bus.$emit("showNowRole");
        });
      } else {
      }
    },
    // 获取用户信息
    get_user_info() {
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const { token, uid } = this.loginUserMsg;
      get_user_info({ time, token, uid }, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          this.$store.commit("SET_lOGINUSERMSG", res.data);
          // if(res.data.info.rid){
          // 登录用户曾经绑定过角色 则直接绑定
          // }
        } else {
          let errMsg =
            res.status == 4040 ? "登录过期，请重新登录" : "获取用户信息失败";
          this.$toast.fail(errMsg);
          res.status == 4040 ? this.logOut() : "";
        }
      });
    },
    // 获取角色列表
    getRoleList() {
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const {
        token,
        info: { uid },
      } = this.loginUserMsg;
      get_role_lists({ time, token, uid }, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          this.$store.commit("SET_ROLELIST", res.data);
        } else {
          let errMsg =
            res.status == 4040
              ? "登录过期，请重新登录"
              : "获取角色列表信息失败！";
          this.$toast.fail(errMsg);
          res.status == 4040 ? this.logOut() : "";
        }
      });
    },
    // 注销
    logOut() {
      this.$store.commit("SET_lOGINUSERMSG", {});
      localStorage.removeItem("loginUserMsg");
      this.$store.commit("SET_FCODE", "");
    },
    // 快捷登录
    xy_login(xyid, channel, rid) {
      const { time } = this;
      const params = {
        time,
        xyid,
        channel,
        sid: 1,
        sname: 1,
        rolename: 1,
        rid,
      };
      xy_login(params, { time, xyid }).then((res) => {
        if (res.status == 1) {
          this.$toast.success("登录成功");
          this.$store.commit("SET_lOGINUSERMSG", res.data);
          this.get_user_info();
        } else {
          this.$toast.fail("登录失败");
        }
      });
    },
    // 去引导
    toLead() {
      this.$el
        .querySelector(".btn1")
        .scrollIntoView({ block: "start", behavior: "smooth" });
      const timer = setTimeout(() => {
        this.setIsMaskShow("allMask");
        this.setMaskTitle("");
        this.lead = true;
        clearTimeout(timer);
      }, 200);
    },
    // 取消引导按钮的高亮
    cancelLead() {
      this.lead = false;
    },
  },
  computed: {
    ...mapState(["loginUserMsg", "roleMsg", "fcode"]),
  },
  mounted() {
    this.run = this.$route.params.flag ? true : false;
    if (this.run) {
      // 从第一页来的 需要引导页
      this.setIsMaskShow("lead");
      this.setMaskTitle("活动引导");
      // 进入首页打点
      const uid = this.loginUserMsg.code ? this.loginUserMsg.code : "";
      clickLog({ type: 1, tag: this.fcode, uid });
    }
    // 判断链接上有参数 且 没有用户已经登陆 则是快捷登录
    if (this.xyLogin && Object.keys(this.loginUserMsg) == 0) {
      // if (this.xyLogin) {
      const { xyid, channel, rid } = this.xyLogin;
      // 快捷登录
      this.xy_login(xyid, channel, rid);
    } else {
      // 不是游戏进来的 则看是否已登录
      // console.log(Object.keys(this.loginUserMsg) == 0);
      if (!this.loginUserMsg.data) {
        // 没登录 则看localStorage中有无登陆过的用户信息
        const loginUserMsg = JSON.parse(localStorage.getItem("loginUserMsg"));
        if (loginUserMsg) {
          //localStorage中有存储的用户信息 则登录
          this.$store.commit("SET_lOGINUSERMSG", loginUserMsg);
          if (loginUserMsg.data) {
            // 已登录 且 已绑定角色
            this.get_user_info();
          }
        }
      }

      // 已登录 但未绑定角色 则获取角色列表
      // this.getRoleList();
    }
    this.$bus.$off(event).$on("get_user_info", () => {
      // console.log(1)
      // 设置公共弹框展示的内容
      this.get_user_info();
    });
  },
  watch: {
    maskShow: {
      handler(newVal) {
        // console.log('page1',newVal)
        if (newVal) {
          // console.log("停住")
          document
            .getElementsByTagName("body")[0]
            .addEventListener("touchmove", this.handler, { passive: true });
        } else {
          // console.log("动起来")
          document
            .getElementsByTagName("body")[0]
            .removeEventListener("touchmove", this.handler, { passive: true });
        }
      },
      // 初始化时立即执行
      immediate: true,
    },
  },
};
</script>
<style lang="scss" scoped>
.page1{
  width: 100%;
  height: 216vw;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-image: imgUrl("bg-page1.png");
  opacity: 1;
  &.run{
    // opacity: 0;
    animation:run-opacity 1s linear ;
    // animation-fill-mode: forwards;
  }
  @keyframes run-opacity {
    0%{
      opacity: 0;
    }
    100%{
      opacity: 1;
    }
  }
  .desc-title{
    width: 64.7vw;
    height: 7.1vw;
    margin: 34.9vw 0 0 0 ;
    font-size: 3.27vw;
    color: #FFFFFF;
    background-image: imgUrl("desc-title.png");
    flex-shrink: 0;
  }
  .slide-bar{
    height: 43vw;
    position: absolute;
    left: 0;
    top: 6vw;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    & > div{
      width: 6.07vw;
      height: 19.67vw;
      line-height: 4vw;
      font-size: 3.4vw;
      color: #FFFFFF;
      background-image: imgUrl("bg-slidebar.png");
    }
  }
  .queen{
    width: 70vw;
    height: 130vw;
    position: absolute;
    top: 100vw;
    left: 0;
    background-image: imgUrl("queen.png");
  }
  .script-group{
    width: 100%;
    height: 120vw;
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
    // padding: 0.1vw 0 0 0 ;
    // margin: -11vw 0 0 0;
    .script{
      width: 52.2vw;
      height: 34.71vw;
      position: relative;
      margin: 0 0 0 39vw;
      display: flex;
      flex-direction: column;
      flex-shrink: 0;
      background-image: imgUrl("bg-script.png");
      &:nth-of-type(1){
        margin-top:15vw;
      }
      &:nth-of-type(2){
        margin-top:-0.7vw ;
        margin-left:44vw ;
      }
      &:nth-of-type(3){
        margin-top:-0.7vw ;
        margin-left: 45.6vw;
      }
      &.achieve{
        .tag-achieve{
          opacity: 1;
        }
      }
      .fly{
        width: 14vw;
        height: 12vw;
        position: absolute;
        top: -2vw;
        right: 0vw;
        background-image: imgUrl("fly.png");
        animation: fly-run 1s linear infinite;
        animation-direction: alternate;
      }
      @keyframes fly-run {
        0%{
          top: -2vw;
        } 
        100%{
          top: -1vw;
        }
      }
      .tag-achieve{
        width:10vw;
        height: 10vw;
        position:absolute;
        top: 5vw;
        right: 6.5vw;
        background-image:imgUrl("tag-achieve.png");
        opacity: 0;
      }
      .script-title{
        width: 26.55vw;
        height: 6.43vw;
        margin: 6vw 0 0 11.5vw;
        font-size: 3.66vw;
        color: #FF6EA8;
        background-image: imgUrl("script-title.png");
      }
      .script-gift{
        width: 80%;
        display: flex;
        justify-content: space-around;
        margin: 2vw 0 0 5vw;
        & > div {
          div{
            width: 11.37vw;
            height: 11.19vw;
            background-image: imgUrl("bg-script-gift.png");
            .gift1_2,
            .gift2_2,
            .gift3_2{
              width: 13vw;
              height: 9vw;
              flex-shrink: 0;
              background-image: imgUrl("high-box.png");
            }
            .gift1_1{
              width: 11vw;
              height: 10vw;
              flex-shrink: 0;
              background-image: imgUrl("box1.png");
            }
             .gift2_1{
              width: 11vw;
              height: 10vw;
              flex-shrink: 0;
              background-image: imgUrl("box2.png");
            }
             .gift3_1{
              width: 11vw;
              height: 10vw;
              flex-shrink: 0;
              background-image: imgUrl("box3.png");
            }
          }
          span{
            display: block;
            margin: -1vw 0 0 0;
            font-size: 2.3vw;
            color: #080808;
          }
        }
      }
      .limit{
          width: 26vw;
          height: 4vw;  
          margin: 1.1vw 0 0 12.5vw;
          justify-content: space-around;
          background-image: imgUrl("bg-limit.png");
          span{
            font-size: 2.54vw;
            color: #EE4A6B;
          }
      }
    }
    
  }
  .btn-group{
    width: 95%;
    margin: 9vw 0 0 0;
    display: flex;
    justify-content: space-around;
    flex-shrink: 0;
    .btn{
        width: 40.5vw;
        height: 14vw;
        font-size: 4.82vw;
        color: #863860;
        line-height: 13.55vw;
      &.btn1{
        background-image: imgUrl("btn-getScriptChip.png");  
        &.lead{
          z-index: 20000;
          box-shadow: 0 0 2vw 2vw #fff;
        }
      }
      &.btn2{
        display: flex;
        justify-content: center;
        position: relative;
        background-image: imgUrl("btn-toShare.png");  
        span{
          width: 100%;
          &.tag{
            position: absolute;
            top: -10vw;
            left: 0;
            font-size: 3.18vw;
            color: #863860;
          }
          &.real-btn{
          }
        }
      }
    }
  }
  .login-msg{
    margin: 2vw 0 0 0;
    height: 10vw;
    .no-login{
      color: #000000;
      font-size: 4vw;
      .no-bind{
        display: inline;
      }
    }
    .logined{
      color: #000000;
      font-size: 4vw;
      line-height: 5vw;
    }
  }
  
}
</style>
