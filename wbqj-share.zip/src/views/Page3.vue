<template>
  <div class="page3 flexColumnCenter">
    <!-- 领取记录 -->
    <div class="btn-record-get" @click="showGiftRecord">奖励领取记录</div>
    <!-- 日常奖励领取 -->
    <div class="prize-group1 flexColumnCenter">
      <!-- 预览按钮 -->
      <div
        class="btn-preview"
        @click="
          setIsMaskShow('preview');
          setMaskTitle('奖励预览');
        "
      ></div>
      <div
        class="prize-item"
        v-for="item in prizeList.prizeGroup1"
        :key="item.id"
      >
        <div class="content">
          <div class="top">
            {{ item.name }}（{{
              item.id == 1
                ? loginUserMsg.is_login
                  ? 1
                  : 0
                : loginUserMsg.is_share
                ? 1
                : 0
            }}/{{ item.limit }}）
          </div>
          <div class="btm">
            <span v-for="(prize, index) in item.prize" :key="index">
              {{ prize }}
            </span>
          </div>
        </div>

        <div
          class="btn-get innerCenter"
          v-if="
            loginUserMsg.prize &&
            loginUserMsg.prize['2'] &&
            loginUserMsg.prize['2'][item.id]
          "
        >
          已领取
        </div>
        <div
          class="btn-get innerCenter"
          @click="getGift(1, item.id, item.done)"
          v-else
        >
          {{ item.done ? "领取" : "去完成" }}
        </div>
      </div>
    </div>
    <!-- 新用户邀请奖励 -->
    <div class="prize-group2 flexColumnCenter">
      <div
        class="prize-item"
        v-for="item in prizeList.prizeGroup2"
        :key="item.id"
      >
        <div class="content">
          <div class="top">{{ item.name }}</div>
          <div class="btm">
            <span v-for="(prize, index) in item.prize" :key="index">
              {{ prize }}
            </span>
          </div>
        </div>
        <div
          class="btn-get innerCenter"
          v-if="
            loginUserMsg.prize &&
            loginUserMsg.prize['3'] &&
            loginUserMsg.prize['3'][item.id]
          "
        >
          已领取
        </div>
        <div
          class="btn-get innerCenter"
          @click="getGift(2, item.id, friendPass(item.name.match(/\d+/g)[0], 2))"
          v-else
        >
          {{ friendPass(item.name.match(/\d+/g)[0], 2) ? "领取" : "去完成" }}
        </div>
      </div>
    </div>
    <!-- 邀请新用户通关奖励 -->
    <div class="prize-group3 flexColumnCenter">
      <div
        class="prize-item"
        v-for="item in prizeList.prizeGroup3"
        :key="item.id"
      >
        <div class="content">
          <div class="top">
            {{ item.name }}（{{
              getPassFriendNum(item.name.match(/\d+/g)[0], 0)
            }}/{{ item.limit }}）
            <span
              >剩余{{ getPassFriendNum(item.name.match(/\d+/g)[0], 1) }}次</span
            >
          </div>
          <div class="btm">
            <span v-for="(prize, index) in item.prize" :key="index">
              {{ prize }}
            </span>
          </div>
        </div>
        <div
          class="btn-get innerCenter"
          v-if="10 - getPassFriendNum(item.name, 1) == 10"
        >
          已领取
        </div>
        <div
          class="btn-get innerCenter"
          @click="getGift(3, item.id, !!getPassFriendNum(item.name, 0))"
          v-else
        >
          {{ getPassFriendNum(item.name, 0) ? "领取" : "去完成" }}
        </div>
      </div>
    </div>
    <!-- 个人成就奖励 -->
    <div class="prize-group4 flexColumnCenter">
      <div
        class="prize-item"
        v-for="item in prizeList.prizeGroup4"
        :key="item.id"
      >
        <div class="content">
          <div class="top">
            {{ item.name }}（{{ getPersonGiftNum(item.id) }}/{{ item.limit }}）
          </div>
          <div class="btm">
            <span v-for="(prize, index) in item.prize" :key="index">
              {{ prize }}
            </span>
          </div>
        </div>
        <div
          class="btn-get innerCenter"
          v-if="
            loginUserMsg.prize &&
            loginUserMsg.prize['5'] &&
            loginUserMsg.prize['5'][item.id]
          "
        >
          已领取
        </div>
        <div
          class="btn-get innerCenter"
          @click="getGift(4, item.id, item.done)"
          v-else
        >
          {{ item.done ? "领取" : "去完成" }}
        </div>
      </div>
    </div>
    <MaskBox
      :maskShow="maskShow"
      @setIsMaskShow="setIsMaskShow"
      @setMaskTitle="setMaskTitle"
      :title="maskTitle"
    >
      <ContentMask
        :maskShow="maskShow"
        @setIsMaskShow="setIsMaskShow"
        @setMaskTitle="setMaskTitle"
        @confirm="confirm"
        :giftRecordList="giftRecordList"
        @scrollTo="scrollTo"
        :previewList="previewList"
        :prizeList="prizeList"
        @setIsMaskShow_btm="setIsMaskShow_btm"
        @get_user_info="get_user_info"
      />
    </MaskBox>
    <MaskBoxBtm
      :maskShow_btm="maskShow_btm"
      @setIsMaskShow_btm="setIsMaskShow_btm"
    >
    </MaskBoxBtm>
  </div>
</template>

<script>
import { mapState } from "vuex";
import { get_user_info } from "@/api";
export default {
  name: "Page3",
  components: {
    MaskBox: (resolve) => require(["@/components/MaskBox.vue"], resolve),
    MaskBoxBtm: (resolve) => require(["@/components/MaskBox_btm.vue"], resolve),
    ContentMask: (resolve) =>
      require(["@/components/ContentMask.vue"], resolve),
  },
  data() {
    return {
      time: Date.now(),
      maskShow: "",
      timer: null,
      // 请求是否回来了
      responseDone: true,
      prizeList: {
        prizeGroup1: [
          {
            id: 1,
            name: "每日登录",
            limit: 1,
            prize: ["剧情碎片*1", "普通盲盒*1"],
            done: false,
          },
          {
            id: 2,
            name: "每日分享",
            limit: 1,
            prize: ["剧情碎片*1", "普通盲盒*1"],
            done: false,
          },
        ],
        prizeGroup2: [
          {
            id: 1,
            name: "成功邀请1人",
            limit: 1,
            prize: ["邀请1人礼包*1", "高级盲盒*1"],
          },
          {
            id: 2,
            name: "成功邀请3人",
            limit: 1,
            prize: ["邀请3人礼包*1"],
          },
          {
            id: 3,
            name: "成功邀请5人",
            limit: 1,
            prize: ["邀请5人礼包*1", "高级盲盒*2"],
          },
          {
            id: 4,
            name: "成功邀请7人",
            limit: 1,
            prize: ["邀请7人礼包*1"],
          },
          {
            id: 5,
            name: "成功邀请10人",
            limit: 1,
            prize: ["邀请10人礼包*1", "高级盲盒*3"],
          },
        ],
        prizeGroup3: [
          {
            id: 1,
            name: "好友通关第2章节剧情",
            limit: 1,
            prize: ["剧情碎片*1", "普通盲盒*1"],
          },
          {
            id: 2,
            name: "好友通关第5章节剧情",
            limit: 1,
            prize: ["剧情碎片*2", "普通盲盒*2"],
          },
          {
            id: 3,
            name: "好友通关第9章节剧情",
            limit: 1,
            prize: ["剧情碎片*2", "普通盲盒*2", "高级盲盒*1"],
          },
        ],
        prizeGroup4: [
          {
            id: 1,
            name: "通关第2章节剧情",
            limit: 1,
            prize: ["剧情碎片*1", "普通盲盒*1"],
            done: false,
          },
          {
            id: 2,
            name: "通关第5章节剧情",
            limit: 1,
            prize: ["剧情碎片*2", "普通盲盒*2"],
            done: false,
          },
          {
            id: 3,
            name: "通关第9章节剧情",
            limit: 1,
            prize: ["剧情碎片*5", "普通盲盒*5"],
            done: false,
          },
          {
            id: 4,
            name: "首次分享",
            limit: 1,
            prize: ["剧情碎片*3", "普通盲盒*3"],
            done: false,
          },
          {
            id: 5,
            name: "反馈有奖",
            limit: 1,
            prize: ["剧情碎片*1", "普通盲盒*1"],
            done: false,
          },
          {
            id: 6,
            name: "全部剧本解锁",
            limit: 3,
            prize: ["戏精大礼包"],
            done: false,
          },
        ],
      },
      maskTitle: "",
      // 奖励领取记录
      giftRecordList: [
        {
          time: `2021.10.01`,
          gift: `道具名`,
          num: `1`,
          content: `每日登录`,
        },
        {
          time: `2021.10.01`,
          gift: `道具名`,
          num: `1`,
          content: `每日登录`,
        },
        {
          time: `2021.10.01`,
          gift: `道具名`,
          num: `1`,
          content: `每日登录`,
        },
        {
          time: `2021.10.01`,
          gift: `道具名`,
          num: `1`,
          content: `每日登录`,
        },
        {
          time: `2021.10.01`,
          gift: `道具名`,
          num: `1`,
          content: `每日登录`,
        },
        {
          time: `2021.10.01`,
          gift: `道具名`,
          num: `1`,
          content: `每日登录`,
        },
      ],
      // 奖励预览种类
      previewList: [
        "日常奖励",
        "新用户邀请奖励",
        "邀请新用户通关奖励",
        "个人成就奖励",
      ],
      btnStatus: ["领取", "去完成"],
      // 底部弹框显示哪个 ""则不显示弹框
      maskShow_btm: "",
    };
  },
  methods: {
    // 设置弹框是否展示
    setIsMaskShow(n) {
      this.maskShow = n;
    },
    // 设置弹框标题
    setMaskTitle(title) {
      this.maskTitle = title;
    },
    confirm() {},
    // 滚动到页面某位置
    scrollTo(item) {
      let index = this.previewList.indexOf(item);
      let flag;
      if (index == 0) flag = `.btn-record-get`;
      if (index == 1) flag = `.prize-group1`;
      if (index == 2) flag = `.prize-group2`;
      if (index == 3) flag = `.prize-group3`;
      this.$el
        .querySelector(flag)
        .scrollIntoView({ block: "start", behavior: "smooth" });
      this.setIsMaskShow("");
    },
    // 领取奖励
    async getGift(groupId, id, done) {
      // console.log("getGift", groupId, id);
      if (Object.keys(this.loginUserMsg).length == 0) {
        this.setIsMaskShow("chooseLoginWay");
        this.setMaskTitle("选择登录方式");
        this.$toast.fail("请先登录");
        return;
      } else if (!this.loginUserMsg.data) {
        this.$toast.fail("请先绑定角色");
        return;
      }
      if (
        (groupId == 1 || groupId == 2 || groupId == 3 || groupId == 4) &&
        done
      ) {
        // 已完成领取奖励
        const { info } = this.loginUserMsg;
        this.setIsMaskShow("confirmRoleGetGift-gift");
        // 进入确认该角色获取奖励弹框
        this.$nextTick(() => {
          this.$bus.$emit("setCommonMaskMsg", [
            `是否将奖励领取到角色  ${info.rname}？`,
            "确认",
            "取消",
          ]);
        });
        this.$nextTick(() => {
          this.$bus.$emit("setGift", [groupId, id]);
        });
      }
      if (groupId == 1 && id == 2 && !done) {
        // 每日分享未完成弹出分享海报
        this.setIsMaskShow("sharePost2");
        // 生成二维码
        await this.$nextTick(() => {
          this.$bus.$emit("createQRcode", 1);
        });
        // 生成海报
        this.$nextTick(() => {
          this.$bus.$emit("htmlToimg");
        });
      }
      // 未完成则跳转page4
      if ((groupId == 2 || groupId == 3) && !done) this.$router.push("/friend");
      if (groupId == 4 && !done) {
          window.location.href=`${location.href.split("#")[0]}#/blank?type=2`
        // 未完成则判断手机是否下安装该游戏 没有则提示下载游戏
        // this.setIsMaskShow("gameDownload");
        // this.$nextTick(() => {
        //   this.$bus.$emit("setCommonMaskMsg", [
        //     `是否下载游戏《我本千金》？`,
        //     "确认",
        //     "取消",
        //   ]);
        // });
        // 安装了则拉起游戏
      }
    },
    showGiftRecord() {
      if (!this.loginUserMsg.token) {
        this.setIsMaskShow("chooseLoginWay");
        this.setMaskTitle("选择登录方式");
        this.$toast.fail("请先登录");
        return;
      }
      this.setIsMaskShow("giftRecordTop");
      this.$nextTick(() => {
        this.$bus.$emit("getGiftRecord", 1);
      });
    },
    // 初始化/刷新奖励领取
    updataGiftStatus() {
      const { is_login, is_share, data, is_first_share, is_feeback, prize } =
        this.loginUserMsg;
      if (!data) return;
      const { pass_two, pass_five, pass_nine } = data.user;
      const allScript = prize["1"] && Object.keys(prize["1"]).length == 3;
      // 每日登录
      this.$set(this.prizeList.prizeGroup1[0], "done", is_login);
      // 每日分享
      this.$set(this.prizeList.prizeGroup1[1], "done", is_share);
      // 个人2章节
      this.$set(this.prizeList.prizeGroup4[0], "done", !!pass_two);
      // 个人5章节
      this.$set(this.prizeList.prizeGroup4[1], "done", !!pass_five);
      // 个人9章节
      this.$set(this.prizeList.prizeGroup4[2], "done", !!pass_nine);
      // 首次分享
      this.$set(this.prizeList.prizeGroup4[3], "done", is_first_share);
      // 反馈有奖
      this.$set(this.prizeList.prizeGroup4[4], "done", is_feeback);
      // 全部剧本解锁
      this.$set(this.prizeList.prizeGroup4[5], "done", allScript);
    },
    // 获取用户信息
    get_user_info() {
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const { token, uid } = this.loginUserMsg;
      get_user_info({ time, token, uid }, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          this.$store.commit("SET_lOGINUSERMSG", res.data);
          // if(res.data.info.rid){
          // 登录用户曾经绑定过角色 则直接绑定
          // }
        } else {
          let errMsg =
            res.status == 4040 ? "登录过期，请重新登录" : "获取用户信息失败";
          this.$toast.fail(errMsg);
          res.status == 4040 ? this.logOut() : "";
        }
      });
    },
    // 设置底部弹框是否显示
    setIsMaskShow_btm(n) {
      this.maskShow_btm = n;
    },
    // 注销
    logOut() {
      this.$store.commit("SET_lOGINUSERMSG", {});
      localStorage.removeItem("loginUserMsg");
      this.$store.commit("SET_FCODE", "");
    },
  },
  computed: {
    ...mapState(["loginUserMsg"]),
    // 好友是否通xx关
    friendPass(num, flag = 1) {
      return (num, flag) => {
        num = parseInt(num);
        if (
          Object.keys(this.loginUserMsg).length != 0 &&
          this.loginUserMsg.data &&
          this.loginUserMsg.data.friend_process
        ) {
          if (flag == 2) {
            // 第二种新用户邀请
            const {
              data: { friend_process },
            } = this.loginUserMsg;
            const fnum = friend_process.reduce((temp, process) => {
              return process.role_bmap >= 3 ? temp + 1 : temp;
            }, 0);
            return fnum >= num;
          }
          return this.loginUserMsg.data.friend_process.some((process) => {
            return process.role_bmap >= num;
          });
        }
        return false;
      };
    },
    // 获取通过指定管卡的好友数
    getPassFriendNum(num, flag) {
      // 0 - 是否可领 1 - 剩余
      return (num, flag) => {
        if (
          Object.keys(this.loginUserMsg).length == 0 ||
          !this.loginUserMsg.data ||
          !this.loginUserMsg.data.friend
        ) {
          return flag ? 10 : 0;
        } else {
          const {
            data: {
              friend: { pass_two, pass_five, pass_nine },
            },
            prize,
          } = this.loginUserMsg;
          const prize1 = prize["4"] && prize["4"]["1"] ? prize["4"]["1"] : 0;
          const prize2 = prize["4"] && prize["4"]["2"] ? prize["4"]["2"] : 0;
          const prize3 = prize["4"] && prize["4"]["3"] ? prize["4"]["3"] : 0;
          const surplusTwo = pass_two - prize1 > 0 ? 1 : 0;
          const surplusFive = pass_five - prize2 > 0 ? 1 : 0;
          const surplusNine = pass_nine - prize3 > 0 ? 1 : 0;
          switch (num) {
            case "2":
              return flag ? 10 - prize1 : surplusTwo;
            case "5":
              return flag ? 10 - prize2 : surplusFive;
            case "9":
              return flag ? 10 - prize3 : surplusNine;
          }
        }
      };
    },
    getPersonGiftNum(rid) {
      return (rid) => {
        if (
          Object.keys(this.loginUserMsg).length == 0 ||
          !this.loginUserMsg.data
        ) {
          return 0;
        }
        const { data, is_first_share, is_feeback, prize } = this.loginUserMsg;
        const { pass_two, pass_five, pass_nine } = data.user;
        switch (rid) {
          case 1:
            return pass_two;
          case 2:
            return pass_five;
          case 3:
            return pass_nine;
          case 4:
            return is_first_share ? 1 : 0;
          case 5:
            return is_feeback ? 1 : 0;
          case 6:
            return !prize["1"] ? 0 : Object.keys(prize["1"]).length;
        }
      };
    },
  },
  mounted() {
    const { lead } = this.$route.params;
    if (lead) {
      this.setIsMaskShow("chooseLoginWay");
      this.setMaskTitle("选择登录方式");
    }
    const { token } = this.loginUserMsg;
    if (Object.keys(this.loginUserMsg) != 0 && this.loginUserMsg.data) {
      this.updataGiftStatus();
    }
    if (token) {
      this.timer = setInterval(() => {
        this.get_user_info();
      }, 2000);
    }
  },
  destroyed() {
    clearInterval(this.timer);
  },
  watch: {
    loginUserMsg(newVal, oldVal) {
      this.updataGiftStatus();
    },
    maskShow: {
      handler(newVal) {
        if (newVal) {
          document
            .getElementsByTagName("body")[0]
            .addEventListener("touchmove", this.handler, { passive: true });
        } else {
          document
            .getElementsByTagName("body")[0]
            .removeEventListener("touchmove", this.handler, { passive: true });
        }
      },
      // 初始化时立即执行
      immediate: true,
    },
  },
};
</script>
<style lang="scss" scoped>
.page3{
  width: 100%;
  height: 382.5vw;
  background-image: imgUrl("bg-page3.png");
  .btn-record-get{
    width: 22.3vw;
    height: 6.08vw;
    margin:3vw 0 0 0;
    align-self: flex-end;
    color: #FFFFFF;
    font-size: 3.2vw;
    line-height: 6vw;
    background-image: imgUrl("btn-record-get.png");
  }
  .prize-group1{
    width: 100%;
    margin: 32vw 0 0 0;
    position: relative;
    .btn-preview{
      position: absolute;
      top: -9.3vw;
      right: 8.6vw;
      width: 12.5vw;
      height: 5vw;
      background-image: imgUrl("btn-preview.png");
    }
  }
  .prize-group2{
    width: 100%;
    margin: 32vw 0 0 0; 
  }
  .prize-group3{
    width: 100%;
    margin: 33vw 0 0 0; 
  }
   .prize-group4{
    width: 100%;
    margin: 33vw 0 0 0; 
  }
  .prize-item{
      width: 79.6vw;
      height: 11.47vw;
      margin: 0 0 2vw 0;
      padding-left: 2vw;
      display: flex;
      align-items: center;
      background: #FCF2FA;
      &:nth-of-type(1){
        margin-bottom: 2vw;
      }
      .content{
        width: 56.4vw;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        margin:0 3vw 0 0;
        text-align: left;
        .top{
          padding:0 0 0.9vw 0;
          font-size: 3.39vw;
          color: #8467D9;
          border-bottom:0.13vw dashed #949494;
          span{
            margin: 0 0 0 -1vw;
            color:#ec82b2;
            font-size: 2.6vw;
          }
        }
        .btm{
          padding:0.9vw 0 0 0;
          font-size: 2.3vw;
          color: #949494;
        }
      }
      .btn-get{
        width: 15.85vw;
        height:6.3vw;
        font-size: 2.9vw;
        color: #FFFFFF;
        background-image: imgUrl("btn-get.png");
      }
    }
}
</style>
