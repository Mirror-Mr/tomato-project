<template>
  <div class="blank">
    <img
      src="https://wcdn.tomatogames.com/web/guonei/wbqj/answer-h5/imgs/download-tips.png"
      alt=""
      v-if="showTip"
    />
    <MaskBox :maskShow="maskShow">
      <ContentMask :maskShow="maskShow" />
    </MaskBox>
  </div>
</template>
<script>
import { getQueryValue } from "@/utils/getQueryValue";
export default {
  name: "Blank",
  components: {
    MaskBox: (resolve) => require(["@/components/MaskBox.vue"], resolve),
    ContentMask: (resolve) =>
      require(["@/components/ContentMask.vue"], resolve),
  },
  data() {
    return {
      USER_AGENT: navigator.userAgent,
      showTip: false,
      type: 0,
      // 当前显示的是哪个弹框 ""则不显示弹框
      maskShow: "",
    };
  },
  methods: {},
  computed: {
    isWeixin() {
      return /micromessenger/i.test(this.USER_AGENT);
    },
    isQQ() {
      return this.USER_AGENT.indexOf("QQ/") !== -1;
    },
    isiOS() {
      let u = navigator.userAgent;
      let isAndroid = u.indexOf("Android") > -1 || u.indexOf("Adr") > -1; //android终端
      let isiOS = !!u.match(/Mac OS X/); //ios终端
      return isiOS;
    },
  },
  mounted() {
    const type = getQueryValue("type");
    type == 1
      ? ta.track(
          "web_wbqj_xjds_frompage1_download" //追踪事件的名称 - 【扫描了分享页1-二维码1（下载页面）】
        )
      : ta.track(
          "web_wbqj_xjds_page2_scan" //追踪事件的名称 - 【扫描了分享页2二维码（吊起游戏/下载页面）】
        );
    if (type == 1) {
      // 下载
      if (this.isiOS) {
        window.location.href =
          "https://market.tomatogames.com/click/v2/customer?isSdk=1&cid=1076&gameId=1100050&channel=wbjqios_ios_qjxjds01_1&customMedia=web_yxhd";
      } else {
        if (this.isWeixin) {
          this.showTip = true;
          return;
        }
        window.location.href =
          "https://assets.tomatogames.com/apk/wbqj/tomato-h5-dramaqueen-202201122029.apk";
      }
    } else {
      // 调起游戏
      if (this.isiOS) {
        this.maskShow = "jumpGameB";
      } else {
        if (this.isWeixin) {
          this.maskShow = "";
          this.showTip = true;
          return;
        }
        this.maskShow = "jumpGameA";
      }
    }
  },
};
</script>
<style scoped lang='scss'>
.blank{
    display: flex;
    justify-content: flex-end;
    img{
        width: 70vw;
        margin:2vw 5vw 0 0
    }
}
</style>