<template>
  <div class="page2 flexColumnCenter">
    <!-- 顶部俩按钮 -->
    <div class="btn-group">
      <div class="show-prize-record" @click="showGiftRecord">查看中奖记录</div>
      <div class="show-probably1" @click="setIsMaskShow('probably')">
        盲盒概率展示
      </div>
    </div>
    <!-- 普通盲盒 -->
    <div class="blind-box flexColumnCenter">
      <div class="main-box flexColumnCenter">
        <div class="title">普通盲盒</div>
        <div class="innerCenter">
          <div class="normal"></div>
        </div>
      </div>
      <span
        >普通盲盒持有数:{{ loginUserMsg.num ? loginUserMsg.num.mnum : 0 }}</span
      >
      <div class="btn-open-box" @click="openBox(0)">开启盲盒</div>
    </div>
    <!-- 中间俩按钮 -->
    <div class="btn-group">
      <div class="show-address" @click="showAddress">地址簿</div>
      <div class="show-probably2" @click="showWinnerList">中奖名单</div>
    </div>
    <!-- 高级盲盒 -->
    <div class="blind-box flexColumnCenter">
      <div class="main-box flexColumnCenter">
        <div class="title">高级盲盒</div>
        <div class="innerCenter">
          <div class="high"></div>
        </div>
      </div>
      <span
        >高级盲盒持有数:{{ loginUserMsg.num ? loginUserMsg.num.gnum : 0 }}</span
      >
      <div class="btn-open-box" @click="openBox(1)">
        开启盲盒
        <span></span>
      </div>
    </div>
    <MaskBox
      :maskShow="maskShow"
      @setIsMaskShow="setIsMaskShow"
      @setMaskTitle="setMaskTitle"
      :title="maskTitle"
    >
      <ContentMask
        ref="contentMask"
        :maskShow="maskShow"
        @setIsMaskShow="setIsMaskShow"
        @setMaskTitle="setMaskTitle"
        @getAddressList="getAddressList"
        :addressList="addressList"
        :winnerList="winnerList"
        @setIsMaskShow_btm="setIsMaskShow_btm"
        @get_user_info="get_user_info"
      />
    </MaskBox>
    <MaskBoxBtm
      :maskShow_btm="maskShow_btm"
      @setIsMaskShow_btm="setIsMaskShow_btm"
    >
    </MaskBoxBtm>
  </div>
</template>

<script>
import { get_addr, lunbo, get_user_info } from "@/api";
import { mapState } from "vuex";
export default {
  name: "Page2",
  components: {
    MaskBox: (resolve) => require(["@/components/MaskBox.vue"], resolve),
    MaskBoxBtm: (resolve) => require(["@/components/MaskBox_btm.vue"], resolve),
    ContentMask: (resolve) =>
      require(["@/components/ContentMask.vue"], resolve),
  },
  data() {
    return {
      time: Date.now(),
      // 请求是否回来了
      responseDone: true,
      maskShow: "",
      maskTitle: "",
      // 地址簿
      addressList: [],
      winnerList: [],
      // 底部弹框显示哪个 ""则不显示弹框
      maskShow_btm: "",
    };
  },
  methods: {
    // 设置弹框是否展示
    setIsMaskShow(n) {
      this.maskShow = n;
    },
    // 开启盲盒
    openBox(n) {
      if (!this.loginUserMsg.token) {
        this.setIsMaskShow("chooseLoginWay");
        this.setMaskTitle("选择登录方式");
        this.$toast.fail("请先登录");
        return;
      } else if (!this.loginUserMsg.data) {
        this.$toast.fail("请先绑定角色");
        return;
      }
      if (n && this.highBoxGift.id) {
        // 如果开高级盲盒且上次未领取 则打开上次需要填写地址的页面
        this.setIsMaskShow("tagHighBox");
        this.$nextTick(() => {
          this.$bus.$emit("setCommonMaskMsg", [
            `有未领取的奖励，请先填写领奖信息`,
            "好的",
            "",
          ]);
        });
        return;
      }
      const { num, info } = this.loginUserMsg;
      const fnum = !n ? num.mnum : num.gnum;
      const id = !n ? 6 : 7;
      if (fnum < 1) {
        // if (fnum > 1) {
        // 没有足够的盲盒
        this.setIsMaskShow("noBox");
        this.$nextTick(() => {
          this.$bus.$emit("setCommonMaskMsg", [
            `你的盲盒不足，快去参与活动获取盲盒吧`,
            "好的",
            "",
          ]);
        });
      } else {
        // 有足够的盲盒
        this.setMaskTitle("");
        this.setIsMaskShow("confirmRoleGetGift-box");
        this.$nextTick(() => {
          this.$bus.$emit("setCommonMaskMsg", [
            `是否使用当前角色 ${info.rname} 获取奖励？`,
            "确认",
            "取消",
          ]);
          this.$bus.$emit("sub_prize", id);
        });
      }
    },
    // 设置弹框标题
    setMaskTitle(title) {
      this.maskTitle = title;
    },
    // 获取地址列表
    getAddressList() {
      if (!this.loginUserMsg.token) {
        this.setIsMaskShow("chooseLoginWay");
        this.setMaskTitle("选择登录方式");
        this.$toast.fail("请先登录");
        return;
      }
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const { token,info: { uid }, } = this.loginUserMsg;
      get_addr({ time, token,uid }, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          this.addressList = res.data;
          if (this.maskShow == "openHigh") {
            this.$nextTick(() => {
              this.$bus.$emit("getAddressPrevMsg");
            });
          }
        } else {
          this.$toast.fail("获取地址列表失败！");
        }
      });
    },
    // 查看中奖记录
    showGiftRecord() {
      if (!this.loginUserMsg.token) {
        this.setIsMaskShow("chooseLoginWay");
        this.setMaskTitle("选择登录方式");
        this.$toast.fail("请先登录");
        return;
      }
      this.setIsMaskShow("giftRecord");
      this.$nextTick(() => {
        this.$bus.$emit("getGiftRecord", 2);
      });
    },
    // 获取中奖信息
    getWinnerList() {},
    // 展示中奖信息弹框
    showWinnerList() {
      const { time } = this;
      lunbo({ time }, { time }).then((res) => {
        if (res.status == 1) {
          this.winnerList = res.data.map((data) => {
            const { log } = data;
            const phone = log.substr(2, 11);
            const gift = log.substring(17, log.length - 1);
            return { ...data, phone, gift };
          });
          // 打乱顺序
          this.winnerList.sort(function () {
            return Math.random() > 0.5 ? -1 : 1;
          });
          this.setMaskTitle("中奖名单");
          this.setIsMaskShow("winnerList");
        } else {
          this.$toast.fail("获取中奖名单失败");
        }
      });
    },
    // 展示地址簿
    showAddress() {
      if (!this.loginUserMsg.token) {
        this.setIsMaskShow("chooseLoginWay");
        this.setMaskTitle("选择登录方式");
        this.$toast.fail("请先登录");
        return;
      }
      this.getAddressList();
      this.setIsMaskShow("addressList");
      this.setMaskTitle("地址簿");
    },
    // 设置底部弹框是否显示
    setIsMaskShow_btm(n) {
      this.maskShow_btm = n;
    },
    // 获取用户信息
    get_user_info() {
      let { time, responseDone } = this;
      if (!responseDone) return;
      responseDone = false;
      const { token, uid } = this.loginUserMsg;
      get_user_info({ time, token,uid }, { time, token }).then((res) => {
        responseDone = true;
        if (res.status == 1) {
          this.$store.commit("SET_lOGINUSERMSG", res.data);
          // if(res.data.info.rid){
          // 登录用户曾经绑定过角色 则直接绑定
          // }
        } else {
          let errMsg =
            res.status == 4040 ? "登录过期，请重新登录" : "获取用户信息失败";
          this.$toast.fail(errMsg);
          res.status == 4040 ? this.logOut() : "";
        }
      });
    },
    // 注销
    logOut() {
      this.$store.commit("SET_lOGINUSERMSG", {});
      localStorage.removeItem("loginUserMsg");
      this.$store.commit("SET_FCODE", "");
    },
  },
  computed: {
    ...mapState(["loginUserMsg", "highBoxGift"]),
  },
  watch: {
    maskShow: {
      handler(newVal) {
        if (newVal) {
          document
            .getElementsByTagName("body")[0]
            .addEventListener("touchmove", this.handler, { passive: true });
        } else {
          document
            .getElementsByTagName("body")[0]
            .removeEventListener("touchmove", this.handler, { passive: true });
        }
      },
      // 初始化时立即执行
      immediate: true,
    },
  },
};
</script> 
<style lang="scss" scoped>
.page2{
  width:100%;
  height: 216.5vw;
  background-image: imgUrl("bg-page2.png");
  .btn-group{
    width: 85%;
    margin: 9.5vw 0 0 0;
    display: flex;
    justify-content: space-around;
    div{
      width: 37vw;
      height: 10vw;
      font-size: 4vw;
      color: #FFFFFF;
      line-height: 8.5vw;
      background-image: imgUrl("bg-btn-page2.png");
    }
  }
  .blind-box{
    margin:2vw 0 0 0;
    .main-box{
      width: 90vw;
      height: 55vw;
      background-image: imgUrl("bg-blindBox-part.png");
      .title{
        width: 36.67vw;
        height: 8.4vw;
        margin:6vw 0 0 0;
        font-size: 5vw;
        color: #FFFFFF;
        line-height: 8.5vw;
        background-image: imgUrl("bg-title-mainBox.png");
       }
       div{
         &:nth-of-type(2){
           width: 36.59vw;
           height:36.41vw;
           background-image: imgUrl("bg-blindBox.png");
          div{
            flex-shrink: 0;
            &.normal{
              width: 35vw;
              height: 35vw;
              background-image: imgUrl("normal-box.png");
              background-position-y: -6vw;
            }
            &.high{
              width: 51vw;
              height: 33vw;
              background-image: imgUrl("high-box.png");
            }
          }
         }
       }
    }
    span{
      font-size: 3.73vw;
      color: #863860;
    }
    .btn-open-box{
      width: 41vw;
      height: 15vw;
      position: relative;
      margin:2.5vw 0 0 0;
      font-size: 4.84vw;
      color: #863860;
      line-height: 13vw;
      background-image: imgUrl("btn-getScriptChip.png");
      span{
        width: 5.44vw;
        height: 5.44vw;
        position: absolute;
        top: -2vw;
        right: -1.5vw;
        display: block;
        background-image: imgUrl("ring.png");
      }
    }
  }
  
  
}
</style>