<template>
  <div id="app">
    <!-- 底部固定导航栏 -->
    <div class="main-navbar" v-if="$route.path != '/enter' && $route.path != '/blank'">
      <router-link
        v-for="item in indexName"
        :key="item.id"
        :class="{ check: $route.path == item.path }"
        :to="item.path"
      >
        {{ item.name }}
      </router-link>
    </div>
    <router-view />
  </div>
</template>
<script>
import { getActivityTime } from "@/api";
import { mapState } from "vuex";

export default {
  name: "App",
  data() {
    return {
      time: Date.now(),
      // 当前是哪一页
      index: 1,
      indexName: [
        { id: 1, name: "剧本解锁", path: "/unlock" },
        { id: 2, name: "开启盲盒", path: "/openBox" },
        { id: 3, name: "剧本奖励", path: "/drama" },
        { id: 4, name: "好友进度", path: "/friend" },
      ],
    };
  },
  methods: {},
  mounted() {
      console.log(this.$route.path)
    const params = { time: this.time, project_id: 30 };
    const headers = { time: this.time, project_id: 30 };
    // 获取活动时间
    getActivityTime(params, headers).then((res) => {
      if (res.status == 1) {
        console.log(res.data);
      }
    });
    // 如果localStorage中有登录的用户信息缓存 则自动登录
    // const loginUserMsg = localStorage.getItem("loginUserMsg");
  },
 
  computed: {
    ...mapState(["loginUserMsg", "fcode"]),
  },
  created() {
    // 一刷新就重新获取用户信息
    const { token } = this.loginUserMsg;
    if (token) {
      this.$bus.$emit("get_user_info");
    }
    //在页面加载时读取sessionStorage里的状态信息
    if (sessionStorage.getItem("store")) {
      this.$store.replaceState(
        Object.assign(
          {},
          this.$store.state,
          JSON.parse(sessionStorage.getItem("store"))
        )
      );
    }
    //在页面刷新时将vuex里的信息保存到sessionStorage里
    window.addEventListener("beforeunload", () => {
      sessionStorage.setItem("store", JSON.stringify(this.$store.state));
    });
  },
};
</script>
<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  overflow-x:hidden ;
  .main-navbar{
    width: 100%;
    height: 17vw;
    position: fixed;
    bottom: 0;
    left: 0;
    display: flex;
    justify-content: center;
    background-position: 100% 100%;
    background-image: imgUrl("bg-mainbar.png");
    z-index: 1;
    a{
      width: 24.7%;
      height: 14.5vw;
      margin: 1.5vw 0 0 0;
      font-size: 4.8vw;
      color: #863860;
      line-height: 13.5vw;
      background-image:imgUrl("btn-mainbar-nocheck.png");
      &.check{
        background-image: imgUrl("btn-mainbar-check.png");
      }
    }
  }
}


</style>
