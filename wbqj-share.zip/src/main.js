import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import "@/assets/style/reset.scss";
import "@/assets/style/common.scss";

Vue.config.productionTip = false;
import { Popup, Field, Toast, Picker } from "vant";
Vue.use(Popup);
Vue.use(Field);
Vue.use(Toast);
Vue.use(Picker);
Vue.prototype.$bus = new Vue();
router.afterEach((to, from, next) => {
  window.scrollTo(0, 0);

  // 或

  // window.scroll(0, 0);
});
/* 路由异常错误处理，尝试解析一个异步组件时发生错误，重新渲染目标页面 */
// router.onError((error) => {
//   const pattern = /Loading chunk (\d)+ failed/g;
//   const isChunkLoadFailed = error.message.match(pattern);
//   const targetPath = router.history.pending.fullPath;
//   if (isChunkLoadFailed) {
//     router.replace(targetPath);
//   }
// });

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount("#app");
