<template>
  <div class="pcContainer">
    <div class="pcIndex" :style="{ height: innerHeight + 'px' }">
      <!-- 导航栏 -->
      <div class="navbar" :style="{ opacity: bodyIndex == 1 ? 0 : 1 }">
        <ul>
          <li
            v-for="item in nav_list"
            :key="item.id"
            @click="changePage(item.id)"
          >
            <template v-if="bodyIndex == item.id && item.id != 1">
              <img :src="`${baseUrl}${item.img}_c.png`" alt="" />
            </template>
            <template v-else>
              <img :src="`${baseUrl}${item.img}.png`" alt="" />
            </template>
          </li>
        </ul>
        <!-- <div class="btn_order" @click="controlMask(1)"></div> -->
      </div>
      <!-- 主题轮播图 -->
      <swiper :options="swiperOption_body" class="body_swiper" ref="bodySwiper">
        <!-- 第一页 -->
        <swiper-slide class="body_slide">
          <img :src="`${baseUrl}kv.jpg`" alt="" class="slide_bg" />
          <div class="btn_tip" @click="changePage(2)"></div>
        </swiper-slide>
        <!-- 第二页 -->
        <swiper-slide class="body_slide center">
          <img class="slide_bg" :src="`${baseUrl}order_bg1.png`" alt="" />
          <div class="order_title"></div>
          <div class="order_num">
            <div></div>
            <b>{{ orderSum }}</b>
            <div>
              <span>位</span>
              <span>千金</span>
              <span>成功穿越</span>
            </div>
          </div>
          <div class="order_milepost">
            <span
              v-for="(item, index) in 5"
              :key="index"
              :class="{ reach: reach(item.id) }"
            ></span>
          </div>
          <div class="order_prize">
            <div
              v-for="item in order_prize_list"
              :key="item.id"
              :class="`order_prize${item.id}`"
            >
              <div
                class="prize_img"
                :style="{
                  backgroundImage: `url(${baseUrl}order_prize${item.id}.png)`,
                }"
                v-if="reach(item.id)"
              ></div>
              <div
                class="prize_img"
                :style="{
                  backgroundImage: `url(${baseUrl}no_order_prize${item.id}.png)`,
                }"
                v-else
              ></div>
              <!-- <div
                class="prize_desc"
              >
              </div> -->
            </div>
          </div>
          <div
            class="btn_order"
            :class="{ no_invalid: !isInvalid }"
            @click="controlMask(1)"
          ></div>
        </swiper-slide>
        <!-- 第三页 -->
        <swiper-slide class="body_slide center">
          <img class="slide_bg" :src="`${baseUrl}worldView_bg1.png`" alt="" />
          <div class="worldView_title"></div>
          <div class="worldView_desc">
            <span
              v-for="(item, index) in worldView_desc"
              :key="index"
              v-html="item"
            ></span>
          </div>
        </swiper-slide>
        <!-- 第四页 -->
        <swiper-slide class="body_slide center">
          <!-- 角色音频 -->
          <audio ref="audio2">
            <source
              src="https://wcdn.tomatogames.com/static/WoBenQianJin/website/audio/lc.mp3"
              type="audio/mp3"
              controls
            />
          </audio>
          <audio ref="audio5">
            <source
              src="https://wcdn.tomatogames.com/static/WoBenQianJin/website/audio/nzy.mp3"
              type="audio/mp3"
              controls
            />
          </audio>
          <audio ref="audio3">
            <source
              src="https://wcdn.tomatogames.com/static/WoBenQianJin/website/audio/wyj.mp3"
              type="audio/mp3"
              controls
            />
          </audio>
          <audio ref="audio4">
            <source
              src="https://wcdn.tomatogames.com/static/WoBenQianJin/website/audio/zkt.mp3"
              type="audio/mp3"
              controls
            />
          </audio>
          <img
            class="slide_bg"
            :src="`${baseUrl}characterIntro_bg.png`"
            alt=""
          />
          <swiper
            :options="swiperOption_character"
            class="character_swiper"
            ref="characterSwiper"
          >
            <swiper-slide
              v-for="item in character_list"
              :key="item.id"
              :class="{
                fadeIn: chaFadeIn[item.id],
                fadeOut: chaFadeOut[item.id],
              }"
            >
              <div
                class="cha_name"
                :style="{
                  backgroundImage: `url(${baseUrl}chaName${item.id}.png)`,
                }"
              >
                <span
                  class="cha_voice"
                  v-if="item.id != 1"
                  @click="controlVoice(item.id)"
                >
                </span>
              </div>
              <div class="cha_img">
                <div>
                  <img class="cha" :src="`${baseUrl}cha${item.id}.png`" />
                </div>
              </div>
              <div class="cha_desc">
                <span>年龄：{{ item.age }}</span>
                <span>身高：{{ item.height }}cm</span>
                <span>星座：{{ item.star }}</span>
                <!-- <span>职业：{{ item.role }}</span> -->
                <div v-html="item.motto"></div>
              </div>
            </swiper-slide>
          </swiper>
          <!-- {{chaFadeIn}}
          {{chaFadeOut}} -->
          <div class="character_nav">
            <span
              v-for="item in character_list"
              :key="item.id"
              :class="{ active: chaIndex == item.id }"
              @click="changeCha(item.id)"
            >
              {{ item.name }}
            </span>
            <!-- left 0.55 top -0.05/0.25/0.55/0.85/1.15 -->
            <div
              class="cha_pointer"
              :style="{ top: -0.05 + (chaIndex - 1) * 0.3 + 'rem' }"
            ></div>
          </div>
        </swiper-slide>
        <!-- 第五页 -->
        <swiper-slide class="body_slide center">
          <img
            class="slide_bg"
            :src="`${baseUrl}gameFeatures_bg1.png`"
            alt=""
          />
          <div class="letter_bg"></div>
          <div class="gameFeatures_title"></div>
          <div class="feaSwiper_container">
            <swiper
              :options="swiperOption_feature"
              class="feature_swiper"
              ref="featureSwiper"
            >
              <swiper-slide
                class="center"
                v-for="(item, index) in 5"
                :key="index"
              >
                <div class="border center">
                  <div
                    :class="'feature' + index"
                    :style="{
                      backgroundImage: `url(${baseUrl}feature${index + 1}.jpg)`,
                    }"
                  ></div>
                </div>
                <MaskBox></MaskBox>
              </swiper-slide>
            </swiper>
            <div class="btn_changeFea" @click="changeFea">
              <div class="btn_prevFea"></div>
              <div class="btn_nextFea"></div>
            </div>
          </div>
        </swiper-slide>
      </swiper>
      <!-- 弹出框 -->
      <mask-box :class="{ showMask: isShowMask }">
        <div class="mask_board">
          <span class="btn_close" @click="controlMask(0)"></span>

          <div class="phoneForm" v-if="isPhoneOrder">
            <img :src="`${baseUrl}phone_order.png`" alt="" />
            <!-- 单选按钮 -->
            <div class="radioGroup">
              <div
                class="radio radio1"
                :class="{ choose: isiOS }"
                @click="isiOS = true"
              >
                <div>
                  <span></span>
                </div>
                <span>iOS</span>
              </div>
              <div
                class="radio radio2"
                :class="{ choose: !isiOS }"
                @click="isiOS = false"
              >
                <div>
                  <span></span>
                </div>
                <span>Android</span>
              </div>
            </div>
            <!-- 输入框 -->
            <input
              type="text"
              class="phoneNum input"
              placeholder="请输入手机号"
              v-model="orderMsg.phoneNum"
            />
            <div class="codeGroup">
              <input
                type="text"
                class="phoneCode input"
                placeholder="请输入验证码"
                v-model="orderMsg.phoneCode"
              /><span class="getCode" @click="getCode(1)">{{ codeMsg }}</span>
            </div>
            <!-- <input
              type="text"
              class="inviteCode input"
              placeholder="请输入邀请码（非必填）"
              v-model="orderMsg.inviteCode"
            /> -->
            <div class="btn_makeSure" @click="toMakeSure(1)"></div>
            <div class="changeOrderWay" @click="controlMask(2)">
              切换邮箱预约
            </div>
          </div>
          <div class="emailForm" v-if="isEmailOrder">
            <img :src="`${baseUrl}email_order.png`" alt="" />
            <!-- 单选按钮 -->
            <!-- <div class="radioGroup">
              <div
                class="radio radio1"
                :class="{ choose: isiOS }"
                @click="isiOS = true"
              >
                <div>
                  <span></span>
                </div>
                <span>iOS</span>
              </div>
              <div
                class="radio radio2"
                :class="{ choose: !isiOS }"
                @click="isiOS = false"
              >
                <div>
                  <span></span>
                </div>
                <span>Android</span>
              </div>
            </div> -->
            <!-- 输入框 -->
            <input
              type="text"
              class="emailNum input"
              placeholder="请输入正确的邮箱地址"
              v-model="orderMsg.emailNum"
            />
            <div class="codeGroup">
              <input
                type="text"
                class="emailCode input"
                placeholder="请输入验证码"
                v-model="orderMsg.emailCode"
              /><span class="getCode" @click="getCode(2)">{{ codeMsg1 }}</span>
            </div>
            <!-- <input
              type="text"
              class="inviteCode input"
              placeholder="请输入邀请码（非必填）"
              v-model="orderMsg.inviteCode"
            /> -->
            <div class="btn_makeSure" @click="toMakeSure(2)"></div>
            <div class="changeOrderWay" @click="controlMask(3)">
              切换手机号预约
            </div>
          </div>
          <div class="shareModule" v-if="isShareModule">
            <div class="myInviteNum">
              您的邀请码：
              <span>{{ userMsg.inviteCode }}</span>
              <!-- <span @click="copy(userMsg.inviteCode)">【复制】</span> -->
            </div>
            <div class="way1">
              <span>方法一：复制地址链接邀请好友点击链接进行预约</span>
              <div class="website">
                <div>{{ invite_website }}</div>
                <span @click="copy(invite_website)">复制地址</span>
              </div>
              <span
                >使用该链接进行预约，系统将会在好友预约界面填写您的邀请码</span
              >
            </div>
            <div class="way2">
              <span>方法二：分享二维码</span>
              <div>
                <canvas class="shareCode" ref="shareCode"></canvas>
              </div>
            </div>
          </div>
          <div class="ordered center" v-if="isOrder">
            <div>恭喜大小姐预约成功</div>
            <!-- <span @click="changeNum"></span> -->
          </div>
        </div>
      </mask-box>
    </div>
  </div>
</template>
<script>
import { Swiper, SwiperSlide } from "vue-awesome-swiper";
import "@/assets/style/common.scss";
import MaskBox from "@/components/MaskBox.vue";
import { getActivityTime, getAppointNum, appoint, sendMail } from "@/api";
import { validatePhone, validateEmail } from "@/utils/validate";
import { compareTime, getNowFormatDate } from "@/utils/compareTime";
import sendCode from "@/api/sendCode";

export default {
  name: "pcIndex",
  components: {
    Swiper,
    SwiperSlide,
    MaskBox,
  },
  data() {
    return {
      // 基础地址
      baseUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/website/img/",
      // 项目id
      project_id: "22",
      // 当前页码
      bodyIndex: 1,
      // 当前选中人物
      chaIndex: 1,
      // 主体轮播配置
      swiperOption_body: {
        initialSlide: 0,
        slidesPerView: "auto",
        allowTouchMove: false,
        speed: 1000,
        resistanceRatio: 0, //slide在边缘不能被拖动
        mousewheel: true, //鼠标滚轮控制切换
        on: {
          transitionStart: () => {
            setTimeout(() => {
              this.bodyIndex = this.bodySwiper.realIndex + 1;
            }, 100);
          },
        },
      },
      // 人物介绍轮播配置
      swiperOption_character: {
        effect: "fade",
        speed: 1000,
        fadeEffect: {
          //  不被覆盖
          crossFade: true,
        },
        on: {
          // 监听窗口大小改变 更新swiper
          resize: () => {
            setTimeout(() => {
              //更新Swiper，相当于初始化
              this.chaSwiper.update();
            }, 500);
          },
          transitionStart: () => {
            this.chaIndex = this.chaSwiper.realIndex + 1;
          },
          transitionEnd: () => {
            this.chaFadeOut[this.chaSwiper.realIndex] = false;
          },
        },
      },
      // 游戏特色轮播配置
      swiperOption_feature: {
        effect: "coverflow",
        initialSlide: 1,
        slideToClickedSlide: true,
        loop: true,
        // grabCursor: true,
        centeredSlides: true,
        slidesPerView: "auto",
        observer: true, //修改swiper自己或子元素时，自动初始化swiper
        observeParents: true, //修改swiper的父元素时，自动初始化swiper
        coverflowEffect: {
          // slide做3d旋转时Y轴的旋转角度
          rotate: 65,
          // 每个slide之间的拉伸值，越大slide靠得越紧。5.3.6 后可使用%百分比
          stretch: 40,
          // slide的位置深度。值越大z轴距离越远，看起来越小。
          depth: 200,
          // depth和rotate和stretch的倍率
          modifier: 1,
          // 是否开启slide阴影
          slideShadows: true,
        },
        on: {
          // 监听窗口大小改变 更新swiper
          resize: () => {
            setTimeout(() => {
              //更新Swiper，相当于初始化
              this.feaSwiper.update();
            }, 500);
          },
          tap: () => {
            // const index = this.handleClickSlide(this.feaSwiper);
            // if (typeof index == "number" && !isNaN(index)) {
            //   // console.log('click--'+this.feaSwiper.clickedIndex)
            // // console.log('active--'+this.feaSwiper.activeIndex)
            // // console.log("real--"+this.feaSwiper.realIndex)
            //   this.feaSwiper.slideTo(index);
            //   // if(this.feaSwiper.clickedIndex == 13){
            //     // this.feaSwiper.slideToLoop(this.feaSwiper.realIndex);
            //   // }
            // }
          },
        },
      },
      // 导航栏分栏内容
      nav_list: [
        {
          id: 1,
          name: "首页",
          img: "btn_home",
        },
        {
          id: 2,
          name: "预约礼",
          img: "btn_gift",
        },
        {
          id: 3,
          name: "世界观",
          img: "btn_world",
        },
        {
          id: 4,
          name: "人物介绍",
          img: "btn_character",
        },
        {
          id: 5,
          name: "游戏特色",
          img: "btn_feature",
        },
      ],
      // 预约好礼列表
      order_prize_list: [
        {
          id: "1",
          name: "钻石",
          num: "8000",
        },
        {
          id: "2",
          name: "钻石",
          num: "8000",
        },
        {
          id: "3",
          name: "钻石",
          num: "8000",
        },
        {
          id: "4",
          name: "钻石",
          num: "8000",
        },
        {
          id: "5",
          name: "钻石",
          num: "8000",
        },
      ],
      // 世界观描述
      worldView_desc: [
        // `番茄娱乐是S市的顶流造星集团，<br>而我，正是番茄娱乐倍受宠爱的三小姐花小蛮，名副其实的豪门千金。<br>没想到在一次宴会中，一个不长眼的服务生竟敢挡了本小姐的路！<br>正当我恼怒之际，一个人劝阻了我，这正是我们家死对头——浮光影业的公子笠川。`,
        `“Cut！”随着导演的声音响起，我恋恋不舍地退下来，<br>没错，我是一名跑龙套的小演员，穷困，整日靠泡面度日，终于接到一下三集下线的恶毒女配的角色。`,
        `回到简陋的家中，我继续翻着剧本，果然！<br>我饰演的三小姐被笠川一杯毒酒送去见了上帝，我不爽地扔下剧本，沉沉睡去……`,
        `当我再次醒来听到管家说道：“三小姐，你醒啦？”<br>……嗯？？三小姐？`,
        `我竟然穿越到了拍摄的剧本里！成了名副其实的豪门千金，躺在人生巅峰的感觉，可~真~好~啊~`,
      ],
      // 人物列表
      character_list: [
        {
          id: 1,
          name: "花小蛮",
          age: "19岁",
          height: "167",
          role: "番茄集团三小姐",
          nature: "古灵精怪",
          star: "白羊座",
          motto: ``,
        },
        {
          id: 2,
          name: "笠川",
          age: "25岁",
          height: "185",
          role: "浮光影视公司CEO",
          nature: "毒舌总裁",
          star: "天蝎座",
          motto: `要记住，这个世界只<br>有一个男主<br>所以你只能属于我。`,
        },
        {
          id: 3,
          name: "王亦瑾",
          age: "25岁",
          height: "182",
          role: "番茄娱乐设计总监",
          nature: "青梅竹马",
          star: "双鱼座",
          motto: `很荣幸，陪着你长大，<br>接下来，<br>也想继续陪你变老。`,
        },
        {
          id: 4,
          name: "郑开太",
          age: "18岁",
          height: "179",
          role: "当红流量小生",
          nature: "直球奶狗",
          star: "双子座",
          motto: `姐姐，<br>我想跟你上个热搜，<br>官宣的那种！`,
        },
        {
          id: 5,
          name: "南致远",
          age: "未知",
          height: "188",
          role: "“黑猫大盗”",
          nature: "冷漠军阀",
          star: "摩羯座",
          motto: `你愿不愿意，<br>跟我回到我的世界？`,
        },
      ],
      // 获取窗口可视区域高度
      innerHeight: window.innerHeight,
      // 预约信息
      orderMsg: {
        phoneNum: "",
        phoneCode: "",
        emailNum: "",
        emailCode: "",
        // 受邀请码
        inviteCode: "",
      },
      // 已预约用户信息
      userMsg: {
        phoneNum: "",
        inviteCode: "12312",
        inviteNum: 0,
      },
      // 手机发送验证码/60s后重新发送
      codeMsg: "发送验证码",
      // 邮箱发送验证码/60s后重新发送
      codeMsg1: "发送验证码",
      // 手机型号 默认安卓
      isiOS: false,
      // 弹出框是手机预约框 默认
      isPhoneOrder: true,
      // 弹出框是邮箱预约框?
      isEmailOrder: false,
      // 弹出框是分享框?
      isShareModule: false,
      // 弹框是否显示
      isShowMask: false,
      // 是否已预约
      isOrder: false,
      // 弹框信息
      msg: null,
      // 手机号定时器
      timer: null,
      // 邮箱号定时器
      timer1: null,
      // 获取手机号验证码请求是否执行完
      isGetCode: true,
      // 获取邮箱号验证码请求是否执行完
      isGetCode1: true,
      // 已预约总人数
      orderSum: 0,
      chaFadeIn: [false, false, false, false, false],
      chaFadeOut: [false, false, false, false, false],
      // 是否在有效期内
      isInvalid: true,
      // 音频数组
      audioList: null,
    };
  },
  computed: {
    // 主题轮播图
    bodySwiper() {
      return this.$refs.bodySwiper.$swiper;
    },
    // 人物轮播图
    chaSwiper() {
      return this.$refs.characterSwiper.$swiper;
    },
    // 游戏特色轮播图
    feaSwiper() {
      return this.$refs.featureSwiper.$swiper;
    },
    // 邀请链接
    invite_website() {
      return `${location.href.split("?")[0]}?code=${this.userMsg.inviteCode}`;
    },
    // 是否到达奖励
    reach(id) {
      return (id) => {
        if (id == 1) {
          return this.orderSum >= 10000 ? true : false;
        } else if (id == 2) {
          return this.orderSum >= 30000 ? true : false;
        } else if (id == 3) {
          return this.orderSum >= 50000 ? true : false;
        } else if (id == 4) {
          return this.orderSum >= 100000 ? true : false;
        } else if (id == 5) {
          return this.orderSum >= 200000 ? true : false;
        }
      };
    },
  },
  methods: {
    // 切换主体轮播图页面
    changePage(index) {
      this.bodySwiper.slideTo(index - 1);
      this.bodyIndex = index;
    },
    // 切换角色轮播图
    changeCha(index) {
      this.chaSwiper.slideTo(index - 1);
      this.chaIndex = index;
      this.chaFadeOut[index - 2] = true;
    },
    // 左右按钮切换游戏特色轮播图
    changeFea(e) {
      if (e.target.className.indexOf("change") == -1) {
        e.target.className == "btn_prevFea"
          ? this.feaSwiper.slidePrev()
          : this.feaSwiper.slideNext();
      }
    },
    toOrder() {},
    getGift() {},
    // 控制弹框
    controlMask(n) {
      if (n == 0) {
        // 关闭弹出框
        this.isShowMask = false;
        if (!this.timer) {
          // 没有正在获取验证码
          this.orderMsg.phoneNum = "";
          this.codeMsg = "发送验证码";
        }
        if (!this.timer1) {
          this.orderMsg.emailNum = "";
          this.codeMsg1 = "发送验证码";
        }
        this.orderMsg.phoneCode = "";
        this.orderMsg.emailCode = "";
      } else if (n == 1) {
        // 显示弹出框
        // this.isPhoneOrder = true;
        // this.isEmailOrder = false;
        // this.isShareModule = false;
        if (!this.isInvalid) {
          if (this.msg) {
            this.msg.close();
          }
          this.$message.info("预约已结束");
          return;
        }
        if (this.isOrder) {
          this.isOrder = false;
          this.isPhoneOrder = true;
        }
        this.isShowMask = true;
      } else if (n == 2) {
        // 切换邮箱预约
        this.isPhoneOrder = false;
        this.isEmailOrder = true;
      } else if (n == 3) {
        // 切换手机号预约
        this.isPhoneOrder = true;
        this.isEmailOrder = false;
      }
    },

    // 切换预约方式
    changeOrderWay() {},
    // 确认预约
    // 1手机号 2邮箱号
    toMakeSure(n) {
      if (this.checkNum(n) && this.checkCode(n)) {
        const time = Date.now();
        const { project_id } = this;
        const touser = n == 1 ? this.orderMsg.phoneNum : this.orderMsg.emailNum;
        const code = n == 1 ? this.orderMsg.phoneCode : this.orderMsg.emailCode;
        const dev = this.isiOS ? 1 : 2;
        const type = this.isPhoneOrder ? 1 : 2;
        const fcode = this.orderMsg.inviteCode;
        const params = { time, project_id, touser, code, dev, type, fcode };
        const headers = { time, touser, code, project_id };
        appoint(params, headers).then((res) => {
          if (res.status == 1) {
            // 预约成功
            if (this.msg) {
              this.msg.close();
            }
            this.msg = this.$message.success("预约成功");
            if (n == 1) {
              clearInterval(this.timer);
              this.codeMsg = "发送验证码";
              this.timer = null;
              this.orderMsg.phoneNum = "";
              this.orderMsg.phoneCode = "";
            } else {
              clearInterval(this.timer1);
              this.codeMsg1 = "发送验证码";
              this.timer1 = null;
              this.orderMsg.emailNum = "";
              this.orderMsg.emailCode = "";
            }
            // 获取预约人数
            this.getAppointNum();
            this.isPhoneOrder = this.isEmailOrder = false;
            this.isOrder = true;
          } else if (res.status == 0) {
            // 验证码错误
            if (this.msg) {
              this.msg.close();
            }
            this.msg = this.$message.error("验证码错误，请重新输入");
          } else {
            // 已预约
            if (this.msg) {
              this.msg.close();
            }
            this.msg = this.$message.info(res.msg);
            if (n == 1) {
              clearInterval(this.timer);
              this.codeMsg = "发送验证码";
              this.timer = null;
              // this.orderMsg.phoneNum = "";
              // this.orderMsg.phoneCode = "";
            } else {
              clearInterval(this.timer1);
              this.codeMsg1 = "发送验证码";
              this.timer1 = null;
              // this.orderMsg.emailNum = "";
              // this.orderMsg.emailCode = "";
            }
          }
        });
      }
    },
    // 获取验证码 1手机号 2邮箱
    getCode(n) {
      const time = Date.now();
      if (n == 1 && (this.timer || !this.isGetCode)) {
        return;
      }
      if (n == 2 && (this.timer1 || !this.isGetCode1)) {
        return;
      }
      if (this.checkNum(n)) {
        if (n == 1) {
          // 手机号
          this.isGetCode = false;
          sendCode(this.orderMsg.phoneNum).then((res) => {
            if (res.status == 1) {
              if (this.msg) {
                this.msg.close();
              }
              this.msg = this.$message.success(res.msg);
              let num = 60;
              this.timer = setInterval(() => {
                this.codeMsg = `${num}s后重新发送`;
                num--;
                if (num === 0) {
                  this.codeMsg = "重新发送";
                  clearInterval(this.timer);
                  this.timer = null;
                }
              }, 1000);
            } else {
              if (this.msg) {
                this.msg.close();
              }
              this.msg = this.$message.info(res.msg);
            }
            this.isGetCode = true;
          });
        } else {
          this.isGetCode1 = false;
          const params = { time, email: this.orderMsg.emailNum };
          sendMail(params, { time }).then((res) => {
            if (res.status == 1) {
              if (this.msg) {
                this.msg.close();
              }
              this.msg = this.$message.success(res.msg);
              let num = 60;
              this.timer1 = setInterval(() => {
                this.codeMsg1 = `${num}s后重新发送`;
                num--;
                if (num === 0) {
                  this.codeMsg1 = "重新发送";
                  clearInterval(this.timer1);
                  this.timer1 = null;
                }
              }, 1000);
            } else {
              if (this.msg) {
                this.msg.close();
              }
              this.msg = this.$message.info(res.msg);
            }
            this.isGetCode1 = true;
          });
        }
      }
    },
    // 判断1手机号/2邮箱号是否合规
    checkNum(n) {
      const text = [
        "请输入手机号",
        "请输入邮箱号",
        "请输入正确的手机号",
        "请输入正确的邮箱号",
      ];
      const num = n == 1 ? this.orderMsg.phoneNum : this.orderMsg.emailNum;
      const way = n == 1 ? validatePhone : validateEmail;
      try {
        if (!num) throw text[n - 1];
        if (!way(num)) throw text[n + 1];
      } catch (err) {
        if (this.msg) {
          this.msg.close();
        }
        this.msg = this.$message.info(err);
        return false;
      }
      return true;
    },
    // 判断1手机号/2邮箱号的验证码是否合规
    checkCode(n) {
      const code = n == 1 ? this.orderMsg.phoneCode : this.orderMsg.emailCode;
      try {
        if (!code) throw "请输入验证码";
        if (code.length !== 6) throw "请输入6位数验证码";
      } catch (err) {
        if (this.msg) {
          this.msg.close();
        }
        this.msg = this.$message.info(err);
        return false;
      }
      return true;
    },
    // 控制角色音频 参数角色id
    controlVoice(id) {
      this.audioList.forEach((e) => {
        if (e != 0) {
          e.pause();
          e.currentTime = 0;
        }
      });
      this.audioList[id].play();
    },
    // 获取预约人数
    getAppointNum() {
      const time = Date.now();
      getAppointNum({ time }, { time }).then((res) => {
        if (res.status == 1) {
          this.orderSum = res.data;
        } else {
          this.$message.info(res.msg);
        }
      });
    },
    // 获取点击的轮播图页码
    handleClickSlide(swiper) {
      let index;
      let temp = swiper.clickedIndex - swiper.activeIndex + swiper.realIndex;
      if (temp < 0) {
        index = 4;
      } else if (temp > 4) {
        index = 0;
      } else {
        index = temp;
      }
      return index;
    },
    test() {
      alert(0);
    },
  },
  mounted() {
    this.audioList = [
      0,
      0,
      this.$refs.audio2,
      this.$refs.audio3,
      this.$refs.audio4,
      this.$refs.audio5,
    ];
    window.addEventListener("resize", () => {
      // 设置最小高度
      // this.innerHeight = window.innerHeight > 675?window.innerHeight:675;
      this.innerHeight = window.innerHeight;
    });
    const time = Date.now();
    const { project_id } = this;
    // 获取活动时间
    getActivityTime({ time, project_id }, { time, project_id }).then((res) => {
      if (compareTime(getNowFormatDate(), res.data.end_time)) {
        // 有效期
        this.isInvalid = false;
      }
      // 当前时间
      // console.log(getNowFormatDate())
    });
    // 获取预约人数
    this.getAppointNum();
  },
};
</script>
<style lang="scss" scoped>
.pcContainer{
    // width:100%;
    // height: 100vh;
//   min-width: 1200px;
//   height: 100vh;
//   min-height:675px;
  // display: flex;
  // justify-content: center;
  // align-items: center;
}
.pcIndex {
  width:100%;
  min-width: 1200px;
  // height: 100vh;
  // min-height: 675px;
  // overflow: hidden;
  // min-width: 1200px;
  .navbar{
    width: 100%;
    height: 0.4rem;
    min-width: 1200px;
    display: flex;
    // 主轴对齐方式（主轴默认横的）
    justify-content: flex-end;
    align-items: center;
    position: fixed;
    top: 0;
    left: 0;
    background-color: #fff;
    border-bottom: 1px solid #CCBD9F;
    z-index: 2;
    transition: 1s;
    ul{
      height: 100%;
      display: flex;
      margin-right: 0.5rem;
      // 规定主轴横的
      // flex-direction: row;
      li{
          height: 100%;
          // line-height: 0.45rem;
          display: flex;
          // 交叉轴（竖的）对齐方式 
          align-items: center;
          font-size: 0.11rem;
          margin: 0 0.2rem;
          cursor: pointer;
          transition: all 0.3s;
        }
    }
    // .btn_order{
    //   width: 0.7rem;
    //   height: 0.19rem;
    //   margin: 0.05rem 0.5rem 0 0;
    //   background-image: imgUrl("btn_order.png");
    //   cursor: pointer;
    // }
  }
  .body_swiper {
    width: 100%;
    // 再小宽度不够了
    // min-width: 1704px;
    height: 100%;
    // min-height: 959px;
    // 宽度小于1704px
    @media screen and (max-width: 1704px){
      .body_slide{
        // width: 10;
      }
    }
    // 宽度大于1704 
    @media screen and(min-width:1704px) {
      
    }
    .body_slide {
      display: flex;
      background-size:  100% auto;
      // background-position: center;
      // 宽度大于1704px 满足宽度
      // @media screen and(min-width:1704px){
      //   background-size: 100% auto;
      // }
      // 小于1704则 
      .slide_bg{
          position: absolute;
          height: 100%;
          width: auto ;
          min-width: 100vw;
          object-fit:cover;
          z-index: -1;
        }
      &:nth-of-type(1){
        position: relative;
        .btn_tip{
          width: 1.1rem;
          height: 0.46rem;
          position: absolute;
          bottom: 0.6rem;
          right:0;
          background-image: imgUrl("btn_tip.png");
          animation: btnTip-run 0.5s infinite;
          animation-direction:alternate;
          cursor: pointer;
        }
        @keyframes btnTip-run {
          0%{
            right:0rem;
          }
          100%{
            right:0.2rem;
          }
        }
      }
      // 第二页
      &:nth-of-type(2){
        // background-image: imgUrl("order_bg.png");
        flex-direction: column;
        position: relative;
        .order_title{
            width: 2.5rem;
            height: 0.55rem;
            // margin: 0.8rem 0 0 0;
            background-image: imgUrl("order_title.png");
        }
        .order_num{
            width: 80%;
            display: flex;
            justify-content: flex-start;
            align-items: flex-start;
            @include SourceHanSerifCN-Bold;
          b{
              width: 0.8rem;
              display: inline-block;
              position: relative;
              top:-0.02rem;
              left: 0.04rem;
              margin:0 0.05rem 0 0;
              font-size: 0.21rem;
              font-style: italic;
              color: rgba(141, 127, 111, 1);
              text-align: left;
            }
          div{
            // 已预约背景
            &:nth-of-type(1){
              width: 1rem;
              height: 0.5rem;
              background-image: imgUrl("order_num_bg.png");
            }
            
            // 已预约人数
            &:nth-of-type(2){
              margin: 0 0 0 -1.5rem;
              align-self: flex-end;
              letter-spacing: 0.01rem;
              span{
                font-size: 0.14rem;
                background: linear-gradient(0deg, #E1BD8D  0%, #BAA687 100%); //为文本元素提供渐变背景
                -webkit-background-clip: text; //使用透明颜色填充文本
                -webkit-text-fill-color: transparent; //用文本剪辑背景，用渐变背景作为颜色填充文本
                &:nth-of-type(2){
                  font-size: 0.23rem;
                }
              }
            }
          }
        }
        .order_milepost{
          width: 59%;
          height: 1.12rem;
          display: flex;
          justify-content: space-between;
          background-image: imgUrl("order_milepost1.png");
          span{
            width: 0.26rem;
            height: 0.26rem;
            display: block;
            background-image: imgUrl("no-reach.png");
            &.reach{
              width: 0.23rem;
              height: 0.3rem;
              background-image: imgUrl("reach.png");
            }
            &:nth-of-type(1){
              margin: 0.45rem 0 0 -0.05rem;
            }
            &:nth-of-type(2){
              margin: 0.7rem 0 0 0;
            }
            &:nth-of-type(3){
              margin: -0.09rem 0 0 0;
            }
            &:nth-of-type(4){
              margin: 0.67rem 0 0 0;
            }
            &:nth-of-type(5){
              margin: 0.06rem  -0.05rem 0 0;
            }
            // 未达到
            &.no_reach{
              width: 0.35rem;
              height: 0.35rem;
              background-image: imgUrl("no-reach.png");
            }
          }
        }
        .order_prize{
          width: 70%;
          height: 1.5rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
          // 每个礼品框
          & > div{
            display: flex;
            flex-direction: column;
            align-items: center;
            // 图片
            .prize_img{
              width: 1.15rem;
              height: 1.5rem;
            }
            &.order_prize1{
              margin:-0.4rem 0 0 0;
            }
            &.order_prize2{
              margin: 0.04rem 0 0 0;
            }
            &.order_prize3{
              margin: -1.6rem 0 0 0;
            }
            &.order_prize4{
              margin: -0.2rem 0 0 0;
            }
            &.order_prize5{
              margin: -1.3rem 0 0 0;
            }
            .prize_desc{
              width: 1rem;
              height: 0.84rem;
              margin: -0.2rem 0 0 0;
              display: flex;
              flex-direction: column;
              justify-content: center;
              font-size: 0.15rem;
              color: #887865;
              line-height: 0.19rem;
              @include SourceHanSansCN-Regular;
              &.reach{
                // background-image: imgUrl("get.png");
              }
              span:nth-of-type(2){
                @include SourceHanSansCN-Normal;
              }
            }
            
          }
          
        }
        .btn_order{
          width: 1.2rem;
          height: 0.33rem;
          // margin: 0.05rem 0.5rem 0 0;
          background-image: imgUrl("btn_order1.png");
          cursor: pointer;
          &.no_invalid{
             // 背景图变灰
            filter: grayscale(100%);
          }
        }
        // .btn_getGift{
        //   width: 0.9rem;
        //   height: 0.24rem;
        //   background-image:imgUrl("btn_getGift.png");
        //   cursor: pointer;
        // }
      }
      // 第三页
      &:nth-of-type(3){
        // background-image: imgUrl("worldView_bg.png");
        flex-direction: column;
        .worldView_title{
          width: 2rem;
          height: 0.8rem;
          // margin: 0.7rem 0 0 0;
          background-image: imgUrl("worldView_title.png");
        }
        .worldView_desc{
          @include SourceHanSerifCN-Medium;
          span{
            display: block;
            color: rgba(114, 113, 118, 1);
            font-size: 0.13rem;
            line-height: 0.27rem;
            &:nth-of-type(1){
              margin: 0.15rem 0 0.2rem 0;
            }
            &:nth-of-type(2){
              margin: 0 0 0.2rem 0;
            }
            &:nth-of-type(3){
              margin: 0 0 0.2rem 0;
            }
          }
        }
      }
      // 第四页
      &:nth-of-type(4){
        // background-image: imgUrl("characterIntro_bg.png");
        .character_swiper{
          width: 7rem;
          height: 4rem;
          margin: 0.3rem 0 0 0;
          .swiper-slide{
            width: 100%;
            height: 100%;
            display: flex;
            flex-wrap: wrap;
            &.fadeOut{
              .cha_name,
              .cha_desc{
                left: -0.4rem;
              }
            }
            &.swiper-slide-active{
              .cha_name,
              .cha_desc{
                left: 0;
              }
              .cha_img{
                .cha{
                  // top:0rem;
                }
              }
            }
            &.swiper-slide-next{
              .cha_img{
                .cha{
                  // top:0.4rem;
                }
              }
            }
            
            .cha_name{
              width: 2rem;
              height: 1rem;
              display: flex;
              justify-content: flex-end;
              position: relative;
              left: 0.4rem;
              margin: 0.7rem 0 0 1.3rem;
              transition: all 0.3s;
              .cha_voice{
                  width: 0.35rem;
                  height: 0.35rem;
                  position: relative;
                  top:-0.2rem;
                  left: 0.2rem;
                  display: block;
                  background-image: imgUrl("voice1.png");
                  cursor: pointer;
                }
            }
            .cha_img{
              width: 3.5rem;
              height: 3.385rem;
              display: flex;
              align-items: flex-end;
              margin: 0.4rem 0 0 0;
              background-image: imgUrl("chaImg_bg.png");
              div{
                width: 87%;
                height:87%;
                display: flex;
                align-items: flex-end;
                margin: 0 0 0.17rem 0.1rem;
                border-bottom-left-radius: 50%;
                border-bottom-right-radius: 50%;
                .cha{
                  width: 3.05rem;
                  position: relative;
                  // top:0rem;
                  transition: all 0.6s;
                  z-index: 2;
                }
              }
            }
            .cha_desc{
              width: 2.2rem;
              height: 1.13rem;
              position: relative;
              left: 0.4rem;
              display: flex;
              flex-direction: column;
              align-items: flex-start;
              margin: -2.26rem 0 0 1.7rem;
              transition: all 0.3s;
              // background-image: imgUrl("chaDesc_bg.png");
              @include SourceHanSerifCN-Medium;
              span{
                width: 100%;
                display: inline-block;
                text-align: left;
                color: #BFAB90;
                font-size: 0.13rem;
                margin: 0.1rem 0 0 0;
              }
              div{
                width: 95%;
                text-align: left;
                margin: 0.2rem 0 0 0;
                font-size: 0.16rem;
                color: #BFAB90;
                line-height: 0.24rem;
                @include SourceHanSerifCN-SemiBold;
              }
            }
          }
        }
        .character_nav{
          display: flex;
          flex-direction: column;
          position: relative;
          left: 0.3rem;
          span{
            width: 1rem;
            height: 0.3rem;
            display: flex;
            align-items: center;
            justify-content: center;
            color:#D3BC8F;
            font-size:0.1rem;
            cursor: pointer;
            transition: all 0.3s;
            @include SourceHanSerifCN-SemiBold;
            &.active{
              color: #A38558;
              font-size: 0.15rem;
              z-index: 2;
              @include SourceHanSerifCN-Bold;
            }
          }
          .cha_pointer{
            width: 0.6rem;
            height: 0.4rem;
            position: absolute;
            top:-0.05rem;
            left:0.55rem;
            background-image: imgUrl("cha_pointer.png");
            transition: all 0.3s;
          }
        }
      }
      // 第五页
      &:nth-of-type(5){
        // background-image: imgUrl("gameFeatures_bg.png");
        .letter_bg{
          width: 1.3rem;
          height: 1.15rem;
          position: absolute;
          bottom: 0;
          right:0.5rem;
          background-image: imgUrl("letter_bg.png");
          z-index: 2;
        }
        .gameFeatures_title{
          width: 1.6rem;
          height: 2.1rem;
          margin: 0 0 0 1.5rem;
          background-image: imgUrl("gameFeatures_title.png");
        }
        .feaSwiper_container{
          position: relative;
          .feature_swiper{
            width: 6rem;
            height: 3.93rem;
            margin: 0.4rem 0 0 1rem;
            /deep/ .swiper-wrapper{
              margin: 0 0 0 -0.37rem;
              .swiper-slide{
                width: 2.25rem;
                height: 3.85rem;
                border:0.03rem solid #CFA972;
                opacity: 0;
                background-color: #fff;
                cursor: pointer;
                transition: all 3s;
                .maskbox{
                    background-color: #624F46;
                    opacity: 0.6;
                  }
                &.swiper-slide-prev,
                &.swiper-slide-active,
                &.swiper-slide-next,
                &.swiper-slide-next + .swiper-slide{
                  opacity: 1;
                }
                &.swiper-slide-active{
                  .maskbox{
                    opacity: 0;
                  }
                }
                .border{
                  width: 2.15rem;
                  height: 3.75rem;
                  border: 1px solid #F8CD8C;
                  div{
                    width: 2.07rem;
                    height: 3.69rem;
                    // background-image: imgUrl("feature1.png");
                  }
                }
              }
            }
          }
          .btn_changeFea{
            display: flex;
            position: absolute;
            top: 50%;
            left: 0;
            transform: translate(0,-35%);
            z-index: 2;
            pointer-events: none;
            div{
              width: 0.5rem;
              height: 0.5rem;
              background-image: imgUrl("btn_changeFeature.png");
              pointer-events: all;
              cursor: pointer;
            }
            .btn_prevFea{
              margin:0 0 0 0.5rem;
            }
            .btn_nextFea{
              margin: 0 0 0 4.5rem;
              transform: rotateY(180deg);
            }
          }
        }
        
      }
    }
  }
  .maskbox{
    opacity: 0;
    pointer-events: none;
    transition: all 0.3s;
    &.showMask{ 
      opacity: 1;
      pointer-events: all;
    }
    .mask_board{
      width: 2.78rem;
      height: 2.86rem;
      display: flex;
      flex-direction: column;
      // justify-content: center;
      align-items: center;
      position: relative;
      background-image: imgUrl("mask_board.png");
      .btn_close{
        width: 0.31rem;
        height: 0.31rem; 
        position: absolute;
        top: -0.2rem;
        right: -0.2rem;
        background-image: imgUrl("btn_close.png"); 
        cursor: pointer;
      }
      img{
        width: auto;
        height:0.3rem;
        // margin:0.4rem 0 0 0;
      }
      .phoneForm{
        display: flex;
        flex-direction: column;
        align-items: center;
        margin: 0.4rem 0 0 0;
        // 手机型号
        .radioGroup{
          width: 70%;
          display: flex;
          justify-content: space-around;
          margin:0.2rem 0 0.2rem 0;
          .radio{
            display: flex;
            justify-content: center;
            cursor: pointer;
             &.choose {
              span {
                opacity: 1;
              }
            }
            div {
              width: 0.06rem;
              height: 0.06rem;
              margin: 0 0.05rem 0 0;
              // display: flex;
              // justify-content: center;
              // align-items: center;
              position: relative;
              border: 0.01rem solid #D3BA8B;
              border-radius: 50%;
              span {
                width: 0.03rem;
                height: 0.03rem;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%,-50%);
                background-color: #D3BA8B;
                border-radius: 50%;
                opacity: 0;
              }
            }
          }
        }
        // 手机号
        .input {
          width: 1.5rem;
          height: 0.18rem;
          line-height: 0.18rem;
          padding: 0 0.1rem;
          border: 0.001rem solid #D3BA8B;;
          color: #636363;
          font-size: 0.07rem;
          &::-webkit-input-placeholder {
            /* WebKit browsers */
            color: #636363;
          }
          &:-moz-placeholder {
            /* Mozilla Firefox 4 to 18 */
            color: #636363;
          }
          &::-moz-placeholder {
            /* Mozilla Firefox 19+ */
            color: #636363;
          }
          &:-ms-input-placeholder {
            /* Internet Explorer 10+ */
            color: #636363;
          }
        }
        // 验证码
        .codeGroup {
          width: 1.5rem;
          margin: 0 0 0.3rem 0;
          display: flex;
          flex-direction: row;
          margin: 0.15rem 0 0 0;
          .phoneCode {
            width: 1rem;
            border-right: none;
          }
          .getCode {
            width: 0.5rem;
            height: 0.18rem;
            line-height: 0.18rem;
            font-size: 0.07rem;
            text-align: center;
            color: #fff;
            background-color: #D3BA8B;
            cursor: pointer;
          }
        }
        // 邀请码
        .inviteCode{
          margin:0.1rem 0 0 0;
        }
        .btn_makeSure{
          width: 1rem;
          height: 0.28rem;
          background-image: imgUrl("btn_makeSure.png");
          margin: 0.3rem 0 0 0;
          cursor: pointer;
        }
        .changeOrderWay{
          margin:0.1rem 0 0 0;
          font-size: 0.08rem;
          color: #6D70A8; 
          text-decoration: underline;
          cursor: pointer;
        }
      }
      .emailForm{
        display: flex;
        flex-direction: column;
        align-items: center;
        margin: 0.4rem 0 0 0;
        // 手机型号
        .radioGroup{
          width: 70%;
          display: flex;
          justify-content: space-around;
          margin:0.2rem 0 0.2rem 0;
          .radio{
            display: flex;
            justify-content: center;
            cursor: pointer;
             &.choose {
              span {
                opacity: 1;
              }
            }
            div {
              width: 0.06rem;
              height: 0.06rem;
              margin: 0 0.05rem 0 0;
              // display: flex;
              // justify-content: center;
              // align-items: center;
              position: relative;
              border: 0.01rem solid #D3BA8B;
              border-radius: 50%;
              span {
                width: 0.03rem;
                height: 0.03rem;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%,-50%);
                background-color: #D3BA8B;
                border-radius: 50%;
                opacity: 0;
              }
            }
          }
        }
        // 手机号
        .input {
          width: 1.5rem;
          height: 0.18rem;
          line-height: 0.18rem;
          padding: 0 0.1rem;
          border: 0.001rem solid #D3BA8B;;
          color: #636363;
          font-size: 0.07rem;
          &.emailNum{
            margin: 0.3rem 0 0 0;
          }
          &::-webkit-input-placeholder {
            /* WebKit browsers */
            color: #636363;
          }
          &:-moz-placeholder {
            /* Mozilla Firefox 4 to 18 */
            color: #636363;
          }
          &::-moz-placeholder {
            /* Mozilla Firefox 19+ */
            color: #636363;
          }
          &:-ms-input-placeholder {
            /* Internet Explorer 10+ */
            color: #636363;
          }
        }
        // 验证码
        .codeGroup {
          width: 1.5rem;
          margin: 0 0 0.3rem 0;
          display: flex;
          flex-direction: row;
          margin: 0.15rem 0 0 0;
          .emailCode {
            width: 1rem;
            border-right: none;
          }
          .getCode {
            width: 0.5rem;
            height: 0.18rem;
            line-height: 0.18rem;
            font-size: 0.07rem;
            text-align: center;
            color: #fff;
            background-color: #D3BA8B;
            cursor: pointer;
          }
        }
        // 邀请码
        .inviteCode{
          margin:0.1rem 0 0 0;
        }
        .btn_makeSure{
          width: 1rem;
          height: 0.28rem;
          background-image: imgUrl("btn_makeSure.png");
          margin: 0.3rem 0 0 0;
          cursor: pointer;
        }
        .changeOrderWay{
          margin:0.1rem 0 0 0;
          font-size: 0.08rem;
          color: #6D70A8; 
          text-decoration: underline;
          cursor: pointer;
        }
      }
      .shareModule{
        width: 100%;
        margin:0.4rem 0 0 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        .myInviteNum{
          font-size:0.11rem;
          color:#6F6254;
          // @include SourceHanSerifCN-Bold ;
          span{
            &:nth-of-type(1){
              color: #A58343;
            }
            &:nth-of-type(2){
              cursor: pointer;
            }
          }
        }
        .way1{
          width: 100%;
          display: flex;
          flex-direction: column;
          align-items: center;
          // 标题
          span{
            width: 65%;
            display: block;
            margin: 0.16rem 0 0 0;
            color: #6F6254;
            font-size: 0.08rem;
            text-align: left;
            // @include SourceHanSerifCN-Bold ;
            &:last-of-type{
              font-size: 0.08rem;
              color: #D3BA8B;
              margin: 0.1rem 0 0 0;
              font-family: "SourceHanSerifCN-Regular";
            }
          }
          .website{
            display: flex;
            justify-content: center;
            margin:0.2rem 0 0 0;
            div{
              width: 1.2rem;
              height: 0.218rem;
              padding-left: 0.1rem;
              line-height:0.2rem;
              text-align: left;
              font-family: "SourceHanSerifCN-Regular";
              font-size: 0.08rem;
              font-weight: 400;
              color: #636363;
              background-color: #fff;
              border:1PX solid #D3BA8B;
              overflow:hidden;
            }
            span{
              width: 0.6rem;
              height: 0.23rem;
              display: block;
              text-align: center;
              margin: -0.005rem 0 0 -0.01rem;
              line-height: 0.21rem;
              color:#fff;
              background-color: #D3BA8B;
              cursor: pointer;
            }
          }
        }
        .way2{
          width: 100%;
          display: flex;
          flex-direction: column;
          align-items: center;
          // 标题
          span{
            width: 65%;
            display: block;
            margin: 0.15rem 0 0 0;
            color: #6F6254;
            font-size: 0.08rem;
            text-align: left;
            // @include SourceHanSerifCN-Bold ;
          }
          div{
           width: 0.82rem;
           height: 0.82rem;
           margin:0.13rem auto 0;
           background-color: #fff;
           border: 1PX solid #C3AB7D;
           .shareCode{
             width:0.8rem !important;
             height: 0.8rem !important;
             margin: auto;
           }
          }
        }
      }
      .ordered{
        width: 100%;
        height: 100%;
        font-size: 0.2rem;
        color:#D3BA8B;
      }
    }
  }
}
</style>
