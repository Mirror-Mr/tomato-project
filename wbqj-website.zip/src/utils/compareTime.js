// 比较时间（yyyy-MM-dd HH:mm:ss）
export function compareTime(startTime, endTime) {
  var startTimes = startTime.substring(0, 10).split("-");
  var endTimes = endTime.substring(0, 10).split("-");
  startTime =
    startTimes[1] +
    "-" +
    startTimes[2] +
    "-" +
    startTimes[0] +
    " " +
    startTime.substring(10, 19);
  endTime =
    endTimes[1] +
    "-" +
    endTimes[2] +
    "-" +
    endTimes[0] +
    " " +
    endTime.substring(10, 19);
  var thisResult = (Date.parse(endTime) - Date.parse(startTime)) / 3600 / 1000;
  if (thisResult < 0) {
    //   有效期
    return true;
  } else if (thisResult > 0) {
    //   时间过了
    return false;
  } else if (thisResult == 0) {
    //   时间正好
    return true;
  } else {
    //   异常
    return false;
  }
}

// 获取当前时间（yyyy-MM-dd HH:mm:ss）
export function getNowFormatDate() {
  var date = new Date();
  var seperator1 = "-";
  var seperator2 = ":";
  var month = date.getMonth() + 1;
  var strDate = date.getDate();
  if (month >= 1 && month <= 9) {
    month = "0" + month;
  }
  if (strDate >= 0 && strDate <= 9) {
    strDate = "0" + strDate;
  }
  var currentdate =
    date.getFullYear() +
    seperator1 +
    month +
    seperator1 +
    strDate +
    " " +
    date.getHours() +
    seperator2 +
    date.getMinutes() +
    seperator2 +
    date.getSeconds();
  return currentdate;
}
