import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
// 初始化页面样式
import '@/assets/style/reset.scss'
// 全局样式
import '@/assets/style/common.scss'
// rem
import "@/utils/flexible";
// swiper
import VueAwesomeSwiper from 'vue-awesome-swiper';
import 'swiper/dist/css/swiper.css'
import { Message } from 'element-ui';
import {Toast} from 'vant';

Vue.prototype.$message = Message;
Vue.prototype.$toast = Toast;
Vue.use(VueAwesomeSwiper)

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
