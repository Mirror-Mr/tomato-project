// 接口
import { post, get } from '@/utils/request';

const baseUrl = "/activity/Wbqj_appoint";

// 获取活动时间
export function getActivityTime(params,headers){
    return get(baseUrl + "/getActivityTime",params,headers);
}

// 预约
export function appoint(params,headers){
    return post(baseUrl + "/appoint",params,headers);
}

// 获取预约数
export function getAppointNum(params,headers){
    return get(baseUrl + "/getAppointNum",params,headers);
}

// 获取邀请数
export function getVisitNum(params,headers){
    return get(baseUrl + "/get_visit_num",params,headers);
}

// 发送邮件
export function sendMail(params,headers){
    return post(baseUrl + "/send_mail",params,headers); 
}