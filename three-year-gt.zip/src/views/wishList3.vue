<template lang="pug">
.wish3
  LoginStatus(ref="login")
  //- 左右按钮和swiper需要在容器外，所以加一层盒子
  .swiper-container__wapper
    .rule(@click="ruleDialog = true") [活動規則]
    .swiper-container
      .swiper-wrapper
        .swiper-slide(v-for="(item,index) in clothingList", :key="item.id")
          .clothing-name
            .name-text {{item.name}}
          img(:src="item.img")
      .clothing-front
      .clothing-tips 選擇一套您喜歡的往期套裝購買
    .swiper-button-prev
    .swiper-button-next
  //- 分页器单独在一个盒子
  .swiper-pagination
  .ensure-btn(@click="ensure"  :class="{'gray': isPay}") 
    .btn-text 
      p {{  isPay ? '已購買' : 'NT$1490' }}
      p.discount 三週年感恩優惠價
  .limit 限購 {{  isPay ? 1 : 0 }}/1次
  //- 确认弹框
  Mymodal(:show="dialog" @close="close" @sure="sure" surebtn :canclebtn="!isPayCallBack")
    .msg-box
      p {{ msg }}
      p {{ msg1 }}
  Mymodal(:show="ruleDialog", @close="close", @sure="close", surebtn)
    .msg-box1
      p 1. 活動時間：2021年12月24日-2022年1月6日。
      p 2. 活動期間，可從獎 池中選擇一套心儀的服裝（11選1）進行購買。
      p 3. 心願服裝每位用戶限購一次。
      p 4. 最終解釋權歸《紫禁繁花》官方團隊所有。
      p.tips * 服裝購買後，該活動內其他服裝將不可再次購買，請小主們認真挑選哦~
</template>

<script type="text/javascript">
import Swiper from "swiper";
import "swiper/dist/css/swiper.min.css";
import { pay, getOrderStatus, clickLog } from "@/request/api.js";
import { mapState } from "vuex";
import { debounce, getQueryValue, isWeChat } from "@/utils/index";
export default {
  name: "wishList1",
  data() {
    return {
      dialog: false,
      isDisable: true,
      swiper: null,
      clothingList: [
        {
          id: 1,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/wishList/clothing/1.jpg",
          name: "綺羅套裝",
          mainlandPrice: 328,
          hkAndMacaoPrice: 1490,
          kind: 95
        },
        {
          id: 2,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/wishList/clothing/2.jpg",
          name: "點絳唇",
          mainlandPrice: 328,
          hkAndMacaoPrice: 1490,
          kind: 95
        },
        {
          id: 3,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/wishList/clothing/3.jpg",
          name: "金宵折枝",
          mainlandPrice: 328,
          hkAndMacaoPrice: 1490,
          kind: 95
        },
        {
          id: 4,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/wishList/clothing/4.jpg",
          name: "風華絕代",
          mainlandPrice: 328,
          hkAndMacaoPrice: 1490,
          kind: 95
        },
        {
          id: 5,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/wishList/clothing/5.jpg",
          name: "粉黛",
          mainlandPrice: 328,
          hkAndMacaoPrice: 1490,
          kind: 95
        },
        // {
        //   id: 6,
        //   img:
        //     "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/wishList/clothing/6.jpg",
        //   name: "霓裳玉容",
        //   mainlandPrice: 328,
        //   hkAndMacaoPrice: 1490,
        //   kind: 95
        // },
        {
          id: 7,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/wishList/clothing/7.jpg",
          name: "驪黃彌霓",
          mainlandPrice: 328,
          hkAndMacaoPrice: 1490,
          kind: 95
        },
        {
          id: 8,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/wishList/clothing/8.jpg",
          name: "帝青空闊",
          mainlandPrice: 328,
          hkAndMacaoPrice: 1490,
          kind: 95
        },
        {
          id: 9,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/wishList/clothing/9.jpg",
          name: "金陵意氣",
          mainlandPrice: 328,
          hkAndMacaoPrice: 1490,
          kind: 95
        },
        {
          id: 10,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/wishList/clothing/10.jpg",
          name: "彼岸花",
          mainlandPrice: 328,
          hkAndMacaoPrice: 1490,
          kind: 95
        },
        {
          id: 11,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/wishList/clothing/11.jpg",
          name: "芷畫",
          mainlandPrice: 328,
          hkAndMacaoPrice: 1490,
          kind: 95
        }
      ],
      currentClothing: 1,
      msg: "購買完成後，其它服裝將不可購買。",
      msg1: "是否確認購買？",
      isPayCallBack: false,
      ruleDialog: false
    };
  },
  methods: {
    initSwiper() {
      let that = this;
      this.swiper = new Swiper(".swiper-container", {
        loop: true, // 循环模式选项
        slidesPerView: "auto",
        autoplay: 1000,
        pagination: {
          el: ".swiper-pagination",
          clickable: true
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev"
        },
        observer: true,
        observeParents: true,
        on: {
          slideChangeTransitionStart: function() {
            // 港澳的服装第6套不上架了，所以需要单独处理
            if (this.realIndex + 1 >= 6) {
              that.currentClothing = this.realIndex + 2;
            } else {
              that.currentClothing = this.realIndex + 1;
            }
            console.log(that.currentClothing);
          }
        }
      });
    },
    ensure() {
      if (this.userInfo) {
        // 测试
        if (this.isPay) return;
        this.dialog = true;
        let time = parseInt(new Date().getTime());
        let access = this.$encrypte([time]);
        // 打开弹窗就打点
        clickLog({
          time,
          access,
          type: 6,
          extra: "",
          state: 1
        });
      } else {
        this.$refs.login.showlogin();
      }
    },
    close() {
      this.dialog = false;
      this.ruleDialog = false;
    },
    sure: debounce(async function() {
      // 支付成功回调逻辑
      if (this.isPayCallBack) {
        this.dialog = false;
        return;
      } else {
        this.msg = "購買完成後，其它服裝將不可購買。";
        this.msg1 = "是否確認購買？";
      }
      // 支付逻辑
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token]);
      let wxid = "";
      if (isWeChat()) {
        wxid = sessionStorage.getItem("wxid");
      }
      try {
        const data = await pay({
          time,
          token,
          good_id: this.currentClothing + "",
          num: "1",
          access,
          wxid
        });
        // 调起支付
        if (data) {
          localStorage.setItem("orderId", data.orderid);
          console.log(data.url);
          location.href = data.url;
        }
      } catch (err) {
        console.log("err", err);
        this.$toast("購買失敗");
      }
    }),
    // 获取订单状态
    getOrderStatus() {
      let time = parseInt(new Date().getTime());
      const orderid = localStorage.getItem("orderId");
      if (!orderid) {
        return;
      }
      let access = this.$encrypte([time, orderid]);
      return new Promise(resolve => {
        getOrderStatus({
          time,
          orderid,
          access
        }).then(res => {
          resolve(res);
        });
      });
    },
    // 是否支付成功
    async isPaySuccess() {
      const str = location.href.split("?")[1];
      if (str) {
        const orderid = str.split("=")[1];
        if (orderid) {
          const value = sessionStorage.getItem(`${orderid}`);
          if (!value) {
            const data = await this.getOrderStatus();
            if (data?.status > 0) {
              // 支付成功，将orderid 存入sessionStorage中， 避免用户刷新次页面时再次弹窗
              sessionStorage.setItem(`${orderid}`, "1");
              this.handlePaySuccess();
            }
          }
        }
      }
    },
    handlePaySuccess() {
      this.isPayCallBack = true;
      this.msg = "購買成功！";
      this.msg1 = "請到遊戲內郵箱領取獎勵！";
      this.dialog = true;
    }
  },
  computed: {
    ...mapState({
      // 用户信息
      userInfo: "userInfo",
      activty: "activty"
    }),
    isPay() {
      return (
        this.activty &&
        Object.prototype.hasOwnProperty.call(this.activty, "gid")
      );
    }
  },
  watch: {
    userInfo(newVal) {
      // console.log("userInfo", newVal, oldVal);
      // 如果没有新的newVal说明是退出登录了，重置页面状态
      if (!newVal) {
        window.location.reload();
      }
    }
  },
  created() {
    this.isPaySuccess();
  },
  mounted() {
    this.initSwiper();
    let token = localStorage.getItem("token");
    token && this.$store.dispatch("getInfo", 4);
    // 判断是否为微信环境
    if (isWeChat()) {
      const wxid = getQueryValue("wxid");
      if (wxid) {
        sessionStorage.setItem("wxid", wxid);
      }
      let data = sessionStorage.getItem("wxid");
      if (!data) {
        location.href = `https://api.xianyuyouxi.com/service/activity/zjfh_third_ani/getauth?url=${encodeURIComponent(
          location.href
        )}`;
      }
    }
  }
};
</script>
<style scoped lang="stylus">
.wish3
  position: relative;
  height: 1624px;
  background-image: bg('wishList/wish3-bg.jpg');
  background-size: 100% auto;
  .login_status
    position: absolute;
    right: 0;
  .swiper-container__wapper
    position: relative;
    width: 559px;
    top: 248px;
    margin-left: 104px;
    .rule
      font-size: 20px;
      color: #f83b18;
      text-align: right;
    .swiper-container
      position: relative;
      width: 386px;
      margin-top: 20px;
      .swiper-wrapper
        position: relative;
        width: 386px;
        height: 767px;
        margin: 0 auto;
        .swiper-slide
          width: 100%;
          height: 100%;
          .clothing-name
            position: absolute;
            width: 51px;
            height: 169px;
            right: 17px;
            background-image: bg('wishList/clothing-name-bg.png');
            background-size: 100% 100%;
            color: #fff1c8;
            font-size: 23px;
            text-align: center;
            // font-family: FZSHENGSKSJW_CU;
            .name-text
              position: absolute;
              width: 22px;
              color: #fff1c8;
              margin: auto 0;
              line-height: 26px;
              left: 50%;
              top: 50%;
              transform: translate(-50%, -39%);
          img
              width: 100%;
              height: 100%;
      .clothing-front
        position: absolute;
        top: 0;
        left:0;
        width: 100%;
        height: 100%;
        background-image: bg('wishList/clothing-bg.png');
        background-size: 100% 100%;
        z-index: 11;
      .clothing-tips
        position: absolute;
        left: 0;
        bottom: 2px;
        width 100%;
        height: 41px;
        line-height: 41px;
        background: rgba(0, 0, 0, 1);
        color: #fff;
        opacity: .5;
        font-size: 20px;
        text-align: center;
        z-index: 10;
    .swiper-button-prev
      background-image:  bg('wishList/button-prev.png');
      background-size: 100% 100%;
      width: 48px;
      height: 60px;
      left: 0;
      -webkit-tap-highlight-color: transparent;
      &.swiper-button-disabled
        opacity: .7;
    .swiper-button-next
      background-image: bg('wishList/button-next.png');
      background-size: 100% 100%;
      width: 48px;
      height: 60px;
      right: 0;
      -webkit-tap-highlight-color: transparent;
  .swiper-pagination
    position: absolute;
    left: 50%;
    top: 1060px;
    transform: translate(-50%);
    >>>.swiper-pagination-bullet
      width: 14px;
      height: 14px;
      margin: 0 8px;
      &.swiper-pagination-bullet-active
        background: #ffab3e;
  .limit
    position: absolute;
    top: 1227px;
    left: 104px;
    color: #202021;
    font-size: 22px;
    opacity: .7;
    // font-family: SourceHanSerifCN-Regular;
  .original-cost
    position: absolute;
    left: 308px;
    top: 1227px;
    color: #febead;
    font-size: 24px;
    text-decoration:line-through;
    // font-family: SourceHanSerifCN-Regular;
  .ensure-btn
    position: absolute;
    width: 359px;
    height: 137px;
    background-image:bg('wishList/ensure-btn.png');
    background-size: 100% 100%;
    top: 1090px;
    left: 50%;
    transform: translateX(-50%);
    text-align: center;
    color: #fff;
    font-size: 48px;
    font-family: SourceHanSerifCN-Regular;

    .btn-text
      // background: linear-gradient(to bottom, #fdffb7 30% , #fff 100%);
      // -webkit-background-clip: text;
      text-shadow: 0 0 1px #fdffb7;
      color:  #fdffb7;
      p:nth-of-type(1)
        margin-top: 34px;
      .discount
        line-height: 14px;
        font-size: 18px;
        text-align: center;
        color: #ffeab8;
        opacity: .9;
  .msg-box
    margin-top: 122px;
    p
      font-size: 28px
      text-align: center;
      &:nth-of-type(1)
          color: #ff6059;
      &:nth-of-type(2)
          color: #d5755b;
  .msg-box1
    margin-top: 100px;
    padding: 0 20px;
    p
      font-size: 26px;
      text-align: left;
      margin-top: 10px;
      color: #d5755b;
      &.tips
        text-align: left;
        color: #ff6059;
</style>
