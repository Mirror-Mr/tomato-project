<template lang="pug">
.phoneReserve.bg-c.column-center
  .btn-container
    .btn.bg-c.inner-center(
      v-for="item in btnList",
      :class="{ click: index == item.id }",
      v-html="item.desc",
      @click="index = item.id"
    ) 
  .content-container
    template(v-if="index == 1")
      .order-methods
        span 活動規則：
        span 1. 活動時間：2021年12月24日-2021年12月31日。
        span 2. 每日登錄遊戲，可通過郵件領取周年登錄獎勵。
        span *當日獎勵僅在當天登錄可領取，未登錄則無當日郵件獎勵
    template(v-if="index == 2")
      .order-methods
        span 活動規則：
        span 1. 活動開始時間：2021年12月24日
        span 2. 元寶充值界面中，首次充值得雙倍元寶獎勵重置，以往已享受過雙倍返利的小主們也可參與。
        span 3. 首次雙倍元寶返利請在遊戲內郵件查收。
    template(v-if="index == 3")
      .title-box.column-center
        .title 【三週年慶典服】
        .time 開服時間: 2021年12月24日10:00
      .order-methods
        span 參與方式:
        span 【三週年慶典服】現已開啟，進入遊戲登陸界面，選擇服務器列表，找到【三週年慶典服】進入即可
      .welfare-box.column-center
        .title-welfare 【三週年慶典服】專屬福利
        .welfare1
          b 第一彈:開服慶典<br>
          span 活動時間: 2021年12月24日 - 2022年1月6日<br>
          span 活動規則：登錄即可在郵箱中領取價值5000元寶的“慶典服禮包”
        .welfare2
          b 第二彈:限定稱號<br>
          span 活動時間：創建角色後7日內<br>
          span 活動規則：參與七日簽到活動，即可領取專屬稱號“三年有你”
        .welfare3
          b 第三彈:新服錦鯉<br>
          span 活動時間: 12月24日 - 12月25日<br>
          span 第1波（24號下午3點） :抽取10名幸運玩家送上元寶8888<br>
          span 第2波（24號下午6點）：抽取8名幸運玩家，送上價值1萬元寶的資源大禮包<br>
          span 第3波（25號下午3點）：抽取5名儲值過的玩家送上年卡1張（儲值任意金額即可參與）
</template>
<script>
export default {
  name: "phoneReserve",
  data() {
    return {
      time: Date.now(),
      index: 1,
      btnList: [
        {
          id: 1,
          desc: `登錄<br>福利`,
        },
        {
          id: 2,
          desc: `首充<br>雙倍`,
        },
        {
          id: 3,
          desc: `週年<br>慶典服`,
        },
      ],
    };
  },
  methods: {},
  mounted() {},
};
</script>
<style scoped lang='stylus'>
.phoneReserve
  width: 100%
  height: 1869px
  background-image: bg('phoneReserve/bg_other.jpg')
  overflow: hidden
.btn-container
  width: 90%
  display: flex
  justify-content: space-around
  margin: 580px 0 0 0
.btn
  width: 200px
  height: 200px
  text-align: center
  color: #85521B
  font-size: 36px
  font($bold)
  background-image: bg('phoneReserve/btn-nav-noclick.png')
  &.click
    height: 194px
    color: #fff
    background-image: bg('totalNav/btn-nav.png')
.content-container
  width: 86%
  margin: 50px 0 0 0
  .order-methods
    line-height: 40px
    span
      display: block
      font-size: 22px
      &:nth-of-type(1)
        color: #C52A13
        font($bold)
      &:not(:nth-of-type(1))
        color: #714E4B
        font($regular)
  .title-box
    margin: 10px 0 20px 0
    font-size: 19.02px
    color: #C52A13
    line-height: 39px
    font($bold)
  .welfare-box
    margin: 20px 0 0 0
    font-size: 22px
    align-items: flex-start
    b, .title-welfare
      color: #C52A13
      font($bold)
    .title-welfare
      margin: 20px 0
    span
      color: #714E4B
      line-height: 42px
      font($regular)
</style>