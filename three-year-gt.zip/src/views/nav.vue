<template lang="pug">
.nav
  .title 臨時導航頁（導航頁設計圖還未給到）
  ul
    li(v-for="(item, index) in navList", :key="index" @click="jump(item.path)") {{ item.name }}
  .remark 備註：活動六還在開發中，部分活動規則未配置，可以先不測
</template>
<script>
export default {
  name: "",
  data() {
    return {
      navList: [
        { name: "活动一", path: "redEnvelope" },
        { name: "活動二", path: "askSign" },
        { name: "活動三", path: "wishlist1" },
        { name: "活動四", path: "wishlist3" },
        { name: "活動五", path: "warorder" },
        { name: "活動六", path: "phonereserve" }
      ]
    };
  },
  methods: {
    jump(path) {
      this.$router.push(path);
    }
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.nav
  width: 100%
  height: 100vh
  .title
    width: 100%
    margin: 80px 0
    text-align: center
  ul
    width: 100%
    padding: 0 180px
    line-height: 60px
  .remark
    width: 100%
    text-align: center
    margin-top: 80px
    padding: 0 20px
</style>
