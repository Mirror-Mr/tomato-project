<template lang="pug">
.war-order-container.bg-c.column-center
  LoginStatus(ref="login")
  //- 侧边栏
  .btn-group-sidebar.column-center
    .active-rule.bg-c.column-center(@click="openDialog('ruleOfWar')")
      span 活動規則
    .reward-overview.bg-c.column-center(@click="openDialog('rewardOverview')") 
      span 獎勵總覽
  //- 开通判春归按钮
  .btn-open-spring.bg-c(
    @click="judgeUserInfo(openDialog, 'waitSpring'); userInfo ? dots.splice(0, 1, 0) : ''"
  ) 
    span.bg-c(v-if="dots[0]")
  //- 中间按钮组
  .btn-group-midbar
    .btn-mid1.bg-c.inner-center(
      @click="judgeUserInfo(openDialog, 'accompany'); userInfo ? dots.splice(1, 1, 0) : ''"
    ) 感恩久伴
      span.bg-c(v-if="dots[1] || loginDaysDot") 
    .btn-mid2.bg-c.inner-center(
      @click="judgeUserInfo(openDialog, 'snowFlower'); userInfo ? dots.splice(2, 1, 0) : ''"
    ) 踏雪尋梅
      span.bg-c(v-if="dots[2] || Object.values(day_task_record).includes(1)")
    .btn-mid3.bg-c.inner-center(
      @click="judgeUserInfo(openDialog, 'buyGrade'); userInfo ? dots.splice(3, 1, 0) : ''"
    ) 購買等級
    //-   span.bg-c(v-if="dots[3]")
  //- 梅树等级和战令经验值
  .rank-exper
    .rank.bg-c.inner-center
      span {{ activty && activty.lv ? (activty.lv >= 50 ? 50 : activty.lv) : 0 }}
      span / 50
    .exper
      div 活動時間：
        span 2021/12/24
        span -
        span 2022/01/06
      div 
        span(:style="{ width: `${exper * 100}%` }")
    .btn-quick-receive.bg-c(
      v-debounce="()=>{judgeUserInfo(subPrize, { flag: 1, rid: 1 })}"
    )
  .award-container
    //- 轮播图
    swiper.award-swiper(:options="swiperoption", ref="awardSwiper")
      swiper-slide.award-slide.bg-c.column-center(
        v-for="item in rewardList_winter"
      )
        .bg-level.bg-c.inner-center {{ item.id }}
        .top-award.bg-c.bg-award.inner-center(
          v-debounce="()=>{judgeUserInfo(subPrize, { rid: item.id })}"
        )
          img(
            :src="`https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/warOrder/icon/${item.id}.png`",
            :class="{ gray: activty && activty.lv < item.id }"
          )
          span.bg-c(v-if="prizeList[`${item.id}`]")
          b *{{ item.num }}
        .bottom-award-group(
          v-debounce="()=>{judgeUserInfo(subPrize,{ rid: item.id * 1 + 50 })}"
        )
          .bg-c.bg-award.inner-center
            img(
              :src="`https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/warOrder/icon/${item.id * 1 + 50}.png`",
              :class="{ gray: (activty && activty.lv < item.id) || (activty && activty.is_buy == 0) }"
            )
            span.bg-c(v-if="prizeList[`${item.id * 1 + 50}`]")
            b *{{ rewardList_spring[item.id * 1 - 1].num }}
          .bg-c.bg-award.inner-center
            img(
              :src="`https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/warOrder/icon/${item.id * 1 + 100}.png`",
              :class="{ gray: (activty && activty.lv < item.id) || (activty && activty.is_buy == 0) }"
            )
            span.bg-c(v-if="prizeList[`${item.id * 1 + 50}`]")
            b *{{ rewardList_spring[item.id * 1 + 49].num }}
    //- 固定奖励展示栏
    .show-special.bg-c.column-center 
      .bg-level.bg-c.inner-center {{ nextReward }}
      .top-award.bg-c.bg-award.inner-center(
        v-debounce="()=>{judgeUserInfo(subPrize, { rid: nextReward })}"
      )
        img(
          :src="`https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/warOrder/icon/${nextReward}.png`",
          :class="{ gray: activty && activty.lv < nextReward }"
        )
        span.bg-c(v-if="prizeList[`${nextReward}`]")
        b *{{ rewardList_winter[nextReward - 1].num }}
      .bottom-award-group(
        v-debounce="()=>{judgeUserInfo(subPrize, { rid: nextReward * 1 + 50 })}"
      )
        .bg-c.bg-award.inner-center
          img(
            :src="`https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/warOrder/icon/${nextReward * 1 + 50}.png`",
            :class="{ gray: (activty && activty.lv < nextReward) || (activty && activty.is_buy == 0) }"
          )
          span.bg-c(v-if="prizeList[`${nextReward * 1 + 50}`]")
          b *{{ rewardList_spring[nextReward * 1 - 1].num }}
        .bg-c.bg-award.inner-center
          img(
            :src="`https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/warOrder/icon/${nextReward * 1 + 100}.png`",
            :class="{ gray: (activty && activty.lv < nextReward) || (activty && activty.is_buy == 0) }"
          )
          span.bg-c(v-if="prizeList[`${nextReward * 1 + 50}`]")
          b *{{ rewardList_spring[nextReward * 1 + 49].num }}
  RuleOfWar(:show="dialog == 'ruleOfWar'", @close="close")
  RewardOverview(:show="dialog == 'rewardOverview'", @close="close")
  SnowFlower(
    :show="dialog == 'snowFlower'",
    @close="close",
    :day_task_record="day_task_record",
    @subPrize="subPrize"
  )
  Accompany(
    :show="dialog == 'accompany'",
    @close="close",
    :login_days_record="login_days_record",
    @subPrize="subPrize"
  )
  WaitSpring(
    :show="dialog == 'waitSpring'",
    @close="close",
    :isVIP="activty && activty.is_buy != 0"
  )
  BuyGrade(:show="dialog == 'buyGrade'", @close="close")
  Common(
    :show="showCommon",
    @close="close",
    @openDialog="openDialog",
    @pay="pay"
  )
</template>
<script>
import { Swiper, SwiperSlide } from "vue-awesome-swiper";
import "swiper/dist/css/swiper.css";
import {
  loginDays,
  finishDays,
  subPrize,
  pay,
  getOrderStatus,
  getActivityTime,
} from "@/request/api.js";
import {
  rewardList_winter,
  rewardList_spring,
} from "@/components/allModals/warOrder/rewardList.js";
import WaitSpring from "@/components/allModals/warOrder/waitSpring.vue";
import { getQueryValue, isWeChat } from "@/utils/index";
import { mapState } from "vuex";
export default {
  name: "warOrder",
  components: {
    Swiper,
    SwiperSlide,
    RuleOfWar: (resolve) =>
      require(["@/components/allModals/warOrder/ruleOfWar.vue"], resolve),
    RewardOverview: (resolve) =>
      require(["@/components/allModals/warOrder/rewardOverview.vue"], resolve),
    SnowFlower: (resolve) =>
      require(["@/components/allModals/warOrder/snowFlower.vue"], resolve),
    Accompany: (resolve) =>
      require(["@/components/allModals/warOrder/accompany.vue"], resolve),
    WaitSpring: WaitSpring,
    //  (resolve) =>
    //   require(["@/components/allModals/warOrder/waitSpring.vue"], resolve),
    BuyGrade: (resolve) =>
      require(["@/components/allModals/warOrder/buyGrade.vue"], resolve),
    Common: (resolve) =>
      require(["@/components/allModals/warOrder/common.vue"], resolve),
  },
  data() {
    return {
      // 控制弹框显示 poster invite
      dialog: "",
      time: Date.now(),
      //   定时器
      timer: null,
      nextReward: 10,
      // 轮播图配置
      swiperoption: {
        slidesPerView: "auto",
        spaceBetween: 5,
        watchSlidesProgress: true,
        observer: true,
        observeParents: true,
        on: {
          touchMove: () => {
            const next = Math.ceil((this.awardSwiper.realIndex + 4) / 10) * 10;
            this.nextReward = next == 60 ? 50 : next;
            // this.test2(this.awardSwiper.realIndex);
          },
        },
      },
      // 历史登录时长+领奖记录
      login_days_record: {
        days: 0,
        prize: {},
      },
      // 每天任务领奖记录
      day_task_record: {
        301: 0,
        302: 0,
        303: 0,
        304: 0,
        305: 0,
      },
      // 迎冬来
      rewardList_winter: rewardList_winter,
      //   盼春归
      rewardList_spring: rewardList_spring,
      //引导用户的点点
      dots: [0, 0, 0, 0],
      //   活动开始时间
      start_time: null,
      // 活动结束时间
      end_time: null,
    };
  },
  methods: {
    test2(next) {
      this.nextReward = next;
    },
    // 打开弹框
    openDialog(type) {
      this.dialog = type;
    },
    // 关闭弹窗
    close() {
      this.dialog = "";
    },
    // 获取历史登录及领奖记录
    loginDays() {
      const { time } = this;
      const token = localStorage.getItem("token");
      const access = this.$encrypte([time, token]);
      loginDays({ time, token, access })
        .then(
          (data) => {
            this.login_days_record = { ...data };
          },
          (err) => {
            console.log(err);
          }
        )
        .catch((err) => {
          console.log(err);
        });
    },
    // 获取每天任务及领奖记录
    finishDays() {
      const { time } = this;
      const token = localStorage.getItem("token");
      const access = this.$encrypte([time, token]);
      finishDays({ time, token, access }).then(
        (data) => {
          //   console.log(data);
          this.day_task_record = { ...data };
        },
        (err) => {}
      );
    },
    // 领取奖励
    subPrize({ flag = "", rid = 1 }) {
      // const obj = { dialog: "quickReward", params: [] };
      // this.$bus.$emit("showCommon", obj);
      // return;
      const { time } = this;
      const token = localStorage.getItem("token");
      //   console.log(flag, rid);
      //   return;
      const access = this.$encrypte([time, token, 1]);
      subPrize({ time, token, num: 1, flag, type: 5, rid, access }).then(
        (data) => {
          console.log(data);
          this.$toast("領取成功");
          // 不同奖励领完获取奖励记录
          this.$store.dispatch("getInfo", 5);
          if (rid >= 200 && rid <= 205) {
            //   登录领奖完获取奖励记录
            // this.loginDays();
          } else if (rid >= 300 && rid <= 305) {
            //   每日奖励领完获取奖励记录
            // this.finishDays();
          } else {
            //   战令奖励领取
            const params = this.getRewardsList(Object.keys(data));
            console.log(params);
            const obj = { dialog: "quickReward", params };
            this.$bus.$emit("showCommon", obj);
          }
        },
        (err) => {
          this.$toast(err.msg);
        }
      );
    },
    // 支付
    pay({ good_id, num = 1 }) {
      const { time } = this;
      const token = localStorage.getItem("token");
      const access = this.$encrypte([time, token]);
      let wxid = "";
      if (isWeChat()) {
        wxid = sessionStorage.getItem("wxid");
      }
      //   let winRef = window.open("", "_blank");
      pay({ time, token, good_id, num, wxid, access }).then(
        (data) => {
          console.log(data);
          location.href = data.url;
          const payMsg = JSON.parse(localStorage.getItem("zl_payMsg"));
          let i = 0;
          //   在支付页面通过滑动屏幕返回时生效
          this.timer = setInterval(() => {
            this.getOrderStatus(data.orderid, good_id, payMsg.params);
            i++;
            if (i > 30) {
              clearInterval(this.timer);
            }
          }, 1000);
        },
        (err) => {
          this.$toast(err.msg);
        }
      );
    },
    // 获取订单状态
    getOrderStatus(orderid, good_id, params) {
      const { time } = this;
      const access = this.$encrypte([time, orderid]);
      getOrderStatus({ time, orderid, access }).then(
        (data) => {
          console.log(data);
          if (data.status > 0) {
            this.$toast("支付成功");
            clearInterval(this.timer);
            // 获取用户信息
            this.$store.dispatch("getInfo", 5);
            // 弹出弹框
            const dialog =
              good_id < 13
                ? "openSpringSuccess1"
                : good_id < 15
                ? "openSpringSuccess2"
                : "buyGraded";
            const obj = { dialog, params: [params] };
            this.$bus.$emit("showCommon", obj);
          }
        },
        (err) => {
          //   this.$toast("获取订单状态失败", err);
        }
      );
    },
    // 判断是否有用户登录
    judgeUserInfo(func, params, flag = true) {
      const token = localStorage.getItem("token");

      if (!token && flag) {
        // 未登录 且 不是注销状态 则弹出登录框
        this.$store.commit("SETVAL", { login_type: true });
        return;
      } else if (!token && !flag) {
        // 注销操作触发 感恩久伴和踏雪寻梅信息初始化
        this.day_task_record = {
          301: 0,
          302: 0,
          303: 0,
          304: 0,
          305: 0,
        };
        this.login_days_record = {
          days: 0,
          prize: {},
        };
        return;
      }
      // 已登录
      func(params);
    },
    // 根据返回的战令领奖id 获取真正领取到的奖励列表
    getRewardsList(arrs) {
      let temp = [];
      arrs.map((arr) => {
        if (arr <= 50) {
          //  上排
          temp = [...temp, this.rewardList_winter[arr - 1]];
          return;
        }
        // 下排两个
        temp = [
          ...temp,
          { ...this.rewardList_spring[arr - 51], id: arr },
          { ...this.rewardList_spring[arr - 1], id: arr * 1 + 50 },
        ];
      });
      return temp;
    },
    // 获取活动时间
    getActivityTime() {
      const { time } = this;
      const access = this.$encrypte([time, 35]);
      getActivityTime({
        time: time,
        project_id: 35,
        access: access,
      }).then(
        (data) => {
          console.log(data);
          this.start_time = data.start_time;
          this.end_time = data.end_time;
        },
        (err) => {}
      );
    },
  },
  computed: {
    ...mapState(["userInfo", "activty"]),
    // 获取经验的百分比
    exper() {
      if (this.userInfo && this.userInfo.jingyan) {
        if (this.userInfo.jingyan >= 5000) return 1;
        return this.userInfo.jingyan / 5000;
      } else {
        return 0;
      }
    },
    awardSwiper() {
      return this.$refs.awardSwiper.$swiper;
    },
    // 固定展示的奖品
    loginDaysDot() {
      const { days, prize } = this.login_days_record;
      if (days >= 30 && Object.keys(prize).length < 1) {
        return true;
      } else if (days >= 180 && Object.keys(prize).length < 2) {
        return true;
      } else if (days >= 360 && Object.keys(prize).length < 3) {
        return true;
      } else if (days >= 540 && Object.keys(prize).length < 4) {
        return true;
      } else if (days >= 720 && Object.keys(prize).length < 5) {
        return true;
      } else {
        return false;
      }
    },
    showCommon() {
      const arr = [
        "maskSureBuyGrade",
        "buyGraded",
        "makeSureOpenSpring",
        "openSpringSuccess1",
        "openSpringSuccess2",
        "quickReward",
      ];
      return arr.includes(this.dialog);
    },
    // 50级领取的奖励记录
    prizeList() {
      return this.activty && this.activty.prize ? this.activty.prize : {};
    },
  },
  mounted() {
    this.getActivityTime();
    this.$bus.$off(event).$on("showCommon", (obj) => {
      this.openDialog(obj.dialog);
    });
    // 判断是否有用户信息
    const token = localStorage.getItem("token");
    // 如果有则请求用户信息
    token && this.$store.dispatch("getInfo", 5);
    // 往session中存入控制消息点点是否展示的控制变量
    let dots = JSON.parse(sessionStorage.getItem("dots"));
    dots
      ? (this.dots = [...dots])
      : sessionStorage.setItem("dots", JSON.stringify([0, 0, 0, 0]));
    // 判断是否微信环境
    if (isWeChat()) {
      const wxid = getQueryValue("wxid");
      if (wxid) {
        sessionStorage.setItem("wxid", wxid);
      }
      let data = sessionStorage.getItem("wxid");
      if (!data) {
        location.href = `https://api.xianyuyouxi.com/service/activity/zjfh_third_ani/getauth?url=${encodeURIComponent(
          location.href
        )}`;
      }
    }

    // 如果是在支付页面点击<返回的 如果是在支付页通过滑动屏幕返回
    const orderid = getQueryValue("orderid");
    if (orderid) {
      history.replaceState({}, "", location.href.split("?")[0]);
      const payMsg = JSON.parse(localStorage.getItem("zl_payMsg"));
      const { good_id, params } = payMsg;
      let i = 0;
      this.timer = setInterval(() => {
        this.getOrderStatus(orderid, good_id, params);
        if (i > 30) {
          clearInterval(this.timer);
        }
        i++;
      }, 1000);
    }
    window.addEventListener("setItem", () => {
      this.dots = [...JSON.parse(sessionStorage.getItem("dots"))];
    });
  },
  watch: {
    activty(newVal) {
      const { lv } = newVal ? newVal : { lv: null };
      lv ? this.awardSwiper.slideTo(lv - 2, 0) : this.awardSwiper.slideTo(0, 0);
    },
    dots: {
      handler(newVal) {
        sessionStorage.setItem("dots", JSON.stringify(newVal));
      },
      deep: true,
    },
    userInfo() {
      this.judgeUserInfo(this.finishDays, "", false);
      this.judgeUserInfo(this.loginDays, "", false);
    },
  },
};
</script>
<style lang="stylus" scoped>
.war-order-container
  width: 100%
  height: 1624px
  position: relative
  background-image: imgUrl('bg_war_order.jpg')
  overflow: hidden
  .login_status
    position: absolute
    top: 0
    right: 180px
  .btn-group-sidebar
    align-self: flex-start
    position: absolute
    top: 65px
    left: 20px
    div
      width: 44px
      height: 140px
      font-size: 18px
      line-height: 23px
      color: #FFF1C8
      background-image: imgUrl('bth_sidebar.png')
      span
        width: 21px
        margin: 35px 0 0 4px
  .btn-open-spring
    width: 546px
    height: 113px
    position: relative
    margin: 538px 0 0 7px
    background-image: imgUrl('btn_open_spring.png')
    span
      width: 25px
      height: 25px
      display: block
      position: absolute
      top: 0
      right: 90px
      background-image: imgUrl('eye.png')
      &.hide
        opacity: 0
  .btn-group-midbar
    width: 94%
    display: flex
    justify-content: space-around
    margin: 88px 0 0 0
    div
      width: 213px
      height: 64px
      position: relative
      font-size: 30px
      color: #FF813E
      text-shadow: 0 1px 2px #FFFFFF
      background-image: imgUrl('btn-midbar-unclick.png')
      span
        width: 25px
        height: 25px
        display: block
        position: absolute
        top: -7px
        right: -7px
        background-image: imgUrl('eye.png')
        &.hide
          opacity: 0
      &.light
        color: #FFF1C8
        text-shadow: 0 1px 2px #FF5F23
        background-image: imgUrl('btn-midbar-click.png')
  .rank-exper
    width: 100%
    display: flex
    margin: 40px 0 0 0
    .rank
      width: 102px
      height: 103px
      margin: 0 0 0 17px
      background-image: imgUrl('bg-rank.png')
      span
        color: #fff
        font-size: 21px
        margin: 14px 0 0 0
        &:nth-of-type(1)
          font-size: 26px
        &:nth-of-type(2)
          margin: 14.5px 0 0 5px
    .exper
      margin: 40px 0 0 20px
      div
        &:nth-of-type(1)
          margin: 0 0 5px 0
          font-size: 17px
          color: #EB4B12
        &:nth-of-type(2)
          width: 300px
          height: 17px
          background-color: #6D5752
          border: 1px solid #FFFFFF
          span
            // width: 150px
            height: 100%
            display: block
            background-color: #E9400D
    .btn-quick-receive
      width: 239px
      height: 93px
      margin: 10px 0 0 20px
      background-image: imgUrl('btn-quick-receive.png')
  .award-container
    display: flex
    .bg-award
      width: 110px
      height: 110px
      position: relative
      background-image: imgUrl('bg-award.png')
      img
        width: 85px
        // height: 70px
        display: block
      span
        width: 100px
        height: 70px
        display: block
        position: absolute
        background-image: imgUrl('tag_getting.png')
      b
        position: absolute
        bottom: 15px
        left: 65px
        text-shadow: -1px 0 white, 0 1px white, 1px 0 white, 0 -1px white
        font-size: 20px
    .award-swiper
      width: 430px
      margin: 50px 0 0 110px
      padding: 15px 0 0 0
      .award-slide
        width: 135px
        height: 515px
        position: relative
        background-image: imgUrl('bg-slide.png')
        .bg-level
          width: 100px
          height: 100px
          position: absolute
          top: -60px
          margin: 40px 0 0 0
          font-size: 33px
          color: #fff
          background-image: imgUrl('bg-level.png')
        .top-award
          margin: 83px 0 0 0
        .bottom-award-group
          margin: 40px 0 0 0
    .show-special
      width: 139px
      height: 575px
      margin: 30px 0 0 5px
      background-image: imgUrl('bg_show_special.png')
      .bg-level
        width: 110px
        height: 95px
        margin: 20px 0 0 3px
        padding: 8px 0 0 0
        font-size: 33px
        color: #fff
        background-image: imgUrl('bg-level-s.png')
      .bottom-award-group
        margin: 41px 0 0 0
</style>
