<!--
 * @Author: your name
 * @Date: 2021-11-08 10:49:52
 * @LastEditTime: 2021-11-25 17:01:13
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three_year\src\views\tips.vue
-->
<template lang="pug">
	.tips 請前往移動端查看
        
</template>
<script>
export default {
  name: "",
  data() {
    return {};
  },
  methods: {
    // 判断是否是为移动端
    getIsWxClient() {
      var sUserAgent = navigator.userAgent.toLowerCase();
      var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
      var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
      var bIsMidp = sUserAgent.match(/midp/i) == "midp";
      var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
      var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
      var bIsAndroid = sUserAgent.match(/android/i) == "android";
      var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
      var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";

      if (
        bIsIpad ||
        bIsIphoneOs ||
        bIsMidp ||
        bIsUc7 ||
        bIsUc ||
        bIsAndroid ||
        bIsCE ||
        bIsWM
      ) {
        return true;
      } else {
        return false;
      }
    }
  },
  mounted() {
    let mac = this.getIsWxClient();
    if (mac) {
      this.$router.replace("/");
    }
  }
};
</script>
<style scoped lang="stylus">
.tips
    height 100vh
    background #ccc
    padding 50px
    text-align center
    color #ffffff
    font-size 40px
</style>
