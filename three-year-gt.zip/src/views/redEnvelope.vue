<template lang="pug">
	.envelope_wrap
		.env_top.clearfix
			.fr
				LoginStatus
		img.charctor(:src="`${imgBaseUrl}charctor.png`")
		//- .envelope_center
		//- 兑换按钮
		.convert_btn(@click="toConvert")
		.rule(@click="openDialog('rule')") [ 活動規則 ]
		.spare_parts 
			.part(v-for="(item,index) in 6" :key="item" :class="had_get[index+1]?'':'gray'")
				img(:src="`${imgBaseUrl}suit_${index+1}.png`")
				//- .had(v-if="had_get[index+1]")
		.collet_num(v-debounce="getSuit"  )
			.mohu {{(activty && activty.had_get_big_prize == 1) ? '已領取' :'集齊領獎'}}
			.num {{`（${Object.keys(had_get).length}/6）`}}
		
		.had_red(v-if="activty") {{`今日已领：${activty ? activty.day_get_num:0}/3`}}
		//- 十四天红包活动框
		.time_envelope
			.swiper-container.envelope_swiper
				.swiper-wrapper
					.swiper-slide(v-for="(item,index) in timeArr", :key="item+index")
						.time-tip(v-if="current_time &&  $gapDay(item,current_time) > 0") {{$gapDay(item,current_time) +'天后解鎖'}}
						//- .time-tip {{$gapDay(item,current_time) +'天后解鎖'}} 
						div(:class="redstatus(item,index)" @click="getId(index,item)")
							.surplus(v-if="$gapDay(item,current_time)<1") {{getnum(index)}}
			.tip_l
		.dog
		.time_range 活動時間：2021.12.24-2022.01.06

		//- 兑换奖励弹框
		Convert( @close="close" :show="dialog === 'convert'" @convertTo="convertTo")
		//- 分享红包弹框
		Share( @close="close" :day="envelopeDay"  :show="dialog === 'share'")
		//- 获取奖励弹框
		Congratulation(@close="close" @convert="openDialog('sure')" :show="congratulation")
		//- 确认弹框
		Mymodal(:show="dialog === 'sure'" @close="close" @sure="reciveSuit" :canclebtn="true" :surebtn="true" )
			.to_convert 確認兌換火霓鹿呦套裝
		//- 兑换数量确认弹框
		ConvertTo(:show="dialog === 'chooseNum'" :gift="gift" @close="close('chooseNum')"  )
		//- 生成海报
		Poster(:show="dialog === 'poster'" @close="close" )
		//- 活动规则
		Rule(:show="dialog === 'rule'" @close="close")
		//- 邀请红包弹框
		InviteRedEnv(:show="invite_red"   )
</template>
<script>
import {
  getActivityTime,
  sharePermis,
  subPrize,
  getRedTimes
} from "@/request/api.js";
import { mapState } from "vuex";
import Swiper from "swiper";
import "swiper/dist/css/swiper.min.css";
export default {
  name: "",
  components: {
    Convert: resolve =>
      require(["@/components/allModals/convert.vue"], resolve),
    Share: resolve =>
      require(["@/components/allModals/shareRedEnv.vue"], resolve),
    Congratulation: resolve =>
      require(["@/components/allModals/congratulation.vue"], resolve),
    ConvertTo: resolve =>
      require(["@/components/allModals/convertTo.vue"], resolve),
    InviteRedEnv: resolve =>
      require(["@/components/allModals/inviteRedEnv.vue"], resolve),
    Rule: resolve => require(["@/components/allModals/rule.vue"], resolve),
    Poster: resolve => require(["@/components/allModals/poster.vue"], resolve)
  },
  data() {
    return {
      swiper: null,
      // 控制弹框显示 poster invite
      dialog: "",
      timeArr: Array(14).fill(0),
      // timeArr:  [],
      // 第几天的红包
      envelopeDay: 0,
      // 红包Id
      red_id: "",
      // 兑换礼包详情
      gift: null,
      // 已获取的套装信息
      had_get: [],
      // 红包领取记录
      red_info: null,
      // 现在的时间
      current_time: "",
      //红包列表接口是否返回
      hadredlist: false,
      imgBaseUrl:
        "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/redEnvelopes/",
      getredIdFlag: true,
      flag: true
    };
  },
  watch: {
    activty: {
      handler(val) {
        if (val && val.had_get !== undefined) {
          this.had_get = val.had_get;
          this.red_info = val.red_info;
        } else {
          this.had_get = [];
          this.red_info = null;
        }
      },
      immediate: true,
      deep: true
    }
  },
  computed: {
    ...mapState(["userInfo", "invite_red", "activty", "congratulation"]),
    // 红包剩余数量
    getnum() {
      return type => {
        if (!this.hadredlist || !this.red_info) {
          return "";
        }
        if (this.red_info) {
          let red = this.red_info.find(item => item.type == type);
          let num = red ? red.num : 3;
          return num > 0 ? `${num}個未被領取` : "";
        }
      };
    }
  },
  filters: {},
  methods: {
    // 红包领取状态
    redstatus(item, index) {
      if (!this.hadredlist || !this.current_time || this.$gapDay(item, this.current_time) > 0) {
        return "lock_env";
      } else  {
				if (this.red_info) {
					let red_day = this.red_info.find((day) => day.type == index);
					return (red_day && red_day.num === "0") ? "over_env" :"share_env";
				} else {
					return "share_env"
				}
        
      } 
    },
    // 兑换套装
    getSuit() {
      let token = localStorage.getItem("token");
      if (!this.userInfo && !token) {
        this.$store.commit("SETVAL", { login_type: true });
      } else if (Object.keys(this.had_get).length >= 6) {
        this.openDialog("sure");
      } else {
        this.$toast("套裝零件尚未集齊哦！");
      }
    },
    // 确认兑换套装
    reciveSuit() {
      if (!this.flag) return;
      this.flag = false;
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token, 1]);
      subPrize({
        time: time,
        token: token,
        num: 1,
        type: 1,
        rid: 10,
        access: access
      })
        .then(data => {
          this.flag = true;
          this.$toast("兌換套裝成功！");
          this.close();
          // this.$router.replaceState({path:this.$route.path})
          this.showtype = "success";
          this.$store.dispatch("getInfo", 1);
        })
        .catch(err => {
          this.flag = true;
          // 未绑定手机号
          if (err.data == 11) {
            this.$emit("close");
            this.$store.commit("SETVAL", { bind_phone: true });
          } else {
            this.$toast(err.msg);
          }
          // this.$store.commit("SETVAL",{bind_phone:true,invite_red:false})
        });
    },
    //
    convertTo(item) {
      this.gift = item;
      this.openDialog("chooseNum");
    },
    // 领取红包成功
    // reciveRed(){
    // 	this.openDialog('congratulation')
    // },
    // 获取红包Id
    getId(index, day) {
      if (this.$gapDay(day, this.current_time) > 0) {
        this.$toast("紅包還未解鎖，請耐心等待");
        return;
      }
      if (!this.ifBindPhone()) return;
      if (!this.getredIdFlag) return;
      this.getredIdFlag = false;
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token]);
      sharePermis({
        time: time,
        token: token,
        id: index,
        access: access
      })
        .then(data => {
          this.getredIdFlag = true;
          this.$store.commit("SETVAL", { red_id: data });
          this.openDialog("share");
        })
        .catch(err => {
          this.getredIdFlag = true;
          // 未绑定手机号
          if (err.status == 11) {
            this.$store.commit("SETVAL", { bind_phone: true });
          } else {
            this.$toast(err.msg || "獲取紅包id失敗");
          }
        });
    },
    //打开兑换确认弹框
    toConvert() {
      // if (this.ifBindPhone()) {
      this.openDialog("convert");
      // }
    },
    // 是否绑定过手机
    ifBindPhone() {
      let token = localStorage.getItem("token");
      if (this.userInfo || token) {
        if (this.userInfo.phone) {
          return true;
        } else {
          this.$store.commit("SETVAL", { bind_phone: true });
          return false;
        }
      } else {
        this.$store.commit("SETVAL", { login_type: true });
        return false;
      }
    },
    initSwiper() {
      this.swiper = new Swiper(".envelope_swiper", {
        loop: false, // 循环模式选项
        slidesPerView: "auto",
        observer: true,
        observeParents: true,
        initialSlide: 1,
        // 如果需要滚动条
        scrollbar: {
          el: ".swiper-scrollbar"
        }
      });
      setTimeout(() => {
        this.swiper.slideTo(0);
      }, 0);
    },
    // 打开弹框
    openDialog(type) {
      this.dialog = type;
    },
    // 关闭弹框
    close(type) {
      this.dialog = "";
      if (type === "chooseNum") {
        this.dialog = "convert";
      } else if (type === "poster") {
        this.red_id = "";
      }
    },
    // 打开分享红包
    share(time, day) {
      if (this.$gapDay(time) < 1) {
        this.envelopeDay = day;
        this.openDialog("share", day);
      } else {
        this.dialog = "congratulation";
        // this.$toast('还未开启哦')
      }
    },
    // 获取活动时间
    getServerTime() {
      let time = parseInt(new Date().getTime());
      let access = this.$encrypte([time, 35]);
      getActivityTime({
        time: time,
        project_id: 35,
        access: access
      })
        .then(data => {
          this.current_time = data.current_time.slice(0, 11).replace(/-/g, "/");
        })
        .catch(err => {
          this.$toast(err.msg || "獲取服務器當前時間失敗");
        });
    },
    // 获取时间数组
    getTimeArr() {
      let time = parseInt(new Date().getTime());
      let access = this.$encrypte([time]);
      getRedTimes({
        time: time,
        access: access
      })
        .then(data => {
          this.timeArr = data;
          this.hadredlist = true;
        })
        .catch(err => {
          this.hadredlist = false;
          this.$toast("紅包開放時間列表獲取失敗");
        });
      // let arr  = []
      // if(!this.start_time) {
      // 	arr = Array(14).fill(0)
      // } else {
      // 	arr = [this.start_time];
      // 	for (let i = 0; i < 13; i++) {
      // 		let time = arr[arr.length - 1];
      // 		let next = new Date(time).getTime() + 24 * 60 * 60 * 1000;
      // 		let year = new Date(next).getFullYear();
      // 		let month = new Date(next).getMonth() + 1;
      // 		let day = new Date(next).getDate();
      // 		arr.push(`${year}/${month}/${day}`);
      // 	}
      // }
      // this.$set(this, "timeArr", arr);
      // console.log('timeArr', arr)
    },
    toggleRole() {
      this.$store.commit("SETVAL", { toggle_role: true });
    },
    //
    logout() {
      this.$store.commit("SETVAL", { logout: true });
      // localStorage.clear()
    },
    // 获取红包领取详情
    getdetailInfo(red_id) {
      this.$store.dispatch("getReddetailInfo", red_id).then(data => {
        if (data.is_get == 1) {
          // this.reciveRed()
          this.$store.commit("SETVAL", { congratulation: true });
        } else {
          this.$store.commit("SETVAL", { invite_red: true });
        }
      });
    }
  },
  mounted() {
    window.scrollTo(0, 0);
    this.initSwiper();
    this.getTimeArr();
    this.getServerTime();
    let token = localStorage.getItem("token");
    token && this.$store.dispatch("getInfo", 1);
    if (this.$route.query.red_id) {
      // this.openDialog('invite')
      if (token) {
        this.getdetailInfo(this.$route.query.red_id);
      } else {
        this.$store.commit("SETVAL", { invite_red: true });
      }
    }
  }
};
</script>
<style scoped lang="stylus">
@import './redEnvelope.styl'
</style>
