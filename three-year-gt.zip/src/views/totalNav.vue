<template lang="pug">
.totalNav.bg-c
  .video-container.inner-center(:style="{ top: showDown ? '248px' : '248px' }")
    .btn-video.bg-c(@click.stop="showVideo")
  .btn-group-nav
    .btn-nav.bg-c.inner-center(
      v-for="item in navList",
      v-html="item.name",
      @click="$router.push(item.path)"
    )
  Video(:show="dialog == 'video'", @close="close")
</template>
<script>
import { mapState } from "vuex";
import { getUrlParams } from "@/utils/index";
import { fastLogin } from "@/request/api.js";
export default {
  name: "",
  components: {
    Video: (resolve) => require(["@/components/allModals/video.vue"], resolve),
  },
  data() {
    return {
      navList: [
        {
          name: `紅包<br>傳情`,
          path: `/redEnvelope`,
        },
        {
          name: `雪宴<br>求籤`,
          path: `/askSign`,
        },
        {
          name: `心願<br>成真`,
          path: `/wishlist1`,
        },
        {
          name: `服裝<br>返場`,
          path: `/wishlist3`,
        },
        {
          name: `寒梅<br>獻禮`,
          path: `/warorder`,
        },
        {
          name: `其他<br>活動`,
          //   path: `/phonereserve`
          path: `/other`,
        },
      ],
      // 控制弹框显示 poster invite
      dialog: "",
    };
  },
  methods: {
    showVideo() {
      this.openDialog("video");
      //   如果在放歌先暂停
      this.$bus.$emit("controlMusic", false);
      this.$bus.$emit("playVideo");
    },
    // 关闭弹窗
    close() {
      this.dialog = "";
    },
    // 打开弹框
    openDialog(type) {
      this.dialog = type;
    },
  },
  mounted() {
    const userInfoGame = getUrlParams();
    console.log("test", userInfoGame);
    if (userInfoGame.xyid) {
      let time = parseInt(new Date().getTime());
      let rid = userInfoGame.roleid;
      let access = this.$encrypte([time, userInfoGame.channel, rid]);
      fastLogin({
        time: time,
        xyid: userInfoGame.xyid,
        channel: userInfoGame.channel,
        sid: userInfoGame.serverid,
        sname: "1",
        rolename: "1",
        rid: userInfoGame.roleid,
        access: access,
      })
        .then((data) => {
          console.log("data", data);
          localStorage.setItem("token", data.token);
          localStorage.setItem("uid", data.uid);
          if (window.location.href.indexOf("3rd") !== -1) {
            window.location.href =
              "https://zjfh.meogames.com/3rd-anniversary-event/index.html";
          }
        })
        .catch((err) => {
          this.$toast(err.msg);
          if (window.location.href.indexOf("3rd") !== -1) {
            window.location.href =
              "https://zjfh.meogames.com/3rd-anniversary-event/index.html";
          }
        });
    }
  },
  computed: {
    ...mapState([
      // 用户信息
      "userInfo",
    ]),
    showDown() {
      let token = localStorage.getItem("token");
      let flag = !this.userInfo && !token && this.$route.path != "/download";
      return flag;
    },
  },
};
</script>
<style scoped lang="stylus">
.totalNav
  width: 100%
  height: 1624px
  position: relative
  background-image: bg('totalNav/bg-totalNav.jpg')
  overflow: hidden
  .video-container
    width: 200px
    height: 200px
    position: absolute
    left: 135px
    z-index: 2
    display: none
    .btn-video
      width: 150px
      height: 150px
      background-image: bg('totalNav/btn-video.png')
      animation: breathe 1s linear infinite
      animation-direction: alternate
  .btn-group-nav
    width: 100%
    margin: 1010px 0 0 0
    display: flex
    flex-wrap: wrap
    justify-content: space-around
    .btn-nav
      width: 190px
      height: 185px
      margin: 15px 0 0 0
      font-size: 36px
      font($bold)
      color: #FFFFFF
      line-height: 40px
      text-align: center
      text-shadow: 0px 0px 5px rgba(230, 50, 67, 0.49)
      background-image: bg('totalNav/btn-nav.png')
@keyframes breathe
  0%
    transform: scale(1)
  100%
    transform: scale(1.2)
</style>
