<template lang="pug">
.phoneReserve.bg-c.column-center
  .top-desc-container
    .order-time 
      span 預約時間：
      span 2021年12月17日 - 2021年12月23日
    .order-methods
      span 預約方法：
      span 1.輸入手機號進行預約
      span 2.通過預約手機號碼收取服裝兌換碼（12月24日起陸續發送短信）
      span 3.在【三週年慶典服】創建新角色後，即可在【設置】-【兌換碼】中兌換“紅袖添香”套裝
      span （該兌換碼僅限【三週年慶典服】角色使用）
  .main-order
    input(type="tel", placeholder="请输入手机号码", v-model="phone")
    .btn-reserve.bg-c.inner-center(@click="appoint") 立即預約
  .btm-desc-container.column-center
    .title-box.column-center
      .title 【三週年慶典服】專屬福利
      .time 開服時間：2021年12月24日 10:00
    .welfare-box.column-center
      .welfare1
        b 第一彈：開服慶典<br>
        span 活動時間：2021年12月24日 - 2022年1月6日<br>
        span 活動規則：活動期間登錄即可在郵箱中領取價值5000元寶 “慶典服禮包”
      .welfare2
        b 第二彈：限定稱號<br>
        span 活動時間：創建角色後7日內<br>
        span 活動規則：參與七日簽到活動，即可領取專屬稱號“三年有你”
      .welfare3
        b 第三弹：新服锦鲤<br>
        span 活動時間：12月24日 - 12月25日<br>
        span 第1波（24號下午3點）：抽取10名幸運玩家送上元寶*8888<br>
        span 第2波（24號下午6點）：抽取8名幸運玩家，送上價值1萬元寶的資源大禮包<br>
        span 第3波（25號下午3點）：抽取5名儲值過的玩家送上年卡1張（儲值任意金額即可參與）
  .contact-container.column-center
    .btn-contact.bg-c.inner-center(@click="contactUs") 聯繫我們
    span 官方保留對活動的解釋權
</template>
<script>
import { appoint } from "@/request/api.js";
export default {
  name: "phoneReserve",
  data() {
    return {
      time: Date.now(),
      phone: ""
    };
  },
  methods: {
    appoint() {
      let { time, phone } = this;
      phone = phone.trim();
      if (!this.validatePhone(phone)) {
        this.$toast("請輸入正確的手機號");
        return;
      }
      const access = this.$encrypte([time, phone]);
      appoint({ time, phone, access }).then(
        data => {
          console.log(data);
          this.$toast("預約成功！請查看手機短信收取兌換碼！");
          this.phone = "";
        },
        err => {
          this.$toast(err.msg);
        }
      );
    },
    validatePhone(phone) {
      return phone.length >= 7 && phone.length <= 13 && /^\d+$/.test(phone);
    },
    contactUs() {
      // window.open("https://wpa1.qq.com/tYyC2BmQ?_type=wpa&qidian=true")
      window.open("https://www.facebook.com/zijinfanhua");
    }
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.phoneReserve
  width: 100%
  height: 1960px
  background-image: bg('phoneReserve/bg_phone_reserve.jpg')
  overflow: hidden
.top-desc-container
  width: 86%
  margin: 700px 0 0 0
  .order-time
    span
      font-size: 22px
      &:nth-of-type(1)
        color: #C52A13
        font($bold)
      &:nth-of-type(2)
        color: #714E4B
        font($regular)
  .order-methods
    line-height: 40px
    span
      display: block
      font-size: 22px
      &:nth-of-type(1)
        color: #C52A13
        font($bold)
      &:not(:nth-of-type(1))
        color: #714E4B
        font($regular)
.main-order
  width: 100%
  margin: 40px 0 40px 0
  display: flex
  position: relative
  input
    width: 462px
    height: 74px
    margin: 0 0 0 35px
    padding: 20px
    background: #FFFFFF
    border: 1px solid #F47959
    opacity: 0.99
    flex-shrink: 0
    font($regular)
  input::-webkit-input-placeholder /* WebKit browsers */
    color: #E4B19E
  input:-moz-placeholder /* Mozilla Firefox 4 to 18 */
    color: #E4B19E
  input::-moz-placeholder /* Mozilla Firefox 19+ */
    color: #E4B19E
  input:-ms-input-placeholder /* Internet Explorer 10+ */
    color: #E4B19E
  .btn-reserve
    width: 274px
    height: 79px
    position: absolute
    top: -3px
    left: 450px
    font-size: 40px
    color: #FDFBB3
    background-image: bg('phoneReserve/btn-reserve.png')
    flex-shrink: 0
    font($bold)
.btm-desc-container
  width: 86%
  .title-box
    font-size: 19.02px
    color: #C52A13
    line-height: 39px
    font($bold)
  .welfare-box
    margin: 20px 0 20px 0
    font-size: 22px
    align-items: flex-start
  b
    color: #C52A13
    font($bold)
  span
    color: #714E4B
    line-height: 42px
    font($regular)
.contact-container
  .btn-contact
    width: 298px
    height: 84px
    font-size: 32.71px
    color: #FDF6E7
    background-image: imgUrl('btn-task.png')
    font($bold)
  span
    font-size: 19.02px
    color: #585858
    margin: 10px 0 0 0
    font($regular)
</style>
