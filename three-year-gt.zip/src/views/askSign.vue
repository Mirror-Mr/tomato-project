<!--
 * @Author: your name
 * @Date: 2021-12-01 17:17:25
 * @LastEditTime: 2021-12-02 11:51:55
 * @LastEditors: Please set LastEditors
 * @Description:活动二
 * @FilePath: \three-year\src\views\down.vue
-->
<template lang="pug">
.ask-sing
  Mymodal(@close="close", :show="cackpack", :longBg="true")
    .prize-back(v-if="chosePrize || exchangeGame", @click="clickBack")
    .prizePool-number
      .content-title.prizePool-footer
        span 擁有幸運簽：
        span.icon
        span.number {{ lotteryNum }}
    .prizePool-title
    .prizePool-content
      .public-prize(
        v-for="(item, index) in prizeList",
        :key="index",
        :class="(index + 1) % 3 == 0 ? 'public-prize-center' : ''"
      )
        .public-icon(
          :class="{ 'public-icon-active': item.id - 0 <= 7 || item.id == '30' }",
          @click="clickChosePrize(index)"
        )
          img(
            :src="'https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/common/ask-icon-' + item.id + '.png?v=0.0.2'"
          )
          .public-name {{ item.name }}
          i.public-checked(
            v-if="chosePrize || exchangeGame",
            :class="{ 'active-i': item.selected }"
          )
        .public-des
          span.public-reduce(
            v-if="chosePrize || exchangeGame",
            @click="clickReduce(index)"
          )
          span.public-words {{ (!chosePrize ? '擁有：' : '') + item.number }}
          span.public-add(
            v-if="chosePrize || exchangeGame",
            @click="clickAdd(index)"
          )
    .prize-button
      .prize-chose(
        v-if="!chosePrize && !exchangeGame",
        @click="(chosePrize = true), (tag = 'receive')"
      )
      .prize-checked(v-if="chosePrize")
        .checked-all
          i(:class="{ 'active-i': selectedAll }", @click="clickSelectedAll")
          span 全選
        .checked-des 已選擇獎勵:
        .checked-num {{ exchangeNumber }}
      .prize-checked(v-if="exchangeGame")
        .checked-all
          i(:class="{ 'active-i': selectedAll }", @click="clickSelectedAll")
          span 全選
      .prize-exchange(
        v-if="!chosePrize && !exchangeGame",
        @click="(exchangeGame = true), (tag = 'exchange')"
      )
      .prize-receive(v-if="chosePrize", @click="choseReceiveToGame('receive')")
      .prize-exchange-game(
        v-if="exchangeGame",
        @click="choseReceiveToGame('exchange')"
      )
        .prize-exchange-game-top
          .checked-des 已選擇轉換物品：
          .checked-num {{ exchangeNumber }}
        .prize-exchange-game-content {{ '兌換' + exchangeSign + '個' }}
          i
    p.style-p(v-if="exchangeGame") 1.每3個獎勵可兌換1個幸運簽
    p.style-p(v-if="exchangeGame") 2.多選的最後不足3個的獎勵會保留
  //- 奖池奖励
  Mymodal(@close="close", :show="prizePool", :longBg="true")
    .prize-back(v-if="chosePrize || exchangeGame", @click="prizePool")
    .prizePool-number
      .content-title.prizePool-footer
        span 擁有幸運簽：
        span.icon
        span.number {{ lotteryNum }}
    .prizePool-title.prize-pool-title
    .prizePool-content.prize-pool-content
      .public-prize(
        v-for="(item, index) in prizePoolList",
        :key="index",
        :class="(index + 1) % 3 == 0 ? 'public-prize-center' : ''"
      )
        .public-icon(
          :class="{ 'public-icon-active': item.id - 0 <= 7 || item.id == 30 }"
        )
          img(
            :src="'https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/common/ask-icon-' + (index <= 4 ? index + 1 : index == 5 ? '30' : index) + '.png?v=0.0.2'"
          )
          .public-name {{ item.name }}
          i.public-checked(
            v-if="chosePrize || exchangeGame",
            :class="{ 'active-i': item.selected }",
            @click="clickChosePrize(index)"
          )
  Mymodal(@close="close", :show="dialogBuy", :longBg="true")
    .prizePool-number
      .content-title.prizePool-footer
        span 擁有幸運簽：
        span.icon
        span.number {{ lotteryNum }}
    .dialog-title
    .dialog-buy-content
      .public-dialog-buy(v-for="(item, index) in priceList", :key="index")
        .public-dialog-buy-sign
        .public-dialog-buy-des
          p {{ item.name }}
          span {{ item.des }}
        .public-dialog-buy-price(@click="buy(index + 16, 1)") {{ 'NT$' + item.price }}
  //- 规则弹框
  Mymodal(@close="dialogRule = false", :show="dialogRule", :longBg="true")
    .dialog-rule
    .dialog-rule-content
      p 1. 活動時間為2021年12月24日-2022年1月6日​
      p 2. 活動期間，可使用【幸運簽】進行單抽或連抽，單抽消耗1支【幸運簽】抽1次；連抽消耗5支【幸運簽】抽6次​
      p 3. 購買幸運簽不計入遊戲內vip經驗​
      p 4. 累計抽到一定數量的【上上簽】可獲得大獎時裝的對應部件，最多能抽到8個【上上簽】​
      p 5. 本活動中獲得的道具，可在背包領取並發放至遊戲內使用；也可選擇將每3個道具（除服裝部件外），兌換成1支【幸運簽】​
      p 6. 活動結束後，未領取的獎勵道具將清空，請小主們及時使用​
      p 7. 活動最終解釋權歸《紫禁繁花》官方團隊所有
  //- 阶段性奖励弹框
  Mymodal(
    @close="dialogTarget = -1",
    :show="dialogTarget !== -1",
    :longBg="false"
  )
    .dialog-rule-stage
    .public-prize.public-prize-special
      .public-icon(:class="{ 'public-icon-active': dialogTarget + 1 <= 7 }")
        img(
          :src="'https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/common/ask-icon-' + (dialogTarget <= 4 ? dialogTarget + 1 : dialogTarget == 5 ? '30' : dialogTarget == 6 || dialogTarget == 7 ? dialogTarget : '') + '.png?v=0.0.2'"
        )
        .public-name {{ dialogTarget >= 0 ? prizePoolList[dialogTarget].name : '' }}
  //- 领取弹框
  Mymodal(
    @close="receiveDialog = false",
    :show="receiveDialog",
    :longBg="false"
  )
    .dialog-receive-title
      img(
        :src="'https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/common/ask-' + receiveObj.icon + '.png?v=0.0.2'"
      )
    .dialog-receive-content 
      p {{ receiveObj.name }}
      p.receive-des {{ receiveObj.des }}
    .dialog-receive-button
      .button-sub(@click="receiveToGame('receive')")
      .button-cancel(
        @click="receiveDialog = false",
        v-if="receiveObj.icon === 'sub-receive' || receiveObj.icon === 'sub-exchange'"
      )
  //- 抽签奖励弹框
  Mymodal(
    @close="receiveSuccess = false",
    :show="receiveSuccess",
    :longBg="false"
  )
    .dialog-receive-congratulations
    .dialog-receive-congratulations-des
      p {{ receiveObj.name }}
    .prizePool-content.prize-pool-content.prizePool-content-special
      .public-prize(
        v-for="(item, index) in lotteryShowList",
        :key="index",
        :class="(index + 1) % 3 == 0 ? 'public-prize-center' : ''"
      )
        .public-icon(:class="{ 'public-icon-active': item.id - 0 <= 7 }")
          img(
            :src="'https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/common/ask-icon-' + item.id + '.png?v=0.0.2'"
          )
          .public-name {{ item.name }}
          i.public-checked(
            v-if="chosePrize || exchangeGame",
            :class="{ 'active-i': item.selected }",
            @click="clickChosePrize(index)"
          )
    .dialog-receive-button
      .button-sub(@click="receiveSuccess = false")
  .login
    LoginStatus(ref="login")
  .menu
    .menu-top(@click="viewBackpack('cackpack')")
    .menu-bottom(@click="prizePool = true") 
  .title
  .rule
    .rule-btn(@click="dialogRule = true")
  .content-title
    span 已獲得上上簽：
    span.icon
    span {{ specialSignNum }}
  .content
    .left
      .public-tag(
        v-for="(item, index) in giftList",
        :key="item",
        :class="[index == 6 || index == 7 ? 'public-tag-last' : '']",
        @click="receiveStagePrize(index)"
      )
        .bar
        .public-title 上上簽:
          span {{ index + 1 }}
        .gift
          img.ask-gift-icon(
            :src="'https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/common/ask-icon-' + item.id + '.png?v=0.0.1'"
          )
          .received(v-if="currentId / 10 >= index + 1")
    .right
      .pet
  .lottery
    .lottery-once(@click="viewBackpack('lottery', 1)")
    .lottery-center(
      :class="[{ animate__animated: lotteryTada }, { ' animate__tada': lotteryTada }]"
    )
      .ask-sign
    .lottery-five(@click="viewBackpack('lottery', 5)")
  .content-title.lottery-footer
    span 擁有幸運簽：
    span.icon
    span.number {{ lotteryNum }}
    .add(@click="viewBackpack('dialogBuy')")
  .footer-time 活動時間：2021.12.24-2021.01.06
</div>
</template>
<script>
import {
  lotteryDraw,
  subLotteryPrize,
  getPrizeHistory,
  getUserInfo,
  pay,
} from "@/request/api.js";
import { mapState } from "vuex";
import { debounce, getQueryValue, isWeChat } from "@/utils/index";
export default {
  name: "",
  data() {
    return {
      cackpack: false,
      prizePool: false,
      chosePrize: false,
      selectedAll: false,
      exchangeGame: false,
      dialogRule: false,
      dialogTarget: -1,
      exchangeNumber: 0,
      exchangeSign: 0,
      dialogBuy: false,
      receiveDialog: false,
      receiveSuccess: false,
      successDialog: true,
      // 抽签动画
      lotteryTada: false,
      receiveObj: {
        icon: "receive-success",
        name: "請到本頁面-背包內查看獎勵！",
        des: "",
      },
      giftList: [
        { id: "1", name: "耳飾-遙雪光" },
        { id: "2", name: "髮飾-凝雨枝*1" },
        { id: "3", name: "背景-冰雪琉璃*1" },
        { id: "4", name: "特效-寒酥飄絮*1" },
        { id: "5", name: "寵物-踏霜*1" },
        { id: "30", name: "妝容-猗蘭蘊秀*1" },
        { id: "6", name: "髮型-向日暖*1" },
        { id: "7", name: "衣服-可堪冬歲*1" },
      ],
      prizePoolList: [
        { id: "1", name: "耳飾-遙雪光*1" },
        { id: "2", name: "髮飾-凝雨枝*1" },
        { id: "3", name: "背景-冰雪琉璃*1" },
        { id: "4", name: "特效-寒酥飄絮*1" },
        { id: "5", name: "寵物-踏霜*1" },
        { id: "30", name: "妝容-猗蘭蘊秀*1" },
        { id: "6", name: "髮型-向日暖*1" },
        { id: "7", name: "衣服-可堪冬歲*1" },
        { id: "8", name: "高級保養油*1" },
        { id: "9", name: "氣勢靈液*1" },
        { id: "10", name: "智謀靈液*1" },
        { id: "11", name: "政略靈液*1" },
        { id: "12", name: "魅力靈液*1" },
        { id: "13", name: "黃銅腰牌*5" },
        { id: "14", name: "保養油*2" },
        { id: "15", name: "焦尾琴*1" },
        { id: "16", name: "宮殿挑戰書*2" },
        { id: "17", name: "宮殿廷鬥令*2" },
        { id: "18", name: "官宴食材*2" },
        { id: "19", name: "官宴佐料*2" },
        { id: "20", name: "知己精力丹*3" },
        { id: "21", name: "出城體力丹*3" },
        { id: "22", name: "徒弟活力丹*3" },
        { id: "23", name: "日常令*5" },
        { id: "24", name: "辦差令*5" },
        { id: "25", name: "車馬令*2" },
        { id: "26", name: "徵收手札*10" },
        { id: "27", name: "徵收銀票*10" },
        { id: "28", name: "徵收名帖*10" },
        { id: "29", name: "天日白月匣*1" },
      ],
      prizeList: [
        {
          name: "耳飾卡*1",
          icon: "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/common/pirze-icon01.png?v=0.0.2",
          selected: false,
          number: 33,
        },
      ],
      savePrizeList: [],
      priceList: [
        { name: "幸運簽*1", des: "贈：元寶*360", price: 30 },
        { name: "幸運簽*5", des: "贈：元寶*1800", price: 150 },
        { name: "幸運簽*10+2", des: "贈：元寶*4080", price: 300 },
        { name: "幸運簽*30+5", des: "贈：元寶*11880", price: 890 },
        { name: "幸運簽*52+6", des: "贈：元寶*19680", price: 1490 },
        { name: "幸運簽*108+9", des: "贈：元寶*38880", price: 3000 },
      ],
      // lotteryNum: 0,
      // specialSignNum: 0,
      tag: "receive",
      lotteryShowList: [],
      // currentId: 0,
    };
  },
  watch: {
    // currentId
    currentId(val, oldVal) {
      //普通的watch监听
      console.log("a: " + val, oldVal);
    },
    "$store.state.historyUpdate": {
      //普通的watch监听
      handler: function (newValue, oldValue) {
        console.log("historyUpdate: " + newValue, oldValue);
        this.getPrizeHistoryList();
      },
    },
  },
  computed: {
    ...mapState({
      // 用户信息
      userInfo: "userInfo",
      activty: "activty",
      lotteryNum: "lotteryNum",
      specialSignNum: "specialSignNum",
      currentId: "currentId",
    }),
    isPay() {
      return this.activty && this.activty.hasOwnProperty("gid");
    },
  },
  methods: {
    buy(good_id, num) {
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token]);
      let wxid = "";
      if (isWeChat()) {
        wxid = sessionStorage.getItem("wxid");
      }
      pay({
        time,
        token,
        good_id,
        num,
        access,
        wxid,
      })
        .then((data) => {
          // console.log(data);
          window.location.href = data.url;
        })
        .catch((err) => {});
    },
    choseReceiveToGame(tag) {
      this.tag = tag;
      let ids = {};
      let obj = {};
      this.prizeList.forEach((ele) => {
        if (ele.selected && ele.number != 0) {
          obj[ele.id] = ele.number;
          ids = JSON.parse(JSON.stringify(obj));
        }
      });
      var arr = Object.keys(ids);
      if (arr.length === 0) {
        this.$toast("請選擇獎勵");
        return;
      }
      if (tag === "receive") {
        this.receiveDialog = true;
        this.receiveObj.icon = "sub-receive";
        this.receiveObj.name =
          "是否將獎勵領取至 " + this.userInfo.role_name + "（當前角色）？";
        this.receiveObj.des = "";
      } else {
        if (this.exchangeSign < 1) {
          this.$toast("道具數量不足");
          return;
        }
        this.receiveDialog = true;
        this.receiveObj.icon = "sub-exchange";
        console.log(this.userInfo);
        this.receiveObj.name = "";
        this.receiveObj.des =
          "是否將當前選中的" +
          (this.exchangeNumber - (this.exchangeNumber % 3)) +
          "件道具兌換為" +
          this.exchangeSign +
          "張幸運簽？";
      }
    },
    receiveToGame() {
      if (
        this.receiveObj.icon == "receive-success" ||
        this.receiveObj.icon == "exchange-success"
      ) {
        this.receiveDialog = false;
        return;
      }
      let ids = {};
      let obj = {};
      this.prizeList.forEach((ele) => {
        if (ele.selected && ele.number != 0) {
          obj[ele.id] = ele.number;
          ids = JSON.parse(JSON.stringify(obj));
        }
      });
      var arr = Object.keys(ids);
      if (arr.length === 0) {
        this.$toast("請選擇獎勵");
        return;
      }
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token, JSON.stringify(ids)]);
      subLotteryPrize({
        time: time,
        token: token,
        type: this.tag === "receive" ? "1" : "2",
        access: access,
        ids: JSON.stringify(ids),
      })
        .then((data) => {
          this.receiveDialog = true;
          if (this.tag === "receive") {
            this.receiveObj.icon = "receive-success";
            this.receiveObj.name = "領取成功！請至遊戲內郵箱查看。";
            this.receiveObj.des = "";
          } else {
            this.receiveObj.icon = "exchange-success";
            this.receiveObj.name =
              "您已成功將" +
              (this.exchangeNumber - (this.exchangeNumber % 3)) +
              "件道具兌換為" +
              this.exchangeSign +
              "張幸運簽！";
            this.receiveObj.des = "";
          }
          this.exchangeNumber = 0;
          this.exchangeSign = 0;
          this.selectedAll = false;
          this.getPrizeHistoryList();
          this.getUserInfoList();
        })
        .catch((err) => {});
    },
    viewBackpack(type, count) {
      if (this.userInfo) {
        if (type === "lottery") {
          this.lotteryTada = true;
          setTimeout(() => {
            this.lotteryTada = false;
            this.getLotteryDraw(count);
          }, 500);
        } else {
          this[type] = true;
        }
      } else {
        this.$refs.login.showlogin();
      }
    },
    // 获取活动详情
    getUserInfoList() {
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token]);
      getUserInfo({
        time: time,
        // project_id: 35,
        token: token,
        type: "2",
        access: access,
      })
        .then((data) => {
          this.$store.commit("SETVAL", {
            lotteryNum: data.data.num,
            specialSignNum: data.data.qian_num,
            currentId: data.data.current_id,
          });
        })
        .catch((err) => {});
    },
    // 抽签
    getLotteryDraw: debounce(async function (count) {
      if (count > this.lotteryNum) {
        this.$toast("您的幸運簽不足");
        this.lotteryTada = false;
        this.dialogBuy = true;
        return;
      }
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token]);
      lotteryDraw({
        time: time,
        token: token,
        type: count,
        access: access,
      })
        .then((data) => {
          console.log(data);
          this.receiveSuccess = true;
          this.lotteryShowList = [];
          this.receiveObj.name = "請到本頁面-背包內查看獎勵！";
          data.forEach((ele) => {
            if (ele.index <= 6)
              this.receiveObj.name = "恭喜您本次抽中上上簽，獲得對應套裝部件！";
            let obj = {};
            obj.name = "";
            this.prizePoolList.forEach((item) => {
              if (item.id == ele.index) {
                obj.name = item.name;
              }
            });
            obj.id = ele.index;
            this.lotteryShowList.push(obj);
          });
          console.log(this.lotteryShowList);
          this.getPrizeHistoryList();
          this.getUserInfoList();
          this.lotteryTada = false;
        })
        .catch((err) => {
          // console.log(err)
          this.lotteryTada = false;
        });
    }, 1000),
    // 获取剩余记录
    getPrizeHistoryList() {
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token]);
      getPrizeHistory({
        time: time,
        // project_id: 35,
        token: token,
        type: "2",
        access: access,
      })
        .then((data) => {
          this.prizeList = [];
          let arr = Object.keys(data.prize);
          this.prizePoolList.forEach((item) => {
            if (arr.includes(item.id)) {
              var obj = {};
              obj.id = item.id;
              obj.name = item.name;
              obj.number = data.prize[item.id];
              obj.selected = false;
              if (data.prize[item.id] > 0) {
                this.prizeList.push(obj);
              }
            }
          });
          this.savePrizeList = JSON.parse(JSON.stringify(this.prizeList));
        })
        .catch((err) => {});
    },
    // 领取阶段性奖励
    receiveStagePrize(index) {
      this.dialogTarget = index;
    },
    close() {
      this.cackpack = false;
      this.prizePool = false;
      this.dialogBuy = false;
      this.chosePrize = false;
      this.exchangeGame = false;
      this.selectedAll = false;
      this.exchangeSign = 0;
      this.exchangeNumber = 0;
      this.prizeList = JSON.parse(JSON.stringify(this.savePrizeList));
      this.prizeList.forEach((element) => {
        element.selected = false;
      });
    },
    clickReduce(index) {
      if (this.prizeList[index].number == 0) return;
      this.prizeList[index].number--;
      if (!this.prizeList[index].selected) return;
      this.exchangeNumber--;
      this.exchangeSign = parseInt(this.exchangeNumber / 3);
    },
    clickAdd(index) {
      if (this.prizeList[index].number == this.savePrizeList[index].number)
        return;
      this.prizeList[index].number++;
      this.exchangeNumber++;
      this.exchangeSign = parseInt(this.exchangeNumber / 3);
    },
    clickSelectedAll() {
      this.exchangeNumber = 0;
      this.selectedAll = !this.selectedAll;
      if (this.selectedAll) {
        this.prizeList.forEach((element) => {
          if (this.tag !== "receive") {
            if (parseInt(element.id) > 7 && parseInt(element.id) != 30) {
              element.selected = true;
              this.exchangeNumber += element.number;
            }
          } else {
            element.selected = true;
            this.exchangeNumber += element.number;
          }
        });
        this.exchangeSign = parseInt(this.exchangeNumber / 3);
      } else {
        this.prizeList.forEach((element) => {
          element.selected = false;
          this.exchangeNumber = 0;
        });
      }
    },
    clickChosePrize(index) {
      if (this.tag !== "receive") {
        if (this.prizeList[index].id <= 7 || this.prizeList[index].id == 30) {
          this.$toast("服飾部件不能兌換");
          return;
        }
      }
      this.prizeList[index].selected = !this.prizeList[index].selected;
      if (!this.prizeList[index].selected) this.selectedAll = false;
      let num = 0;
      this.exchangeNumber = 0;
      this.prizeList.forEach((element) => {
        if (element.selected) {
          num++;
          this.exchangeNumber += element.number;
        }
      });
      this.exchangeSign = parseInt(this.exchangeNumber / 3);
      if (num == this.prizeList.length) this.selectedAll = true;
    },
    clickBack() {
      this.chosePrize = false;
      this.exchangeGame = false;
      this.selectedAll = false;
      this.exchangeSign = 0;
      this.exchangeNumber = 0;
      this.prizeList = JSON.parse(JSON.stringify(this.savePrizeList));
      this.prizeList.forEach((element) => {
        element.selected = false;
      });
    },
    download() {
      var u = navigator.userAgent;
      var isAndroid = u.indexOf("Android") > -1 || u.indexOf("Adr") > -1; //android终端
      var isiOS = !!u.match(/Mac OS X/); //ios终端
      if (isAndroid) {
        window.location.href =
          "https://source-apk.tomatogames.com/sem/apk/wbqj/gdtyl01/wbqj_and_gdtyl01_02.apk";
      } else {
        window.location.href =
          "https://apple-app-site-wbqj.tomatogames.com/open-app";
      }
    },
  },
  mounted() {
    let token = localStorage.getItem("token");
    token && this.$store.dispatch("getInfo", 2);
    if (token) {
      this.getPrizeHistoryList();
      this.getUserInfoList();
    }
    // 判断是否微信环境
    if (isWeChat()) {
      const wxid = getQueryValue("wxid");
      if (wxid) {
        sessionStorage.setItem("wxid", wxid);
      }
      let data = sessionStorage.getItem("wxid");
      if (!data) {
        location.href = `https://api.xianyuyouxi.com/service/activity/zjfh_third_ani/getauth?url=${encodeURIComponent(
          location.href
        )}`;
      }
    }
  },
};
</script>
<style scoped lang='stylus'>
.ask-sing
  width: 100%
  min-height: 100vh
  padding-bottom: 11px
  background: bg('common/ask-bg.jpg?v=0.0.5') no-repeat
  background-size: 100% 100%
  position: relative
  .dialog-receive-title
    width: 192px
    height: 47px
    margin: 60px auto 0
    text-align: center
    img
      width: 192px
      height: 47px
  .dialog-receive-congratulations
    width: 519px
    height: 92px
    margin: 30px auto 0
    background: bg('common/ask-congratulations.png?v=0.0.3') no-repeat
    background-size: 100%
  .dialog-receive-content
    width: 100%
    font-size: 28px
    text-align: center
    margin: 60px auto
    .receive-des
      margin-top: 16px
      font-size: 28px
  .dialog-receive-congratulations-des
    width: 100%
    margin: 22px 0
    text-align: center
    font-size: 22px
  .dialog-receive-congratulations-content
    display: flex
    flex-wrap: wrap
  .dialog-receive-button
    width: 100%
    height: 67px
    padding: 0 39px
    display: flex
    justify-content: center
    .button-sub
      width: 237px
      height: 67px
      background: bg('common/ask-button-sub.png?v=0.0.3') no-repeat
      background-size: 100%
    .button-cancel
      width: 237px
      height: 67px
      margin-left: 22px
      background: bg('common/ask-button-cancel.png?v=0.0.3') no-repeat
      background-size: 100%
  .dialog-rule
    width: 519px
    height: 92px
    margin: 30px auto 0
    background: bg('common/ask-rule-title.png?v=0.0.3') no-repeat
    background-size: 100%
  .dialog-rule-content
    margin-top: 10px
    padding: 30px 30px 0
    line-height: 48px
  .dialog-rule-stage
    width: 314px
    height: 72px
    margin: 30px auto 0
    background: bg('common/ask-stage-title.png?v=0.0.3') no-repeat
    background-size: 100%
  .prizePool-title
    width: 442px
    height: 92px
    margin: 20px auto 0
    background: bg('common/prizePool-title.png?v=0.0.3') no-repeat
    background-size: 100%
  .prize-pool-title
    width: 442px
    height: 92px
    margin: 20px auto 0
    background: bg('common/prize-pool-title.png?v=0.0.3') no-repeat
    background-size: 100%
  .dialog-title
    width: 442px
    height: 92px
    margin: 20px auto 0
    background: bg('common/ask-dialog-buy.png?v=0.0.3') no-repeat
    background-size: 100%
  .dialog-buy-content
    .public-dialog-buy
      width: 524px
      height: 105px
      margin: 30px auto 30px
      padding-left: 130px
      background: bg('common/ask-buy-bg.png?v=0.0.3') no-repeat
      background-size: 100%
      position: relative
      display: flex
      align-items: center
    .public-dialog-buy-sign
      width: 96px
      height: 126px
      background: bg('common/ask-buy-sign.png?v=0.0.3') no-repeat
      background-size: 100%
      position: absolute
      top: -10px
      left: 20px
    .public-dialog-buy-des
      width: 250px
      margin-left: 10px
      p
        font-size: 28px
        font-weight: 700
      span
        font-size: 20px
    .public-dialog-buy-price
      width: 163px
      height: 51px
      line-height: 51px
      font-size: 28px
      margin-left: 10px
      color: #FDF6E7
      text-align: center
      background: bg('common/ask-price-bg.png?v=0.0.3') no-repeat
      background-size: 100%
  .public-icon
    width: 192px
    height: 192px
    background: bg('common/ask-prize-bg.png?v=0.0.3') no-repeat
    background-size: 100%
    display: flex
    justify-content: center
    align-items: center
    position: relative
    img
      transform: scale(0.4)
    .public-name
      width: 150px
      height: 26px
      background: bg('common/ask-name-bg.png?v=0.0.3') no-repeat
      background-size: 100%
      position: absolute
      bottom: 36px
      font-size: 20px
      line-height: 26px
      text-align: center
      color: #FDF6E7
    .public-checked
      position: absolute
      right: 30px
      top: 30px
  .public-icon-active
    background: bg('common/ask-prize-bg-active.png?v=0.0.3') no-repeat
    background-size: 100%
  .public-prize
    margin-bottom: 20px
    margin-left: -12px
  .public-des
    height: 27px
    font-size: 18px
    color: #CA5E3D
    text-align: center
    display: flex
    align-items: center
    justify-content: center
    .public-reduce
      display: inline-block
      width: 27px
      height: 27px
      background: bg('common/ask-icon-reduce.png?v=0.0.3') no-repeat
      background-size: 100%
    .public-words
      display: inline-block
      margin: 0 10px
    .public-add
      display: inline-block
      width: 27px
      height: 27px
      background: bg('common/ask-icon-add.png?v=0.0.3') no-repeat
      background-size: 100%
  .public-prize-special
    display: flex
    justify-content: center
    margin-top: 40px
  .prizePool-content
    width: 100%
    max-height: 520px
    display: flex
    flex-wrap: wrap
    // padding: 0 40px 0 10px
    padding-left: 38px
    overflow: scroll
    .public-prize-center
      // margin-right: 0
  .prizePool-content-special
    width: 100%
    max-height: 520px
    display: flex
    flex-wrap: wrap
    padding: 0
    justify-content: center
  .prize-pool-content
    max-height: 780px
  .style-p
    color: #DA8F79
    font-size: 20px
    padding-left: 34px
  .prize-button
    display: flex
    justify-content: space-between
    align-items: center
    padding: 0 46px
    margin-top: 80px
    margin-bottom: 30px
    .prize-chose
      width: 237px
      height: 67px
      background: bg('common/ask-btn-chose.png?v=0.0.3') no-repeat
      background-size: 100%
    .prize-checked
      display: flex
      align-items: center
      font-size: 22px
      color: #CA5E3D
      height: 27px
      .checked-all
        margin-right: 20px
        display: flex
        align-items: center
        span
          margin-left: 10px
      .checked-num
        color: #E45234
    .prize-exchange
      width: 237px
      height: 67px
      background: bg('common/ask-btn-exchange.png?v=0.0.3') no-repeat
      background-size: 100%
    .prize-receive
      width: 237px
      height: 67px
      background: bg('common/ask-icon-receive.png?v=0.0.3') no-repeat
      background-size: 100%
    .prize-exchange-game
      width: 237px
      height: 67px
      background: bg('common/ask-icon-ex-game.png?v=0.0.3') no-repeat
      background-size: 100%
      position: relative
      .prize-exchange-game-top
        width: 100%
        display: flex
        justify-content: center
        align-items: center
        position: absolute
        top: -45px
        left: 50%
        transform: translate(-50%, 0)
      .prize-exchange-game-content
        width: 237px
        height: 67px
        line-height: 67px
        text-align: center
        font-size: 26px
        color: #FDF6E7
        display: flex
        justify-content: center
        align-items: center
        i
          display: inline-block
          width: 23px
          height: 50px
          margin-left: 10px
          background: bg('common/ask-icon.png?v=0.0.3') no-repeat
          background-size: 100%
  i
    display: inline-block
    width: 27px
    height: 27px
    background: bg('common/ask-unselected.png?v=0.0.3') no-repeat
    background-size: 100%
  .active-i
    background: bg('common/ask-selected.png?v=0.0.3') no-repeat
    background-size: 100%
  .content-title
    width: 230px
    height: 40px
    line-height: 40px
    padding: 0 19px
    font-size: 22px
    margin: 26px 0 0 110px
    background: #C43F1C
    color: #FFD0AF
    border-radius: 20px
    display: flex
    align-items: center
    .icon
      display: inline-block
      width: 19px
      height: 41px
      margin-right: 5px
      background: bg('common/ask-icon.png?v=0.0.3') no-repeat
      background-size: 100% 100%
  .content-title-special
    padding: 0
  .login
    text-align: right
  .title
    width: 506px
    height: 52px
    margin: 145px auto 0
    font-size: 24px
    line-height: 54px
    text-align: center
    background: bg('common/ask-title.png?v=0.0.6') no-repeat
    background-size: 100%
  .rule
    width: 485px
    height: 81px
    margin-left: 220px
    background: bg('common/ask-rule.png?v=0.0.3') no-repeat
    background-size: 100%
    position: relative
    .rule-btn
      width: 165px
      height: 1.75rem
      background-size: 100%
      position: absolute
      right: 50px
  .prizePool-number
    display: flex
    justify-content: flex-end
    .prizePool-footer
      // width 260px
      margin: 0 30px 0
      padding: 0
      background: none
      color: #FFAC55
      .icon
        width: 23px
        height: 1.5625rem
      .number
        color: #FF6059
  .prize-back
    width: 40px
    height: 40px
    background: bg('common/ask-back.png?v=0.0.3') no-repeat
    background-size: 100%
    position: absolute
    top: 70px
    left: 30px
  .lottery-footer
    width: 309px
    margin: 20px auto 0
    background: bg('common/ask-title-bg.png?v=0.0.3') no-repeat
    background-size: 100% 100%
    .number
      color: #FF593D
    .add
      width: 46px
      height: 46px
      margin-left: 25px
      background: bg('common/ask-add.png?v=0.0.3') no-repeat
      background-size: 100% 100%
  .content
    position: relative
    height: 900px
    .left
      display: flex
      flex-wrap: wrap
      width: 470px
      padding: 34px 0 0 145px
      position: absolute
      z-index: 1
      .public-tag
        width: 128px
        height: 205px
        margin-right: 19px
        margin-bottom: 9px
        background: bg('common/ask-tag-bg.png?v=0.0.3') no-repeat
        background-size: 100% 100%
        position: relative
        .bar
          width: 13px
          height: 46px
          background: bg('common/ask-bar.png?v=0.0.3') no-repeat
          background-size: 100% 100%
          position: absolute
          top: -31px
          left: 58px
        .public-title
          width: 100%
          margin-top: 19px
          text-align: center
          font-size: 22px
          color: #A44B33
          span
            color: #D74A30
        .gift
          width: 107px
          height: 107px
          margin: 28px auto 0
          background: bg('common/gift-bg.png?v=0.0.3') no-repeat
          background-size: 100% 100%
          display: flex
          justify-content: center
          align-items: center
          position: relative
          .ask-gift-icon
            width: 60px
          .received
            width: 88px
            height: 76px
            background: bg('common/ask-icon-received.png?v=0.0.3') no-repeat
            background-size: 100% 100%
            position: absolute
      .public-tag-last
        background: bg('common/ask-tag-bg-last.png?v=0.0.3') no-repeat
        background-size: 100% 100%
      .public-tag-special
        // -webkit-filter: grayscale(100%)
        // -moz-filter: grayscale(100%)
        // -ms-filter: grayscale(100%)
        // -o-filter: grayscale(100%)
        // filter: grayscale(100%)
        // filter: gray
    .right
      width: 489px
      height: 1156px
      position: absolute
      top: -100px
      right: 0
      background: bg('common/ask-heroine.png?v=0.0.3') no-repeat
      background-size: 100% 100%
      .pet
        width: 140px
        height: 384px
        background: bg('common/ask-pet.png?v=0.0.3') no-repeat
        background-size: 100% 100%
        position: absolute
        right: 0
        bottom: -35px
  .lottery
    display: flex
    justify-content: center
    position: relative
    z-index: 5
    .lottery-once
      width: 248px
      height: 173px
      background: bg('common/ask-once.png?v=0.0.5') no-repeat
      background-size: 100% 100%
    .lottery-center
      width: 115px
      height: 186px
      background: bg('common/ask-center.png?v=0.0.3') no-repeat
      background-size: 100% 100%
      position: relative
      bottom: 20px
      .ask-sign
        width: 149px
        height: 98px
        background: bg('common/ask-sign.png?v=0.0.3') no-repeat
        background-size: 100% 100%
        position: absolute
        top: -78px
        left: -19px
    .lottery-five
      width: 248px
      height: 173px
      background: bg('common/ask-five.png?v=0.0.4') no-repeat
      background-size: 100% 100%
  .menu
    width: 79px
    height: 400px
    padding-top: 50px
    background: bg('common/ask-menu.png?v=0.0.3') no-repeat
    background-size: 100% 100%
    position: absolute
    top: 345px
    left: 10px
    z-index: 10
    .menu-top
      width: 79px
      height: 138px
      margin-bottom: 21px
    .menu-bottom
      width: 79px
      height: 188px
  .footer-time
    width: 100%
    text-align: center
    margin-top: 35px
    font-size: 22px
    color: #B5695A
</style>