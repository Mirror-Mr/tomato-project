<!--
 * @Author: your name
 * @Date: 2020-06-12 18:56:03
 * @LastEditTime: 2021-11-11 11:26:26
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \one_year\sezg_one_year\src\views\notFound.vue
-->
<template lang="pug">
    div
        van-empty( description="未找到此頁面")
        .btn( v-if="machine == 'phone'" @click="$router.replace('/m.home')") 返回首頁
</template>
<script>
export default {
  name: "",
  data() {
    return {
      machine: ""
    };
  },
  methods: {},
  mounted() {
    this.machine = localStorage.getItem("machine");
  }
};
</script>
<style scoped lang="stylus">
.btn
    width 2rem
    height calc(0.75 * 75px)
    line-height calc(0.75 * 75px)
    margin 0 auto
    background $red
    color #ffffff
    text-align center
    border-radius calc(0.75 * 75px)
    .tip
        color #000
</style>
