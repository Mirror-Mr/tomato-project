/*
 * @Author: your name
 * @Date: 2021-11-08 10:49:52
 * @LastEditTime: 2021-11-15 19:23:58
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three_year\src\assets\js\vant.js
 */
import Vue from "vue";
import {
  Toast,
  Dialog,
  Swipe,
  SwipeItem,
  Field,
  PullRefresh,
  List,
  RadioGroup,
  Radio,
  Loading,
  Empty,
  Slider,
  Picker,
  Popup,
  ActionSheet
} from "vant";

Vue.use(Toast)
  .use(Dialog)
  .use(Swipe)
  .use(SwipeItem)
  .use(Field)
  .use(PullRefresh)
  .use(List)
  .use(RadioGroup)
  .use(Radio)
  .use(Loading)
  .use(Empty)
  .use(Slider)
  .use(Picker)
  .use(Popup)
  .use(ActionSheet);
