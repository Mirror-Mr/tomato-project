/*
 * @Author: your name
 * @Date: 2021-11-16 16:34:10
 * @LastEditTime: 2021-11-30 17:20:34
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three-year\src\assets\js\newRem.js
 */
!(function(e, t) {
  function n() {
    t.body
      ? (t.body.style.fontSize = 12 * o + "px")
      : t.addEventListener("DOMContentLoaded", n);
  }
  function d() {
		// let width = i.clientWidth > 750 ?750:i.clientWidth
    var e = i.clientWidth / 10;
    i.style.fontSize = e + "px";
  }
  var i = t.documentElement,
    o = e.devicePixelRatio || 1;
  if (
    (n(),
    d(),
    e.addEventListener("resize", d),
    e.addEventListener("pageshow", function(e) {
      e.persisted && d();
    }),
    o >= 2)
  ) {
    var a = t.createElement("body"),
      s = t.createElement("div");
    (s.style.border = ".5px solid transparent"),
      a.appendChild(s),
      i.appendChild(a),
      1 === s.offsetHeight && i.classList.add("hairlines"),
      i.removeChild(a);
  }
})(window, document);
