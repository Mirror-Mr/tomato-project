/*
 * @Author: your name
 * @Date: 2021-11-08 10:49:52
 * @LastEditTime: 2021-12-24 00:57:55
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three_year\src\assets\js\common.js
 */
import Vue from "vue";
import md5 from 'js-md5';
function getTime() {
  let time = parseInt(new Date().getTime() / 1000);
  return time;
}
// 距离指定日期有多少天
function gapDay(dateTime,start) {
	start =  start.replace(/-/g, '/')
  // 指定日期和时间
  var EndTime = new Date(dateTime);
  var startTime = new Date(start) || new Date();
  var t = EndTime.getTime() - startTime.getTime();
  var d = Math.floor(t / 1000 / 60 / 60 / 24);
  return d;
}
// 加密方法
export  function encrypte(params){
  let str ;
	const key = '0391591aafc5db68b08787645b837b4f';
  if(Array.isArray(params) && params.length >0) {
    str = params.reduce(((x,y)=>x+''+y))
		str = key+str
		// console.log('str',str,params)
    return md5(str)
  } else {
    return str
  }
  
}


Vue.prototype.$getTime = getTime
Vue.prototype.$gapDay = gapDay
Vue.prototype.$encrypte = encrypte
