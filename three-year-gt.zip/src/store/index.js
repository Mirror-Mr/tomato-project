/*
 * @Author: your name
 * @Date: 2021-11-08 10:49:52
 * @LastEditTime: 2021-12-21 12:25:32
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three_year\src\store\index.js
 */
import Vue from "vue";
import Vuex from "vuex";
import { encrypte } from "@/assets/js/common.js";
import { getUserInfo, getPrizeHistory, getRedUsers } from "@/request/api.js";
import wish from "./wish";
import { Toast } from "vant";

Vue.use(Vuex);
export default new Vuex.Store({
  state: {
    username: "",
    idName: "",
    is_back: "",
    // 登录平台
    loginChannel: "",
    // 登录方式
    loginType: "phone",
    // 登录方式弹框
    login_type: false,
    // 登录弹框
    login: false,
    // 下载弹框
    down_load: false,
    // 退出
    logout: false,
    // 绑定区服角色弹框
    bind_role: false,
    // 角色绑定手机
    bind_phone: false,
    // 切换角色
    toggle_role: false,
    // 活动一分享海报
    showPoster: false,
    // 活动一邀请红包
    invite_red: false,
    // 活动一红包详情弹框
    congratulation: false,
    // 用户信息
    userInfo: null,
    // 活动一页面，点击分享红包返回的红包Id
    red_id: "",
    act1: {
      num: 0, //万能卡数量
      act1_prize: [], //兑换记录
    },
    // 每天红包限制领取数量
    red_limit: 3,
    // 红包详情信息
    red_detail_info: null,

    // 活动信息
    activty: null,

    isOldPlayer: false,
    notOldPlayer: false,
    cur_day: "",
    // 活动二抽奖值
    lotteryNum: 0,
    specialSignNum: 0,
    currentId: 0,
    // 活动二绑定角色标识
    historyUpdate: false,
  },
  mutations: {
    //这里是set方法
    SETVAL(state, objdata) {
      for (let key in objdata) {
        if (key in state) {
          state[key] = objdata[key];
        }
      }
    },
  },
  getters: {
    //get方法
    getDemoValue: (state) => state.demoValue,
  },
  actions: {
    //这个部分我暂时用不上
    // 获取用户信息
    getInfo({ commit }, type) {
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = encrypte([time, token]);
      let params = {
        time: time,
        token: token,
        type: type,
        access: access,
      };
      getUserInfo(params)
        .then((data) => {
          commit("SETVAL", {
            userInfo: data?.info,
            activty: data?.data,
            lotteryNum: data?.data?.num,
            specialSignNum: data?.data?.qian_num,
            currentId: data?.data?.current_id,
            historyUpdate: true,
          });
        })
        .catch((err) => {
            if (err?.code == 4040  || err.msg.includes("活動結束")) {
              localStorage.clear();
              sessionStorage.clear();
              commit("SETVAL", {
                userInfo: null,
                activty: null,
                lotteryNum: 0,
                specialSignNum: 0,
                currentId: 0,
                historyUpdate: false,
              });
           }
            err?.code != 4040 && Toast(err.msg || "獲取用戶信息失敗")
        });
    },
    // 兑换记录
    getHistory({ commit }, type) {
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = encrypte([time, token]);
      getPrizeHistory({
        time: time,
        token: token,
        type: type,
        access,
        access,
      })
        .then((data) => {
          commit("SETVAL", { act1: data });
        })
        .catch((err) => {
          Toast(err.msg || "獲取兌換記錄失敗");
        });
    },
    // 红包详情记录
    getReddetailInfo({ commit }, red_id) {
      console.log("獲取紅包詳情", red_id);
      // debugger
      let token = localStorage.getItem("token");
      if (!token) {
        commit("SETVAL", { loginChannel: true });
        return;
      }
      // let red_id = this.$route.query.red_id
      if (!red_id) return;
      let time = parseInt(new Date().getTime());
      let access = encrypte([time, token]);

      return new Promise((resolve, reject) => {
        getRedUsers({
          time: time,
          token: token,
          red_id: red_id,
          access: access,
        })
          .then((data) => {
            commit("SETVAL", { red_detail_info: data });
            resolve(data);
          })
          .catch((err) => {
            commit("SETVAL", { red_detail_info: null });
            reject(err);
            this.$toast(err.msg || "獲取紅包領取詳情失敗！");
          });
      });
    },
  },
  modules: {
    wish,
    //这里是我自己理解的是为了给全局变量分组，所以需要写提前声明其他store文件，然后引入这里
  },
});
