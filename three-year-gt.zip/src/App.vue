<!--
 * @Author: your name
 * @Date: 2021-11-08 10:49:52
 * @LastEditTime: 2021-12-21 18:36:39
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three_year\src\App.vue
-->
<template lang="pug">
#app(:class="{ pt85: showDown }", @click.once="clickApp")
  .top_down(:class="{ zindex: login_type }", v-if="showDown")
    .icon.fl.bg-c
    .txt_game.fl 紫禁繁花-三週年 <br/> 小宮女逆襲紫禁城
    .down_btn.fr(@click="down")
  .btn-return.bg-c(
    @click="$router.push('/')",
    v-if="$route.path != '/'",
    :style="{ top: showDown ? '40.1px' : '0px' }"
  ) 
  .btn-music.bg-c(
    :style="{ top: showDown ? '45px' : '5px', left: $route.path == '/' ? '40px' : '40px' }",
    @click.stop="controlMusic()",
    :class="{ pause: !isPlay }"
  )
    //-   keep-alive
    //-     audio(autoplay, ref="audio", loop)
    //-       source(
    //-         src="https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/bg.mp3",
    //-         type="audio/mpeg"
    //-       )
  router-view
  //- 选择登录方式弹框
  LoginType(:show="login_type")
  //- 登录弹框
  Login(:show="login")
  //- 绑定区服信息
  BindRole(:show="bind_role")
  //- 角色绑定手机号
  RoleBindPhone(:show="bind_phone")
  //- 切换角色确认弹框
  ToggleRole(:show="toggle_role")
  //- 分享海报
  Poster(:show="showPoster", :id="red_id")
  //- 退出登录
  LogOut(:show="logout")
  //- 下载游戏弹框
  Down(:show="down_load")
</template>
<script>
import { mapState } from "vuex";
import { clickLog } from "@/request/api.js";
import { getUrlParams } from "@/utils/index";
export default {
  name: "Home",
  components: {
    LoginType: (resolve) =>
      require(["@/components/allModals/loginType.vue"], resolve),
    Login: (resolve) => require(["@/components/allModals/login.vue"], resolve),
    RoleBindPhone: (resolve) =>
      require(["@/components/allModals/roleBindPhone.vue"], resolve),
    BindRole: (resolve) =>
      require(["@/components/allModals/bindRole.vue"], resolve),
    ToggleRole: (resolve) =>
      require(["@/components/allModals/toggleRole.vue"], resolve),
    Poster: (resolve) =>
      require(["@/components/allModals/poster.vue"], resolve),
    LogOut: (resolve) =>
      require(["@/components/allModals/logout.vue"], resolve),
    Down: (resolve) =>
      require(["@/components/allModals/downLoad.vue"], resolve),
  },
  data() {
    return {
      isPlay: false,
      timer: null,
      timer1: null,
      audioIns: null,
      self: false,
      isVideo: false,
    };
  },
  beforeCreate() {
    var u = navigator.userAgent;
    var isAndroid = u.indexOf("Android") > -1 || u.indexOf("Adr") > -1; //android终端
    var isiOS = !!u.match(/Mac OS X/); //ios终端
    const userInfoGame = getUrlParams();
    if (window.location.href.indexOf("3rd") !== -1) {
      if (
        !isAndroid &&
        !isiOS &&
        window.location.href.indexOf("pc.html") === -1
      ) {
        window.location.href =
          "https://zjfh.meogames.com/3rd-anniversary-event/pc.html?xyid=" +
          userInfoGame.xyid +
          "&channel=" +
          userInfoGame.channel +
          "&serverid=" +
          userInfoGame.serverid +
          "&roleid=" +
          userInfoGame.roleid;
      } else if (
        (isAndroid || isiOS) &&
        window.location.href.indexOf("index.html") === -1
      ) {
        window.location.href =
          "https://zjfh.meogames.com/3rd-anniversary-event/index.html?xyid=" +
          userInfoGame.xyid +
          "&channel=" +
          userInfoGame.channel +
          "&serverid=" +
          userInfoGame.serverid +
          "&roleid=" +
          userInfoGame.roleid;
      }
    }
  },
  watch: {
    $route(to, from) {
      //   console.log("path", to, from);
      let path = to.path;
      if (path === "/wishList1" || path === "/wishList2") {
        if (this.userInfo && this.userInfo.choose_rid) {
          path === "/wishList1" && this.$router.push("/wishList2");
        } else {
          this.$router.push("/wishList1");
        }
      }
      // for (let i = 0; i < this.arr.length; i++) {
      //   if (path == this.arr[i].url) {
      //     this.index = i;
      //   }
      //   if (path == "/tip") {
      //     this.hid_btn = true;
      //   } else {
      //     this.hid_btn = false;
      //   }
      // }
    },
  },
  computed: {
    ...mapState([
      // 登錄方式
      "login_type",
      // 登录
      "login",
      // 退出
      "logout",
      // 切换角色
      "toggle_role",
      // 绑定区服角色
      "bind_role",
      // 角色绑定手机号
      "bind_phone",
      // 活动一分享海报
      "showPoster",
      // 活动一红包Id
      "red_id",
      // 用户信息
      "userInfo",
      // 下载弹框
      "down_load",
    ]),
    showDown() {
      let token = localStorage.getItem("token");
      let flag = !this.userInfo && !token && this.$route.path != "/download";
      return flag;
    },
  },
  methods: {
    // 前往下载游戏
    down() {
      let time = Date.now();
      let access1 = this.$encrypte([time]);
      // 点击下载游戏
      clickLog({
        time,
        access: access1,
        type: 9,
        state: 1,
      });
      // this.$router.push('/download')
      window.open("https://zjfh.onelink.me/bRE6/h5downloads");
      // window.open("http://webevent.zijinfanhua.com/download/");
      //   this.$store.commit("SETVAL", { down_load: true });
    },
    // 判断是否是为移动端
    getIsWxClient() {
      var sUserAgent = navigator.userAgent.toLowerCase();
      var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
      var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
      var bIsMidp = sUserAgent.match(/midp/i) == "midp";
      var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
      var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
      var bIsAndroid = sUserAgent.match(/android/i) == "android";
      var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
      var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
      if (
        bIsIpad ||
        bIsIphoneOs ||
        bIsMidp ||
        bIsUc7 ||
        bIsUc ||
        bIsAndroid ||
        bIsCE ||
        bIsWM
      ) {
        return true;
      } else {
        return false;
      }
    },
    // 控制music
    controlMusic() {
      this.timer && clearInterval(this.timer);
      this.timer1 && clearInterval(this.timer1);
      this.isPlay ? this.audioIns.suspend() : this.audioIns.resume();
      this.isPlay = !this.isPlay;
    },
    async initAudio() {
      try {
        const URL =
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/bg.mp3";
        const audioContext = new (window.AudioContext ||
          window.webkitAudioContext)();
        this.audioIns = audioContext;
        //加载音频文件
        const getBuffer = function (url) {
          const request = new XMLHttpRequest();
          return new Promise((resolve, reject) => {
            request.open("GET", url, true);
            request.responseType = "arraybuffer";
            request.onload = () => {
              audioContext.decodeAudioData(request.response, (buffer) =>
                buffer ? resolve(buffer) : reject("decoding error")
              );
            };
            request.onerror = (error) => reject(error);
            request.send();
          });
        };
        const playAudio = function (buffer) {
          const source = audioContext.createBufferSource();
          source.buffer = buffer;
          source.connect(audioContext.destination);
          source.start();
        };
        const buffer = await getBuffer(URL);
        if (buffer) {
          playAudio(buffer);
        }
      } catch (error) {
        console.log(error);
      }
    },
    // 点击App层
    clickApp() {
      const that = this;
      const body = document.querySelector("body");
      const fn = function () {
        if (that.isPlay === false) {
          if (that.isVideo) return;
          that.audioIns.resume();
          this.isPlay = true;
          body.removeEventListener("click", fn);
        }
      };
      body.addEventListener("click", fn);
    },
  },
  mounted() {
    // let mobile = this.getIsWxClient();
    // if (!mobile) {
    //   this.$router.replace("/tip");
    //   return;
    // }
    this.initAudio();
    // 判断音频是否播放
    let i = 0;
    this.timer1 = setInterval(() => {
      //   console.log(this.audioIns.state === "running");
      this.isPlay = this.audioIns.state === "running";
      if (this.audioIns.state === "running" || i >= 50)
        clearInterval(this.timer1);
      i++;
    }, 500);
    this.clickApp();
    // 绑定手机号初始化存储区号
    sessionStorage.setItem("area_code", "86");
    // 接收bus消息
    this.$bus.$off(event).$on("controlMusic", (flag) => {
      if (!flag) this.isVideo = true;
      // 暂停歌曲
      if (this.isPlay && !flag) {
        this.audioIns.suspend();
        this.isPlay = false;
        // 标识是自己手动停歌的
        this.self = true;
      }
      //   继续播放
      if (flag && this.self) {
        this.audioIns.resume();
        this.isPlay = true;
        this.self = false;
      }
    });
  },
};
</script>
<style lang="stylus">
#app
  margin: 0 auto
// @import 'assets/stylus/common.styl';
// @import 'assets/stylus/allmodal.styl';
.top_down
  width: 100%
  height: 85px
  background: #5C1501
  position: fixed
  top: 0
  left: 0
  right: 0
  z-index: 99
  box-sizing: border-box
  padding: 10px
  font($r-jian)
.pt85
  padding-top: 85px
.icon
  width: 64px
  height: 64px
  // background: #FFFFFF
  border-radius: 10px
  background-image: bg('common/icon.png')
.txt_game
  font-size: 20px
  font-weight: 600
  color: #FDF4EA
  line-height: 25px
  padding: 10px 0 0 20px
.down_btn
  width: 218px
  height: 62px
  background: bg('common/todown.png')
  background-size: 100% 100%
.btn-return
  width: 210px
  height: 85px
  position: absolute
  left: 0
  background-image: bg('common/btn-return.png')
  z-index: 98
.btn-music
  width: 80px
  height: 85px
  position: absolute
  background-image: bg('common/btn_play.png')
  z-index: 98
  &.pause
    background-image: bg('common/btn_pause.png')
.zindex
  z-index: 1000
</style>
