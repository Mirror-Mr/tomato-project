/*
 * @Author: your name
 * @Date: 2021-11-08 10:49:52
 * @LastEditTime: 2021-12-17 20:28:23
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three_year\src\router\index.js
 */
import Vue from "vue";
import VueRouter from "vue-router";
import { Toast } from "vant";
Vue.use(VueRouter);
const machine = localStorage.getItem("machine");
// const nav = () => import("../views/nav.vue");
const totalNav = () => import("../views/totalNav.vue");
const wishList1 = () => import("../views/wishList1.vue");
const wishList2 = () => import("../views/wishList2.vue");
const wishList3 = () => import("../views/wishList3.vue");
const redEnvelope = () => import("../views/redEnvelope.vue");
const warOrder = () => import("../views/warOrder.vue");
// const phoneReserve = () => import("../views/phoneReserve.vue");
const other = () => import("../views/other.vue");
const notFound = () => import("../views/notFound.vue");
const askSign = () => import("../views/askSign.vue");
const tip = () => import("../views/tips.vue");
const routes = [
  { path: "/", name: "totalNav", component: totalNav },
  //   { path: "/totalNav", name: "totalNav", component: totalNav },
  { path: "/redEnvelope", name: "redEnvelope", component: redEnvelope },
  { path: "/wishlist1", name: "wishList1", component: wishList1 },
  { path: "/wishlist2", name: "wishList2", component: wishList2 },
  { path: "/wishlist3", name: "wishList3", component: wishList3 },
  { path: "/warorder", name: "warOrder", component: warOrder },
//   { path: "/phonereserve", name: "phoneReserve", component: phoneReserve },
  { path: "/other", name: "other", component: other },
  { path: "/tip", name: "tip", component: tip },
  { path: "/askSign", name: "askSign", component: askSign },
  // { path: "*", component: notFound },
];

const router = new VueRouter({
	// base:'/haiwai/zjfh/three_year/',
	// base:'/three-year-gt/',
  // mode:'history',
  routes,
});

router.beforeEach((to, from, next) => {
  next();
});

export default router;
