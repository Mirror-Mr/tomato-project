<!--
 * @Author: your name
 * @Date: 2021-11-16 12:22:37
 * @LastEditTime: 2021-12-13 17:39:18
 * @LastEditors: Please set LastEditors
 * @Description: 兑换具体道具弹框
 * @FilePath: \three_year\src\components\allModals\convertTo.vue
-->
<template lang="pug">
	Mymodal(:show='show' @sure="sure" @close="close" :surebtn="true" :canclebtn="showtype!=='success'")
		template(v-if="showtype ==='choose'")
			img.goods(:src="info.img")
			.price_and_num
				.conv 消耗萬能卡：
					span.conv_n {{info.price*value}}		
				.conv 兌換數量：
					span.conv_n {{value}}
			.slider_box(v-if="max >1")
				.subtarct(@click="changeNum(false)") -
				van-slider(v-model="value" :min="1" :max="max"  @change="onChange" active-color="#FF6059" inactive-color="#febaac")
				.add(@click="changeNum(true)") +
		template(v-if="showtype ==='tosure'")
			.tip_txt 確認消耗
				span.conv_n  萬能卡*{{info.price*value}}	
				span 兌換
				span.conv_n {{info.name}}	* {{value}}
		template(v-if="showtype ==='success'")
			.tip_success.pt60 兌換成功！恭喜您獲得
				span {{info.name}}	* {{value}}！
			.tip_success.pb50 請在本頁面或遊戲內查看獎勵！
</template>
<script>
import { mapState } from "vuex";
import { subPrize } from "@/request/api.js";
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false
    },
    gift: {
      type: Object
    }
  },
  computed: {
    ...mapState({
      num: state => state.act1.num,
      prize: state => state.act1.prize
    }),
    max() {
      if (!this.info.id) return 0;
      if (this.prize && this.prize[this.info.id]) {
        return this.info.limit - this.prize[this.info.id] > 0
          ? this.info.limit - this.prize[this.info.id]
          : 0;
      } else {
        return this.info.limit;
      }
    }
  },
  // computed: mapState(["act1"]),
  data() {
    return {
      value: 1,
      showtype: "choose",
      info: {
        limit: 1,
        price: 0,
        hadBuy: 0,
        img: "",
        name: "",
        id: ""
      },
      flag: true
    };
  },
  watch: {
    show(val) {
      if (val) {
        this.gift && (this.info = this.gift);
      } else {
        this.value = 1;
        this.showtype = "choose";
      }
    }
  },
  methods: {
    onChange(val) {
      this.value = val;
    },
    changeNum(isAdd) {
      if (isAdd) {
        this.value =
          this.info.limit > this.value ? this.value + 1 : this.info.limit;
      } else {
        this.value = this.value > 1 ? this.value - 1 : 1;
      }
    },
    close() {
      // if (this.showtype !== "choose") {
      //   this.showtype = "choose";
      // } else {
      this.$emit("close");
      // }
    },
    sure() {
      if (this.showtype === "choose") {
        this.showtype = "tosure";
      } else if (this.showtype === "tosure") {
        // 兑换奖励接口
        this.getPrize();
        // 兑换奖励成功后关闭
        // this.showtype = "success";
      } else if (this.showtype === "success") {
        this.showtype = "choose";
        this.$emit("close");
      }
    },
    // 兑换礼包
    getPrize() {
      // if(this.info.price*this.value > this.act1.num) {
      // 	this.$toast('万能卡不足！')
      // 	return
      // }
      if (!this.flag) return;
      this.flag = false;
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token, this.value]);
      subPrize({
        time: time,
        token: token,
        num: this.value,
        type: 1,
        rid: this.info.id,
        access: access
      })
        .then(data => {
          this.flag = true;
          // this.$router.replaceState({path:this.$route.path})
          this.showtype = "success";
          this.$store.dispatch("getHistory", 1);
          this.$store.dispatch("getInfo", 1);
        })
        .catch(err => {
          this.flag = true;
          // 未绑定手机号
          if (err.data == 11) {
            this.$emit("close");
            this.$store.commit("SETVAL", { bind_phone: true });
          } else {
            this.$toast(err.msg || "領取紅包失敗");
          }
          // this.$store.commit("SETVAL",{bind_phone:true,invite_red:false})
        });
    }
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.goods
	width 240px
	height 240px
	display block
	margin 0 auto
.price_and_num
	display flex
	justify-content space-between
	margin 0 50px 0  50px
	.conv
		color #D5755B
		text-align center
		padding 120px 0 40px 0
	.tip_success
		color #D5755B
		font-size 28px
		text-align center
.tip_success
	padding 0 40px
	text-align center
	font-size 30px
.pt60
	padding-top 60px
	padding-bottom 10px
.pb50
	padding-bottom 50px
	span
		color #FF6059
.slider_box
	margin 0 60px
	display flex
	height 50px
	/deep/ .van-slider
		margin 24px 40px 0 40px
.tip_txt
	padding 100px 0 50px  40px
	font-size 30px
	align-items center
.subtarct,.add
	flex 0 0 50px
	height 50px
	line-height 50px
	text-align center
	font-size 30px
	color #fff
	background-image linear-gradient(0deg, #FF734B, #FFC96A)
	border-radius 50%

// .subtarct
// 	margin-right 20px
// .add
// 	margin-left 20px
</style>
