<!--
 * @Author: your name
 * @Date: 2021-12-03 18:43:38
 * @LastEditTime: 2021-12-06 12:06:28
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three-year\src\components\allModals\downLoad.vue
-->
<template lang="pug">
	Mymodal(:show='show' @close='close')
		.tit_con 下載安裝地址
			img.icon_down(:src="imgBaseUrl + 'down.png'")
		.con_box
			.list_item(v-for="item in list()"  @click="linlTo(item)") 
				img(:src="imgBaseUrl + item.img")
				.info
					.name(:class="{'pt10':!item.tip }") {{ item.name }}
					.tips {{ item.tip }}
					.down_btns(:class="{'mt30':!item.tip }") 下載
		.end 如有下載疑問小主可通過微信關注“紫禁繁花”公眾號聯繫遊戲客服
</template>
<script>
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      imgBaseUrl:
        "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/download/"
    };
  },
  methods: {
    close() {
      this.$store.commit("SETVAL", { down_load: false });
    },
    linlTo(item) {
      window.open(item.link);
    },
    list() {
      return [
        {
          name: "App store",
          img: "appstore.png",
          link: "https://apps.apple.com/cn/app/id1494452064",
          tip: "Tips:下載更新後即可，第一次需時較長，請耐心等候喲～"
        },
        {
          name: "IOS安裝包",
          img: "iOS.png",
          link: "https://www.zanbugames.com/zjfh_download/index.html#/",
          tip: "Tips:下載完成之後需要按照引導進行設備信任"
        },
        {
          name: "安卓官方",
          img: "andr_gf.png",
          link:
            "https://source.zanbugames.com/apk/com.xingyugame.gttf_v1.1.6.183.apk"
        },
        {
          name: "安卓登錄IOS",
          img: "andr_login_ios.png",
          link: "https://assets.zanbugames.com/apk/IOS_list0806.apk"
        },
        {
          name: "華為",
          img: "huawei.png",
          link:
            "https://assets.zanbugames.com/apk/gtmz_huawei_2.6.3.306_202001201829.apk"
        },
        {
          name: "應用寶",
          img: "yingyongbao.png",
          link:
            "https://assets.zanbugames.com/apk/gtmz_yyb_1.4.5_202001092336.apk"
        },
        {
          name: "小米",
          img: "mi.png",
          link:
            "https://source.xingchonggame.com/apk/com.xingyugame.gttf_v1.1.6.155.apk"
        },
        {
          name: "魅族",
          img: "meitu.png",
          link:
            "https://assets.zanbugames.com/apk/gtmz_meizu_5.2.3_202001092338.apk"
        },
        {
          name: "嗶哩嗶哩",
          img: "bilibili.png",
          link:
            "https://assets.zanbugames.com/apk/gtmz_bili_2.6.2_202001092029.apk"
        },
        {
          name: "百度",
          img: "baidu.png",
          link:
            "https://assets.zanbugames.com/apk/gtmz_baidu_4.3.1_202001092318.apk"
        },
        {
          name: "三星",
          img: "sumsung.png",
          link:
            "https://assets.zanbugames.com/apk/gtmz_Samsung_4.3.6_202001092343.apk"
        },
        {
          name: "360",
          img: "360.png",
          link:
            "https://assets.zanbugames.com/apk/gtmz_Qihoo360_2.2.2_710_202001091919.apk"
        },
        {
          name: "聯想",
          img: "lenovo.png",
          link:
            "https://assets.zanbugames.com/apk/gtmz_Lenovo_2.6.9.1_202001092333.apk"
        },
        {
          name: "九遊",
          img: "jiuyou.png",
          link: "https://assets.zanbugames.com/apk/gtmz_UC9game-aligame.apk"
        },
        {
          name: "OPPO",
          img: "oppo.png",
          link:
            "https://assets.zanbugames.com/apk/gtmz_OPPO_2.0.2.306_202001201827.apk"
        },
        {
          name: "vivo",
          img: "vivo.png",
          link:
            "https://assets.zanbugames.com/apk/gtmz_vivo_4.5.0.1_202001201825.apk"
        }
      ];
    }
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.tit_con
	text-align: center
	font-size: 37px
	color: #F87C5A
	position: absolute
	top: 40px
	width:100%
	margin: 0 auto
	.icon_down
		position: absolute
		width: 44px
		height 44px
		left: 140px
		top: 5px
.con_box
	height: calc(100% - 120px)
	overflow scroll
	margin-top:40px
	box-sizing: border-box
	.list_item
		display flex
		padding 0 40px 40px 40px
		img
			flex 0 0 126px
			height 136px
		.info
			color #F36945
			padding-left 18px
			.name
				font-size 28px
				font-weight 600
			.pt10
				padding-top:15px
			.tips
				font-size 20px
				margin-bottom:20px
			.down_btns
				width: 101px;
				height: 35px
				background: #F47959
				border-radius: 18px
				color: #fff
				text-align: center
				font-size 22px
			.mt30
				margin-top 30px
.end
	padding 0 40px
	margin-bottom: 60px
	font-size: 22px
	font-weight: 400
	color: #CA5E3D
	position: absolute
	bottom:15px
</style>
