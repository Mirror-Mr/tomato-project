<template lang="pug">
Mymodal(:show="show", @close="close", :noBg="true")
  video(
    src="https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/video.mp4",
    controls,
    preload="auto",
    ref="video",
    controlslist="nodownload  noremoteplayback disablePictureInPicture "
  )
</template>
<script>
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {};
  },
  methods: {
    close() {
      this.$emit("close");
      this.$bus.$emit("controlMusic", true);
    },
  },
  mounted() {
    this.$bus.$off(event).$on("playVideo", () => {
      this.$nextTick(() => {
        // console.log(this.$refs);
        this.$refs.video.play();
      });
      //   this.$refs.video.play()
    });
  },
};
</script>
<style scoped lang='stylus'>
video
  width: 100%
</style>