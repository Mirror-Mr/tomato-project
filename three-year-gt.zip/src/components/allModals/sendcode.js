/*
 * @Author: your name
 * @Date: 2021-11-16 11:37:35
 * @LastEditTime: 2021-12-10 12:03:41
 * @LastEditors: Please set LastEditors
 * @Description:发送验证码
 * @FilePath: \three_year\src\components\allModals\sendcode.js
 */
import { sendCode} from "@/request/api.js";
export default {
  name: "",
  data() {
    return {
			// 发送验证码的定时器
			codetxt: "獲取驗證碼",
			secondtime: 179,
			timer: null,
		};
  },

  methods: {
		// 发送验证码
		sendCode(phone) {
			if(!phone) {
				this.$toast('請先填寫手機號')
				return
			}
			if (this.timer) return;
			let time = parseInt(new Date().getTime());
            let area_code = sessionStorage.getItem("area_code")
			let access= this.$encrypte([time,35,phone,1]);
			let params ={
				time:time,
				to_user:phone,
				project_id:35,
				type:1,
				flag:1,
                area_code,
				access:access,
			}
			sendCode(params).then((data) => {
				this.codetxt = this.secondtime + "s後獲取";
				this.$toast("短信發送成功，請注意查收");
				this.timer = setInterval(() => {
					this.secondtime--;
					if (this.secondtime <= 0) {
						clearInterval(this.timer);
						this.timer = null;
						this.codetxt = "獲取驗證碼";
						this.secondtime = 180;
						return;
					}
					this.codetxt = this.secondtime + "s後獲取";
				}, 1000);
			}).catch(err=>{
				// clearInterval(this.timer);
				// this.timer = null;
				this.$toast(err.msg||'短信發送失敗');
			})
		},
		// 清除定时器
		clearTimer(){
			if(this.timer) {
				clearInterval(this.timer);
				this.timer = null;
			}
		}
  },
  mounted() {},
	destroyed(){
		
	}
};
