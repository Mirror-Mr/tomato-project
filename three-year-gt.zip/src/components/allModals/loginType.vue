<!--
 * @Author: your name
 * @Date: 2021-11-11 18:38:01
 * @LastEditTime: 2021-12-21 16:34:53
 * @LastEditors: Please set LastEditors
 * @Description: 登录
 * @FilePath: \three_year\src\components\allModals\bind.vue
-->
<template lang="pug">
Mymodal(:show="show", @close="close")
  div(v-show="!loading")
    .top_tit(@click="login") 登錄
    .type_box(v-if="isGt")
      .fb(@click="FBLogin")
      .google(ref="google", @click="googleLogin")
      .apple(@click="appleLogin")
      #appleid-signin.apple-btn.withd_0(ref="apple") 
    .type_box.pt40(v-else-if="!showLoginType")
      .type_item(
        v-for="item in loginPlatList()",
        :key="item.id",
        @click="chosechannel(item)"
      ) 
        img(:src="imgBaseUrl + item.img")
    .type_box.m_between(v-if="showLoginType")
      .type_item(
        v-for="item in loginTYpe()",
        :key="item.id",
        @click="choseLoginType(item)"
      )
        img(:src="imgBaseUrl + item.img")
  van-loading.mt100(v-show="loading", size="24px", vertical) 登錄中...
    //- .back(@click="backTo") <返回上一级
  .info_active 溫馨提示：
  .info_active 1、部分瀏覽器不支持使用Google登錄，建議您使用其他瀏覽器進行登錄，如：谷歌瀏覽器，Safari瀏覽器
  .info_active 2、由於GameCenter和遊客賬號不支持網頁登錄，請您使用其他綁定賬號登錄
</template>
<script>
import { outsideLogin, getActivityTime } from "@/request/api.js";
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      // 是否为港台登录
      isGt: true,
      showLoginType: false,
      imgBaseUrl:
        "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/",
      loading: false,
      isEnd: false,
    };
  },
  watch: {
    show(val) {
      if (val) {
        const p = this.getServerTime();
        p.then((res) => {
          if (this.isEnd) {
            this.$toast("活動結束");
            return;
          }
          this.$nextTick(() => {
            this.googleLogin();
            this.appleLoginInit();
          });
          document.addEventListener(
            "AppleIDSignInOnSuccess",
            this.appleLoginSuccess
          );
          document.addEventListener(
            "AppleIDSignInOnFailure",
            this.appleLoginFail
          );
        });
      } else {
        document.removeEventListener(
          "AppleIDSignInOnSuccess",
          this.appleLoginSuccess
        );
        document.removeEventListener(
          "AppleIDSignInOnFailure",
          this.appleLoginFail
        );
      }
    },
  },
  methods: {
    // 海外登录
    login(token) {
      let time = parseInt(new Date().getTime());
      let access = this.$encrypte([time, token]);
      this.loading = true;

      outsideLogin({
        time: time,
        account_id: token,
        access: access,
      })
        .then((data) => {
          this.loading = false;
          if (data.uid) {
            localStorage.setItem("uid", data.uid);
            localStorage.setItem("loginChannel", 4);
            this.$store.commit("SETVAL", {
              login_type: false,
              bind_role: true,
              loginChannel: 4,
            });
          } else {
            this.$toast("无用户ID,请更换账号重试");
          }
        })
        .catch((err) => {
          this.loading = false;
          this.$toast(err.msg);
        });
    },
    // 谷歌登录
    googleLogin() {
      if (this.isEnd) {
        this.$toast("活動結束");
        return;
      }
      let vm = this,
        element = this.$refs.google,
        startApp = function () {
          gapi.load("auth2", function () {
            var auth3 = gapi.auth2.init({
              client_id:
                "506721028392-1g9f50nua23s36161jkded92domks9fj.apps.googleusercontent.com", //客户端ID
              cookiepolicy: "single_host_origin",
              scope: "profile", //可以请求除了默认的'profile' and 'email'之外的数据
            });
            attachSignin(element, auth3);
          });
        };

      function attachSignin(element, auth3) {
        auth3.attachClickHandler(
          element,
          {},
          function (googleUser) {
            console.log(googleUser);
            let token = googleUser.wc
              ? googleUser.wc.id_token
              : googleUser.vc
              ? googleUser.vc.id_token
              : "";
            if (!token) {
              this.$toast("获取谷歌信息失败！");
              return;
            }
            vm.login(token);
            // googleUser = googleUser.wc.id_token
            // console.log('google登录信息',googleUser)
            // //登录成功后回调
            // vm.$toast(googleUser)
          },
          function (error) {
            vm.$toast(error.error || "google账号登录失败");
            //登录失败回调
            // console.log(JSON.stringify(error, undefined, 2))
          }
        );
      }
      startApp();
    },
    FBLogin() {
      if (this.isEnd) {
        this.$toast("活動結束");
        return;
      }
      // 获取是否已登录状态
      const vm = this;
      FB.getLoginStatus(function (response) {
        if (response.status == "connected") {
          FB.api("/me", function (response) {
            //connected为已登录，可直接获取对应参数
            console.log("connected", response);
            if (response && response.id) {
              vm.login(response.id);
            }
          });
        } else {
          FB.login(function (response) {
            if (response.authResponse) {
              FB.api("/me", function (response) {
                console.log(response);
                if (response && response.id) {
                  vm.login(response.id);
                }
              });
            } else {
              console.log("User cancelled login or did not fully authorize.");
            }
          });
        }
      });
    },
    appleLogin() {
      if (this.isEnd) {
        this.$toast("活動結束");
        return;
      }
      this.$refs.apple.click();
    },
    close() {
      if (this.showLoginType) {
        this.showLoginType = false;
        return;
      }
      this.$store.commit("SETVAL", { login_type: false });
    },
    // 选择登录渠道
    chosechannel(item) {
      this.$store.commit("SETVAL", { loginChannel: item.id });
      localStorage.setItem("loginChannel", item.id);
      if (item.id == 2) {
        // 显示角色id登录弹框
        this.$store.commit("SETVAL", { bind_role: true });
      } else {
        // 显示登录方式选择弹框
        this.showLoginType = true;
      }
    },
    // 选择登录类型
    choseLoginType(item) {
      this.$store.commit("SETVAL", {
        login_type: false,
        loginType: item.id,
        login: true,
      });
    },
    // backTo(){
    // 	this.showLoginType = false
    // },
    loginPlatList() {
      return [
        { txt: "官服", id: "1", img: "common/login_azgf.png" },
        { txt: "IOS", id: "3", img: "common/login_ios.png" },
        { txt: "渠道", id: "2", img: "common/login_azqd.png" },
      ];
    },
    loginTYpe() {
      return [
        { txt: "账号", id: "account", img: "common/login_account.png" },
        { txt: "手机号", id: "phone", img: "common/login_phone.png" },
      ];
    },
    appleLoginInit() {
      let path = location.href;
      AppleID.auth.init({
        clientId: "com.zlihf.xianyugame.gat.service",
        redirectURI: "https://webtest2.xianyuyouxi.com",
        usePopup: true, //or false defaults to false
        scope: "name",
        state: "state",
      });
    },
    appleLoginSuccess(res) {
      this.login(res.detail.authorization.id_token);
    },
    appleLoginFail(err) {
      this.$toast(err.msg || "登錄失敗");
    },
    // 获取活动时间
    async getServerTime() {
      let time = parseInt(new Date().getTime());
      let access = this.$encrypte([time, 32]);
      await getActivityTime({
        time: time,
        project_id: 32,
        access: access,
      })
        .then((data) => {
          //   this.current_time = data.current_time.slice(0, 11).replace(/-/g, "/");
        })
        .catch((err) => {
          console.log(0)
        //   if (err.msg.includes("活動結束")) {
          if (err.msg.includes("活動結束")) {
            this.isEnd = true;
            this.$toast("活動結束！")
            return
          }
          this.$toast(err.msg || "獲取服務器當前時間失敗");
        });
    },
  },
  mounted() {},
  destroyed() {},
};
</script>
<style scoped lang="stylus">
/deep/ .top_tit
  padding-top: 20px
  margin-bottom: 10px
  font($bold)
.type_box
  display: flex
  color: #F87C5A
  justify-content: space-between
  position: relative
  .type_item, .fb, .google, .apple
    width: 190px
    height: 190px
    line-height: 190px
    font-size: 30px
    text-align: center
    // background bg('common/type_btn_bg.png')
    // background-size 100% 100%
    img
      width: 100%
      height: 100%
  .fb
    background: bg('common/fb_btn.png')
    background-size: 100% 100%
  .google
    background: bg('common/google_btn.png')
    background-size: 100% 100%
  .apple
    background: bg('common/apple_btn.png')
    background-size: 100% 100%
.m_between
  margin: 0 70px
.pt40
  padding-top: 40px
.back
  position: absolute
  bottom: -60px
  width: 100%
  text-align: center
// 苹果登录按钮宽度为0
.withd_0
  width: 0
  overflow: hidden
.mt100
  margin-top: 180px
.info_active
  color: #CA5E3d
  font-size: 22px
  padding: 0 20px
  margin-bottom: 10px
</style>
