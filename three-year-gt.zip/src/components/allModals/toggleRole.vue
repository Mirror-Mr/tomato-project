<!--
 * @Author: your name
 * @Date: 2021-11-16 11:00:55
 * @LastEditTime: 2021-11-23 15:04:46
 * @LastEditors: Please set LastEditors
 * @Description: 切换角色确认框
 * @FilePath: \three_year\src\components\allModals\toogleRole.vue
-->
<template lang="pug">
	Mymodal( @close="close" :show="show" :canclebtn="true" :surebtn="true"  @sure="toToggle")
		.tit.toggle_role
		.tip_txt 本頁面的活動根據角色計算進度與獎勵，確認切換角色嗎？
</template>
<script>
export default {
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  name: "",
  data() {
    return {};
  },
  methods: {
    close() {
      this.$store.commit("SETVAL", { toggle_role: false });
    },
    toToggle() {
      this.$store.commit("SETVAL", { bind_role: true, toggle_role: false });
    }
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.toggle_role
	background	bg('common/toggleRole.png')
.tip_txt
	color #D5755B
	font-size 28px
	line-height 40px
	font-weight bold
	padding 40px  40px 20px 40px
</style>
