<!--
 * @Author: your name
 * @Date: 2021-11-15 17:49:00
 * @LastEditTime: 2021-12-01 18:05:38
 * @LastEditors: Please set LastEditors
 * @Description: 角色-手机号绑定
 * @FilePath: \three_year\src\components\allModals\bindphone.vue
-->
<template lang="pug">
Mymodal(
  @close="close",
  :show="show",
  :canclebtn="status !== 'error'",
  :surebtn="true",
  @sure="tobind"
)
  .top_tit 角色-手機號綁定
  template(v-if="!status")
    .tip_txt 親愛的玩家，為了更方便地參與活動，
    .tip_txt 請先將角色與手機號進行綁定。
    .tip_txt_s 注：一個手機號只能綁定一個角色，且綁定後不再能夠切換角色，請仔細確認綁定角色信息後再進行綁定！
    .input_box
      .input_item.pl {{ userInfo ? userInfo.role_name : '' }}
      .input_item
        .areabtn.fl(@click="showAreaList")
          span.fl {{ chooseArea }}
          .triangle
        input.code.area(
          type="text",
          v-model.trim="params.mobile",
          placeholder="请输入绑定手机号"
        )
      .input_item
        input.code(
          type="text",
          v-model.trim="params.code",
          maxlength="6",
          placeholder="请输入验证码"
        )
        .codebtn.fr(@click="sendCode(params.mobile)") {{ codetxt }}
  //- 手机号验证失败
  template(v-else-if="status == 'error'")
    .tip_txt.txt_center 親愛的玩家，您的手機號已綁定過角色
    .tip_txt {{ `當前綁定角色為：${roleInfo.server_name}-${roleInfo.role_name} 。請使用其它手機號進行綁定` }}
    .tip_txt_s 注：一個手機號只能綁定一個角色，且綁定後不再能夠切換角色，請仔細確認綁定角色信息後再進行綁定！
  //- 手机号验证成功，再次确认 
  template(v-else-if="status == 'success'")
    .tip_txt.txt_center 綁定手機：12345678900
    .tip_txt.txt_center 綁定角色：XX區 XX角色名
    .tip_txt_s.txt_center 綁定後將無法更改或取消綁定，確認綁定？
  van-popup(v-model="showArea", position="bottom", get-container="body")
    van-picker(
      show-toolbar,
      :columns="list",
      @cancel="showArea = false",
      @confirm="onConfirm($event)"
    )
</template>
<script>
import { bindPhone } from "@/request/api.js";
import sendCodeMixin from "./sendcode";
import { mapState } from "vuex";
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  mixins: [sendCodeMixin],
  computed: mapState(["userInfo"]),
  data() {
    return {
      params: {
        rolename: "",
        mobile: "",
        code: "",
      },
      // 绑定手机号进度 初始，验证完成，验证失败
      status: "",
      // 手机号绑定过的信息
      roleInfo: {
        server_name: "",
        role_name: "",
      },
      list: [ "大陸 +86","香港 +852", "台灣 +886", "澳門 +853"],
      showArea: false,
	  chooseArea:"大陸 +86"
    };
  },
  watch: {
    show(val) {
      if (!val) {
        this.roleInfo = {
          server_name: "",
          role_name: "",
        };
        this.secondtime = 59;
        this.codetxt = "獲取驗證碼";
        this.clearTimer();
      }
    },
  },
  methods: {
    close() {
      this.$store.commit("SETVAL", { bind_phone: false });
    },
    tobind() {
      if (this.status == "error") {
        this.status = "";
        return;
      }
      if (!this.params.mobile) {
        this.$toast("請先填寫手機號");
        return;
      }
      if (!this.params.code) {
        this.$toast("請先填寫驗證碼");
        return;
      }
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token]);
      let params = {
        time: time,
        token: token,
        phone: this.chooseArea.split("+")[1]+this.params.mobile,
        code: this.params.code,
        access: access,
        project_id: 35,
      };
      bindPhone(params)
        .then((data) => {
          this.$toast("綁定手機號成功");
          // localStorage.setItem('loginChannel',this.loginChannel)
          this.$store.dispatch("getInfo", 1);
          // 是否有受邀请的红包
          let redId = this.$route.query.red_id;
          if (redId) {
            this.$store.commit("SETVAL", { invite_red: true });
          }
          this.close();
        })
        .catch((err) => {
          // 手机已绑定过角色
          if (err?.status == 2) {
            this.status = "error";
            this.roleInfo = err.data;
          } else {
            this.$toast(err.msg || "角色綁定手機號失敗");
          }
        });
    },
    // 选择区号
    onConfirm(el) {
		this.chooseArea = el;
		this.showArea = false;
        sessionStorage.setItem("area_code",this.chooseArea.split("+")[1])
	},
    // 展示下拉选择区号
    showAreaList() {
      this.showArea = !this.showArea;
    },
  },
  mounted() {},
};
</script>
<style scoped lang="stylus">
.tip_txt
  font-size: 22px
  color: #D5755B
  font-weight: bold
  padding: 0 40px
.tip_txt_s
  padding: 20px 40px
  font-size: 18px
  color: #E3A38E
.pd20
  padding: 0 20px
.txt_center
  text-align: center
.pl
  padding: 0 calc(0.27 * 75px)
  box-sizing: border-box
</style>
