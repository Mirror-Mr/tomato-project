/*
 * @Author: your name
 * @Date: 2021-11-16 11:37:35
 * @LastEditTime: 2021-11-22 12:47:47
 * @LastEditors: Please set LastEditors
 * @Description:弹框公用方法
 * @FilePath: \three_year\src\components\allModals\mixins.js
 */
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {};
  },
  methods: {
    close() {
      this.$emit("close");
    },
		sure() {
      this.$emit("sure");
    }
  },
  mounted() {}
};
