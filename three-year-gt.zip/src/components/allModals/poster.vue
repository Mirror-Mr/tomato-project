<!--
 * @Author: your name
 * @Date: 2021-11-16 19:32:13
 * @LastEditTime: 2021-12-20 16:09:21
 * @LastEditors: Please set LastEditors
 * @Description: 生成海报
 * @FilePath: \three-year\src\components\allModals\poster.vue
-->
<template lang='pug'>
	.mask( v-if="show" )
		.wrap
			.box(ref="ewmBox")
				//- .inv 姐妹送你一个请宴大红包，
				//- .inv.red  诚邀你前来赴宴！
				img.post_bg(:src="bgImg")
				vue-qr.erw( :logoSrc="imageUrl" :text="linkUrl" :size="200")
				//- .erm_tip 扫码领取请宴红包免费获得XX套装
				.post(style="backgroundsize: 100%" :class={'show_post':showpost})
					img#post(src="#")
			.tip 長按保存海報
			.close_btn(@click="close"  ref="closeBtn")
			
</template>
<script>
	import vueQr from 'vue-qr'
	import html2canvas from 'html2canvas';
	export default {
		name: '',
		props:{
			show:{
				type:Boolean,
				default:false,
			},
			// 红包ID
			id:{
				type:[Number,String],
			}
		},
		data(){
			return {
				linkUrl:'',
				imageUrl:  require("@/assets/img/icon.png"),
				bgImg:require("@/assets/img/poster.png"),
				showpost:false,
			}
		},
		components: { vueQr },
		watch:{
			show(val){
				if(val){
					this.linkUrl = location.origin+location.pathname+'#'+this.$route.path+'?red_id='+this.id
					this.$nextTick(()=>{
						setTimeout(()=>{
							this.htmlToimg()
						},1000)
						
					})
				}else {
					this.showpost = false
				}
			}
		},
		methods:{
			close(){
				this.$store.commit('SETVAL',{showPoster:false})
			},
			htmlToimg() {
				// let dom = document.getElementsByClassName('box')[0];
				let dom = this.$refs.ewmBox
				this.$nextTick(()=>{
					let closeBtn = this.$refs.closeBtn
				let vm = this
				// console.log('dom',dom,dom.offsetHeight,dom.offsetWidth)
				let width = dom.offsetWidth;
				let height = dom.offsetHeight;
				let canvas = document.createElement("canvas");
				let scale = 2; //数值大一点也可以，就是会影响生成图片的速度
				//画布实际宽度和高度
				canvas.width = width * scale;
				canvas.height = height * scale;
				// 浏览器中被渲染的高度和宽度
				canvas.style.width = width * scale + "px";
				canvas.style.height = height * scale + "px";
				canvas.getContext("2d");
				let opts = {
					useCORS: true,
					backgroundColor: "rgba(255,255,255,0)", //去掉白边
					scrollX: 0,
					scrollY: 0,
					scale: scale,
					canvas: canvas,
					dpi: window.devicePixelRatio,
					// ignoreElements:closeBtn,
				};
				html2canvas(dom, opts).then((canvas) => {
					canvas.toBlob((blob) => {
						var imgUrl = canvas.toDataURL("image/png", 1); // 获取生成的图片的url
						// let newImg = document.createElement("img");
						// newImg.src = imgUri;
						// this.$refs.post.append(newImg);
						document.getElementById("post").src = imgUrl;
						vm.showpost = true
					});
				});
				})
				
			},
		},
		mounted(){
			// this.linkUrl = location.href
		},
	}
</script>
<style scoped lang='stylus'>
	.role_games
		width 339px
		height 734px
		background bg('redEnvelopes/role.png')
		background-size 100% 100%
		position absolute
		bottom -40px
		left -90px
	.wrap
	.box
		width 707px
		height 1046px
		display block
		position absolute
		left 50%
		top 50%
		transform translate(-50%,-50%)
		.post_bg
			width 100% 
			height 100%
		.erw
			width 110px
			height 110px
			position absolute
			bottom 80px
			right 80px
			border 1px solid #ffaab0
			// border-radius 40px
	.red 
		color  #f05535
	.mask
		position fixed
		top 0
		left 0
		bottom 0
		right 0
		background #472e28
		z-index 999
	.close_btn
		position absolute
		width 66px
		height 66px
		background bg('common/btn_close.png')
		background-size 100% 100%
		right 13px
		top 23px
		z-index 20
	.post 
		position absolute
		top 0
		left 0
		right 0
		bottom 0
		img 
			width 100%
			height 100%
	.post 
	#post
		opacity 0
		// pointer-events none
	.show_post 
		opacity 1
	.tip
		width 100%
		position absolute
		bottom 20px
		text-align center
		font-size 22px
		color #b78181
		font-weight bold
</style>
