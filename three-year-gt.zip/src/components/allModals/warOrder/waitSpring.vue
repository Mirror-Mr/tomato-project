<template lang="pug">
Mymodal(:show="show", @close="close", :longBg="true", :wholeWidth="true")
  .waitSpring.column-center
    .tit-spring.bg-c
    .container-spring
      .role.bg-c
      .contents.column-center
        .content-item.bg-c.column-center(
          v-for="item in contentList",
          :class="`content${item.id}`"
        )
          .tag-content.bg-c(v-if="item.id != 1") {{item.discount}}折
          img.tit-content(
            :src="`https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary-ht/warOrder/tit-content${item.id}.png`"
          )
          .bg-price.bg-c.inner-center
            .price NT${{ item.price }}
          .desc
            .icon.bg-c
            span {{ item.desc }}
          .btn-open.bg-c.inner-center(
            @click="openSpring(item.id)",
            :class="{ gray: isVIP }"
          ) 點擊開通
</template>
<script>
export default {
  name: "waitSpring",
  props: {
    show: {
      type: Boolean,
      default: false
    },
    isVIP: {
      type: Boolean,
      default: false
    }
  },
  watch: {
    show(newVal) {
      console.log(newVal);
    }
  },
  data() {
    return {
      contentList: [
        {
          id: 1,
          price: "300",
          name: "盼春歸·新芽",
          desc: "解鎖盼春歸",
          discount: ""
        },
        {
          id: 2,
          price: "600",
          name: "盼春歸·含苞",
          desc: "解鎖盼春歸，梅樹等級直升20級，獎勵1280元寶",
          discount: "4"
        },
        {
          id: 3,
          price: "890",
          name: "盼春歸·盛放",
          desc: "解鎖盼春歸，梅樹等級直升滿級，獎勵3280元寶",
          discount: "3"
        }
      ]
    };
  },
  methods: {
    close() {
      this.$emit("close");
    },
    // 点击“点击开通”按钮
    openSpring(id) {
      if (this.isVIP) return;
      const { name, price } = this.contentList[id - 1];
      const obj = {
        dialog: "makeSureOpenSpring",
        params: [name, price, 11 + id]
      };
      this.$bus.$emit("showCommon", obj);
    }
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.waitSpring
  margin: 20px 0 60px 0
  .tit-spring
    width: 70%
    height: 100px
    background-image: imgUrl('tit-spring.png')
  .container-spring
    width: 100%
    display: flex
    position: relative
    .role
      width: 90%
      height: 1100px
      position: absolute
      top: 10px
      left: -190px
      flex-shrink: 0
      background-image: imgUrl('role.png')
    .contents
      display: flex
      flex-shrink: 0
      margin: 0 0 0 320px
      .content-item
        width: 330px
        height: 290px
        margin: 0 0 40px 0
        position: relative
        flex-shrink: 0
        background-image: imgUrl('bg_spring_content.png')
        &:nth-of-type(1)
          margin: 30px 0 40px 0
        .tag-content
          width:120px
          height 40px
          padding:3px 0 0 25px
          position: absolute
          top:0
          left:0
          font-size: 22px;
          color: #FFF6B7;
          letter-spacing: 3px
          background-image: imgUrl("tag_spring_content.png")
        .tit-content
          width: 162px
          margin: 45px 0 0 0
        .bg-price
          width: 170px
          height: 65px
          margin: 25px 0 0 0
          color: #FFE4AB
          font-size: 30px
          flex-shrink: 0
          background-image: imgUrl('bg-price.png')
        .desc
          width: 70%
          margin: 10px 0 0 0
          display: flex
          flex-shrink: 0
          font-size: 18px
          color: #636363
          .icon
            width: 18px
            height: 18px
            margin: 1px 0 0 0
            flex-shrink: 0
            background-image: imgUrl('icon_spring.png')
        .btn-open
          width: 220px
          height: 63px
          position: absolute
          bottom: -9px
          color: #FDF6E7
          font-size: 22px
          background-image: imgUrl('btn-task.png')
</style>
