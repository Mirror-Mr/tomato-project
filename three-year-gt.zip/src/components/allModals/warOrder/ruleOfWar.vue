<template lang="pug">
Mymodal(:show="show", @close="close", :longBg="true")
  .ruleOfWar.column-center
    .tit-war.bg-c
    .content-war
      .content1
        b 梅樹等級
        br
        span 梅樹初始等級為0級，每升1級可領取1檔獎勵，超過50級後無額外獎勵
      .content2
        b 等級提升
        div 
          span 感恩久伴：根據角色過往累計登錄天數，可直接領取一定梅樹等級獎勵，僅限領取1次
          br
          span 踏雪寒梅：活動期間，通過完成每日任務提升梅樹等級，任務每日0點刷新
          br
          span 購買等級：購買等級可直接提升梅樹等級，NT$30/級
      .content3
        b 迎冬來
        br
        span 免費獎勵線，提升梅樹等級可直接領取對應等級獎勵
      .content4
        b 盼春歸
        br
        span 開通後可解鎖“盼春歸”獎勵線，提升梅樹等級可直接領取對應等級獎勵
        br
        span 開通盼春歸不享受遊戲內充值活動
      .content5
        span *寒梅獻禮獎勵僅可在活動時間內領取，請小主們及時領取
        br
        span *活動最終解釋權歸《紫禁繁花》官方團隊所有
          
</template>
<script>
export default {
  name: "ruleOfWar",
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {};
  },
  methods: {
    close() {
      this.$emit("close");
    }
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.ruleOfWar
  padding: 20px 0 20px 0
  .tit-war
      width: 90%;
      height: 100px
      background-image: imgUrl("tit_war.png")
  .content-war
      width: 85%
      margin: 20px 0 0 0
      text-align: justify
      line-height: 35px
      &>div
          margin: 0 0 10px 0
</style>
