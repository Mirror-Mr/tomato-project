<!--
 * @Author: your name
 * @Date: 2021-11-16 20:47:44
 * @LastEditTime: 2021-12-21 17:37:27
 * @LastEditors: Please set LastEditors
 * @Description: 邀请红包
 * @FilePath: \three-year\src\components\allModals\inviteRedEnv.vue
-->
<template lang="pug">
	Mymodal(:show='show' @close='close')
		.role_games
		.box
			.inv 您收到來自
			.inv 
				//- span.name {{info.server_name+"-"+info.role_name}}
				span.name {{info.role_name}}
				span 的請宴大紅包！
			.red_env
			.tip 登錄遊戲賬號開啟大紅包，集卡免費獲得火霓鹿呦套裝！
			.btn_1(@click="getRed" v-if="userInfo && userInfo.role_id") 領取紅包
			.btn_1(@click="toLogin" v-else) 前往登錄
</template>
<script>
import { getRedDesc, subPrize, clickLog } from "@/request/api.js";
import { mapState } from "vuex";
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  computed: mapState(["userInfo", "red_limit", "red_detail_info"]),
  data() {
    return {
      red_id: "",
      info: {
        server_name: "",
        role_name: ""
      },
      // 红包详情
      detail_info: null
    };
  },
  watch: {
    show: {
      handler(val) {
        if (val) {
					let time = Date.now();
					let access1 = this.$encrypte([time]);
					// 进入分享红包
					clickLog({
						time,
						access: access1,
						type: 7,
						state: 1
					});
          this.getform();
          // this.getdetailInfo()
        }
      },
      immediate: true
    }
  },
  methods: {
    close() {
      this.$store.commit("SETVAL", { invite_red: false });
    },
    toLogin() {
				// "点击分享红包的登录"
				let time = Date.now();
				let access1 = this.$encrypte([time]);
				// 进入分享红包
				clickLog({
					time,
					access: access1,
					type: 8,
					state: 1
				});
      this.$store.commit("SETVAL", { login_type: true });
      this.close();
    },
    getform() {
      this.red_id = this.$route.query.red_id;
      if (!this.red_id) return;
      let time = parseInt(new Date().getTime());
      let access = this.$encrypte([time, this.red_id]);
      getRedDesc({
        time: time,
        red_id: this.red_id,
        access: access
      })
        .then(data => {
          if (data) {
            this.info = data;
          } else {
            this.$toast("紅包已失效");
            this.$router.push(this.$route.path);
            this.$store.commit("SETVAL", { invite_red: false });
          }
        })
        .catch(err => {
          this.$toast(err.msg || "獲取紅包來源失敗");
        });
    },
    getRed() {
      if (!this.userInfo.phone) {
        this.$store.commit("SETVAL", { bind_phone: true });
        return;
      }
      this.red_id = this.$route.query.red_id;
      if (!this.red_id) return;
      if (this.red_detail_info) {
        let info = this.red_detail_info;
        // 当天领取红包次数满了三次，红包被领取完了,或者领取过这个红包
        if (
          info.num >= this.red_limit ||
          info.list.length >= this.red_limit ||
          info.is_get == 1
        ) {
          // this.$emit('reciveRed')
          this.$store.commit("SETVAL", {
            invite_red: false,
            congratulation: true
          });
          return;
        }
      }

      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token, 1]);
      subPrize({
        time: time,
        token: token,
        num: 1,
        type: 2,
        rid: this.red_id,
        access: access
      })
        .then(data => {
          // debugger
          // this.$router.replaceState({path:this.$route.path})
          // this.$emit('reciveRed')
          this.$store.commit("SETVAL", {
            invite_red: false,
            red_id: "",
            congratulation: true
          });
          this.$store.dispatch("getInfo", 1);
        })
        .catch(err => {
          if (err.status == 22) {
            // this.$emit('reciveRed')
            this.$store.commit("SETVAL", {
              invite_red: false,
              congratulation: true
            });
          } else {
            this.$toast(err.msg || "領取紅包失敗");
          }
          // this.$store.commit("SETVAL",{bind_phone:true,invite_red:false})
        });
    }
    // 获取红包领取详情
    // getdetailInfo(){
    // 	let token = localStorage.getItem("token");
    // 	if(!token) return
    // 	this.$store.dispatch('getReddetailInfo',this.red_id).then(data=>{
    // 		this.detail_info = data
    // 	})
    // let time = parseInt(new Date().getTime());
    // let access = this.$encrypte([time, token]);
    // getRedUsers({
    // 	time:time,
    // 	token:token,
    // 	red_id:this.red_id,
    // 	access:access
    // }).then(data=>{
    // 	this.detail_info = data
    // 	// data && (this.info = data)
    // }).catch(err=>{
    // 	this.$toast(err.msg||'获取红包领取详情失败！')
    // })
    // },
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.role_games
	width 379px
	height 958px
	background bg('redEnvelopes/role.png')
	background-size 100% 100%
	position absolute
	bottom -40px
	left -90px
.box
	height 750px
	padding 70px 10px 0 160px
	box-sizing border-box
	text-align center
	.inv
		color #CA5E3D
		font-size 30px
		.name
			color #FF6059
	.red_env
		width 170px
		height 228px
		margin 30px  auto
		background bg('redEnvelopes/redEnv.png')
		background-size 100% 100%
	.tip
		color #CA5E3D
		font-size 16px
		padding 50px 0
		border-top 1px solid rgba(255, 138, 97, .5)
	.btn_1
		margin 0 auto
</style>
