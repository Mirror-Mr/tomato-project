<!--
 * @Author: your name
 * @Date: 2021-11-18 17:04:48
 * @LastEditTime: 2021-12-09 18:39:33
 * @LastEditors: Please set LastEditors
 * @Description: 规则弹框
 * @FilePath: \three-year\src\components\allModals\rule.vue
-->
<template lang="pug">
	Mymodal(:show='show' @close='close' :maskClose="true")
		.box 
			.title 活動規則
			.con_txt 
				span.point 分享紅包：
				span 活動期間，可將已解鎖的紅包分享給好友，每封紅包含3個【套裝部件卡】獎勵可領取
			.con_txt 
				span.point 領取紅包：
				span 領取他人分享的紅包，每封可獲得至多1個【套裝部件卡】獎勵，每人每天最多通過紅包領取3個獎勵，兌換的部件卡不納入限制次數內
			.con_txt 
				span.point 重複獎勵轉換：
				span 重複獲得的【套裝部件卡】將按1:1自動轉換成【萬能卡】，用於兌換商城使用
			.con_txt 
				span.point 萬能卡兌換：
				span 在兌換商城使用【萬能卡】可兌換部件卡或其它物品（活動結束後，萬能卡道具將清空，請小主們及時使用）
			.con_txt 
				span.point 領取套裝：
				span 活動期間集齊所有部件的卡片即可領取套裝獎勵，獎勵將會通過遊戲內郵件發放（活動結束後將無法領取獎勵，請小主們及時領取）
			.con_txt *參與活動需要綁定手機號，每個手機號只能綁定1個角色
</template>
<script>
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {};
  },
  methods: {
    close() {
      this.$emit("close");
    }
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.box
	padding 40px
	.title
		text-align: center
		font-size:30px
		color: rgb(214,53,45)
		line-height:60px
		margin-bottom: 20px
	.con_txt
		font-size:24px
		line-height:40px
		margin-bottom: 20px
		.point
			color: rgb(214,53,45)
			font-weight: bold
</style>
