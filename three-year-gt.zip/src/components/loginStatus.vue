<!--
 * @Author: your name
 * @Date: 2021-11-23 15:39:44
 * @LastEditTime: 2021-12-02 11:49:49
 * @LastEditors: Please set LastEditors
 * @Description: 登录状态栏
 * @FilePath: \three-year\src\components\loginStatus.vue
-->
<template lang="pug">
	.login_status(@click="showlogin" v-if="!userInfo") 請[ 登錄 ]
	.login_status(v-else) 
			span.name 歡迎您！{{ userInfo  ? (userInfo.role_name.length >8 ?userInfo.role_name.slice(0,7)+'...' : userInfo.role_name) :''}}
			span(@click="toggleRole") [ 切換角色 ]
			span(@click="logout") [ 退出 ]
</template>
<script>
import { mapState } from "vuex";
export default {
  name: "",
  data() {
    return {};
  },
  computed: { ...mapState(["userInfo"]) },
  methods: {
    toggleRole() {
      this.$store.commit("SETVAL", { toggle_role: true });
    },
    //
    logout() {
      this.$store.commit("SETVAL", { logout: true });
      // localStorage.clear()
    },
    showlogin() {
      // let uid = localStorage.getItem('uid')
      // if(uid){
      // 	this.$store.commit('SETVAL',{bind_role:true})
      // }else {
      this.$store.commit("SETVAL", { login_type: true });
      // }
    }
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.login_status
	color #f05535
	font-size 24px
	padding 20px 20px 0 0
	span
		margin-left 20px
		line-height 30px
</style>
