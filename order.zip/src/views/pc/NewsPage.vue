<!--
 * @Author: your name
 * @Date: 2021-07-20 21:50:16
 * @LastEditTime: 2021-08-02 20:50:51
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \vue-testc:\Users\leishan\Desktop\web\inland\Games\TangMistyRain\Activity\order\src\views\pc\newsPage.vue
-->
<template>
  <div class="newsPage" v-cloak>
    <div class="newsPage_top">
      <div class="game_logo" @click="returnHome"></div>
    </div>
    <div class="newsPage_btm">
      <i class="iconfont icon-left" @click="returnHome"></i>
      <div class="news_container">
        <div class="news_header">
          <span class="news_title">{{ news.title }}</span>
          <span class="news_time">{{ news.start_time.slice(0, 10) }}</span>
        </div>
        <div class="news_content" v-html="news.content"></div>
      </div>
      <div class="changePage">
        <span @click="prevNews">上一篇</span>
        <span @click="nextNews">下一篇</span>
      </div>
    </div>
  </div>
</template>
<script>
import { getNewsInfo } from "@/api/news";

export default {
  name: "NewsPage",
  data() {
    return {
      news: {
        title: ".....",
        start_time: "2021-05-07",
        content: ``,
        id: "",
      },
      afterNews: {},
      beforeNews: {},
      newsList: [],
      msg: null,
    };
  },
  methods: {
    returnHome() {
      this.$router.push({ name: "pcIndex", params: { open_show: true } });
    },
    getNewsInfo(id) {
      // this.$toast.loading({
      //   message: "加载中...",
      //   forbidClick: true,
      // });
      const time = Date.now();
      const type = "1";
      const params = { time, id, type };
      const headers = { time };
      getNewsInfo(params, headers).then((res) => {
        this.$toast.clear();
        if (res.status == 1) {
          this.news = res.data.data;
          this.beforeNews = res.data.before;
          this.afterNews = res.data.after;
        }
      });
    },
    // 上一篇
    prevNews() {
      if (this.beforeNews.length == 0) {
        if (this.msg) {
          this.msg.close();
        }
        this.msg = this.$message.info("已经是最新一篇啦~");
      } else {
        this.$router.push({ name: "pcNewsPage", params: { id: this.beforeNews.id } });
        this.getNewsInfo(this.beforeNews.id)
        // this.$router.go(0)
      }
    },
    // 下一篇
    nextNews() {
      if (this.afterNews.length == 0) {
        if (this.msg) {
          this.msg.close();
        }
        this.msg = this.$message.info("已经是最后一篇啦~");
      } else {
        this.$router.push({ name: "pcNewsPage", params: { id: this.afterNews.id } });
        this.getNewsInfo(this.afterNews.id)
        // this.$router.go(0)

      }
    },
  },

  mounted() {
    this.news.id = this.$route.params.id;
    this.getNewsInfo(this.news.id);
    this.newsList = JSON.parse(sessionStorage.getItem("newsList"));
  },
};
</script>
<style lang="scss">
[v-cloak]{
  display: none;
}
.newsPage {
  width: 100%;
  .newsPage_top {
    width: 100%;
    height: 3.3rem;
    position: relative;
    background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/newsPage_top_bg.png");
    .game_logo {
      width: 1.5rem;
      height: 0.7rem;
      position: absolute;
      top: 0.1rem;
      right: 0;
      background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/game_logo1.png");
      cursor: pointer;
    }
  }
  .newsPage_btm {
    width: 100%;
    padding: 0.001rem 0 0.5rem 0;
    background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/newsPage_btm_bg1.png");
    background-color: #F8E8E3;
    i {
      width: 0.23rem;
      height: 0.23rem;
      line-height: 0.23rem;
      display: block;
      margin: 0.3rem 0 0 0.2rem;
      text-align: center;
      border: 2PX solid #8C5730;
      border-radius: 50%;
      font-size: 0.13rem;
      color: #8C5730;
      cursor: pointer;
      &::before{
        margin: 0 0.01rem 0 0;
      }
    }
    .news_container {
      width: 55%;
      margin: 0 auto ;
      .news_header {
        display: flex;
        justify-content: center;
        position: relative;
        border-bottom: 0.001rem solid rgba(140, 87, 48, 0.3);
        .news_title {
          font-size: 0.2rem;
          color: #8C5730;
          line-height: 0.41rem;
          margin: 0 0 0.3rem 0;
          @include SourceHanSerifCN-Bold ;

        }
        .news_time {
          position: absolute;
          bottom: 0;
          right: 0;
          margin: 0 0 0.05rem 0;
          font-size: 0.11rem;
          @include SourceHanFontAll;
          color: #8C5730;
        }
      }
      .news_content {
        margin: 0.2rem 0 0 0;
        font-size: .085rem;
        font-weight: 300;
        color: #8C5730;
        line-height: 0.16rem;
        text-align: justify;
        @include SourceHanFontAll;
        img{
          width: 60% !important;
          display: block !important;
          margin: 0 auto !important;
        }
      }
    }
    .changePage{
      width: 70%;
      margin: 0.3rem auto 0;
      display: flex;
      justify-content: space-around;
      @include SourceHanSerifCN-Bold;
      span{
        font-size: 0.13rem;
        color: #8C5730;
        cursor: pointer;
      }
    }
  }

}

</style>
