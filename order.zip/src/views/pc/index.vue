<!--
 * @Author: your name
 * @Date: 2021-07-19 16:09:25
 * @LastEditTime: 2021-08-04 14:21:13
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \vue-testc:\Users\leishan\Desktop\web\inland\Games\TangMistyRain\Activity\order\src\views\pc\index.vue
-->
<template>
  <div
    class="pcContainer"
    :class="[{ container_show: container_show }]"
    :style="{ width: cWidth, height: cHeight }"
    v-show="isAllShow"
  >
    <!-- 右下角版权 -->
    <div class="game_copyright"></div>
    <div class="pcIndex special" :style="{ width: pWidth, height: pHeight }">
      <!-- 音频 -->
      <audio class="playMusic" loop="loop" ref="audio" autoplay="autoplay">
        <source
          src="https://wcdn.tomatogames.com/static/TangMistyRain/appoint/login_page.mp3"
          type="audio/mp3"
          controls
        />
      </audio>
      <!-- 鼠标跟随效果 -->
      <canvas
        id="canvas"
        ref="canvas"
        class="stage"
        width="100%"
        height="100%"
      ></canvas>
      <!-- 背景视频 -->
      <video
        class="bg_video"
        src="https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/bg.mp4"
        autoplay="autoplay"
        muted
        loop="loop"
      ></video>
      <!-- 开屏动画 -->
      <!-- <div
        class="open_an1 open_circle_an"
        v-if="isfirstAn == 1"
        :style="{ zIndex: open_an1_show ? 1000 : -1 }"
        @click="enterHome"
      >
        <div
          class="enter"
          :style="{ opacity: enterIsShow ? 1 : 0 }"
          @click="enterHome"
        >
          进入官网
        </div>
      </div> -->

      <!-- <div class="open_an2 open_cloud_an" v-if="isfirstAn == 2"></div> -->
      <div class="open_an2 open_cloud_an" v-if="isfirstAn == 1"></div>
      <div class="login">
        <template v-if="!isOrder">
          欢迎您！请
          <span @click="controlMask(2)">【登录】</span>
        </template>
        <template v-if="isOrder">
          {{ userMsg.phoneNum }}
          <span @click="changeNum">【切换】</span>
        </template>
      </div>
      <!-- 左侧新闻 -->
      <div class="newsSider" :style="{ marginLeft: newsSiderLeft + 'rem' }">
        <div class="news_title">
          <!-- <span>/</span>
          新闻资讯
          <span>/</span> -->
        </div>

        <swiper
          v-if="newsList.length"
          :options="swiperOption"
          class="swiper-container-news"
          ref="mySwiper"
        >
          <swiper-slide v-if="newsList.length > 0">
            <ul>
              <li
                v-for="item in newsList.slice(0, 3)"
                :key="item.id"
                @click="showNews(item.id)"
              >
                <span>{{ item.start_time }}</span>
                <b></b>
                <p>{{ item.title }}</p>
              </li>
            </ul>
          </swiper-slide>
          <swiper-slide v-if="newsList.length > 3">
            <ul>
              <li
                v-for="item in newsList.slice(3, 6)"
                :key="item.id"
                @click="showNews(item.id)"
              >
                <span>{{ item.start_time }}</span>
                <b></b>
                <p>{{ item.title }}</p>
              </li>
            </ul>
          </swiper-slide>
          <swiper-slide v-if="newsList.length > 6">
            <ul>
              <li
                v-for="item in newsList.slice(6, 9)"
                :key="item.id"
                @click="showNews(item.id)"
              >
                <span>{{ item.start_time }}</span>
                <b></b>
                <p>{{ item.title }}</p>
              </li>
            </ul>
          </swiper-slide>
          <div class="swiper-pagination" slot="pagination"></div>
        </swiper>

        <div class="news_order_gift" @click="controlMask(1)"></div>
        <div
          class="news_control"
          @click="controlNews()"
          :style="{ right: newsControlRight + 'rem' }"
          :class="{ big: newsControlRight == -0.3 }"
        >
          <span>
            {{ news_control }}
          </span>
          <span v-show="newsControlRight == -0.3">·</span>
          <span v-show="newsControlRight == -0.3">{{ news_control1 }}</span>
        </div>
      </div>
      <!-- 中下预约模板 -->
      <div class="game_order">
        <div class="order_btn" @click="controlMask(2, 1)">
          <span>{{ order_status }}</span>
        </div>
        <div class="order_num">
          已预约<span>{{ order_num }}</span
          >人
        </div>
      </div>
      <!-- 右上角介绍 -->
      <div class="game_logo"></div>

      <!-- 右侧导航栏 -->
      <div class="navbar_right">
        <ul>
          <!-- 控制视频 -->
          <li class="navbar_btn1" @click="controlMask(3)">
            <div></div>
            <div></div>
            <div></div>
          </li>
          <li
            class="navbar_btn2"
            @click="controlMusic"
            :class="{ play: isPlay }"
          >
            <i class="iconfont icon-music"></i>
          </li>
          <li class="navbar_btn3" @mouseenter="toDots(4)">
            <i class="iconfont icon-weixin"></i>
            <div class="wechatCode">
              <span></span>
            </div>
          </li>
          <li class="navbar_btn4" @click="jumpTo(6)">
            <i class="iconfont icon-weibo"></i>
            <div class="weiboCode">
              <span></span>
            </div>
          </li>
          <li class="navbar_btn5" @click="jumpTo(7)">
            <i class="iconfont icon-taptap"></i>
            <div class="taptapCode">
              <span></span>
            </div>
          </li>
          <li class="navbar_btn6" @click="jumpTo(5)">
            <i class="iconfont icon-qq"></i>
            <div class="qqCode">
              <span></span>
              <b>709896386</b>
            </div>
          </li>
          <li class="navbar_btn7">
            <i class="iconfont icon-share"></i>
            <div class="shareBox">
              <span class="shareTowx" @click="toShare(0)">
                <i class="iconfont icon-weixin1"></i>
                <canvas class="shareWxCode" id="canvas1" ref="canva"> </canvas>
              </span>
              <span class="shareTowb" @click="toShare(1)">
                <i class="iconfont icon-weibo1"></i>
              </span>
              <span class="shareTokj" @click="toShare(2)">
                <i class="iconfont icon-kongjian"></i>
              </span>
              <span class="shareToqq" @click="toShare(3)">
                <i class="iconfont icon-qq1"></i>
              </span>
            </div>
          </li>
        </ul>
      </div>
      <MaskBox
        class="maskBox"
        :class="{
          show_mask:
            isWelfareBoard ||
            isOrderBoard ||
            isPropagate ||
            isDetailBoard ||
            isShareBoard,
        }"
      >
        <template v-if="isWelfareBoard">
          <!-- <template v-if="true"> -->
          <div class="welfare_board">
            <span class="close_board" @click="controlMask(0)"></span>
            <span class="activity_detail" @click="controlMask(4)"
              >[活动详情]</span
            >
            <!-- 福利1 -->
            <div class="welfareBox1">
              <div class="welfare_title"></div>
              <span class="welfare_desc1 welfare_desc"
                >预约后即可获得奖励，领取方式见活动详情</span
              >
              <ul class="welfare_top">
                <li v-for="(item, index) in welfares1" :key="index">
                  <div
                    :class="`welfare welfare${index + 1}`"
                    :style="{
                      backgroundImage: `url(https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/welfare${
                        index + 1
                      }.png)`,
                    }"
                  >
                    <!-- <img
                      :src="`https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/welfare${
                        index + 1
                      }.png`"
                    /> -->
                  </div>
                  <span v-html="item.desc"></span>
                </li>
              </ul>
            </div>
            <!-- 福利2 -->
            <div class="welfareBox2">
              <div class="welfare_title"></div>
              <span class="welfare_desc2 welfare_desc">
                成功邀请1/2/3位好友预约，邀请人将获得额外好礼。领取方式见活动详情
              </span>
              <!-- 进度条2 -->
              <div class="progressBox_desc2">
                <div class="progress_milepost">
                  <span>邀请1人奖励 </span>
                  <span>邀请2人奖励 </span>
                  <span>邀请3人奖励 </span>
                </div>
                <div class="progress_bg">
                  <div :style="{ width: `${progressBarWidth(1, 2, 3)}rem` }">
                    <span class="fly"></span>
                  </div>
                </div>
              </div>
              <ul class="welfare_mid">
                <li v-for="(item, index) in welfares2" :key="index">
                  <div
                    :class="`welfare welfare${index + 5}`"
                    :style="{
                      opacity: isOpacity(index + 5),
                      backgroundImage: `url(https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/welfare${
                        index + 5
                      }.png)`,
                    }"
                  >
                    <!-- <img
                      :src="`https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/welfare${
                        index + 5
                      }.png`"
                    /> -->
                  </div>
                  <span
                    v-html="item.desc"
                    :style="{
                      opacity: isOpacity(index + 5),
                    }"
                  ></span>
                </li>
              </ul>
              <div class="invite_btn" @click="controlMask(5)"></div>
              <div class="invite_sum">已邀请{{ userMsg.inviteNum }}位好友</div>
            </div>

            <!-- 福利3 -->
            <div class="welfareBox3">
              <div class="welfare_title"></div>
              <span class="welfare_desc3 welfare_desc"
                >我们将根据官网总预约量里程碑达成，发放以下奖励。领取方式见活动详情</span
              >
              <!-- 进度条3 -->
              <div class="progressBox_desc3">
                <div class="progress_milepost">
                  <span>10W</span>
                  <span>20W</span>
                  <span>50W</span>
                  <span>80W</span>
                  <span>100W</span>
                </div>
                <div class="progress_bg">
                  <div
                    :style="{
                      width: `${progressBarWidth(
                        100000,
                        200000,
                        500000,
                        800000,
                        1000000
                      )}rem`,
                    }"
                  >
                    <span class="fly"></span>
                  </div>
                </div>
              </div>
              <ul class="welfare_btm">
                <li v-for="(item, index) in welfares3" :key="index">
                  <div
                    :class="`welfare welfare${index + 8}`"
                    :style="{
                      opacity: isOpacity(index + 8),
                      backgroundImage: `url(https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/welfare${
                        index + 8
                      }.png)`,
                    }"
                  >
                    <!-- <img
                      :src="`https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/welfare${
                        index + 8
                      }.png`"
                    /> -->
                  </div>
                  <span
                    v-html="item.desc"
                    :style="{
                      opacity: isOpacity(index + 8),
                    }"
                  ></span>
                </li>
              </ul>
            </div>
          </div>
        </template>
        <template v-if="isOrderBoard">
          <div class="order_board" :class="{ order: isOrderBoard1 }">
            <span class="close_board" @click="controlMask(0)"></span>
            <div class="form" v-show="!isOrder">
              <!-- 单选按钮 -->
              <div class="radioGroup">
                <div
                  class="radio radio1"
                  :class="{ choose: isiOS }"
                  @click="isiOS = true"
                >
                  <div>
                    <span></span>
                  </div>
                  <span>iOS</span>
                </div>
                <div
                  class="radio radio2"
                  :class="{ choose: !isiOS }"
                  @click="isiOS = false"
                >
                  <div>
                    <span></span>
                  </div>
                  <span>Android</span>
                </div>
              </div>
              <!-- 输入框 -->
              <input
                type="text"
                class="phoneNum input"
                placeholder="请输入手机号"
                v-model="loginMsg.phoneNum"
              />
              <div class="codeGroup">
                <input
                  type="text"
                  class="phoneCode input"
                  placeholder="请输入验证码"
                  v-model="loginMsg.phoneCode"
                /><span class="getCode" @click="getCode">{{ codeMsg }}</span>
              </div>
              <input
                type="text"
                class="inviteCode input"
                placeholder="请输入邀请码（非必填）"
                v-model="loginMsg.inviteCode"
              />
              <div class="order_check" @click="orderCheck">确认</div>
            </div>
            <div class="ordered" v-show="isOrder">
              <div>您已预约成功！</div>
              <span @click="changeNum"></span>
            </div>
          </div>
        </template>
        <template v-if="isPropagate">
          <div class="propagate_board">
            <span class="close_board" @click="controlMask(0)"></span>
            <!-- 宣传视频 -->
            <video
              class="propagate"
              autoplay="autoplay"
              controls
              controlsList="nodownload"
              :disablePictureInPicture="true"
              οncοntextmenu="return false"
              src="https://wcdn.tomatogames.com/static/TangMistyRain/appoint/video.mp4"
            ></video>
          </div>
        </template>
        <template v-if="isDetailBoard">
          <div class="detail_board">
            <span class="close_board" @click="controlMask(0)"></span>
            <div class="container">
              <div class="detail" v-for="(item, index) in details" :key="index">
                <b>{{ item.title }}</b>
                <span v-html="item.desc"></span>
              </div>
            </div>
          </div>
        </template>
        <template v-if="isShareBoard">
          <div class="share_board">
            <span class="close_board" @click="controlMask(0)"></span>
            <div class="container">
              <div class="myInviteNum">
                您的邀请码：{{ userMsg.inviteCode }}
                <span @click="copy(userMsg.inviteCode)">【复制】</span>
              </div>
              <div class="way1">
                <span>方法一：复制地址链接邀请好友点击链接进行预约</span>
                <div class="website">
                  <div>{{ invite_website }}</div>
                  <span @click="copy(invite_website)">复制地址</span>
                </div>
                <span
                  >使用该链接进行预约，系统将会在好友预约界面填写您的邀请码</span
                >
              </div>
              <div class="way2">
                <span>方法二：分享二维码</span>
                <div>
                  <canvas class="shareCode" ref="shareCode"></canvas>
                </div>
              </div>
            </div>
          </div>
        </template>
      </MaskBox>
    </div>
  </div>
</template>

<script>
import "@/assets/fonts/iconfont.css";
import MaskBox from "@/components/pc/MaskBox.vue";
import validatePhone from "@/utils/validatePhone";
import sendCode from "@/api/sendCode";
import { getAppointNum, getVisitNum, appoint } from "@/api";
import { getNewsList } from "@/api/news";
import clickLog from "@/api/clickLog";
import QRCode from "qrcode";
// import mouseFoolow from "@/assets/js/mouseFollow.js";
import { Swiper, SwiperSlide } from "vue-awesome-swiper";
import "swiper/dist/css/swiper.min.css";

export default {
  // pc端
  name: "pcIndex",
  components: {
    MaskBox,
    Swiper,
    SwiperSlide,
  },
  data() {
    return {
      // 是否显示container
      container_show: false,
      // 新闻列表
      newsList: [],
      //标识新闻列表是否展开 false关闭 true展开
      news_show: true,
      newsSiderLeft: 0.05,
      newsControlRight: -0.09,
      // 预约人数
      order_num: 51129,
      // 福利
      welfares1: [
        {
          desc: "商店刷新券*5",
        },
        {
          desc: "许愿币*1",
        },
        {
          desc: "初等经验丹*10",
        },
        {
          desc: "银两*10W",
        },
      ],
      welfares2: [
        {
          desc: `中等经验丹*10<br>专属聊天气泡`,
        },
        {
          desc: `元宝*50<br>升星石*20`,
        },
        {
          desc: `专属时装-丝路云歌头饰<br/>稀有卡片碎片包*20<br/>许愿币*2`,
        },
      ],
      welfares3: [
        {
          desc: "初等经验丹*10",
        },
        {
          desc: `升星石*20`,
        },
        {
          desc: `点击特效-浮花<br>银两*5W`,
        },
        {
          desc: `头像框-玉翎寒梅<br>元宝*88`,
        },
        {
          desc: `许愿币*2<br>元宝*188`,
        },
      ],
      // 标识福利弹框是否显示
      isWelfareBoard: false,
      // 标识预约弹框是否显示
      isOrderBoard: false,
      // 宣传视频是否显示
      isPropagate: false,
      // 标识活动详情弹框是否显示
      isDetailBoard: false,
      // 标识分享弹框是否显示
      isShareBoard: false,
      // 是否预约
      isOrder: false,
      // 手机型号
      isiOS: true,
      shareMsg: {
        url: location.href,
        title: "《盛唐烟雨》游戏预约",
        pics: ``,
        summary: `古风大女主恋爱手游——《盛唐烟雨》预约正式开启！烟雨之中，轻笔落墨。立即预约，一场华丽的盛唐探索之旅，等待你来开启~`,
        desc: `古风大女主恋爱手游——《盛唐烟雨》预约正式开启！烟雨之中，轻笔落墨。立即预约，一场华丽的盛唐探索之旅，等待你来开启~`,
      },
      // 被这个邀请码邀请来的
      friendInviteCode: null,
      // 登录信息
      loginMsg: {
        phoneNum: "",
        phoneCode: "",
        // 受邀请码
        inviteCode: "",
      },
      // 已经登录的用户信息
      userMsg: {
        phoneNum: "",
        inviteCode: "",
        inviteNum: 0,
      },
      timer: null,
      codeMsg: "发送验证码",
      // 音频是否被视频打断
      musicFlag: 0,
      isfirstAn: 1,
      // 进入官网字样是否出现
      enterIsShow: false,
      // 第一层动画是否出现
      open_an1_show: true,
      // 音乐是否播放
      isPlay: true,
      // 电脑屏幕宽度
      screenWidth: window.screen.width,
      // 电脑屏幕高度
      screenHeight: window.screen.height,

      //弹框是否触发
      msg: null,
      // container宽度
      cWidth: null,
      // container高度
      cHeight: null,
      // pcIndex宽度
      pWidth: null,
      // pcIndex高度
      pHeight: null,
      // 开屏动画前 元素先不显示
      isAllShow: true,
      // 获取验证码请求是否执行完
      isGetCode: true,
      // 新闻栏轮播图参数
      swiperOption: {
        observer: true,
        slidesPerView: "auto",
        centeredSlides: true,
        notNextTick: true,
        // spaceBetween: 10,
        // loop: true,
        speed: 600,
        // 显示分页
        pagination: {
          el: ".swiper-pagination",
          clickable: true, //允许分页点击跳转
        },
        on: {
          resize: () => {
            setTimeout(() => {
              let swiper = this.$refs.mySwiper.$swiper;
              swiper.update();
            }, 500); //延时器很重要，不加可能会出错
          },
        },
      },
      //预约状态
      // order_status: "游戏预约",

      // 活动详情
      details: [
        {
          title: `一、活动时间：`,
          desc: `即日起至不删档测试开启前一天23:59。`,
        },
        {
          title: `二、活动说明：`,
          desc: `①游戏上线后，玩家需在官网下载游戏，并于不删档开服后两周内登录游戏并创建角色，方可获得预约时所得全部虚拟奖励；
<br>②每个手机号仅限参与一次预约活动，并用于后继奖励接收，请确认手机号填写正确；
<br>③活动具体发放时间和发放方式，请关注游戏上线前官网的统一公告。`,
        },
        {
          title: `三、活动规则：`,
          desc: `①多重预约礼：在官网进行预约成功后，即可获得该奖励，每人仅可获得一次。
<br>②好友邀约礼：活动期间，参加官网预约活动的玩家邀请1位、2位、3位好友，通过生成的专属链接或二维码完成预约后，邀请人可获得相应档位的游戏道具奖励。
<br>③预约集结礼：总预约量达到10万、20万、50万、80万、100万，所有活动期间在官网成功预约的玩家都可领取相应档位的奖励。`,
        },
      ],
      // 是否是预约弹框
      isOrderBoard1: false,
      // 查询邀请好友数定时器
      friendTimer: null,
      news_control1: "福利",
    };
  },
  computed: {
    news_control() {
      return this.news_show ? "收起" : "新闻";
    },
    progressBarWidth() {
      return (num1, num2, num3, num4, num5) => {
        // 总长
        const sumWidth = 2.8;
        let singleWidth;
        let width = 0;
        // 邀请人数
        if (num1 == 1) {
          if (localStorage.getItem("userMsg")) {
            // 有登录
            // this.userMsg.inviteNum = 3;
            reserveNum = this.userMsg.inviteNum;
            // reserveNum = 3;
            singleWidth = sumWidth / 6;
            if (reserveNum <= num1) {
              width = singleWidth * reserveNum;
            } else if (reserveNum == num2) {
              width = singleWidth * 3;
            } else if (reserveNum == num3) {
              // width = singleWidth * 5;
              width = sumWidth;
            } else {
              width = sumWidth;
            }
          }
          return width;
        }
        // 预约人数
        // this.order_num = 100000;
        let reserveNum = parseInt(this.order_num);
        // let reserveNum = parseInt(100000);
        // 总长2.8rem 分成10份
        singleWidth = sumWidth / 10;
        // 如果预约数小于10万，则按单个长度乘以所占的比例
        if (reserveNum <= num1) {
          width = (reserveNum / num1) * singleWidth;
          // 如果预约数大于10万小于20万，则单个长度加上预约数-10万除以对应的长度(20万)所占的比例乘以2个单个长度
        } else if (reserveNum > num1 && reserveNum <= num2) {
          width =
            singleWidth +
            ((reserveNum - num1) / (num2 - num1)) * 2 * singleWidth;
          // 同上
        } else if (reserveNum > num2 && reserveNum <= num3) {
          width =
            3 * singleWidth +
            ((reserveNum - num2) / (num3 - num2)) * 2 * singleWidth;
        } else if (reserveNum > num3 && reserveNum <= num4) {
          width =
            5 * singleWidth +
            ((reserveNum - num3) / (num4 - num3)) * 2 * singleWidth;
        } else if (reserveNum > num4 && reserveNum <= num5) {
          width =
            7 * singleWidth +
            ((reserveNum - num4) / (num5 - num4)) * 2 * singleWidth;
        } else {
          // 大于100万，直接占满
          width = sumWidth;
        }
        return width;
      };
    },
    swiper() {
      return this.$refs.mySwiper.swiper;
    },
    // 预约状态
    order_status() {
      return this.isOrder ? "您已预约" : "游戏预约";
    },
    // 邀请链接
    invite_website() {
      return `${location.href.split("?")[0]}?code=${this.userMsg.inviteCode}`;
    },
    // 透明度
    isOpacity() {
      return (n) => {
        if (n == 5) {
          return this.userMsg.inviteNum >= 1 ? 1 : 0.5;
        } else if (n == 6) {
          return this.userMsg.inviteNum >= 2 ? 1 : 0.5;
        } else if (n == 7) {
          return this.userMsg.inviteNum >= 3 ? 1 : 0.5;
        } else if (n == 8) {
          return this.order_num >= 100000 >= 1 ? 1 : 0.5;
        } else if (n == 9) {
          return this.order_num >= 200000 >= 1 ? 1 : 0.5;
        } else if (n == 10) {
          return this.order_num >= 500000 >= 1 ? 1 : 0.5;
        } else if (n == 11) {
          return this.order_num >= 800000 >= 1 ? 1 : 0.5;
        } else {
          return this.order_num >= 1000000 >= 1 ? 1 : 0.5;
        }
      };
    },
  },
  methods: {
    // 进入首页
    enterHome() {
      this.isfirstAn = 2;
      this.open_an1_show = false;
      this.$refs.audio.play();
      this.isPlay = true;
    },
    // 控制新闻页的展示
    controlNews() {
      if (this.news_show) {
        // 展开状态
        this.newsSiderLeft = -1.75;
        this.newsControlRight = -0.3;
      } else {
        // 收起状态
        this.newsSiderLeft = 0.05;
        this.newsControlRight = -0.09;
      }
      this.news_show = !this.news_show;
    },
    // 切换账号
    changeNum() {
      this.isOrder = false;
      this.isOrderBoard = true;
      // localStorage.removeItem("userMsg");
      // this.loginMsg.phoneNum = "";
    },
    // 控制弹出框
    controlMask(n, m = 0) {
      if (n == 0) {
        if (this.isWelfareBoard && this.friendTimer) {
          clearInterval(this.friendTimer);
        }
        this.isWelfareBoard = false;
        if (this.isDetailBoard) {
          this.isDetailBoard = false;
          this.isWelfareBoard = true;
        }
        if (this.isShareBoard) {
          this.isShareBoard = false;
          this.isWelfareBoard = true;
        }
        if (this.isOrderBoard && localStorage.getItem("userMsg")) {
          this.isOrder = true;
        }

        this.isOrderBoard = false;
        this.isPropagate = false;
        this.loginMsg.phoneNum = "";
        this.loginMsg.phoneCode = "";
        // this.loginMsg.inviteCode = "";
        if (this.musicFlag) {
          this.$refs.audio.play();
          this.musicFlag = false;
          this.isPlay = true;
        }
      } else if (n == 1) {
        // 礼包
        this.isWelfareBoard = true;
        this.friendTimer = setInterval(() => {
          this.getInviteNum();
        }, 2000);
      } else if (n == 2) {
        // 预约
        this.isOrderBoard1 = m == 1 ? true : false;
        this.isOrderBoard = true;
        if (localStorage.getItem("userMsg")) {
          this.isOrder = true;
          let { phoneNum, inviteCode } = JSON.parse(
            localStorage.getItem("userMsg")
          );
          // 这个手机号预约了
          this.userMsg.phoneNum = phoneNum;
          this.userMsg.inviteCode = inviteCode;
        }
      } else if (n == 3) {
        // 宣传视频
        this.isPropagate = true;
        this.$nextTick(() => {
          document.getElementsByClassName("propagate")[0].volume = 0.3;
          //   document
          //     .getElementsByClassName("propagate")[0]
          //     .addEventListener("enterpictureinpicture", () => {
          //       this.isPropagate = false;
          //       if (this.musicFlag) {
          //         this.$refs.audio.play();
          //         this.musicFlag = false;
          //         this.isPlay = true;
          //       }
          //     });
        });

        if (!this.$refs.audio.paused) {
          // musicFlag表示是被打断的
          this.musicFlag = true;
          this.$refs.audio.pause();
          this.isPlay = false;
        }
      } else if (n == 4) {
        //活动详情
        this.isWelfareBoard = false;
        this.isDetailBoard = true;
      } else if (n == 5) {
        if (this.isOrder) {
          //分享
          this.isWelfareBoard = false;
          this.isShareBoard = true;
          // console.log(this.invite_website)
          this.$nextTick(() => {
            let canvas = this.$refs.shareCode;
            QRCode.toCanvas(
              canvas,
              this.invite_website,
              { color: { dark: "#C8430D" } },
              function (error) {
                if (error) console.error(error);
              }
            );
            canvas.style.display = "block"; //显示canvas
            this.qrcode = canvas.toDataURL("image/png");
          });
        } else {
          if (this.msg) {
            this.msg.close();
          }
          this.msg = this.$message.info("请您先预约");
        }
      }
    },
    // 进入新闻页
    showNews(id) {
      this.isfirstAn = 0;
      sessionStorage.setItem("isPlay", this.isPlay);
      this.$router.push({ name: "pcNewsPage", params: { id: id } });
    },
    // 控制视频
    // controlVideo() {},
    // 控制音乐
    controlMusic() {
      if (this.$refs.audio.paused) {
        this.$refs.audio.play();
        this.isPlay = true;
      } else {
        this.$refs.audio.pause();
        this.isPlay = false;
      }
      sessionStorage.setItem("isPlay", this.isPlay);
    },
    // 分享
    toShare(n) {
      // 分享埋点
      clickLog({ type: 2, from: 1, dev: 1 });

      if (n == 0) {
        // 微信
        let canvas = this.$refs.canva;
        QRCode.toCanvas(
          canvas,
          this.shareMsg.url,
          { margin: 1.5 },
          function (error) {
            if (error) console.error(error);
          }
        );
        canvas.style.display = "block"; //显示canvas
        this.qrcode = canvas.toDataURL("image/png");
      } else if (n == 1) {
        // 微博
        window.open(
          "http://v.t.sina.com.cn/share/share.php?pic=" +
            this.shareMsg.pics +
            "&title=" +
            this.shareMsg.summary +
            "&url=" +
            this.shareMsg.url
        );
      } else if (n == 2) {
        // 空间
        window.open(
          "https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=" +
            this.shareMsg.url +
            "&sharesource=qzone&title=" +
            this.shareMsg.title +
            "&pics=" +
            this.shareMsg.pics +
            "&summary=" +
            this.shareMsg.summary
        );
      } else {
        // qq
        clickLog({ type: 8, from: 1, dev: 1 });

        window.open(
          "http://connect.qq.com/widget/shareqq/index.html?url=" +
            encodeURIComponent(this.shareMsg.url) +
            "?sharesource=qzone&title=" +
            this.shareMsg.title +
            "&pics=" +
            this.shareMsg.pics +
            "&summary=" +
            this.shareMsg.summary +
            "&desc=" +
            this.shareMsg.desc
        );
      }
    },
    // 确认预约
    orderCheck() {
      if (this.checkPhone() && this.checkCode()) {
        const time = Date.now();
        const project_id = "6";
        const phone = this.loginMsg.phoneNum;
        const code = this.loginMsg.phoneCode;
        const invite = this.loginMsg.inviteCode;
        const dev = this.isiOS ? 1 : 2;
        const params = { time, project_id, phone, code, dev, fcode: invite };
        const headers = { time, phone, code, project_id };
        appoint(params, headers).then((res) => {
          let text;
          // 预约成功
          if (res.status == 1) {
            if (this.msg) {
              this.msg.close();
            }
            text = this.isOrderBoard1 ? `预约成功` : `您已登录并预约成功`;
            this.msg = this.$message.success(text);
            this.userMsg.phoneNum = this.loginMsg.phoneNum;
            this.userMsg.inviteCode = res.data;
            localStorage.setItem("userMsg", JSON.stringify(this.userMsg));
            this.isOrder = true;
            clickLog({ type: 3, from: 1, dev: 1 });
            // 获取预约人数
            this.getReserveNum();
            // 获取邀请人数
            this.getInviteNum();
            this.loginMsg.phoneNum = "";
            this.loginMsg.phoneCode = "";
            this.loginMsg.inviteCode = "";
            if (this.friendInviteCode) {
              this.loginMsg.inviteCode = this.friendInviteCode;
            }
            this.isOrderBoard = false;
          } else if (res.status == 0) {
            if (this.msg) {
              this.msg.close();
            }
            this.msg = this.$message.error("验证码错误，请重新输入");
          } else {
            // 已预约 则直接登录
            if (this.msg) {
              this.msg.close();
            }
            this.msg = this.$message.info(res.msg);
            this.isOrder = true;
            this.isOrderBoard = false;
            this.userMsg.phoneNum = this.loginMsg.phoneNum;
            this.userMsg.inviteCode = res.data;
            localStorage.setItem("userMsg", JSON.stringify(this.userMsg));
            // 获取邀请人数
            this.getInviteNum();
            this.loginMsg.phoneNum = "";
            this.loginMsg.phoneCode = "";
            this.loginMsg.inviteCode = "";
            if (this.friendInviteCode) {
              this.loginMsg.inviteCode = this.friendInviteCode;
            }
          }
        });
      }
    },
    // 获取验证码
    getCode() {
      if (this.timer || !this.isGetCode) {
        return;
      }

      if (this.checkPhone()) {
        this.isGetCode = false;
        sendCode(this.loginMsg.phoneNum).then((res) => {
          if (res.status == 1) {
            if (this.msg) {
              this.msg.close();
            }
            this.msg = this.$message.success(res.msg);
            let num = 60;
            this.timer = setInterval(() => {
              this.codeMsg = `${num}s后重新发送`;
              num--;
              if (num === 0) {
                this.codeMsg = "重新发送";
                clearInterval(this.timer);
                this.timer = null;
              }
            }, 1000);
          } else {
            if (this.msg) {
              this.msg.close();
            }
            this.msg = this.$message.info(res.msg);
          }
          this.isGetCode = true;
        });
      }
    },
    // 判断手机号码
    checkPhone() {
      if (!this.loginMsg.phoneNum) {
        if (this.msg) {
          this.msg.close();
        }
        this.msg = this.$message.info("请输入手机号码");
        return false;
      } else if (!validatePhone(this.loginMsg.phoneNum)) {
        if (this.msg) {
          this.msg.close();
        }
        this.msg = this.$message.info("请输入正确的手机号码");
        return false;
      } else {
        return true;
      }
    },
    // 判断验证码
    checkCode() {
      if (!this.loginMsg.phoneCode) {
        if (this.msg) {
          this.msg.close();
        }
        this.msg = this.$message.info("请输入验证码");
        return false;
      } else if (this.loginMsg.phoneCode.length !== 6) {
        if (this.msg) {
          this.msg.close();
        }
        this.msg = this.$message.info("请输入6位数验证码");
        return false;
      } else {
        return true;
      }
    },
    // 获取预约人数
    getReserveNum() {
      const time = Date.now();
      getAppointNum({ time }, { time }).then((res) => {
        if (res.status == 1) {
          this.order_num = res.data;
        }
      });
    },
    // 获取新闻列表
    getNewsList() {
      // const newsList = JSON.parse(sessionStorage.getItem("newsList"));
      // if (!newsList) {
      const time = Date.now();
      const type = "1";
      const current_page = 1;
      const params = { time, type, current_page };
      const headers = { time };
      getNewsList(params, headers).then((res) => {
        if (res.status == 1) {
          const newsList1 = res.data.data.slice(0, 9);
          this.newsList = newsList1;
          // sessionStorage.setItem("newsList", JSON.stringify(newsList1));
        }
      });
      // } else {
      // this.newsList = newsList;
      // }
    },
    // 打点
    toDots(n) {
      clickLog({ type: n, from: 1, dev: 1 });
    },
    // 跳链接 + 打点
    jumpTo(n) {
      clickLog({ type: n, from: 1, dev: 1 });
      let href;
      if (n == 6) {
        href = "https://weibo.com/styy1";
      } else if (n == 7) {
        href = "https://www.taptap.com/app/205540";
      } else if (n == 5) {
        href = "https://jq.qq.com/?_wv=1027&k=VDOcshJU";
      }
      window.open(href, "_blank");
    },
    // 调整页面宽高
    adapterPage() {
      // 判断是否全屏
      // 电脑屏幕宽度
      let screenWidth = window.screen.width;
      // 电脑屏幕高度
      let screenHeight = window.screen.height;
      // 工具栏高度
      let toolHeight = window.outerHeight - window.innerHeight;
      // 任务栏高度
      let taskHeight = window.screen.height - window.screen.availHeight;
      // 计算出来的浏览器可视区域高度
      let standardHeight = screenHeight - toolHeight - taskHeight;
      // 背景图的长宽比
      // let picScale = 1509/849;
      let picScale = 1509 / 760;
      if (
        (standardHeight == window.innerHeight &&
          screenWidth == window.innerWidth) ||
        (toolHeight == 0 && screenWidth == window.innerWidth)
      ) {
        // 全屏显示
        this.cWidth = "100%";
        this.pWidth = "100%";
        this.cHeight = `${window.innerHeight}PX`;
        this.pHeight = `${(1080 * window.innerWidth) / 1920}PX`;
      } else if (window.innerWidth / window.innerHeight >= picScale) {
        // 页面有缩放 且 页面宽了 就让宽度满足 高度自适应
        this.cWidth = `${window.innerWidth}PX`;
        this.pWidth = this.cWidth;
        // this.cHeight = `${(849 * parseInt(this.cWidth)) / 1509}PX`
        this.cHeight = `${(760 * parseInt(this.cWidth)) / 1509}PX`;
        this.pHeight = `${(1080 * parseInt(this.cWidth)) / 1920}PX`;
      } else if (window.innerWidth / window.innerHeight < picScale) {
        // 页面有缩放 且 页面高了 就让高度满足 宽度自适应

        this.cHeight = `${window.innerHeight}PX`;
        // this.cWidth = `${(1509 * window.innerHeight) / 849}PX`
        this.cWidth = `${(1509 * window.innerHeight) / 760}PX`;
        this.pWidth = this.cWidth;
        this.pHeight = `${(1080 * parseInt(this.pWidth)) / 1920}PX`;
      }
      document.getElementsByTagName("html")[0].style.width = this.cWidth;

      // console.log("电脑屏幕宽度" + window.screen.width);
      // console.log("电脑屏幕高度" + window.screen.height);
      // console.log("工具栏高度" + (window.outerHeight - window.innerHeight));
      // console.log(
      //   "任务栏高度" + (window.screen.height - window.screen.availHeight)
      // );
      // console.log(
      //   "计算出来的浏览器可视区域高度" +
      //     (window.screen.height -
      //       (window.outerHeight - window.innerHeight) -
      //       (window.screen.height - window.screen.availHeight))
      // );
      // console.log("获取浏览器可视区域高度" + window.innerHeight);
      // console.log("获取浏览器可视区域高度" + window.innerWidth);
    },
    // 获取指定参数
    getQueryValue(variable) {
      if (window.location.href.indexOf(variable) == -1) {
        return null;
      }
      var arr = window.location.href.split("?");
      var query = arr[arr.length - 1];
      var vars = query.split("&");
      for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) {
          return pair[1];
        }
      }
      return null;
    },
    // 传入要复制的内容即可
    copy(data) {
      let input = document.createElement("input"); // 直接构建input
      input.setAttribute("readonly", "readonly"); //设置只读，否则移动端会有键盘弹出
      input.value = data; // 设置内容
      document.body.appendChild(input); // 添加临时实例
      input.select(); // 选择实例内容
      document.execCommand("Copy"); // 执行复制
      document.body.removeChild(input); // 删除临时实例
      if (this.msg) {
        this.msg.close();
      }
      this.msg = this.$message.success("复制成功");
    },
    // 获取邀请人数
    getInviteNum() {
      const { inviteCode } = JSON.parse(localStorage.getItem("userMsg")) || {};
      if (inviteCode) {
        const time = Date.now();
        const code = inviteCode;
        const params = { time, code };
        const headers = { time };
        getVisitNum(params, headers).then((res) => {
          if (res.status == 1) {
            this.userMsg.inviteNum = res.data;
          }
        });
      } else {
        this.userMsg.inviteNum = 0;
      }
    },
  },
  mounted() {
    // 判断是否通过好友链接进入
    const code = this.getQueryValue("code");
    if (code) {
      this.loginMsg.inviteCode = code;
      this.friendInviteCode = code;
      localStorage.setItem(
        "friendInviteCode",
        JSON.stringify(this.friendInviteCode)
      );
      localStorage.removeItem("userMsg");
    } else {
      if (JSON.parse(localStorage.getItem("friendInviteCode"))) {
        this.friendInviteCode = JSON.parse(
          localStorage.getItem("friendInviteCode")
        );
        this.loginMsg.inviteCode = this.friendInviteCode;
      }
    }
    // 背景视频音量调整
    this.$refs.audio.volume = 0.3;
    // 判断音频播放
    if (JSON.parse(sessionStorage.getItem("isPlay"))) {
      this.$refs.audio.play();
      this.isPlay = true;
      // sessionStorage.setItem("isPlay", this.isPlay);
    } else if (JSON.parse(sessionStorage.getItem("isPlay")) == false) {
      this.isPlay = false;
      this.$refs.audio.pause();
    } else if (JSON.parse(sessionStorage.getItem("isPlay")) == null) {
      setTimeout(() => {
        if (this.$refs.audio.paused) {
          //是暂停的
          this.isPlay = false;
        } else {
          this.isPlay = true;
        }
      }, 1000);
    }

    // this.$nextTick(() => {
    //   let init = mouseFoolow();
    //   init(this.$refs.canvas);
    // });
    if (!JSON.parse(sessionStorage.getItem("isDeviceMobile"))) {
      this.$nextTick(() => {
        this.adapterPage();
      });
    }
    // this.$nextTick(() => {
    //   let init = mouseFoolow();
    //   init(this.$refs.canvas);
    // });
    window.onresize = () => {
      return (() => {
        if (!JSON.parse(sessionStorage.getItem("isDeviceMobile"))) {
          this.adapterPage();
        }
      })();
    };
    if (this.$route.params.open_show) {
      this.isfirstAn = 0;
      // this.container_show = false;
    } else {
      this.container_show = true;
    }

    // 获取预约人数
    this.getReserveNum();
    // 获取新闻
    this.getNewsList();
    // 进入首页埋点
    clickLog({ type: 1, from: 1, dev: 1 });
    // 监听动画开始 container内容开始出现
    document
      .getElementsByClassName("open_an2")[0]
      .addEventListener("animationstart", () => {
        setTimeout(() => {
          this.container_show = false;
        }, 100);
      });

    // 当前是否已有账号登录
    if (localStorage.getItem("userMsg")) {
      this.isOrder = true;
      this.userMsg = JSON.parse(localStorage.getItem("userMsg"));
      this.getInviteNum();
    }
  },
};
</script>

<style lang="scss" scoped>

@font-face{
  font-family: "SourceHanSerifCN-Heavy";
//   src: url("~@/assets/fonts/SourceHanSerifCN-Heavy.ttf");
}

.pcContainer{
  width:100%;
  min-width: 1200PX;
  position: relative;
  // 限制一屏高
  height:4.877rem;
  min-height: 594PX;
  overflow: hidden;
  opacity: 1;
  transition: opacity 1s ;
  &.container_show{
    opacity: 0;
  }

  .game_copyright {
    width: 1.5rem;
    height: 0.2rem;
    position: absolute;
    bottom: 0;
    right: 0;
    background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/game_copyright.png");
    z-index: 1;
  }
}
.pcIndex {
  width: 100%;
  min-width: 1200PX;
  height: 5.62rem;
  min-height: 675PX;
  display: flex;
  position: relative;
  justify-content: space-between;
  // justify-content: center;
  align-items: center;

  overflow: hidden;
  // background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/bg.png");
  // background-size: cover;

  // 鼠标跟随效果
  .stage {
    width: 100%;
    height: 100%;
    display:block;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2000;
    pointer-events: none;
  }
  video {
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
    // pointer-events: none;
    // height: 100%;
    &.bg_video{
      pointer-events: none;
    }
  }
  // 开屏帧动画
  .open_an1 {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    position: absolute;
    top:0 ;
    left: 0;

    // opacity: 0;
    // pointer-events: none;
    // animation: open-circle-run 5s steps(79, end)  both;
    .enter{
      margin: 1.4rem 0 0 0;
      font-size: 0.2rem;
      // font-family: "SourceHanSerifCN-Regular";
      font-weight: 500;
      color: #D34F16;
      transition: all 1s;
      cursor: pointer;
      animation:enter-run 1s linear infinite;
      animation-direction: alternate;
    }
  }
  .open_circle_an{
    width:100%;
    height: 100%;
    min-height: 675PX;
    top:-0.5rem;
    background: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/open_circle_an.png");
    background-size: cover;
    animation: open-run 2s steps(49, end)  both ;
    animation-fill-mode: forwards;
    cursor: pointer;

  }
  .open_an2 {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0 ;
    left: 0;
    pointer-events: none;
    // background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/open_an.png");
    background-size: cover;
    // opacity: 0;
    pointer-events: none;
    z-index: 1000;
    // animation: open-circle-run 5s steps(79, end)  both;
  }
  .open_cloud_an{
    width:100%;
    height: 100%;
    min-height: 675PX;
    top: -0.2rem;
    background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/open_cloud_an.png");
    animation: open-run 2s steps(29, end)  both;

  }
  // 登录
  .login{
    position:absolute;
    top: 0.1rem;
    left:0.1rem;
    font-size: 0.11rem;
    font-weight: 400;
    color: #FFDAC1;
    font-family: "SourceHanSerifCN-Regular";
    span{
      cursor: pointer;
    }
  }
  // 左侧新闻
  .newsSider {
    width: 1.75rem;
    height: 3.2rem;
    position: relative;
    display: flex;
    flex-direction: column;
    // margin: 0.14rem 0 0rem 0.05rem;
    margin: 0.14rem 0 0rem -1.75rem;
    background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/newsSider1.png");
    transition: all 0.5s ease;
    .news_title {
      width:0.9rem;
      height: 0.3rem;
      margin: 0.28rem auto 0;
      background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/news_title.png");
      // font-size: 0.19rem;
      // font-family: SourceHanSerifCN-Medium, serif !important;
      // font-weight: bold;
      // color: #ce4313;
      // line-height: 0.3rem;
      // span {
      //   font-size: 0.08rem;
      //   font-weight: bold;
      //   color: #ce5013;
      //   vertical-align: top;

      // }
    }
    .swiper-container-news{
       width: 1.3rem;
       margin: 0.05rem auto 0;
       @include SourceHanFontAll;

      .swiper-slide{
        width:100%;
      }
      ul{
          width: 100%;
          li {
            width: 100%;
            height: 0.62rem;
            text-align: left;
            font-size: 0.08rem;
            //  font-family: SourceHanSerifCN-Medium, serif !important;
            font-weight: 500;
            color: #ce4313;
            cursor: pointer;
            span {
              display: block;
              margin: 0 0 0.05rem 0;
              // font-family: SourceHanSerifCN-Medium, serif !important;
            }
            b {
              width: 98%;
              height: 1PX;
              background-color: #b49985;
              display: block;
            }
            p {
              margin: 0.05rem 0 0 0;
              font-size: 0.09rem;
              font-weight: 300;
              line-height: 0.12rem;
              /* 关键代码 ！！！！ 以下5行 */
              overflow: hidden;
              /* 超出部分设为... */
              text-overflow: ellipsis;
              /* 盒子模型 */
              display: -webkit-box;
              /* 最多2行文本 多余部分隐藏*/
              -webkit-line-clamp: 2;
              /* 从顶部向底部垂直布置子元素 */
              -webkit-box-orient: vertical;
            }
          }
        }
      .swiper-pagination{
         bottom: 0.04rem !important;
        /deep/ span{
          width: 0.03rem;
          height: 0.03rem;
          &.swiper-pagination-bullet-active{
            background-color: #ce4313;
          }
        }
      }
    }

    .news_order_gift {
      width: 0.74rem;
      height: 0.57rem;
      margin: -0.05rem auto 0;
      position: relative;
      background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/news_order_gift.gif");
      background-size: cover;
      cursor: pointer;
    }
    // 控制新闻
    .news_control {
      width: 0.24rem;
      height: 0.91rem;
      position: absolute;
      top: 0.2rem;
      // right: -0.09rem;
      right: -0.3rem;
      background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/news_control.png");
      cursor: pointer;
      text-align: center;
      transition: all 0.2s ease;
      span {
        width: 0.12rem;
        display: block;
        margin: 0.15rem auto 0;
        font-size: 0.11rem;
        @include SourceHanSerifCN-Bold;
        color: #ce4313;
        line-height: 0.15rem;
      }
      &.big{
        width: 0.24rem;
        height: 0.91rem;
        // width: 0.35rem;
        // height: 1.27rem;
        span{
          width:0.13rem;
          margin:0.08rem auto 0;
          font-size: 0.1rem;
          line-height: 0.1rem;
          &:nth-of-type(2){
            margin:-0.02rem auto 0;
          }
          &:nth-of-type(3){
            margin:-0.02rem auto 0;
          }
        }
      }
    }
  }
  .game_order {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, 53%);
    .order_btn {
      width: 1.3rem;
      height: 0.85rem;
      margin: 0 0 0 0.4rem;
      padding: 0.001rem;
      background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/order_btn1.png");
      cursor: pointer;
      span{
        width: 0.4rem;
        line-height: 0.16rem;
        display: block;
        margin:0.26rem 0 0 0.59rem;
        // font-family: "SourceHanSerifCN-Bold";
        @include SourceHanSerifCN-Bold ;
        font-size: 0.15rem;
        font-weight: bold;
        color: #FEEFE0;
      }
    }
    .order_num {
      width: 2.4rem;
      height: 0.56rem;
      margin: -0.1rem 0 0 0;
      font-size: 0.15rem;
      text-align: center;
        @include SourceHanSerifCN-Bold ;

      // font-family: "SourceHanSerifCN-Bold";
      letter-spacing: 0.02rem;
      color: #B33929;
      line-height: 0.52rem;
      background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/order_num1.png");
      span {
        color: #FF3D00;
        font-size: 0.17rem;
        letter-spacing: 0.025rem;
        vertical-align: top;
        font-family: "SourceHanSerifCN-Heavy";
      }
    }
  }
  .game_logo {
    width: 1.5rem;
    height: 0.7rem;
    position: absolute;
    top: 0.1rem;
    right: 0;
    background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/game_logo1.png");
  }

  // 右侧导航栏
  .navbar_right {
    width: 0.6rem;
    height: 3rem;
    // position: absolute;
    // top:0;
    // right: 0;
    // margin: ;
    // background-color: #b49985;
    ul {
      margin: 0 auto;
      li {
        width: 0.17rem;
        height: 0.17rem;
        position: relative;
        margin: 0 auto 0.1rem;
        text-align: center;
        line-height: 0.17rem;
        border-radius: 50%;
        border: 1PX solid #f3bf7a;
        cursor: pointer;
        &:hover {
          .iconfont {
            color: #ffe5c2;
          }
        }
        &.navbar_btn2.play{
          animation: spin 3s linear infinite;
          animation-direction: reverse;
        }
        &.navbar_btn3:hover
        // &.navbar_btn4:hover,
        // &.navbar_btn5:hover,
        // &.navbar_btn6:hover
        {
          div {
            opacity: 1;
            pointer-events: all;
          }
        }
        &.navbar_btn7:hover {
          // &.navbar_btn7 {
          .shareBox {
            margin: -0.05rem 0 0 -0.7rem;
            opacity: 1;
          }
        }
        &:first-child {
          width: 0.3rem;
          height: 0.3rem;
          position: relative;
          // line-height: 0.3rem;
          border: none;
          transition: all 0.3s;
          &:hover {
            transform: scale(1.1);
          }

          > div:nth-child(1) {
            width: 0.15rem;
            height: 0.15rem;
            position: absolute;
            top: 50%;
            left: 50%;
            margin: -0.075rem 0 0 -0.075rem;
            background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/videoBtn_desc1.png");
          }
          > div:nth-child(2) {
            width: 0.25rem;
            height: 0.25rem;
            position: absolute;
            top: 50%;
            left: 50%;
            margin: -0.115rem 0 0 -0.13rem;
            background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/videoBtn_desc2.png");
            animation: spin 4s linear infinite;
          }
          > div:nth-child(3) {
            width: 0.35rem;
            height: 0.35rem;
            position: absolute;
            top: 50%;
            left: 50%;
            margin: -0.165rem 0 0 -0.18rem;
            background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/videoBtn_desc3.png");
            animation: spin 4s linear infinite;
            animation-direction: reverse;
          }
        }
        .iconfont {
          font-size: 0.1rem;
          color: #f3bf7a;
        }
        div {
          position: absolute;
          top: 50%;
          left: 0;
          margin: -0.32rem 0 0 -0.75rem;
          transition: all 0.3s;
        }

        .wechatCode,
        .weiboCode,
        .taptapCode,
        .qqCode {
          width: 0.7rem;
          height: 0.66rem;
          display: flex;
          align-items: center;
          background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/code_bg.png");
          opacity: 0;
          pointer-events: none;

          span {
            width: 0.54rem;
            height: 0.54rem;
            display: block;
            margin: 0 0 0 0.045rem;
            background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/wechat.jpeg");
          }
          b{
            position: absolute;
            bottom: -0.01rem;
            left: 0.16rem;
          }
          &.weiboCode {
            span {
              background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/weibo.png");
            }
          }
          &.taptapCode {
            span {
              background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/tap.png");
            }
          }
          &.qqCode {
            span {
              width: 0.5rem;
              height: 0.5rem;
              margin:-0.06rem 0 0 0.065rem;
              background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/qq.png");
            }
          }
        }
        .shareBox {
          width: 0.7rem;
          display: flex;
          flex-direction: row;
          // margin: -0.05rem 0 0 -0.7rem;
          margin: -0.05rem 0 0 0rem;
          transition: all 0.3s;
          opacity: 0;
          span {
            margin: 0 0.015rem;
            vertical-align: top;
            line-height: 0.13rem;
            border-radius: 50%;
            &:hover {
              i{
                color: #ffe5c2;
              }
            }
            .iconfont {
              font-size: 0.13rem;
              color: #f3bf7a;
            }
          }
          .shareTowx {
            // display: flex;
            // justify-content: center;
            // align-items: center;
            position: relative;
            &:hover {
              canvas {
                opacity: 1;
              }
            }
            canvas {
              width: 0.4rem !important;
              height: 0.4rem !important;
              opacity: 0;
              position: absolute;
              top: 0.2rem;
              left: 50%;
              transform: translateX(-50%);
              transition: all 0.3s;
              pointer-events: none;
            }
          }
        }
      }
    }
  }
  // 弹出框
  .maskBox {
    opacity: 0;
    // opacity: 1;
    pointer-events: none;
    // pointer-events: all;
    transition: all 0.4s;
    z-index: 2;
    &.show_mask {
      // opacity: 0;
      opacity: 1;
      pointer-events: all;
      // pointer-events: none;
    }
    .close_board{
        width: 0.3rem;
        height: 0.3rem;
        display: block;
        position: absolute;
        background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/close.png");
        cursor: pointer;
    }
    .welfare_board {
      width: 5.1rem;
      height: 4.8rem;
      position: relative;
      top:-0.27rem;
      // display: flex;
      // flex-direction: row;
      background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/welfare_board.png");
      .close_board {
        top: -0.16rem;
        right: 0rem;
      }
      // 活动详情
      .activity_detail{
        position: absolute;
        top: 0.15rem;
        right: 0.55rem;
        @include SourceHanFontAll;
        font-size: 0.1rem;
        font-weight: 500;
        color: #CE4313;
        cursor: pointer;
      }
     
      .welfare_title{
        width:2rem;
        height: 0.3rem;
      }
      .welfareBox1{
        .welfare_title{
          margin:0.3rem 0 0 1.7rem;
          background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/welfare_title1.png");
        }
      }
      .welfareBox2{
         .welfare_title{
           margin:0.12rem 0 0 1.7rem;
          background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/welfare_title2.png");
        }
      }
      .welfareBox3{
         .welfare_title{
          margin:0.15rem 0 0 1.7rem;
          background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/welfare_title3.png");
        }
      }
      // 描述 预约后.. 成功邀请.. 我们将..
      .welfare_desc{
        display: block;
        text-align: center;
        width: 3rem;
        font-size: 0.07rem;
        font-family: "SourceHanSerifCN-Regular";
        font-weight: 400;
        color: #D47F69;
        &.welfare_desc1{
          margin: 0 0 0 1.22rem;
        }
        &.welfare_desc2{
          margin: 0.01rem 0 0 1.22rem;
        }
        &.welfare_desc3{
          margin: 0.01rem 0 0 1.22rem;
          line-height: 0.1rem;
        }
      }
      // ul
      .welfare_top,
      .welfare_mid,
      .welfare_btm {
        width: 2.8rem;
        margin: 0.12rem 0 0 1.35rem;
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        &.welfare_mid{
          margin:0.07rem 0 0 1.35rem;
        }
        &.welfare_btm{
          margin: 0.1rem 0 0 1.35rem;
        }
        li {
          width: 0.55rem;
          text-align: center;
          font-family: SourceHanSerifCN-Medium, serif !important;
          font-weight: 500;
          color: #bb3f14;
          .welfare {
            width: 100%;
            height: 0.35rem;
            margin: 0 auto 0.02rem;
            display: flex;
            justify-content: center;
            align-items: center;
            // margin:0 0 0.1rem 0;
            // background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/welfare_bg.png");
            
            // img {
            //   width: auto;
            //   height: 0.3rem;
            //   display: block;
            // }
          }
          span {
            width:1rem;
            display: inline-block;
            margin:0 0 0 -0.23rem ;
            font-size: 0.065rem;
            line-height: 0.1rem;
          }
        }
      }
      ul:nth-of-type(2){
        li{
          width:0.7rem;
          display: flex;
          flex-direction: column;
          align-items: center;
          position:relative;
          span{
            width:1.1rem;
            display:block;
          }
        }
      }
      .progressBox_desc2,
      .progressBox_desc3 {
        width: 2.8rem;
        display: flex;
        flex-direction: column;
        margin: 0.09rem 0 0 1.36rem;
        
        .progress_milepost {
          display: flex;
          justify-content: space-around;
          margin: 0 0 0.07rem 0;
          span {
            font-size: 0.08rem;
            font-weight: bold;
            color: #cc341a;
            line-height: 0.12rem;
            // @include SourceHanSerifCN-Bold ;
           
          }
        }
        .progress_bg {
          width: 100%;
          height: 0.025rem;
          position: relative;
          background-color: #ffdfb8;
          border-radius: 0.02rem;
          div {
            width: 10%;
            height: 100%;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            position: absolute;
            top: 0;
            left: 0;
            background-color: #dd582c;
            border-radius: 0.02rem;

            .fly {
              width: 0.15rem;
              height: 0.15rem;
              display: block;
              position: absolute;
              bottom: -86%;
              // right: -6%;
              right:-0.065rem;
              background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/fly.png");
            }
          }
        }
      }
      // 邀请好友按钮
      .invite_btn{
        width: 0.9rem;
        height: 0.2rem;
        margin:-0.06rem 0 0 2.35rem;
        background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/invite_btn.png");
        cursor: pointer;
      }
      .invite_sum{
        width: 3rem;
        text-align: center;
        font-size: 0.1rem;
        font-weight: 400;
        color: #BB3F14;
        margin: 0.06rem 0 0 1.3rem;
        letter-spacing: 0.01rem;

      }
      .welfare_btm {
        margin: 0.15rem 0 0 1.22rem;
      }
    }
    .order_board {
      width: 4rem;
      height: 2.35rem;
      position: relative;
      top:-0.3rem;
      // display: flex;
      // flex-direction: row;
      display: flex;
      justify-content: center;
      align-items: center;
      background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/order_board3.png");
      &.order{
        background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/order_board2.png");
      }
      .close_board {
        top: -0.25rem;
        right: -0.02rem;
      }
      .form {
        width: 2rem;
        margin: -0.2rem 0 0 0.25rem;
        text-align: center;
        .radioGroup {
          width: 75%;
          display: flex;
          justify-content: space-around;
          margin: 0 auto 0.15rem;
          .radio {
            display: flex;
            // flex-direction: row;
            // justify-content: center;
            align-items: center;
            cursor: pointer;
            &.choose {
              span {
                opacity: 1;
              }
            }
            div {
              width: 0.08rem;
              height: 0.08rem;
              margin: 0 0.05rem 0 0;
              // display: flex;
              // justify-content: center;
              // align-items: center;
              position: relative;
              border: 0.01rem solid #be3d36;
              border-radius: 50%;

              span {
                width: 0.05rem;
                height: 0.05rem;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%,-50%);
                background-color: #be3d36;
                border-radius: 50%;
                opacity: 0;
              }
            }
            span{
                font-size: 0.1rem;
            }
          }
        }
        .input {
          width: 1.5rem;
          height: 0.18rem;
          line-height: 0.18rem;
          padding: 0 0.1rem;
          border: 0.001rem solid #be3d36;
          color: #cfa6a1;
          font-size: 0.07rem;
          &::-webkit-input-placeholder {
            /* WebKit browsers */
            color: #cfa6a1;
          }
          &:-moz-placeholder {
            /* Mozilla Firefox 4 to 18 */
            color: #cfa6a1;
          }
          &::-moz-placeholder {
            /* Mozilla Firefox 19+ */
            color: #cfa6a1;
          }
          &:-ms-input-placeholder {
            /* Internet Explorer 10+ */
            color: #cfa6a1;
          }
        }
        .codeGroup {
          width: 1.5rem;
          display: flex;
          flex-direction: row;
          margin: 0.1rem auto 0;
          .phoneCode {
            width: 1rem;
            border-right: none;
          }
          .getCode {
            width: 0.5rem;
            height: 0.18rem;
            line-height: 0.18rem;
            font-size: 0.07rem;
            text-align: center;
            color: #fff;
            background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/phone_code.png");
            cursor: pointer;
          }
        }
        .inviteCode{
          margin:0.1rem 0 0 0;
        }
        .order_check {
          width: 1rem;
          height: 0.23rem;
          line-height: 0.23rem;
          margin: 0.15rem auto 0;
          font-size: 0.1rem;
          letter-spacing: 0.02rem;
          font-family: SourceHanSerifCN-Medium, serif !important;
          font-weight: bold;
          color: #784848;
          background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/order_check.png");
          cursor: pointer;
        }
      }
      .ordered{
        width:2rem;
        height: 1rem;
        margin: 0.1rem 0 0 0.3rem;
        // background-color: #bb3f14;
        @include SourceHanFontAll;
        font-size: 0.17rem;
        // color: #D47F69;
        color: #bb3f14;

        div{
          margin:0 0 0.18rem 0.45rem;
        }
        span{
          width: 0.9rem;
          height: 0.22rem;
          display: block;
          margin:0 auto;
          background-image:url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/changeNum.png");
          cursor: pointer;
        }
      }
    }
    .propagate_board{
      width:60%;
      position:relative;
      top:-0.3rem;

      .propagate{
        position: relative;
        width: 100%;
      }
      .close_board {
        top: -0.3rem;
        right: -0.2rem;
      }
    }
    .detail_board{
      width: 6rem;
      height: 3.5rem;
      top:-0.3rem;
      position:relative;
      background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/detail_board.png");
      .close_board {
        top: -0.25rem;
        right: -0.1rem;
      }
      .container{
        width: 3.45rem;
        margin: 0.8rem 0 0 1.8rem;
        line-height: 0.14rem;
        color: #CF3E0C;
        letter-spacing: 0.01rem;
        .detail{
          &:first-of-type{
            margin-bottom: 0.1rem;
          }
          &:last-of-type{
            margin-top: 0.1rem;
          }
          b{
            display: block;
            font-size: 0.1rem;
            @include SourceHanSerifCN-Bold ;
            
          }
          span{
            font-size:0.08rem;
                  
          }
        }
      }
    }
    .share_board{
      width: 5rem;
      height: 2.9rem;
      top:-0.3rem;
      position:relative;
      background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/share_board1.png");
      text-align: center;
      .close_board {
        top: -0.3rem;
        right: -0.2rem;
      }
      .container{
        width:3rem;
        margin:0.45rem 0 0 1.35rem;
        .myInviteNum{
          font-size:0.14rem;
          color:#CE4313;
          @include SourceHanSerifCN-Bold ;
          span{
            cursor: pointer;
          }
        }
        .way1{
          // 标题
          span{
            display: block;
            margin: 0.16rem 0 0 0.4rem;
            color: #CF3E0C;
            font-size: 0.1rem;
            text-align: left;
            @include SourceHanSerifCN-Bold ;
            &:last-of-type{
              font-size: 0.08rem;
              margin: 0.1rem 0 0 0.4rem;
              font-family: "SourceHanSerifCN-Regular";

            }
          }
          .website{
            display: flex;
            margin:0.2rem 0 0 0.16rem;
            div{
              width: 2rem;
              height: 0.218rem;
              padding-left: 0.1rem;
              line-height:0.2rem;
              text-align: left;
              font-family: "SourceHanSerifCN-Regular";
              font-size: 0.08rem;
              font-weight: 400;
              color: #CFA6A1;
              background-color: #fff;
              border:1PX solid #BE3D36;
              overflow:hidden;
            }
            span{
              width: 0.6rem;
              height: 0.23rem;
              display: block;
              text-align: center;
              margin: -0.005rem 0 0 -0.01rem;
              line-height: 0.21rem;
              color:#fff;
              background-image: url("https://wcdn.tomatogames.com/static/TangMistyRain/appoint/pc/phone_code.png");
              cursor: pointer;
            }
          }
        }
        .way2{
          // 标题
          span{
            display: block;
            margin: 0.15rem 0 0 0.4rem;
            color: #CF3E0C;
            font-size: 0.1rem;
            text-align: left;
            @include SourceHanSerifCN-Bold ;
            
          }
          div{
           width: 0.82rem;
           height: 0.82rem;
           margin:0.13rem 0 0 1rem;
           background-color: #fff;
           border: 1PX solid #C8430D;
           .shareCode{
             width:0.8rem !important;
             height: 0.8rem !important;
             margin: auto;
           }
          }
        }
      }
    }

  }
}
@keyframes spin {
  to {
    transform: rotate(1turn);
  }
}
@keyframes open-run {
  0%{
    background-position:0% 0%;

  }
  100%{
    background-position:100% 0;

  }


}
@keyframes open-run1 {
  0%{
    background-position:0% 0%;

  }
  100%{
    background-position:61% 0;

  }


}
@keyframes enter-run {
  0%{
    transform: scale(1);
  }
  100%{
    transform: scale(1.1);
  }
}
</style>
