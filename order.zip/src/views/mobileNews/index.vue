<template>
  <div class="news-wrapper" v-cloak>
    <div class="news-bg">
      <div class="logo" @click="$router.push('/mobile')"></div>
    </div>
    <div class="news-main">
      <div class="news-top">
        <div class="arrow" @click="$router.push('/mobile')">
          <i class="iconfont icon-left"></i>
        </div>
        <h1 class="title">{{ newsInfo.title }}</h1>
        <span class="date">{{ newsInfo.start_time.slice(0, 10) }}</span>
      </div>
      <div class="news-content" v-html="newsInfo.content"></div>
      <div class="page">
        <span @click="prePage">上一篇</span>
        <span @click="nextPage">下一篇</span>
      </div>
    </div>
  </div>
</template>

<script>
import { getNewsInfo } from "@/api/news";

export default {
  name: "index",
  data() {
    return {
      newsInfo: {
        title: "",
        start_time: "",
        content: "",
      },
      beforeNewsId: null,
      afterNewsId: null,
    };
  },
  created() {
    this.getNewsInfo();
  },
  methods: {
    getNewsInfo() {
      const { id } = this.$route.params;
      this.$toast.loading({
        message: "加载中...",
        forbidClick: true,
      });
      const time = Date.now();
      const type = "1";
      const params = { time, id, type };
      const headers = { time };
      getNewsInfo(params, headers).then((res) => {
        this.$toast.clear();
        if (res.status == 1) {
          const {before, after, data} = res.data;
          this.newsInfo = data;
          this.beforeNewsId = before.id ? before.id : null;
          this.afterNewsId = after.id ? after.id : null;
        }
      });
    },
    prePage() {
      const {beforeNewsId} = this;
      console.log(beforeNewsId);
      if (!beforeNewsId) {
        this.$toast("已经是最新一篇了");
        return;
      }
      this.$router.replace(`/mobileNews/${beforeNewsId}`);
    },
    nextPage() {
      const {afterNewsId} = this;
      console.log(afterNewsId);
      if (!afterNewsId) {
        this.$toast("已经是最后一篇了");
        return;
      }
      this.$router.replace(`/mobileNews/${afterNewsId}`);
    },
  },
  watch: {
    '$route.path'(newVal) {
      this.getNewsInfo();
    },
  }
};
</script>

<style lang="scss" scoped>
@import "./index";
</style>
