<template>
  <div class="app-wrapper">
    <!--背景图片-->
    <img src="https://wcdn.tomatogames.com/static/TangMistyRain/appoint/mobile/poster.jpg" class="bg-img" alt="">
    <!--背景视频-->
    <video
      v-if="!isShowBgVideo"
      ref="bgVideo"
      class="bg-video"
      src="https://wcdn.tomatogames.com/static/TangMistyRain/appoint/mobile/bg_video.mp4?q=111"
      loop="loop"
      autoplay="autoplay"
      muted="muted"
      preload="auto"
      playsinline="true"
      webkit-playsinline="true"
      x-webkit-airplay="true"
      x5-video-player-type="h5-page"
      x5-video-player-fullscreen=""
      x5-video-orientation="portraint"
    ></video>
    <!--顶部-->
    <div class="top">
      <audio
        loop
        autoplay
        ref="music"
        src="https://wcdn.tomatogames.com/static/TangMistyRain/appoint/login_page.mp3"
        style="display: none"
      ></audio>
      <div class="logo"></div>
      <ul class="menu-list">
        <li
          class="menu-item music"
          :class="[music ? 'turn' : '']"
          @click="music = !music"
        >
          <i class="iconfont icon-music"></i>
        </li>
        <li class="menu-item" @click="showWechatImg">
          <i class="iconfont icon-weixin"></i>
        </li>
        <li class="menu-item" v-for="(item, index) in menus" :key="index">
          <i
            class="iconfont"
            :class="[`icon-${item.name}`]"
            @click="jumpLink(item.url, item.name)"
          ></i>
        </li>
      </ul>
      <div class="login">
        <span v-if="phone" @click="onReserve(true, '登录')">{{phone}}【切换账号】</span>
        <span v-else @click="onReserve(false, '登录')">欢迎您！请【登录】</span>
      </div>
    </div>
    <!--新闻盒子-->
    <div class="news-wrapper">
      <div class="news-box" ref="newsBox">
        <div class="news-title"></div>
        <div class="news-list">
          <swiper class="swiper-container" :options="swiperOptions">
            <swiper-slide>
              <div class="news-item"
                   :class="[index === 0 ? 'first' : '']"
                   v-for="(item, index) in newsList.slice(0, 3)"
                   :key="index"
                   @click="onSeeNewsInfo(item.id)">
                <p class="title">{{ item.start_time }}</p>
                <p class="content">{{ item.title }}</p>
              </div>
            </swiper-slide>
            <swiper-slide v-if="newsList.length > 3">
              <div class="news-item"
                   :class="[index === 0 ? 'first' : '']"
                   v-for="(item, index) in newsList.slice(3, 6)"
                   :key="index"
                   @click="onSeeNewsInfo(item.id)">
                <p class="title">{{ item.start_time }}</p>
                <p class="content">{{ item.title }}</p>
              </div>
            </swiper-slide>
            <swiper-slide v-if="newsList.length > 6">
              <div class="news-item"
                   :class="[index === 0 ? 'first' : '']"
                   v-for="(item, index) in newsList.slice(6, 9)"
                   :key="index"
                   @click="onSeeNewsInfo(item.id)">
                <p class="title">{{ item.start_time }}</p>
                <p class="content">{{ item.title }}</p>
              </div>
            </swiper-slide>
            <div class="swiper-pagination" slot="pagination"></div>
          </swiper>
        </div>
        <div class="gift-pack" @click="modal2Visible = true">
          <img src="https://wcdn.tomatogames.com/static/TangMistyRain/appoint/mobile/giftPack.gif" alt="">
        </div>
      </div>
      <div class="news-action" @click="handleAction" ref="newsAction">
        <div class="news-action-inner">
          <p>{{ show ? "收起" : "新闻·福利" }}</p>
        </div>
      </div>
    </div>
    <!--底部-->
    <div class="footer">
      <div class="video-btn" @click="videoVisible = true">
        <div class="big-circle"></div>
        <div class="small-circle"></div>
      </div>
      <div class="game-reserve" @click="onReserve(false, '游戏预约')">
        <p>{{phone ? "您已预约" : "游戏预约"}}</p>
      </div>
      <div class="reserve-num">
        <p>
          已预约
          <span>{{ reserveNum }}</span
          >人
        </p>
      </div>
    </div>
    <!--版权信息-->
    <div class="copyright">◆爱的番茄游戏版权所有©2021</div>
    <!--预约弹框-->
    <reserve-modal :visible.sync="modal1Visible" :isReserve.sync="isReserve" :reserveType="reserveType" @onReserveSuccess="handleReserveSuccess" />
    <!--预约奖励弹框-->
    <reserve-welfare-modal
      :visible.sync="modal2Visible"
      :reserve-num="reserveNum"
      @onSeeActivityDetail="modal3Visible = true"
      @onInviteFriends="modal4Visible = true"
    />
    <!--活动详情弹框-->
    <activity-detail-modal :visible.sync="modal3Visible"/>
    <!--邀请好友弹框-->
    <invite-friends-modal :visible.sync="modal4Visible"/>
    <!--微信公众号图片弹框-->
    <van-popup v-model="wechatVisible">
      <p class="tips">关注《盛唐烟雨》微信公众号</p>
      <img
        src="https://wcdn.tomatogames.com/web/guonei/tang-misty-rain/community/wechat.jpeg"
        alt=""
      />
    </van-popup>
    <!--视频弹框-->
    <van-popup
      v-model="videoVisible"
      @open="handleVideoOpen"
      @close="handleVideoClose"
    >
      <video
        src="https://wcdn.tomatogames.com/static/TangMistyRain/appoint/video.mp4"
        controls
        preload="auto"
        ref="video"
        style="width: 10rem"
      ></video>
    </van-popup>
  </div>
</template>

<script>
import ReserveModal from "@/components/ReserveModal/index"; // 预约弹框
import ReserveWelfareModal from "@/components/ReserveWelfareModal/index"; // 预约奖励弹框
import ActivityDetailModal from "@/components/ActivityDetailModal/index"; // 活动详情弹框
import InviteFriendsModal from "@/components/InviteFriendsModal/index"; // 邀请好友弹框
import { getAppointNum } from "@/api";
import { getNewsList } from "@/api/news";
import clickLog from "@/api/clickLog";
import { Swiper, SwiperSlide } from "vue-awesome-swiper";
import "swiper/dist/css/swiper.min.css";

export default {
  // 移动端
  name: "index",
  components: { ReserveModal, ReserveWelfareModal, ActivityDetailModal, InviteFriendsModal, Swiper, SwiperSlide },
  data() {
    const logType = {
      enterPage: 1, // 进入首页
      onReserve: 3, // 预约
      weixin: 4, // 点击微信
      qq: 5, // 点击Q群
      weibo: 6, // 点击微博
      taptap: 7, // 点击taptap
    };
    return {
      phone: "", // 预约的手机号
      modal1Visible: false, // 预约弹框控制显示隐藏
      modal2Visible: false, // 预约好礼弹框控制显示隐藏
      modal3Visible: false, // 活动详情弹框控制显示隐藏
      modal4Visible: false, // 邀请好友弹框控制显示隐藏
      wechatVisible: false, // 显示隐藏微信公众号图片
      videoVisible: false, // 显示隐藏视频
      text: "收起", // 新闻框漂浮文本
      reserveNum: 0, // 预约数
      show: true,
      newsList: [], // 新闻列表
      menus: [
        {
          name: "weibo",
          url: "https://weibo.com/styy1",
        },
        {
          name: "taptap",
          url: "https://www.taptap.com/app/205540",
        },
        {
          name: "qq",
          url: "https://jq.qq.com/?_wv=1027&k=VDOcshJU",
        },
      ],
      logType, // 埋点类型
      music: true, // 是否播放背景音乐
      isMusicPlay: false, // 打开视频前背景音乐是否在播放
      isShowBgVideo: false, // 是否显示背景视频
      isReserve: false, // 是否预约
      swiperOptions: {
        slidesPerView: "auto",
        resizeObserver: true,
        pagination: {
          el: ".swiper-pagination"
        },
      },
      reserveType: "登录",
    };
  },
  created() {
    this.init();
  },
  mounted() {
    const { bgVideo, music } = this.$refs;
    music.volume = 0.2;
    if (window.WeixinJSBridge) {
      window.WeixinJSBridge.invoke(
        "getNetworkType",
        {},
        () => {
          bgVideo.play();
        },
        false
      );
      document.addEventListener("touchstart", () => {
        bgVideo.play();
      });
    } else {
      document.addEventListener(
        "WeixinJSBridgeReady",
        () => {
          window.WeixinJSBridge.invoke("getNetworkType", {}, () => {
            bgVideo.play();
          });
        },
        false
      );
      document.addEventListener("touchstart", () => {
        bgVideo.play();
      });
    }
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        this.isMusicPlay = this.music;
        this.music = false;
      } else {
        this.music = this.isMusicPlay;
      }
    });
  },
  filters: {
    omit(str) {
      return str.length < 19 ? str : str.slice(0, 18) + "...";
    },
  },
  methods: {
    // 初始化
    init() {
      this.pageLog("enterPage");
      this.handleCheckReserve();
      this.getReserveNum();
      this.getNewsList();
      this.handleSpecialBrowser();
    },
    // 判断是否已预约
    handleCheckReserve() {
      const {phone} = JSON.parse(localStorage.getItem("userinfo")) || {};
      if (phone) {
        this.phone = phone;
      }
    },
    // 页面埋点
    async pageLog(name) {
      const type = this.logType[name];
      const params = { type };
      await clickLog(params);
    },
    // 新闻框收起和打开
    handleAction() {
      this.show = !this.show;
      const newsAction = this.$refs.newsAction;
      const newsBox = this.$refs.newsBox;
      if (this.show) {
        newsAction.setAttribute("class", "news-action expand");
        newsBox.setAttribute("class", "news-box show");
      } else {
        newsAction.setAttribute("class", "news-action pack-up");
        newsBox.setAttribute("class", "news-box hide");
      }
    },
    // 获取预约人数
    getReserveNum() {
      const time = Date.now();
      getAppointNum({ time }, { time }).then((res) => {
        if (res.status === 1) {
          this.reserveNum = Number(res.data);
        }
      });
    },
    // 获取新闻列表
    getNewsList() {
      const time = Date.now();
      const type = "1";
      const current_page = 1;
      const params = { time, type, current_page };
      const headers = { time };
      getNewsList(params, headers).then((res) => {
        if (res.status == 1) {
          const newsList = res.data.data;
          this.newsList = newsList;
        }
      });
    },
    // 预约弹框
    onReserve(flag = false, reserveType) {
      this.reserveType = reserveType;
      if (flag) {
        this.phone = "";
      }
      this.modal1Visible = true;
      this.isReserve = !!this.phone;
      this.pageLog("onReserve");
    },
    // 查看新闻详情
    onSeeNewsInfo(id) {
      console.log(id);
      this.$router.push(`/mobileNews/${id}`);
    },
    // 显示微信公众号图片
    showWechatImg() {
      this.wechatVisible = true;
      this.pageLog("weixin");
    },
    // 跳转链接
    jumpLink(url, name) {
      this.pageLog(name);
      window.open(url);
    },
    handleReserveSuccess(phone) {
      this.phone = phone;
      this.getReserveNum();
      this.reserveText = "您已预约";
    },
    // 关闭背景音乐
    handleMusicPlay() {
      this.music ? this.$refs.music.play() : this.$refs.music.pause();
    },
    // 视频弹框打开
    handleVideoOpen() {
      this.isMusicPlay = this.music;
      this.music = false;
      this.videoVisible = true;
      this.$nextTick(() => {
        const {video} = this.$refs;
        video.volume = 0.2;
        video.play();
      });
    },
    // 视频弹框关闭
    handleVideoClose() {
      this.videoVisible = false;
      this.$refs.video.pause();
      this.music = this.isMusicPlay;
    },
    // 处理浏览器背景视频播放异常的情况
    handleSpecialBrowser() {
      const blackList = ["miuibrowser", "qqbrowser", "baidu"]; // 黑名单
      const userAgent = navigator.userAgent.toLowerCase();
      this.isShowBgVideo = blackList.some((item) => userAgent.includes(item));
    },
    // 查看活动详情
    onSeeActivityDetail() {
      this.modal3Visible = true;
      this.modal2Visible = false;
    },
  },
  watch: {
    music() {
      this.handleMusicPlay();
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./index";
</style>
