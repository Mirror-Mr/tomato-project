<!--
 * @Author: your name
 * @Date: 2021-07-19 15:33:50
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \vue-testc:\Users\leishan\Desktop\web\inland\Games\TangMistyRain\Activity\order\src\App.vue
-->
<template>
  <div id="app" :style="[{ minWidth: !isDeviceMobile() ? '1200PX' : 0 }]">
    <router-view />
  </div>
</template>
<script>
export default {
  methods: {
    isDeviceMobile() {
      var u = navigator.userAgent;
      var isAndroid = u.indexOf("Android") > -1 || u.indexOf("Adr") > -1; //android终端
      var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
      if (isiOS || isAndroid) {
        return true;
      } else {
        return false;
      }
    },
  },
  mounted() {
    sessionStorage.setItem("isDeviceMobile", this.isDeviceMobile());
  },
  watch: {
    $route(newVal) {
      // console.log(newVal);
      if (newVal.path === "/pc") {
        if (this.isDeviceMobile()) {
          if (newVal.query.code) {
            this.$router.replace(`/mobile?code=${newVal.query.code}`);
          } else {
            this.$router.replace("/mobile");
          }
        }
      }
      if (newVal.path.includes("pcNews")) {
        const { id } = this.$route.params;
        if (this.isDeviceMobile()) {
          this.$router.replace(`/mobileNews/${id}`);
        }
      }
      if (newVal.path === "/mobile") {
        if (!this.isDeviceMobile()) {
          this.$router.replace("/pc");
        }
      }
      if (newVal.path.includes("mobileNews")) {
        const { id } = this.$route.params;
        if (!this.isDeviceMobile()) {
          this.$router.replace(`/pcNews/${id}`);
        }
      }
    },
  },
};
</script>
<style lang="scss"></style>
