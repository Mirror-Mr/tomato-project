import { post, get } from "@/utils/request";

const baseUrl = "/activity/Styy_appoint";

// 预约
export function appoint(params, headers) {
  return post(baseUrl+"/appoint", params, headers);
}

// 获取预约数
export function getAppointNum(params, headers) {
  return get(baseUrl+"/getAppointNum", params, headers);
}

// 获取邀请人数
export function getVisitNum(params, headers) {
  return get(baseUrl+"/get_visit_num", params, headers);
}
