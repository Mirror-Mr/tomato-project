import { get } from "@/utils/request";

const baseUrl = "/webhome/styy";

export function getNewsList(params, headers) {
  return get(baseUrl + "/news_list", params, headers);
}

export function getNewsInfo(params, headers) {
  return get(baseUrl + "/getNewsInfo", params, headers);
}
