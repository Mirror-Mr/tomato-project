/*
 * @Author: your name
 * @Date: 2021-07-19 15:33:50
 * @LastEditTime: 2021-07-30 16:09:43
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \vue-testc:\Users\leishan\Desktop\web\inland\Games\TangMistyRain\Activity\order\src\router\index.js
 */
import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

const originalReplace = VueRouter.prototype.replace;
VueRouter.prototype.replace = function replace(location) {
  return originalReplace.call(this, location).catch((err) => err);
};

const routes = [
  {
    path:"/",
    redirect:"/pc"
  },
  {
    path: "/mobile",
    component: () => import("@/views/mobile/index"),
  },
  {
    path: "/mobileNews/:id",
    name: "MobileNews",
    component: () => import("@/views/mobileNews/index"),
  },
  {
    path:"/pc",
    name:"pcIndex",
    component:()=> import("@/views/pc/index.vue")
  },
  {
    path:"/pcNews/:id",
    name:"pcNewsPage",
    component:() => import("../views/pc/NewsPage.vue")
  }
];

const router = new VueRouter({
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition;
    } else {
      return { x: 0, y: 0 };
    }
  },
});


export default router;
