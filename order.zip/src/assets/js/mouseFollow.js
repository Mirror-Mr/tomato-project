/*
 * @Author: your name
 * @Date: 2021-07-23 15:02:26
 * @LastEditTime: 2021-08-03 11:30:08
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \vue-testc:\Users\leishan\Desktop\web\inland\Games\TangMistyRain\Activity\order\src\assets\js\mouseFollow.js
 */

function mouseFoolow() {
  let mouse = {
    x: undefined,
    y: undefined,
  };
  let circleArray = [];
  let frame = 0;
  let colorArray = [
    "250,205,137",
    "250,205,137",
    "250,205,137",
    "250,205,137",
  ];
  let c = null;
  // 记录前一个点的x
  let beforeX = null;
  // 记录前一个点的y
  let beforeY = null;

  function Circle(x, y, radius, vx, vy, rgb, opacity, birth, life) {
    this.x = x;
    this.y = y;
    this.radius = radius;
    this.minRadius = radius;
    this.vx = vx;
    this.vy = vy;
    this.birth = birth;
    this.life = life;
    this.opacity = opacity;

    this.draw = function () {
      c.beginPath();
      c.arc(this.x, this.y, this.radius, Math.PI * 1, false);
      c.fillStyle = "rgba(" + rgb + "," + this.opacity + ")";
      c.fill();
    };

    this.update = function () {
      if (this.x + this.radius > innerWidth || this.x - this.radius < 0) {
        this.vx = -this.vx;
      }

      if (this.y + this.radius > innerHeight || this.y - this.radius < 0) {
        this.vy = -this.vy;
      }

      this.x += this.vx;
      this.y += this.vy;

      this.opacity = 1 - ((frame - this.birth) * 1) / this.life;

      if (frame > this.birth + this.life) {
        for (let i = 0; i < circleArray.length; i++) {
          if (
            this.birth == circleArray[i].birth &&
            this.life == circleArray[i].life
          ) {
            circleArray.splice(i, 1);
            break;
          }
        }
      } else {
        this.draw();
      }
    };
  }

  function initCanvas() {
    circleArray = [];
  }

  function drawCircles() {
    for (let i = 0; i < 40; i++) {
      let radius = Math.floor(Math.random()) + 1;
      let vx = Math.random() * 1;
      let vy = Math.random() * 1;
      let spawnFrame = frame;
      let rgb = colorArray[Math.floor(Math.random() * colorArray.length)];
      // 跟随尾部有多长
      let life = 100;
      circleArray.push(
        new Circle(mouse.x, mouse.y, radius, vx, vy, rgb, 1, spawnFrame, life)
      );
    }
  }
  function animate() {
    requestAnimationFrame(animate);
    frame = 1;
    c.clearRect(0, 0, innerWidth, innerHeight);
    for (let i = 0; i < circleArray.length; i++) {
      circleArray[i].update();
    }
  }
  function init(canvas) {
    let stage = document.getElementsByClassName("stage")[0];
    

    setTimeout(() => {
      canvas.height = stage.offsetHeight;
      canvas.width = stage.offsetWidth;
    }, 1000);

    c = canvas.getContext("2d");
    // 监听stage大小的改变
    window.addEventListener("resize", function () {
      setTimeout(() => {
        canvas.height = stage.offsetHeight;
        canvas.width = stage.offsetWidth;
      }, 1000);

      initCanvas();
    });
    window.addEventListener("mousemove", function (event) {
      
      // console.log(event.pageX,event.pageY)
      // if (beforeX) {
      //   let tempX = beforeX - event.pageX;
      //   let tempY = beforeY - event.pageY;
      //   // event.pageX 相对于文档的X坐标
      //   if (Math.abs(tempX) > 5 || Math.abs(tempY) > 5) {
      //     // 会产生间距
      //     for (let i = 0; i <= 3; i++) {
      //       mouse.x = beforeX + (tempX / 5) * i;
      //       mouse.y = beforeY + (tempY / 5) * i;
      //       // console.log(mouse.x,mouse.y)
      //       drawCircles();
      //     }
      //   } else {
      //     mouse.x = event.pageX;
      //     mouse.y = event.pageY;
      //     drawCircles();
      //   }
      // } else {
        mouse.x = event.pageX;
        mouse.y = event.pageY;
        drawCircles();
      // }
      // beforeX = event.pageX;
      // beforeY = event.pageY;
    },100);
    window.addEventListener("touchmove", function (event) {
      let touch = event.touches[0];
      mouse.x = touch.clientX;
      mouse.y = touch.clientY;
      drawCircles();
    }, 1);
    initCanvas();
    animate();
  }

  return init;
}

export default mouseFoolow;
