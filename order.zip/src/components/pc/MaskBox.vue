<!--
 * @Author: your name
 * @Date: 2021-07-20 16:37:49
 * @LastEditTime: 2021-07-30 17:27:19
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \vue-testc:\Users\leishan\Desktop\web\inland\Games\TangMistyRain\Activity\order\src\components\pc\Mask.vue
-->
<template>
  <div class="maskbox">
    <slot/>
  </div>
</template>

<script>
export default {
  name: "MaskBox",
};
</script>

<style lang="scss" scoped>
.maskbox {
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0,0,0,  0.6);
}
</style>
