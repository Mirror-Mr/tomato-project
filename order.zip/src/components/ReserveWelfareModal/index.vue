<template>
  <transition name="fade">
    <div class="modal-wrapper" v-show="visible">
      <div class="modal-mask" @click="onClose"></div>
      <div class="modal-main" @click.self="handleClick($event)">
        <div class="modal-box">
          <p class="activity-detail" @click="handleSeeActivityDetail">[活动详情]</p>
          <div class="modal-content">
            <!--预约礼-->
            <div class="reserve-gift-wrapper wrapper">
              <div class="title"></div>
              <div class="rules">预约后即可获得奖励，领取方式见活动详情</div>
              <div class="props-wrapper">
                <ul class="props-list">
                  <li class="props-item" v-for="(item, index) in reserveProps" :key="index">
                    <img :src="`${baseUrl}${index + 1}.png?q=1`" alt=""/>
                    <p class="name">{{ item }}</p>
                  </li>
                </ul>
              </div>
            </div>
            <!--邀约礼-->
            <div class="invite-gift-wrapper wrapper">
              <div class="title"></div>
              <div class="rules">
                <p>成功邀请1/2/3位好友预约，邀请人将获得额外好礼。</p>
                <p>领取方式见活动详情</p>
              </div>
            </div>
            <div class="progress-wrapper">
              <div class="reserve-progress">
                <div class="progress-num invite-num">
                  <p>邀请1人奖励</p>
                  <p>邀请2人奖励</p>
                  <p>邀请3人奖励</p>
                </div>
                <div class="progress-bar-bg">
                  <div class="progress-bar" :style="{width: `${inviteProgressBarWidth}rem`}"></div>
                  <div class="butterfly" :style="{left: `${inviteProgressBarWidth - 0.146}rem`}"></div>
                </div>
              </div>
              <div class="props-wrapper">
                <ul class="props-list">
                  <li class="props-item" :class="inviteProgress(index)" v-for="(item, index) in inviteProps"
                      :key="index">
                    <img :src="`${baseUrl}${index + 5}.png?q=1`" alt=""/>
                    <div class="name">
                      <p v-for="(item1, index1) in item" :key="index1">{{ item1 }}</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <div class="invite-friends" @click="handleInviteFriends">邀请好友</div>
            <p class="tips">{{ tipsText }}</p>
            <!--集结礼-->
            <div class="assemble-title-wrapper wrapper">
              <div class="title"></div>
              <div class="rules">
                <p>我们将根据官网总预约量里程碑达成，发放以下奖励</p>
                <p>领取方式见活动详情</p>
              </div>
            </div>
            <div class="progress-wrapper wrapper2">
              <div class="reserve-progress">
                <div class="progress-num">
                  <p>10W</p>
                  <p>20W</p>
                  <p>50W</p>
                  <p>80W</p>
                  <p>100W</p>
                </div>
                <div class="progress-bar-bg">
                  <div class="progress-bar" :style="{width: `${assembleProgressBarWidth}rem`}"></div>
                  <div class="butterfly" :style="{left: `${assembleProgressBarWidth - 0.146}rem`}"></div>
                </div>
              </div>
              <div class="props-wrapper">
                <ul class="props-list">
                  <li class="props-item small" :class="assembleProgress(index)" v-for="(item, index) in assembleProps" :key="index">
                    <img :src="`${baseUrl}${index + 8}.png?q=1`" alt=""/>
                    <div class="name">
                      <p v-for="(item1, index1) in item" :key="index1">{{ item1 }}</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="modal-close" @click="onClose"></div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
import {getVisitNum} from "@/api";

export default {
  name: "index",
  props: {
    visible: {
      type: Boolean,
      default: () => false,
    },
    reserveNum: {
      type: Number,
      default: () => 0,
    },
  },
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/TangMistyRain/appoint/mobile/welfare/",
      reserveProps: Object.freeze(["商店刷新券*5", "许愿币*1", "初等经验丹*10", "银两*10W",]),
      inviteProps: Object.freeze([["中级经验丹*10", "专属聊天气泡"],["元宝*50", "升星石*20"],["专属时装-丝路云歌头饰", "稀有卡牌碎片包*20", "许愿币*2"],]),
      assembleProps: Object.freeze([
        ["初级经验丹*10"],
        ["升星石*20"],
        ["点击特效-浮花", "银两*5W"],
        ["头像框-玉翎寒梅", "元宝*88"],
        ["许愿币*2", "元宝*188"],
      ]),
      inviteNum: 0,
      tipsText: "请您先预约",
      timer: null,
    };
  },
  created() {
    this.getInviteNum();
  },
  mounted() {
    this.$bus.$on("reserved", () => {
      this.getInviteNum();
    })
  },
  beforeDestroy() {
    clearTimeout(this.timer);
  },
  computed: {
    // 邀请进度
    inviteProgress() {
      const {inviteNum} = this;
      return (index) => {
        return inviteNum > index ? '' : 'mask';
      }
    },
    // 邀请好友进度条宽度
    inviteProgressBarWidth() {
      const num1 = 1, num2 = 2, num3 = 3;
      const {inviteNum: num} = this;
      // 单个长度，总长度分为6份，0-50占1/6,50-150和150-250占1/3,250-最后占1/6
      const singleWidth = 519 / 75 / 6;
      let width;
      // 如果预约数小于50万，则按单个长度乘以所占的比例
      if (num <= num1) {
        width = (num / num1) * singleWidth * 0.8;
        // 如果预约数大于50万小于150万，则单个长度加上预约数-50万除以对应的长度(100万)所占的比例乘以2个单个长度
      } else if (num > num1 && num <= num2) {
        width = singleWidth + ((num - num1) / (num2 - num1)) * 2 * singleWidth;
        // 同上
      } else if (num > num2 && num <= num3) {
        width = 3 * singleWidth + ((num - num2) / (num3 - num2)) * 2 * singleWidth;
      } else {
        // 大于250万，直接占满
        width = 519 / 75;
      }
      return width;
    },
    // 集结进度
    assembleProgress() {
      const map = {
        0: 100000,
        1: 200000,
        2: 500000,
        3: 800000,
        4: 1000000,
      }
      const {reserveNum} = this;
      return (index) => {
        return reserveNum > map[index] ? '' : 'mask';
      }
    },
    // 集结进度条宽度
    assembleProgressBarWidth() {
      const num1 = 100000, num2 = 200000, num3 = 500000, num4 = 800000, num5 = 1000000;
      const {reserveNum: num} = this;
      const singleWidth = 546 / 75 / 10;
      let width;
      if (num <= num1) {
        width = (num / num1) * singleWidth * 0.7;
      } else if (num > num1 && num <= num2) {
        width = singleWidth * 0.7 + ((num - num1) / (num2 - num1)) * 2 * singleWidth;
      } else if (num > num2 && num <= num3) {
        width = 3 * singleWidth + ((num - num2) / (num3 - num2)) * 2 * singleWidth * 0.95;
      } else if (num > num3 && num <= num4) {
        width = 5 * singleWidth + ((num - num3) / (num4 - num3)) * 2 * singleWidth;
      } else if (num > num4 && num <= num5) {
        width = 7 * singleWidth + ((num - num4) / (num5 - num4)) * 2 * singleWidth;
      } else {
        width = 546 / 75;
      }
      return width;
    },
  },
  methods: {
    // 关闭弹框
    onClose() {
      this.$emit("update:visible", false);
    },
    // 获取邀请人数
    async getInviteNum() {
      const {inviteCode} = JSON.parse(localStorage.getItem("userinfo")) || {};
      if (inviteCode) {
        const num = await this.fetchInviteNum();
        this.inviteNum = num;
        this.tipsText = `已邀请${num}位好友`;
      } else {
        this.inviteNum = 0;
      }
    },
    fetchInviteNum() {
      const {inviteCode} = JSON.parse(localStorage.getItem("userinfo"));
      return new Promise(resolve => {
        const time = Date.now();
        const code = inviteCode;
        const params = {time, code};
        const headers = {time};
        getVisitNum(params, headers).then((res) => {
          if (res.status == 1) {
            resolve(res.data);
          }
        });
      })
    },
    // 查看活动详情
    handleSeeActivityDetail() {
      this.$emit("onSeeActivityDetail");
    },
    // 邀请好友
    handleInviteFriends() {
      const userinfo = JSON.parse(localStorage.getItem("userinfo"));
      if (userinfo) {
        this.$emit("onInviteFriends");
      } else {
        this.$toast("请您先预约");
      }
    },
    // 当点击类名为modal-main的元素时关闭弹框
    handleClick(e) {
      const {className} = e.target;
      if (className === "modal-main") {
        this.onClose();
      }
    },
    // 轮询获取邀请的人数
    async handlePolling() {
      const {inviteCode} = JSON.parse(localStorage.getItem("userinfo")) || {};
      if (inviteCode) {
        const num = await this.fetchInviteNum();
        this.inviteNum = num;
        this.tipsText = `已邀请${num}位好友`;
        this.timer = setTimeout(this.handlePolling, 2000);
      }
    },
  },
  watch: {
    visible(newVal) {
      if (newVal) {
        this.handlePolling();
      } else {
        clearTimeout(this.timer);
      }
    }
  }
};
</script>

<style lang="scss" scoped>
@import "./index";
</style>
