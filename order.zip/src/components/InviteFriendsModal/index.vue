<template>
  <transition nam="fade">
    <div v-show="visible">
      <div class="modal-mask" @click="onClose"></div>
      <div class="modal-main">
        <div class="modal-box">
          <div class="modal-content">
            <div class="invite-code">
              <span>您的邀请码为：{{inviteCode}}</span>
              <span class="copy" @click="copy('inviteCode')">【复制】</span>
            </div>
            <div class="way way1">方法一：复制地址链接邀请好友点击链接进行预约</div>
            <div class="form">
              <div class="form-item">
                <input type="text" readonly v-model="url">
                <div class="btn" @click="copy('url')">复制地址</div>
              </div>
              <p class="tips">使用该链接进行预约，系统将会在好友预约界面填写您的邀请码</p>
            </div>
            <div class="way way2">方法二：分享二维码</div>
            <div class="qr-code">
              <canvas style="display: none" class="qr-code" ref="qrcode"></canvas>
              <img src="" alt="" ref="qrcodeImg">
            </div>
          </div>
          <div class="modal-close" @click="onClose"></div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
import QRCode from "qrcode";

export default {
  name: "index",
  props: {
    visible: {
      type: Boolean,
      default: () => false,
    },
  },
  data() {
    return {
      inviteCode: "",
      url: "",
      done: false,
    };
  },
  methods: {
    // 生成二维码
    generateQRCode() {
      if (!this.done) {
        const {inviteCode} = JSON.parse(localStorage.getItem("userinfo")) || {};
        this.inviteCode = inviteCode;
        this.url = location.href + '?code=' + inviteCode;
        const {qrcode, qrcodeImg} = this.$refs;
        QRCode.toCanvas(qrcode, this.url, { margin: 2, color: {dark: "#C8430D"} });
        qrcodeImg.src = qrcode.toDataURL("image/png");
        this.done = true;
      }
    },
    // 关闭弹框
    onClose() {
      this.$emit("update:visible", false);
    },
    // 复制
    copy(key) {
      const textarea = document.createElement("textarea");
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.value = this[key];
      textarea.select();
      document.execCommand("copy");
      this.$toast.success("复制成功");
      document.body.removeChild(textarea);
    },
  },
  watch: {
    visible(newVal) {
      if (newVal) {
        this.generateQRCode();
      }
    }
  },
}
</script>

<style lang="scss" scoped>
@import "./index";
</style>
