<template>
  <transition name="fade">
    <div class="reserve-modal-wrapper" v-show="visible">
      <div class="modal-mask" @click="onClose"></div>
      <div class="modal-main">
        <div class="modal-box">
          <div class="modal-type">
            <span>{{reserveType}}</span>
          </div>
          <div class="modal-content" v-if="!isReserve">
            <div class="choose-dev">
              <div class="ios" @click="onSelect(1)">
                <i class="radio" :class="[dev === 1 ? 'selected' : '']"></i>
                <span>iOS</span>
              </div>
              <div class="android" @click="onSelect(2)">
                <i class="radio" :class="[dev === 2 ? 'selected' : '']"></i>
                <span>Android</span>
              </div>
            </div>
            <div class="form">
              <div class="form-item">
                <input type="text" maxlength="11" placeholder="请输入手机号" v-model="phone" />
              </div>
              <div class="form-item code">
                <input type="text" maxlength="6" placeholder="请输入验证码" v-model="code" />
                <div class="btn" :class="[disabled ? 'disabled' : '']" @click="sendCode">{{ text }}</div>
              </div>
              <div class="form-item">
                <input type="text" maxlength="11" placeholder="请输入邀请码（非必填）" v-model="inviteCode" />
              </div>
            </div>
            <div class="confirm" @click="onReserve">确认</div>
          </div>
          <div class="modal-content" v-else>
            <p class="success">您已登录并预约成功！</p>
            <div class="confirm" @click="handleToggleAccount">切换账号</div>
          </div>
          <div class="modal-close" @click="onClose"></div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
import validatePhone from "@/utils/validatePhone";
import sendCode from "@/api/sendCode";
import { appoint } from "@/api";

export default {
  name: "index",
  props: {
    visible: {
      type: Boolean,
      default: () => false,
    },
    isReserve: {
      type: Boolean,
      default: () => false,
    },
    reserveType: String,
  },
  data() {
    return {
      dev: 1,
      phone: "", // 手机号
      code: "", // 验证码
      inviteCode: null, // 邀请码
      text: "发送验证码",
      timer: null,
      disabled: false,
    };
  },
  created() {
    this.handleCheckInvite();
  },
  methods: {
    // 判断是否通过已预约用户分享的链接进入
    handleCheckInvite() {
      const {code} = this.$route.query;
      if (code) {
        this.inviteCode = code;
        localStorage.removeItem("userinfo");
      }
    },
    // 重置数据
    resetData() {
      this.phone = "";
      this.code = "";
      this.disabled = false;
      clearInterval(this.timer);
      this.text = "发送验证码";
    },
    // 关闭弹框
    onClose() {
      this.$emit("update:visible", false);
    },
    // 切换dev
    onSelect(dev) {
      this.dev = dev;
    },
    // 判断手机号码
    checkPhone() {
      const { phone } = this;
      if (!phone) {
        this.$toast("请输入手机号码");
        return false;
      } else if (!validatePhone(phone)) {
        this.$toast("请输入正确的手机号码");
        return false;
      } else {
        return true;
      }
    },
    // 判断验证码
    checkCode() {
      const { code } = this;
      if (!code) {
        this.$toast("请输入验证码");
        return false;
      } else if (code.length !== 6) {
        this.$toast("请输入6位数验证码");
        return false;
      } else {
        return true;
      }
    },
    // 发送验证码
    sendCode() {
      if (this.checkPhone()) {
        const { phone } = this;
        sendCode(phone).then((res) => {
          if (res.status == 1) {
            this.disabled = true;
            this.$toast.success(res.msg);
            let num = 60;
            this.timer = setInterval(() => {
              this.text = `${num}s后重新发送`;
              num--;
              if (num === 0) {
                this.text = "重新发送";
                this.disabled = false;
                clearInterval(this.timer);
              }
            }, 1000);
          } else {
            this.$toast(res.msg);
            return false;
          }
        });
      }
    },
    // 预约
    onReserve() {
      if (this.checkPhone() && this.checkCode()) {
        const { phone, code, dev, inviteCode } = this;
        const time = Date.now();
        const project_id = "6";
        const params = { time, project_id, phone, code, dev, fcode: inviteCode };
        const headers = { time, phone, code, project_id };
        appoint(params, headers).then((res) => {
          if(res.status == 0) {
            this.$toast("验证码错误，请重新输入");
          } else {
            localStorage.removeItem("userinfo");
            localStorage.setItem("userinfo", JSON.stringify({phone, inviteCode: res.data}));
            res.status == 1 ? this.$toast.success("预约成功") : this.$toast("您已预约");
            this.$emit("onReserveSuccess", phone);
            this.$bus.$emit("reserved");
            this.resetData();
            this.onClose();
          }
        });
      }
    },
    // 切换账号
    handleToggleAccount() {
      this.$emit("update:isReserve", false);
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./index";
</style>
