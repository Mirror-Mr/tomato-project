<template>
  <transition nam="fade">
    <div v-show="visible">
      <div class="modal-mask" @click="onClose"></div>
      <div class="modal-main">
        <div class="modal-box">
          <div class="modal-content">
            <div class="title"></div>
            <div class="content" v-for="(item, index) in activityDetails" :key="index">
              <h2>{{item.summary}}</h2>
              <p v-for="(item1, index1) in item.detail" :key="index1">{{item1}}</p>
            </div>
          </div>
          <div class="modal-close" @click="onClose"></div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  name: "index",
  props: {
    visible: {
      type: Boolean,
      default: () => false,
    },
  },
  data() {
    return {
      activityDetails: Object.freeze([
        {
          summary: "一、活动时间：",
          detail: ["即日起至不删档测试开启前一天23:59。"],
        },
        {
          summary: "二、活动说明：",
          detail: [
            "①游戏上线后，玩家需在官网下载游戏，并于不删档开服后两周内登录游戏并创建角色，方可获得预约时所得全部虚拟奖励；",
            "②每个手机号仅限参与一次预约活动，并用于后继奖励接收，请确认手机号填写正确；",
            "③活动具体发放时间和发放方式，请关注游戏上线前官网的统一公告。",
          ],
        },
        {
          summary: "三、活动规则：",
          detail: [
            "①多重预约礼：在官网进行预约成功后，即可获得该奖励，每人仅可获得一次。",
            "②好友邀约礼：活动期间，参加官网预约活动的玩家邀请1位、2位、3位好友，通过生成的专属链接或二维码完成预约后，邀请人可获得相应档位的游戏道具奖励。",
            "③预约集结礼：总预约量达到10万、20万、50万、80万、100万，所有活动期间在官网成功预约的玩家都可领取相应档位的奖励。",
          ],
        },
      ]),
    };
  },
  methods: {
    // 关闭弹框
    onClose() {
      this.$emit("update:visible", false);
    },
  },
}
</script>

<style lang="scss" scoped>
@import "./index";
</style>
