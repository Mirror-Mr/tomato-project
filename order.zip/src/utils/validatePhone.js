// 校验手机号
export default function (phone) {
  const reg = /^(?:(?:\+|00)86)?1[3-9]\d{9}$/;
  return reg.test(phone);
}
