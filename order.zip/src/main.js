/*
 * @Author: your name
 * @Date: 2021-07-19 15:33:50
 * @LastEditTime: 2021-08-02 17:18:57
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \vue-testc:\Users\leishan\Desktop\web\inland\Games\TangMistyRain\Activity\order\src\main.js
 */

import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import { Toast, Popup } from "vant";
import ElementUI from "element-ui";
import "element-ui/lib/theme-chalk/index.css";
import "@/assets/style/reset.scss";
import "@/utils/flexible";
import "@/assets/fonts/iconfont.css";
import animated from "animate.css/animate.compat.css";




Vue.use(ElementUI);
Vue.use(animated);
Vue.config.productionTip = false;
Vue.prototype.$toast = Toast;
Vue.prototype.$bus = new Vue();
Vue.use(Popup);

let _main = new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount("#app");

export { _main };
