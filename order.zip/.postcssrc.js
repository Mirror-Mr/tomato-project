/*
 * @Author: your name
 * @Date: 2021-07-19 16:09:25
 * @LastEditTime: 2021-07-22 15:17:25
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \vue-testc:\Users\leishan\Desktop\web\inland\Games\TangMistyRain\Activity\order\.postcssrc.js
 */
module.exports = {
  plugins: {
    autoprefixer: {},
    "postcss-pxtorem": {
      rootValue({ file }) {
        return file.indexOf('vant') !== -1 ? 37.5 : 75;
      },
      selectorBlackList: [".el",".special"],
      propList: ["*"],
    },
  },
};
