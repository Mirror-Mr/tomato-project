
var parcelRequire = (function (t) {
  function e(t, e) {
    if (t in a) return a[t];
    var r = "function" == typeof parcelRequire && parcelRequire;
    if (!e && r) return r(t, !0);
    if (n) return n(t, !0);
    if (i && "string" == typeof t) return i(t);
    var o = new Error("Cannot find module '" + t + "'");
    throw ((o.code = "MODULE_NOT_FOUND"), o);
  }
  var n = "function" == typeof parcelRequire && parcelRequire,
    i = "function" == typeof require && require,
    a = {};
  return (
    (e.register = function (t, e) {
      a[t] = e;
    }),
    (a = t(e)),
    (e.modules = a),
    e
  );
})(function () {
  function t(t) {
    return t && t.__esModule ? { d: t["default"] } : { d: t };
  }
  function e(t) {
    return a(t) || i(t) || n();
  }
  function n() {
    throw new TypeError("Invalid attempt to spread non-iterable instance");
  }
  function i(t) {
    return Symbol.iterator in Object(t) ||
      "[object Arguments]" === Object.prototype.toString.call(t)
      ? Array.from(t)
      : void 0;
  }
  function a(t) {
    if (Array.isArray(t)) {
      for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
      return n;
    }
  }
  function r(t, e) {
    if (!(t instanceof e))
      throw new TypeError("Cannot call a class as a function");
  }
  function o(t, e) {
    for (var n = 0; n < e.length; n++) {
      var i = e[n];
      (i.enumerable = i.enumerable || !1),
        (i.configurable = !0),
        "value" in i && (i.writable = !0),
        Object.defineProperty(t, i.key, i);
    }
  }
  function s(t, e, n) {
    return e && o(t.prototype, e), n && o(t, n), t;
  }
  function l() {}
  function u(t) {
    return f(t) || h(t) || c();
  }
  function c() {
    throw new TypeError("Invalid attempt to spread non-iterable instance");
  }
  function h(t) {
    return Symbol.iterator in Object(t) ||
      "[object Arguments]" === Object.prototype.toString.call(t)
      ? Array.from(t)
      : void 0;
  }
  function f(t) {
    if (Array.isArray(t)) {
      for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
      return n;
    }
  }
  function d(t) {
    return (d =
      "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
        ? function (t) {
            return typeof t;
          }
        : function (t) {
            return t &&
              "function" == typeof Symbol &&
              t.constructor === Symbol &&
              t !== Symbol.prototype
              ? "symbol"
              : typeof t;
          })(t);
  }
  function v(t, e) {
    if (!(t instanceof e))
      throw new TypeError("Cannot call a class as a function");
  }
  function m(t, e) {
    for (var n = 0; n < e.length; n++) {
      var i = e[n];
      (i.enumerable = i.enumerable || !1),
        (i.configurable = !0),
        "value" in i && (i.writable = !0),
        Object.defineProperty(t, i.key, i);
    }
  }
  function p(t, e, n) {
    return e && m(t.prototype, e), n && m(t, n), t;
  }
  function g(t, e, n, i) {
    return (n * t) / i + e;
  }
  function y(t, e, n, i) {
    return n * (t /= i) * t + e;
  }
  function b(t, e, n, i) {
    return -n * (t /= i) * (t - 2) + e;
  }
  function w(t, e, n, i) {
    return (t /= i / 2) < 1
      ? (n / 2) * t * t + e
      : (-n / 2) * (--t * (t - 2) - 1) + e;
  }
  function P(t, e, n, i) {
    return n * Math.pow(t / i, 3) + e;
  }
  function x(t, e, n, i) {
    return n * (Math.pow(t / i - 1, 3) + 1) + e;
  }
  function E(t, e, n, i) {
    return (t /= i / 2) < 1
      ? (n / 2) * Math.pow(t, 3) + e
      : (n / 2) * (Math.pow(t - 2, 3) + 2) + e;
  }
  function S(t, e, n, i) {
    return n * Math.pow(t / i, 4) + e;
  }
  function R(t, e, n, i) {
    return -n * (Math.pow(t / i - 1, 4) - 1) + e;
  }
  function k(t, e, n, i) {
    return (t /= i / 2) < 1
      ? (n / 2) * Math.pow(t, 4) + e
      : (-n / 2) * (Math.pow(t - 2, 4) - 2) + e;
  }
  function C(t, e, n, i) {
    return n * Math.pow(t / i, 5) + e;
  }
  function H(t, e, n, i) {
    return n * (Math.pow(t / i - 1, 5) + 1) + e;
  }
  function T(t, e, n, i) {
    return (t /= i / 2) < 1
      ? (n / 2) * Math.pow(t, 5) + e
      : (n / 2) * (Math.pow(t - 2, 5) + 2) + e;
  }
  function I(t, e, n, i) {
    return n * (1 - Math.cos((t / i) * (Math.PI / 2))) + e;
  }
  function F(t, e, n, i) {
    return n * Math.sin((t / i) * (Math.PI / 2)) + e;
  }
  function M(t, e, n, i) {
    return (n / 2) * (1 - Math.cos((Math.PI * t) / i)) + e;
  }
  function O(t, e, n, i) {
    return n * Math.pow(2, 10 * (t / i - 1)) + e;
  }
  function z(t, e, n, i) {
    return n * (-Math.pow(2, (-10 * t) / i) + 1) + e;
  }
  function A(t, e, n, i) {
    return (t /= i / 2) < 1
      ? (n / 2) * Math.pow(2, 10 * (t - 1)) + e
      : (n / 2) * (-Math.pow(2, -10 * --t) + 2) + e;
  }
  function D(t, e, n, i) {
    return n * (1 - Math.sqrt(1 - (t /= i) * t)) + e;
  }
  function W(t, e, n, i) {
    return n * Math.sqrt(1 - (t = t / i - 1) * t) + e;
  }
  function j(t, e, n, i) {
    return (t /= i / 2) < 1
      ? (n / 2) * (1 - Math.sqrt(1 - t * t)) + e
      : (n / 2) * (Math.sqrt(1 - (t -= 2) * t) + 1) + e;
  }
  function L(t, e) {
    if (!(t instanceof e))
      throw new TypeError("Cannot call a class as a function");
  }
  function U(t, e) {
    for (var n = 0; n < e.length; n++) {
      var i = e[n];
      (i.enumerable = i.enumerable || !1),
        (i.configurable = !0),
        "value" in i && (i.writable = !0),
        Object.defineProperty(t, i.key, i);
    }
  }
  function B(t, e, n) {
    return e && U(t.prototype, e), n && U(t, n), t;
  }
  function q(t) {
    function e(i) {
      var a = Math.min(u, i - n),
        o = p(a, r, m, u);
      t(o, a),
        a === u
          ? d
            ? ((n = i), requestAnimationFrame(e))
            : v && v()
          : requestAnimationFrame(e);
    }
    var n,
      i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
      a = i.begin,
      r = void 0 === a ? 0 : a,
      o = i.finish,
      s = void 0 === o ? 1 : o,
      l = i.duration,
      u = void 0 === l ? 500 : l,
      c = i.easing,
      h = void 0 === c ? "easeInOutCubic" : c,
      f = i.isRoop,
      d = void 0 === f ? !1 : f,
      v = i.onAfter,
      m = s - r,
      p = ee[h];
    requestAnimationFrame(function (t) {
      (n = t), e(t);
    });
  }
  function Q(t, e) {
    if (!(t instanceof e))
      throw new TypeError("Cannot call a class as a function");
  }
  function Y(t, e) {
    for (var n = 0; n < e.length; n++) {
      var i = e[n];
      (i.enumerable = i.enumerable || !1),
        (i.configurable = !0),
        "value" in i && (i.writable = !0),
        Object.defineProperty(t, i.key, i);
    }
  }
  function _(t, e, n) {
    return e && Y(t.prototype, e), n && Y(t, n), t;
  }
  function X(t) {
    var e = t.text,
      n = t.fontSize,
      i = t.letterSpacing,
      a = void 0 === i ? 0 : i,
      r = t.font,
      o = void 0 === r ? "Open sans" : r,
      s = t.color,
      l = void 0 === s ? "#000000" : s,
      u = t.width,
      c = void 0 === u ? n * e.length + n * a * (e.length - 1) : u,
      h = t.height,
      f = void 0 === h ? n : h,
      d = t.pixelRatio,
      v = void 0 === d ? window.devicePixelRatio : d;
    (n *= v), (c *= v), (f *= v);
    var m = document.createElement("canvas");
    (m.width = c),
      (m.height = f),
      (m.style.fontSize = n + "px"),
      (m.style.letterSpacing = a + "em"),
      (m.style.display = "none"),
      document.body.appendChild(m);
    var p = m.getContext("2d");
    (p.font = "".concat(n, "px ").concat(o)),
      (p.fillStyle = l),
      (p.textAlign = "center"),
      (p.textBaseline = "middle");
    var g = e.split("\n");
    return (
      g.forEach(function (t, e) {
        var i = c / 2,
          a = f / 2 + n * e - (n / 2) * (g.length - 1);
        p.fillText(t, i, a);
      }),
      m
    );
  }
  function G(t, e) {
    if (!(t instanceof e))
      throw new TypeError("Cannot call a class as a function");
  }
  function V(t, e) {
    for (var n = 0; n < e.length; n++) {
      var i = e[n];
      (i.enumerable = i.enumerable || !1),
        (i.configurable = !0),
        "value" in i && (i.writable = !0),
        Object.defineProperty(t, i.key, i);
    }
  }
  function Z(t, e, n) {
    return e && V(t.prototype, e), n && V(t, n), t;
  }
  function N(t, e) {
    if (!(t instanceof e))
      throw new TypeError("Cannot call a class as a function");
  }
  function J(t, e) {
    for (var n = 0; n < e.length; n++) {
      var i = e[n];
      (i.enumerable = i.enumerable || !1),
        (i.configurable = !0),
        "value" in i && (i.writable = !0),
        Object.defineProperty(t, i.key, i);
    }
  }
  function K(t, e, n) {
    return e && J(t.prototype, e), n && J(t, n), t;
  }
  var $ = (function () {
      function t(n) {
        var i,
          a = this;
        r(this, t);
        var o = n.container,
          s = void 0 === o ? document.body : o,
          l = n.fov,
          u = void 0 === l ? 45 : l,
          c = n.zNear,
          h = n.zFar,
          f = n.cameraPosition,
          d = void 0 === f ? [0, 0, 30] : f,
          v = n.createCameraControls,
          m = void 0 === v ? !1 : v,
          p = n.isAutoStart,
          g = void 0 === p ? !0 : p,
          y = n.pixelRatio,
          b = void 0 === y ? window.devicePixelRatio : y,
          w = n.antialias,
          P = void 0 === w ? 1 === window.devicePixelRatio : w,
          x = !0,
          E = void 0 === x ? !1 : x,
          S = n.clearColor,
          R = void 0 === S ? 0 : S,
          k = n.aspect,
          C = n.canvas,
          H = void 0 === C ? document.createElement("canvas") : C,
          T = n.speed,
          I = void 0 === T ? 0.06 : T,
          F = n.interval,
          M = n.firstTime,
          O = void 0 === M ? 0 : M,
          z = n.isDev,
          A = void 0 === z ? !1 : z;
        (this.speed = I),
          (this.interval = F),
          (this.time = this.firstTime = O),
          (this.stopTime = 0),
          (this.updateCallbacks = []),
          (this.resizeCallbacks = []),
          (this.objects = {}),
          (this.renderer = new THREE.WebGLRenderer({
            antialias: P,
            alpha: E,
            canvas: H,
          })),
          this.renderer.setPixelRatio(b),
          this.renderer.setClearColor(R, E ? 0 : 1),
          (this.canvas = this.renderer.domElement),
          (this.container =
            "string" == typeof s ? document.querySelector(s) : s),
          !n.canvas && this.container.appendChild(this.canvas),
          (this.aspect =
            k || this.container.clientWidth / this.container.clientHeight),
          this.setSize(),
          (this.camera = new THREE.PerspectiveCamera(
            u,
            this.width / this.height,
            c,
            h
          )),
          (i = this.camera.position).set.apply(i, e(d)),
          this.camera.updateProjectionMatrix(),
          (this.scene = new THREE.Scene()),
          this.resize(),
          window.addEventListener("resize", function () {
            a.resize();
          }),
          g && this.start(),
          m && this.createOrbitControls(),
          (this.raycaster = new THREE.Raycaster()),
          (this.pointer = new THREE.Vector2()),
          A &&
            document.addEventListener("keydown", function (t) {
              var e = t.key;
              "Escape" === e && a.toggle();
            });
      }
      return (
        s(t, [
          {
            key: "setSize",
            value: function () {
              this.aspect
                ? this.container.clientWidth / this.container.clientHeight >
                  this.aspect
                  ? ((this.width = this.container.clientHeight * this.aspect),
                    (this.height = this.container.clientHeight))
                  : ((this.width = this.container.clientWidth),
                    (this.height = this.container.clientWidth / this.aspect))
                : ((this.width = this.container.clientWidth),
                  (this.height = this.container.clientHeight));
            },
          },
          {
            key: "createOrbitControls",
            value: function () {
              var t = this;
              return THREE.TrackballControls
                ? ((this.controls = new THREE.TrackballControls(
                    this.camera,
                    this.canvas
                  )),
                  void this.addUpdateCallback(function () {
                    t.controls.update();
                  }))
                : void console.error(
                    "TrackballControls.js file is not loaded."
                  );
            },
          },
          {
            key: "start",
            value: function () {
              var t = this,
                e = this.stopTime || this.firstTime;
              requestAnimationFrame(function (n) {
                (t.startTime = n - e), (t.time = n - t.startTime);
              }),
                this.tick();
            },
          },
          {
            key: "tick",
            value: function () {
              var t = this;
              this.update(),
                this.render(),
                (this.animationFrameId = requestAnimationFrame(function (e) {
                  (t.time = e - t.startTime), t.tick();
                }));
            },
          },
          {
            key: "update",
            value: function () {
              var t = this.time * this.speed;
              (t = this.interval ? t % this.interval : t),
                this.updateCallbacks.forEach(function (e) {
                  e(t);
                });
            },
          },
          {
            key: "render",
            value: function () {
              this.renderer.render(this.scene, this.camera);
            },
          },
          {
            key: "draw",
            value: function () {
              this.update(), this.render();
            },
          },
          {
            key: "stop",
            value: function () {
              cancelAnimationFrame(this.animationFrameId),
                (this.animationFrameId = null),
                (this.stopTime = this.time);
            },
          },
          {
            key: "reset",
            value: function () {
              this.stop(), (this.stopTime = 0);
            },
          },
          {
            key: "toggle",
            value: function () {
              this.animationFrameId ? this.stop() : this.start();
            },
          },
          {
            key: "addUpdateCallback",
            value: function (t) {
              this.updateCallbacks.push(t);
            },
          },
          {
            key: "addResizeCallback",
            value: function (t) {
              this.resizeCallbacks.push(t);
            },
          },
          {
            key: "add",
            value: function (t, e) {
              e && (this.objects[e] = t), this.scene.add(t);
            },
          },
          {
            key: "addTo",
            value: function (t, e, n) {
              n && (this.objects[n] = t), this.get(e).add(t);
            },
          },
          {
            key: "get",
            value: function (t) {
              return this.objects[t];
            },
          },
          {
            key: "remove",
            value: function (t) {
              var e;
              (e = "string" == typeof t ? this.objects[t] : t),
                e && (e.parent.remove(e), delete this.objects[t]);
            },
          },
          {
            key: "resize",
            value: function () {
              (this.container.style.width = ""),
                (this.container.style.height = ""),
                this.aspect &&
                  (this.aspect =
                    this.container.clientWidth / this.container.clientHeight),
                this.setSize(),
                (this.camera.aspect = this.width / this.height),
                this.camera.updateProjectionMatrix(),
                this.renderer.setSize(this.width, this.height),
                this.resizeCallbacks.forEach(function (t) {
                  t();
                });
            },
          },
          {
            key: "initPostProcessing",
            value: function (t) {
              var e = this,
                n = this.renderer.getSize(),
                i = this.renderer.getPixelRatio();
              (n.width *= i), (n.height *= i);
              var a = (this.composer = new THREE.EffectComposer(
                  this.renderer,
                  new THREE.WebGLRenderTarget(n.width, n.height, {
                    minFilter: THREE.LinearFilter,
                    magFilter: THREE.LinearFilter,
                    format: THREE.RGBAFormat,
                    stencilBuffer: !1,
                  })
                )),
                r = new THREE.RenderPass(this.scene, this.camera);
              a.addPass(r);
              for (var o = 0; o < t.length; o++) {
                var s = t[o];
                (s.renderToScreen = o === t.length - 1), a.addPass(s);
              }
              (this.renderer.autoClear = !1),
                (this.render = function () {
                  e.renderer.clear(), a.render();
                }),
                this.addResizeCallback(function () {
                  a.setSize(
                    e.canvas.clientWidth * i,
                    e.canvas.clientHeight * i
                  );
                });
            },
          },
          {
            key: "checkPointer",
            value: function (t, e, n, i) {
              var a = t.x,
                r = t.y;
              (this.pointer.x = (a / this.canvas.clientWidth) * 2 - 1),
                (this.pointer.y = 2 * -(r / this.canvas.clientHeight) + 1),
                this.raycaster.setFromCamera(this.pointer, this.camera);
              var o = this.raycaster.intersectObjects(e);
              return o.length > 0 ? (n(o[0].object), !0) : (i && i(), !1);
            },
          },
        ]),
        t
      );
    })(),
    te = (function () {
      function t(e) {
        v(this, t);
        var n = e.closed;
        ((this.gui = new dat.GUI(e))), (this.gui.closed = n);
      }
      return (
        p(t, [
          {
            key: "addData",
            value: function (t) {
              var e =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : {},
                n = e.folder,
                i = void 0 === n ? this.gui : n,
                a = e.callback,
                r = void 0 === a ? l : a,
                o = e.isUniform,
                s = Object.keys(t),
                c = {};
              return (
                s.forEach(function (e) {
                  c[e] = t[e].value;
                }),
                s.forEach(function (e) {
                  var n,
                    a = t[e],
                    s = a.isColor,
                    l = a.value,
                    h = a.range,
                    f = a.onChange,
                    v = a.listen;
                  if (o)
                    switch (d(l)) {
                      case "boolean":
                        n = "1i";
                        break;
                      case "array":
                        n = l.length + "f";
                        break;
                      case "object":
                        n = "t";
                        break;
                      default:
                        n = "1f";
                    }
                  var m;
                  if (s) m = i.addColor(c, e);
                  else {
                    var p = [];
                    if (h) p = h;
                    else if ("frame" === e) p = [0, 1];
                    else if ("number" == typeof l)
                      if (1 > l && l >= 0) p = [0, 1];
                      else {
                        var g =
                          2 * Math.pow(10, String(Math.floor(l)).length - 1);
                        p = [l - g, l + g];
                      }
                    m = i.add.apply(i, [c, e].concat(u(p)));
                  }
                  f &&
                    m.onChange(function (t) {
                      f(t);
                    }),
                    v && m.listen(),
                    r(e, { type: n, value: l });
                }),
                c
              );
            },
          },
          {
            key: "addUniformData",
            value: function (t) {
              var e =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : {},
                n =
                  arguments.length > 2 && void 0 !== arguments[2]
                    ? arguments[2]
                    : {};
              return this.addData(t, {
                callback: function (t, n) {
                  e[t] = n;
                },
                folder: n.folder,
                isUniform: !0,
              });
            },
          },
          {
            key: "addFolder",
            value: function (t, e) {
              var n = this.gui.addFolder(t);
              return !e && n.open(), n;
            },
          },
        ]),
        t
      );
    })(),
    ee = {};
  (ee.linear = g),
    (ee.easeInQuad = y),
    (ee.easeOutQuad = b),
    (ee.easeInOutQuad = w),
    (ee.easeInCubic = P),
    (ee.easeOutCubic = x),
    (ee.easeInOutCubic = E),
    (ee.easeInQuart = S),
    (ee.easeOutQuart = R),
    (ee.easeInOutQuart = k),
    (ee.easeInQuint = C),
    (ee.easeOutQuint = H),
    (ee.easeInOutQuint = T),
    (ee.easeInSine = I),
    (ee.easeOutSine = F),
    (ee.easeInOutSine = M),
    (ee.easeInExpo = O),
    (ee.easeOutExpo = z),
    (ee.easeInOutExpo = A),
    (ee.easeInCirc = D),
    (ee.easeOutCirc = W),
    (ee.easeInOutCirc = j);
  var ne = [
    "linear",
    "easeInSine",
    "easeOutSine",
    "easeInOutSine",
    "easeInQuad",
    "easeOutQuad",
    "easeInOutQuad",
    "easeInCubic",
    "easeOutCubic",
    "easeInOutCubic",
    "easeInQuart",
    "easeOutQuart",
    "easeInOutQuart",
    "easeInQuint",
    "easeOutQuint",
    "easeInOutQuint",
    "easeInExpo",
    "easeOutExpo",
    "easeInOutExpo",
    "easeInCirc",
    "easeOutCirc",
    "easeInOutCirc",
  ];
  ee.easingList = ne;
  var ie =
      ((function () {
        function t(e, n) {
          L(this, t);
          var i = n.begin,
            a = void 0 === i ? 0 : i,
            r = n.finish,
            o = void 0 === r ? 1 : r,
            s = n.duration,
            l = void 0 === s ? 500 : s,
            u = n.easing,
            c = void 0 === u ? "easeInOutCubic" : u,
            h = n.isRoop,
            f = void 0 === h ? !1 : h,
            d = n.isAuto,
            v = void 0 === d ? !0 : d,
            m = n.onBefore,
            p = n.onAfter,
            g = n.onStop;
          (this.fn = e),
            (this.duration = l),
            (this.easingFunction = ee[c]),
            (this.originalFrom = a),
            (this.originalTo = o),
            (this.isRoop = f),
            (this.onBefore = m),
            (this.onAfter = p),
            (this.onStop = g),
            v && this.start();
        }
        return (
          B(t, [
            {
              key: "tick",
              value: function (t) {
                var e = Math.min(this.duration, t - this.startTime),
                  n = this.easingFunction(
                    e,
                    this.begin,
                    this.change,
                    this.duration
                  );
                this.fn(n, e),
                  e === this.duration
                    ? this.isRoop
                      ? this.animate()
                      : this.onAfter && this.onAfter()
                    : (this.id = requestAnimationFrame(this.tick.bind(this)));
              },
            },
            {
              key: "animate",
              value: function () {
                var t = this;
                this.id = requestAnimationFrame(function (e) {
                  (t.startTime = e), t.tick(e);
                });
              },
            },
            {
              key: "start",
              value: function () {
                this.onBefore && this.onBefore(),
                  (this.begin = this.originalFrom),
                  (this.finish = this.originalTo),
                  (this.change = this.finish - this.begin),
                  this.id && this.stop(),
                  this.animate();
              },
            },
            {
              key: "reverse",
              value: function () {
                this.onBefore && this.onBefore(),
                  (this.begin = this.originalTo),
                  (this.finish = this.originalFrom),
                  (this.change = this.finish - this.begin),
                  this.id && this.stop(),
                  this.animate();
              },
            },
            {
              key: "play",
              value: function () {
                this.animate();
              },
            },
            {
              key: "stop",
              value: function () {
                cancelAnimationFrame(this.id),
                  (this.id = null),
                  this.onStop && this.onStop();
              },
            },
            {
              key: "easing",
              set: function (t) {
                this.easingFunction = ee[t];
              },
            },
          ]),
          t
        );
      })(),
      {}),
    ae = {};
  ae =
    "precision highp float;\nprecision highp int;\n#define GLSLIFY 1\nattribute vec3 position;\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\n\nattribute vec4 mouse;\nattribute vec2 aFront;\nattribute float random;\n\n// uniform float uProgress;\nuniform vec2 resolution;\nuniform float pixelRatio;\nuniform float timestamp;\n\nuniform float size;\nuniform float minSize;\n// uniform float delay;\nuniform float speed;\nuniform float far;\nuniform float spread;\nuniform float maxSpread;\nuniform float maxZ;\nuniform float maxDiff;\nuniform float diffPow;\n\nvarying float vProgress;\nvarying float vRandom;\nvarying float vDiff;\nvarying float vSpreadLength;\nvarying float vPositionZ;\n\nfloat cubicOut(float t) {\n  float f = t - 1.0;\n  return f * f * f + 1.0;\n}\n\n// #pragma glslify: cubicBezier = require(../../modules/cubicBezier.glsl)\n\nconst float PI = 3.1415926;\nconst float PI2 = PI * 2.;\n\nvec2 cartesianToPolar (vec2 p) {\n  return vec2((atan(p.y, p.x) + PI) / PI2, length(p));\n}\n\nvec2 polarToCartesian (vec2 p) {\n  float r = p.x * PI2 - PI;\n  float l = p.y;\n  return vec2(cos(r) * l, sin(r) * l);\n}\n\nvoid main () {\n  // float progress = max(uProgress - random * delay, 0.);\n  float progress = clamp((timestamp - mouse.z) * speed, 0., 1.);\n  progress *= step(0., mouse.x);\n\n  float startX = mouse.x - resolution.x / 2.;\n  float startY = mouse.y - resolution.y / 2.;\n  vec3 startPosition = vec3(startX, startY, random);\n\n  float diff = clamp(mouse.w / maxDiff, 0., 1.);\n  diff = pow(diff, diffPow);\n\n  vec3 cPosition = position * 2. - 1.;\n\n  float radian = cPosition.x * PI2 - PI;\n  vec2 xySpread = vec2(cos(radian), sin(radian)) * spread * mix(1., maxSpread, diff) * cPosition.y;\n\n  vec3 endPosition = startPosition;\n  endPosition.xy += xySpread;\n  endPosition.xy -= aFront * far * random;\n  endPosition.z += cPosition.z * maxZ * (pixelRatio > 1. ? 1.2 : 1.);\n\n  float positionProgress = cubicOut(progress * random);\n  // float positionProgress = cubicBezier(.29, .16, .3, 1., progress);\n  vec3 currentPosition = mix(startPosition, endPosition, positionProgress);\n\n  vProgress = progress;\n  vRandom = random;\n  vDiff = diff;\n  vSpreadLength = cPosition.y;\n  vPositionZ = position.z;\n\n  gl_Position = projectionMatrix * modelViewMatrix * vec4(currentPosition, 1.);\n  gl_PointSize = max(currentPosition.z * size * diff * pixelRatio, minSize * (pixelRatio > 1. ? 1.3 : 1.));\n}\n";
  var re = {};
  re =
    "precision highp float;\nprecision highp int;\n#define GLSLIFY 1\n\n// uniform float uProgress;\nuniform float fadeSpeed;\nuniform float shortRangeFadeSpeed;\nuniform float minFlashingSpeed;\nuniform float blur;\n\nvarying float vProgress;\nvarying float vRandom;\nvarying float vDiff;\nvarying float vSpreadLength;\nvarying float vPositionZ;\n\nhighp float random(vec2 co)\n{\n    highp float a = 12.9898;\n    highp float b = 78.233;\n    highp float c = 43758.5453;\n    highp float dt= dot(co.xy ,vec2(a,b));\n    highp float sn= mod(dt,3.14);\n    return fract(sin(sn) * c);\n}\n\nfloat quadraticIn(float t) {\n  return t * t;\n}\n\n#ifndef HALF_PI\n#define HALF_PI 1.5707963267948966\n#endif\n\nfloat sineOut(float t) {\n  return sin(t * HALF_PI);\n}\n\nconst vec3 baseColor = vec3(170., 133., 88.) / 255.;\n\nvoid main(){\n	vec2 p = gl_PointCoord * 2. - 1.;\n	float len = length(p);\n\n  float cRandom = random(vec2(vProgress * mix(minFlashingSpeed, 1., vRandom)));\n  cRandom = mix(0.3, 2., cRandom);\n\n  float cBlur = blur * mix(1., 0.3, vPositionZ);\n	float shape = smoothstep(1. - cBlur, 1. + cBlur, (1. - cBlur) / len);\n  shape *= mix(0.5, 1., vRandom);\n\n  if (shape == 0.) discard;\n\n  float darkness = mix(0.1, 1., vPositionZ);\n\n  float alphaProgress = vProgress * fadeSpeed * mix(2.5, 1., pow(vDiff, 0.6));\n  alphaProgress *= mix(shortRangeFadeSpeed, 1., sineOut(vSpreadLength) * quadraticIn(vDiff));\n  float alpha = 1. - min(alphaProgress, 1.);\n  alpha *= cRandom * vDiff;\n\n	gl_FragColor = vec4(baseColor * darkness * cRandom, shape * alpha);\n}\n";
  var oe = 800,
    se = 400 * oe,
    le = 4,
    ue = 2,
    ce = { visible: { value: !0 } },
    he = {
      size: { value: 0.05, range: [0, 1] },
      minSize: { value: 1, range: [0, 5] },
      speed: { value: 0.012, range: [0, 0.05] },
      fadeSpeed: { value: 1.1, range: [1, 2] },
      shortRangeFadeSpeed: { value: 1.3, range: [1, 5] },
      minFlashingSpeed: { value: 0.1, range: [0, 1] },
      spread: { value: 7, range: [0, 20] },
      maxSpread: { value: 5, range: [1, 20] },
      maxZ: { value: 100, range: [0, 500] },
      blur: { value: 1, range: [0, 1] },
      far: { value: 10, range: [0, 100] },
      maxDiff: { value: 100, range: [0, 1e3] },
      diffPow: { value: 0.24, range: [0, 10] },
    },
    fe = Object.keys(he),
    de = (function () {
      function e() {
        var n = this;
        Q(this, e);
        var i = ie.root,
          a = ie.controller;
        (this.root = i), (this.rate = 1), this.setSize();
        var r = a.addFolder("Shooting Star");
        this.datData = a.addData(ce, { folder: r });
        var o = new THREE.Vector2(),
          s = {
            resolution: { value: ie.resolution },
            pixelRatio: { value: i.renderer.getPixelRatio() },
            timestamp: { value: 0 },
          };
        this.datUniformData = a.addUniformData(he, s, { folder: r });
        for (
          var l = (this.geometry = new THREE.BufferGeometry()),
            u = [],
            c = [],
            h = [],
            f = [],
            d = 0;
          se > d;
          d++
        )
          u.push(Math.random(), Math.random(), Math.random()),
            c.push(-1, -1, 0, 0),
            h.push(o.x, o.y),
            f.push(Math.random());
        l.addAttribute("position", new THREE.Float32BufferAttribute(u, 3)),
          l.addAttribute("mouse", new THREE.Float32BufferAttribute(c, le)),
          l.addAttribute("aFront", new THREE.Float32BufferAttribute(h, ue)),
          l.addAttribute("random", new THREE.Float32BufferAttribute(f, 1));
        var v = t(ae),
          m = t(re),
          p = (this.material = new THREE.RawShaderMaterial({
            uniforms: s,
            vertexShader: v.d,
            fragmentShader: m.d,
            transparent: !0,
            depthTest: !1,
            blending: THREE.AdditiveBlending,
          })),
          g = (this.mesh = new THREE.Points(l, p));
        (g.frustumCulled = !1),
          (g.visible = this.datData.visible),
          i.add(g),
          (this.mouseI = 0),
          (this.lineCoordinateList = []),
          (this.enableSaveCoordinate = !1),
          i.addResizeCallback(function () {
            n.setSize(), (p.uniforms.resolution.value = ie.resolution);
          }),
          i.addUpdateCallback(function (t) {
            n.update(t);
          });
      }
      return (
        _(e, [
          {
            key: "setSize",
            value: function () {
              (this.rate = Math.min(
                ie.ratio > ie.initialRatio
                  ? ie.clientHeight / ie.initialClientHeight
                  : ie.clientWidth / ie.initialClientWidth,
                1
              )),
                (this.rate *= 1 / (ie.clientHeight / ie.initialClientHeight));
            },
          },
          {
            key: "update",
            value: function (t) {
              var e = this;
              (this.timestamp = t),
                (this.material.uniforms.timestamp.value = t),
                (this.mesh.visible = this.datData.visible),
                fe.forEach(function (t) {
                  e.material.uniforms[t].value = e.datUniformData[t];
                });
            },
          },
          {
            key: "draw",
            value: function (t) {
              var e = t.clientX,
                n = t.clientY;
              this.enableSaveCoordinate &&
                this.lineCoordinateList.push({ clientX: e, clientY: n });
              for (
                var i = e * this.rate + ie.clientHalfWidth,
                  a = ie.clientHeight - (n * this.rate + ie.clientHalfHeight),
                  r = new THREE.Vector2(i, a),
                  o = this.oldPosition
                    ? r.clone().sub(this.oldPosition)
                    : new THREE.Vector2(),
                  s = o.length(),
                  l = o.clone().normalize(),
                  u = 0;
                oe > u;
                u++
              ) {
                var c = (this.mouseI % (se * le)) + u * le,
                  h = this.oldPosition
                    ? this.oldPosition
                        .clone()
                        .add(o.clone().multiplyScalar(u / oe))
                    : r;
                (this.geometry.attributes.mouse.array[c] = h.x),
                  (this.geometry.attributes.mouse.array[c + 1] = h.y),
                  (this.geometry.attributes.mouse.array[c + 2] =
                    this.timestamp),
                  (this.geometry.attributes.mouse.array[c + 3] = s),
                  (this.geometry.attributes.aFront.array[c] = l.x),
                  (this.geometry.attributes.aFront.array[c + 1] = l.y);
              }
              (this.oldPosition = r),
                (this.geometry.attributes.mouse.needsUpdate = !0),
                (this.geometry.attributes.aFront.needsUpdate = !0),
                (this.mouseI += le * oe);
            },
          },
          {
            key: "start",
            value: function () {
              var t = this;
              (this.oldPosition = null),
                window.addEventListener("pointermove", function (e) {
                  var n = e.clientX,
                    i = e.clientY;
                  t.draw({
                    clientX: n - ie.clientHalfWidth,
                    clientY: i - ie.clientHalfHeight,
                  });
                }),
                window.addEventListener("touchmove", function (e) {
                  var n = e.touches[0],
                    i = n.clientX,
                    a = n.clientY;
                  t.draw({
                    clientX: i - ie.clientHalfWidth,
                    clientY: a - ie.clientHalfHeight,
                  });
                });
            },
          },
        ]),
        e
      );
    })(),
    ve = {};
  ve =
    "precision highp float;\nprecision highp int;\n#define GLSLIFY 1\nattribute vec3 position;\nattribute vec2 uv;\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\n\nvarying vec2 vUv;\n\nvoid main () {\n  vUv = uv;\n  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.);\n}\n";
  var me = {};
  me =
    "precision highp float;\nprecision highp int;\n#define GLSLIFY 1\n\nuniform sampler2D map;\nuniform float uProgress;\nuniform float uStartX;\nuniform float uRatio;\nuniform float alpha;\n\nvarying vec2 vUv;\n\nvoid main(){\n	vec4 textureColor = texture2D(map, vUv);\n	float angle = uRatio / 3.;\n	float isShow = step(1., 1. - vUv.x + (uProgress / uStartX * 0.5 + 0.5) - abs(vUv.y - 0.5) / angle);\n	gl_FragColor = vec4(textureColor.rgb, textureColor.a * alpha * isShow);\n	// gl_FragColor = vec4(isShow);\n}\n";
  var pe = "",
    ge = 30,
    ye = 24,
    be = 20,
    we = 0.18,
    Pe = 0.1,
    xe = "Georgia, serif",
    Ee = "#fff",
    Se = {
      visible: { value: !0 },
      duration: { value: 1080, range: [0, 5e3] },
      easing: { value: "easeOutQuint", range: [ne] },
    },
    Re = { alpha: { value: 0.8, range: [0, 1] } },
    ke = Object.keys(Re),
    Ce = (function () {
      function e() {
        var n = this;
        G(this, e);
        var i = ie.root,
          a = ie.controller,
          r = (this.folder = a.addFolder("Text"));
        this.datData = a.addData(Se, { folder: r });
        var o = ie.clientWidth < 360 ? be : ie.clientWidth < 768 ? ye : ge,
          s = ie.clientWidth < 768 ? Pe : we,
          l = (pe.length + s * (pe.length - 1), 1.2 * o),
          u = window.devicePixelRatio,
          c = X({
            text: pe,
            fontSize: o,
            height: l,
            letterSpacing: s,
            font: xe,
            color: Ee,
            pixelRatio: u,
          }),
          h = c.width / u,
          f = c.height / u,
          d = h / 2,
          v = new THREE.Texture(c);
        (v.needsUpdate = !0), (v.minFilter = THREE.LinearFilter);
        var m = new THREE.PlaneBufferGeometry(h, f),
          p = {
            map: { value: v },
            uProgress: { value: -ie.clientHalfWidth },
            uStartX: { value: ie.clientHalfWidth - d },
            uRatio: { value: h / f },
          };
        this.datUniformData = a.addUniformData(Re, p, { folder: r });
        var g = t(ve),
          y = t(me),
          b = (this.material = new THREE.RawShaderMaterial({
            uniforms: p,
            vertexShader: g.d,
            fragmentShader: y.d,
            transparent: !0,
          })),
          w = (this.mesh = new THREE.Mesh(m, b));
        (w.frustumCulled = !1),
          (w.visible = this.datData.visible),
          w.position.setZ(0.1),
          i.add(w),
          i.addUpdateCallback(function () {
            (n.mesh.visible = n.datData.visible),
              ke.forEach(function (t) {
                n.material.uniforms[t].value = n.datUniformData[t];
              });
          });
      }
      return (
        Z(e, [
          {
            key: "update",
            value: function (t) {
              this.material.uniforms.uProgress.value = t;
            },
          },
        ]),
        e
      );
    })(),
    He = 5e3,
    Te = 5e3,
    Ie = 1080,
    Fe = 300,
    Me = { play: { value: null } },
    Oe = (function () {
      function t(e) {
        var n = this,
          i = e.canvas,
          a = e.container,
          r = void 0 === a ? document.body : a;
        N(this, t);
        var o = new te({ closed: !0 });
        ie.controller = o;
        var s =
          ((ie.initialClientWidth = r.clientWidth),
          (ie.initialClientHeight = r.clientHeight));
        ie.initialRatio = 1;
        var l =
          (this.root =
          ie.root =
            new $({
              isDev: !0,
              container: r,
              fov: Math.atan(s / 2 / He) * (180 / Math.PI) * 2,
              zFar: Te,
              cameraPosition: [0, 0, He],
              aspect: window.innerWidth / window.innerHeight,
              canvas: i,
            }));
        this.setSize(),
          l.addResizeCallback(function () {
            n.setSize();
          }),
          (this.text = new Ce()),
          (this.shootingStar = new de()),
          (Me.play.value = function () {
            n.textStart();
          }),
          o.addData(Me, { folder: this.text.folder });
      }
      return (
        K(t, [
          {
            key: "setSize",
            value: function () {
              var t = (ie.clientWidth = this.root.canvas.clientWidth),
                e = (ie.clientHeight = this.root.canvas.clientHeight);
              (ie.clientHalfWidth = t / 2),
                (ie.clientHalfHeight = e / 2),
                (ie.resolution = new THREE.Vector2(t, e)),
                (ie.ratio = t / e);
            },
          },
          {
            key: "start",
            value: function () {
              {
                var t = this;
                3 * Math.PI, Math.min(Math.max(0.1 * ie.clientWidth, 100), 180);
              }
              q(function () {}, {
                duration: Ie,
                onAfter: function () {
                  t.shootingStar.draw({
                    clientX: -ie.clientHalfWidth,
                    clientY: ie.clientHeight - ie.clientHalfHeight,
                  }),
                    t.shootingStar.draw({
                      clientX: 1.1 * -ie.clientHalfWidth,
                      clientY: 0,
                    }),
                    setTimeout(function () {
                      t.textStart();
                    }, 300);
                },
              });
            },
          },
          {
            key: "textStart",
            value: function () {
              var t = this;
              q(
                function (e) {
                  t.text.update(e - 0.08 * ie.clientWidth);
                },
                {
                  begin: 1.1 * -ie.clientHalfWidth,
                  finish: 1.1 * ie.clientHalfWidth,
                  duration: this.text.datData.duration,
                  easing: this.text.datData.easing,
                  onAfter: function () {
                    t.shootingStar.start(),
                      document.body.classList.add("o-start");
                  },
                }
              );
            },
          },
        ]),
        t
      );
    })(),
    ze = new Oe({ canvas: document.getElementById("canvas") });
  return (
    setTimeout(function () {
      ze.start();
    }, Fe),
    { Focm: {} }
  );
});
