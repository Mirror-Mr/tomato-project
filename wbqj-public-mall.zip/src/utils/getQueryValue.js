// variable：想要获取的参数名
export function getQueryValue(variable) {
    if (window.location.href.indexOf(variable) == -1) {
        return null
    }
    var arr = window.location.href.split('?')
    var query = arr[arr.length - 1];
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) {
            return pair[1].split("#")[0];
        }
    }
    return null;
}
// 获取链接上的全部参数 返回对象
export function getAllQueryValue() {
    var queryObject={};
    var arr = window.location.href.split('?')
    if(arr.length < 2){
        return null;
    }
    var query = arr[arr.length - 1];
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        queryObject[pair[0]]=pair[1]
    }
    return queryObject;
}

