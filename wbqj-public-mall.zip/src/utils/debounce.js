// 防抖(设置的时间内，频繁触发，只执行最后一次)
export function debounce(func, params, time) {
  let timer ;
  return function () {
    // console.log(timer)
    if (timer) {
      clearTimeout(timer);
    }
    let that = this;
    timer = setTimeout(() => {
      func.call(that, params);
    }, time);
  };
}
// 节流 (是延迟定时多次调用)
export function throttle(func, wait = 0, execFirstCall) {
  let timeout = null;
  let firstCallTimestamp;
  function throttled(...args) {
    if (!firstCallTimestamp) firstCallTimestamp = new Date().getTime();
    if (!execFirstCall || !args) {
    }
    if (timeout) {
      clearTimeout(timeout);
      timeout = null;
    }
    // 以Promise的形式返回函数执行结果
    return new Promise(async (res, rej) => {
      if (new Date().getTime() - firstCallTimestamp >= wait) {
        try {
          const result = await func.apply(this, args);
          res(result);
        } catch (e) {
          rej(e);
        } finally {
          cancel();
        }
      } else {
        timeout = setTimeout(async () => {
          try {
            const result = await func.apply(this, args);
            res(result);
          } catch (e) {
            rej(e);
          } finally {
            cancel();
          }
        }, firstCallTimestamp + wait - new Date().getTime());
      }
    });
  }
  // 允许取消
  function cancel() {
    clearTimeout(timeout);
    args = null;
    timeout = null;
    firstCallTimestamp = null;
  }
  // 允许立即执行
  function flush() {
    cancel();
    return func.apply(this, args);
  }
  throttled.cancel = cancel;

  throttled.flush = flush;

  return throttled;
}
// 是否为微信
export function isWeChat() {
    //window.navigator.userAgent属性包含了浏览器类型、版本、操作系统类型、浏览器引擎类型等信息，这个属性可以用来判断浏览器类型
    var ua = window.navigator.userAgent.toLowerCase(); //通过正则表达式匹配ua中是否含有MicroMessenger字符串
    return ua.match(/MicroMessenger/i) == "micromessenger";
  }