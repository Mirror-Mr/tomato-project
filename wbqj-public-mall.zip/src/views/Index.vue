<template>
  <div class="index flexColumnCenter">
    <!-- 登录提示 -->
    <div class="login-msg flexColumnCenter">
      <div class="no-login" v-if="!roleMsg.role_id">
        <span
          @click="setIsMaskShow('chooseLoginWay')"
          v-if="Object.keys(loginUserMsg).length == 0"
          >【登录】</span
        >
        <div v-else class="no-bind">
          <span
            v-debounce="
              () => {
                changeRole(0);
              }
            "
            >【绑定角色】</span
          >
          <br />
          <span @click="logOut">【注销】 </span>
        </div>
      </div>
      <div class="logined" v-else>
        欢迎您，{{ roleMsg.role_name }}
        <span
          v-debounce="
            () => {
              changeRole(1);
            }
          "
          >【切换角色】
        </span>
        <br />
        <span @click="logOut">【注销】 </span>
      </div>
    </div>
    <!-- 客服 -->
    <div class="btn-server" @click="toServer">
      <img
        src="https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/btn-server.png"
        alt=""
      />
      <span>联系客服</span>
    </div>
    <!-- 侧边栏 -->
    <div class="slide-bar">
      <div
        class="innerCenter check-order"
        v-debounce="
          () => {
            judgeUserInfo(() => {
              setIsMaskShow('checkOrder');
              getShopHistory();
            }, '');
          }
        "
      ></div>
      <div
        class="innerCenter activity-rule"
        @click="setIsMaskShow('activityRule')"
      ></div>
    </div>
    <div class="scroll-container flexColumnCenter">
      <!-- 主要买礼包的地儿 -->
      <div class="main-container">
        <!-- 顶部背景 -->
        <div class="bg-top"></div>
        <!-- 底部背景 -->
        <div class="bg-btm"></div>
        <!-- 切换按钮 -->
        <div class="btn-group">
          <div @click="index = 1" :class="{ choose: index == 1 }"></div>
          <div @click="index = 2" :class="{ choose: index == 2 }"></div>
        </div>
        <!-- 回旋针装饰 -->
        <div class="needle"></div>
        <!-- 礼包们 -->
        <div class="gift-bags flexColumnCenter">
          <Bag
            v-for="item in index == 1 ? bagMsg_blue : bagMsg_purple"
            :key="item.id"
            :bagMsg="item"
            :type="index"
            @setIsMaskShow="setIsMaskShow"
            @setMaskTitle="setMaskTitle"
            @getRoleInfo="getRoleInfo"
          />
        </div>
      </div>
    </div>
    <MaskBox
      :maskShow="maskShow"
      @setIsMaskShow="setIsMaskShow"
      @setMaskTitle="setMaskTitle"
      :title="maskTitle"
    >
      <ContentMask
        ref="contentMask"
        :maskShow="maskShow"
        :shopHistory="shopHistory"
        @setIsMaskShow="setIsMaskShow"
        @setMaskTitle="setMaskTitle"
        @setIsMaskShow_btm="setIsMaskShow_btm"
        @getUserInfo="getUserInfo"
        :payMsg="payMsg"
        @getOrderStatus="getOrderStatus"
      />
    </MaskBox>
    <MaskBoxBtm
      :maskShow_btm="maskShow_btm"
      @setIsMaskShow_btm="setIsMaskShow_btm"
    >
    </MaskBoxBtm>
  </div>
</template>

<script>
// import MaskBox from "@/components/MaskBox.vue";

import {
  getUserInfo,
  getGoods,
  getShopHistory,
  getRoleInfo,
  getOrderStatus,
} from "@/api";
// import clickLog from "@/api/toDots.js";
import { getQueryValue } from "@/utils/getQueryValue.js";
import { mapState } from "vuex";
import { isWeChat } from "@/utils/debounce.js";
import icon_mall from "@/assets/js/icon_mall.js";
export default {
  name: "Index",
  components: {
    MaskBox: (resolve) => require(["@/components/MaskBox.vue"], resolve),
    MaskBoxBtm: (resolve) => require(["@/components/MaskBox_btm.vue"], resolve),
    ContentMask: (resolve) =>
      require(["@/components/ContentMask.vue"], resolve),
    Bag: (resolve) => require(["@/components/Bag.vue"], resolve),
  },
  data() {
    return {
      time: Date.now(),
      index: 1,
      // 礼包集每周
      bagMsg_purple: [
        {
          id: 1,
          good_name: "12312323",
          old_price: 999,
          price: 726,
          limit_num: 10,
          gift: "",
        },
      ],
      // 礼包集每日
      bagMsg_blue: [
        {
          id: 1,
          good_name: "猫猫肚肚饿礼包",
          old_price: 999,
          price: 726,
          limit_num: 10,
          gift: "",
        },
      ],
      // 当前显示的是哪个弹框 ""则不显示弹框
      maskShow: "",
      // 弹框标题
      maskTitle: "",

      // 底部弹框显示哪个 ""则不显示弹框
      maskShow_btm: "",
      //订单列表
      shopHistory: [],
      //   购买的信息
      payMsg: {},
      // 商品icon数组
      icon_mall: icon_mall,
    };
  },
  methods: {
    // 展示弹框
    showMask(n) {
      this.setIsMaskShow(n);
    },
    // 设置弹框是否展示
    setIsMaskShow(n) {
      this.maskShow = n;
    },
    // 设置底部弹框是否显示
    setIsMaskShow_btm(n) {
      this.maskShow_btm = n;
    },

    // 设置弹框标题
    setMaskTitle(title) {
      this.maskTitle = title;
    },

    // 切换/绑定角色
    changeRole(n) {
      this.setIsMaskShow("bindRole");
      this.getRoleInfo();
      const title = n ? "切换角色" : "绑定角色";
      this.setMaskTitle(title);
      if (n) {
        //   切换角色
        this.$nextTick(() => {
          this.$bus.$emit("showNowRole");
        });
        this.setMaskTitle("切换角色");
      } else {
      }
    },
    // 获取用户信息
    getUserInfo() {
      let { time } = this;
      const { token, uid } = this.loginUserMsg;
      getUserInfo({ time, token, uid }, { time, token }).then((res) => {
        if (res.status == 1) {
          this.$store.commit("SET_lOGINUSERMSG", res.data);
          // if(res.data.info.rid){
          // 登录用户曾经绑定过角色 则直接绑定
          // }
        } else {
          let errMsg =
            res.status == 4040 ? "登录过期，请重新登录" : "获取用户信息失败";
          this.$toast.fail(errMsg);
          res.status == 4040 ? this.logOut() : "";
        }
      });
    },
    // 获取角色列表
    getRoleInfo() {
      let { time } = this;
      const { token, uid } = this.loginUserMsg;
      getRoleInfo({ time, token, uid }, { time, token }).then((res) => {
        if (res.status == 1) {
          this.$store.commit("SET_ROLELIST", res.data);
        } else {
          let errMsg =
            res.status == 4040
              ? "登录过期，请重新登录"
              : "获取角色列表信息失败！";
          this.$toast.fail(errMsg);
          res.status == 4040 ? this.logOut() : "";
        }
      });
    },
    // 客服
    toServer() {
      window.open(
        "https://wpa1.qq.com/a03J4kQX?_type=wpa&qidian=true",
        "_blank"
      );
    },
    // 注销
    logOut() {
      this.$store.commit("SET_lOGINUSERMSG", {});
      this.$store.commit("SET_ROLEMSG", {});
      localStorage.removeItem("userInfo");
      localStorage.removeItem("roleMsg");
    },

    // 获取商品列表
    getGoods() {
      getGoods({ time: this.time }, { time: this.time }).then((res) => {
        if (res.status == 1) {
          this.bagMsg_purple = [...res.data[1].lists];
          this.bagMsg_blue = [...res.data[0].lists];
          //   this.bagMsg_purple = res.data
          //     .filter((bag) => bag.type == 2)
          //     .map((bag) => ({ ...bag, gift: JSON.parse(bag.gift) }));
          //   this.bagMsg_blue = res.data
          //     .filter((bag) => bag.type == 1)
          //     .map((bag) => ({ ...bag, gift: JSON.parse(bag.gift) }));
        } else {
          if (res.status == 4040) {
            this.logOut();
            this.$toast.fail("登录过期，请重新登录");
            return;
          }
          this.$toast.fail(res.msg);
        }
      });
    },
    // 获取历史订单
    getShopHistory() {
      const { time } = this;
      const { token, uid } = this.loginUserMsg;
      getShopHistory({ time, token, uid }, { time, token }).then((res) => {
        if (res.status == 1) {
          this.shopHistory = res.data.filter((item) => {
            return item.status != 0;
          });
        } else {
          if (res.status == 4040) {
            this.logOut();
            this.$toast.fail("登录过期，请重新登录");
            return;
          }
          this.$toast.fail(res.msg);
        }
      });
    },
    // 获取订单状态
    // getOrderStatus(orderid, good_id, params) {
    getOrderStatus(orderid) {
      const { time } = this;
      const { token, uid } = this.loginUserMsg;
      this.payMsg = { ...JSON.parse(localStorage.getItem("payMsg")) };
      getOrderStatus({ time, token, orderid, uid }, { time, token }).then(
        (res) => {
          if (res.status == 1) {
            if (res.data > 0) {
              this.$toast("支付成功");
              clearInterval(this.timer);
              // 获取用户信息
              this.getUserInfo();
              // 弹出弹框
              this.setIsMaskShow("buySuccess");
              this.setMaskTitle("购买成功");
              localStorage.removeItem("payMsg");
            }
          } else {
            // this.$toast("获取订单状态失败", res.msg);
          }
        }
      );
    },
    // 判断是否有用户登录
    judgeUserInfo(func, params, flag = true) {
      if (Object.keys(this.loginUserMsg).length == 0) {
        // 未登录
        this.setIsMaskShow("chooseLoginWay");
        return;
      }
      if (!this.roleMsg.role_id) {
        //   已登录 未绑定
        this.setIsMaskShow("bindRole");
        this.setMaskTitle("绑定角色");
        this.getRoleInfo();
        return;
      }
      // 已登录
      func(params);
    },
  },
  computed: {
    ...mapState(["loginUserMsg", "roleMsg"]),
  },
  mounted() {
    // 获取商品列表
    this.getGoods();
    // 判断是否微信环境
    if (isWeChat()) {
      const wxid = getQueryValue("wxid");
      if (wxid) {
        sessionStorage.setItem("wxid", wxid);
      }
      let data = sessionStorage.getItem("wxid");
      if (!data) {
        //   没有wxid则跳转
        location.href = `https://api.xianyuyouxi.com/service/shop/Wbqj_shop/getauth`;
      }
    }
    // // 如果是在支付页面点击<返回的 如果是在支付页通过滑动屏幕返回
    const orderid = getQueryValue("orderid");
    if (orderid) {
      history.replaceState({}, "", location.href.split("?")[0]);
      let i = 0;
      this.timer = setInterval(() => {
        // this.getOrderStatus(orderid, good_id, params);
        this.getOrderStatus(orderid);
        if (i > 30) {
          clearInterval(this.timer);
          localStorage.removeItem("payMsg");
        }
        i++;
      }, 1000);
    } else {
      const payMsg = localStorage.getItem("payMsg");
      if (payMsg) {
        // 如果曾经支付过
        this.payMsg = { ...JSON.parse(payMsg) };
        let i = 0;
        this.timer = setInterval(() => {
          // this.getOrderStatus(orderid, good_id, params);
          this.getOrderStatus(this.payMsg.orderid);
          if (i > 30) {
            clearInterval(this.timer);
            localStorage.removeItem("payMsg");
          }
          i++;
        }, 1000);
      }
    }
    // debugger;
    // if (Object.keys(this.loginUserMsg).length == 0) {
    // 没登陆 则看本地是否有token uid
    const userInfo = localStorage.getItem("userInfo");
    if (userInfo) {
      // 有本地token uid则直接获取用户信息
      this.$store.commit("SET_lOGINUSERMSG", JSON.parse(userInfo));
      const roleMsg = localStorage.getItem("roleMsg");
      if (roleMsg) {
        this.$store.commit("SET_ROLEMSG", JSON.parse(roleMsg));
      }

      this.setIsMaskShow("blank");
      // 获取角色信息
      // this.$nextTick(() => {
      //   setTimeout(() => {
      // this.$bus.$emit("getUserInfo");
      this.getUserInfo();
      //   }, 500);
      // });
    }
    // } else {
    // 已登录 更新信息
    //   this.getUserInfo();
    // }
  },
  created() {
    if (localStorage.getItem("payMsg")) {
      this.payMsg = { ...JSON.parse(localStorage.getItem("payMsg")) };
      this.index = this.payMsg.type;
    }
  },
  watch: {},
};
</script>
<style lang="scss" scoped>
.index{
  width: 100%;
	height: 100%;
  // position: relative;
	position: fixed;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	overflow: hidden;
  background-image: imgUrl("bg.jpg?v=0.0");
  .login-msg{
    height: 10vw;
    position: fixed;
    // position: absolute;
    top: 4.5vw;
    right: 2vw;
		z-index: 2;
    .no-login{
      color: #4D4187;
      font-size: 3.5vw;
      .no-bind{
        display: inline;
        line-height: 5vw;
        span{
            &:nth-of-type(2){
                float: right;
            }
        }
      }
    }
    .logined{
      color: #4D4187;
      font-size: 3.5vw;
      line-height: 5vw;
      span{
            &:nth-of-type(2){
                float: right;
            }
        }
    }
  }
  .btn-server{
      display: flex;
      align-items: center;
      position: absolute;
      top: 4.5vw;
      left: 4vw;
      font-size: 3.5vw;
			z-index: 2;
      img{
          width: 1rem;
          margin: 0 0.3rem 0 0;
      }
      span{
          color:#4D4187;
          border-bottom: 1px solid #4D4187;
      }
  }
  .slide-bar{
    height: 24vw;
    position: absolute;
    right: 0;
    top: 48vw;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
		z-index: 4;
    div{
      width: 10.9vw;
      height: 11.5vw;
    }
    div:nth-of-type(1){
      background-image: imgUrl("btn_check_order.png");
    }
    div:nth-of-type(2){
      background-image: imgUrl("btn_activity_rule.png");
    }
  }
	.scroll-container{
		overflow-y: auto;
	}
  .main-container{
    width: 90%;
    margin:94vw 0 0 0;
		position:relative;
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
    background-image: imgUrl("bg_main_container_main.png");
    background-repeat: repeat;
		z-index: 3;
    .bg-top{
        width: 100%;
        height: 20vw;
        background-image: imgUrl("bg_main_container_top.png");
        position: absolute;
        top: -20vw;
        left: 0;
    }   
    .bg-btm{
        width: 100%;
        height: 17vw;
        position: absolute;
        bottom: -17vw;
        left: 0;
        background-image: imgUrl("bg_main_container_btm.png");
    }
    .btn-group{
        width:61%;
        display: flex;
        position: absolute;
        top: -21.8vw;
        left: 6vw;
        div{
            width: 27.9vw;
            height: 9.4vw;
            &:nth-of-type(1){
                background-image: imgUrl("btn_day_normal.png");
                &.choose{
                    background-image: imgUrl("btn_day_choose.png");
                }
            }
            &:nth-of-type(2){
                background-image: imgUrl("btn_week_normal.png");
                &.choose{
                    background-image: imgUrl("btn_week_choose.png");
                }
            }
        }
    }
    .needle{
        width: 18vw;
        height: 9.1vw;
        position: absolute;
        top:-10vw;
        left: -6vw;
        background-image: imgUrl("needle.png");
    }
    .gift-bags{
        width: 100%;
        margin:0 0 0 0;
    }
  }

  
}
</style>
