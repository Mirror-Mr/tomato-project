<template>
  <div class="blank">
    <img
      src="https://wcdn.tomatogames.com/web/guonei/wbqj/answer-h5/imgs/download-tips.png"
      alt=""
      v-if="showTip"
    />
  </div>
</template>
<script>
import { getQueryValue } from "@/utils/getQueryValue";
export default {
  name: "Blank",
  data() {
    return {
      USER_AGENT: navigator.userAgent,
      showTip: false,
    };
  },
  methods: {},
  computed: {
    isWeixin() {
      return /micromessenger/i.test(this.USER_AGENT);
    },
    isQQ() {
      return this.USER_AGENT.indexOf("QQ/") !== -1;
    },
  },
  mounted() {
    const type = getQueryValue("type");
    type == 1
      ? ta.track(
          "web_wbqj_xjds_frompage1_download" //追踪事件的名称 - 【扫描了分享页1-二维码1（下载页面）】
        )
      : ta.track(
          "web_wbqj_xjds_page2_scan" //追踪事件的名称 - 【扫描了分享页2二维码（下载页面）】
        );
    let u = navigator.userAgent;
    let isAndroid = u.indexOf("Android") > -1 || u.indexOf("Adr") > -1; //android终端
    let isiOS = !!u.match(/Mac OS X/); //ios终端
    if (isiOS) {
      window.location.href =
        "https://apple-app-site-wbqj.tomatogames.com/open-app";
    } else {
      if (this.isWeixin) {
        this.showTip = true;
        return;
      }
      window.location.href =
        "https://source-apk.tomatogames.com/sem/apk/wbqj/gdtyl01/wbqj_and_gdtyl01_02.apk";
    }
  },
};
</script>
<style scoped lang='scss'>
.blank{
    display: flex;
    justify-content: flex-end;
    img{
        width: 70vw;
        margin:2vw 5vw 0 0
    }
}
</style>