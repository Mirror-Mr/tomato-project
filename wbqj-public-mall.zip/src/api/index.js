/**
 * 接口
 */

import { post , get } from "@/utils/request";

const baseUrl = "/shop/Wbqj_shop";

// 账密登录
export function login(params,headers){
    return post(baseUrl+"/login",params,headers)
}
// 手机获取账号登录
export function plogin(params,headers){
    return post(baseUrl+"/plogin",params,headers)
}
// 手机登录获取账号列表
export function getAccountList(params,headers){
    return post(baseUrl+"/getAccountList",params,headers)
}
// 获取用户信息
export function getUserInfo(params,headers){
    return post(baseUrl+"/getUserInfo",params,headers)
}
// 绑定角色
export function bindRole(params,headers){
    return post(baseUrl+"/bindRole",params,headers)
}
// 获取获奖信息
export function getGoods(params,headers){
    return post(baseUrl+"/getGoods",params,headers)
}
// 领奖
export function getShopHistory(params,headers){
    return post(baseUrl+"/getShopHistory",params,headers)
}

// 购买
export function pay(params,headers){
    return post(baseUrl+"/pay",params,headers)
}
// 获取角色列表
export function getRoleInfo(params,headers){
    return post(baseUrl+"/getRoleInfo",params,headers)
}
// 获取订单状态
export function getOrderStatus(params,headers){
    return post(baseUrl+"/getOrderStatus",params,headers)
}


