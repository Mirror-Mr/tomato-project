<template>
  <div
    class="bag flexColumnCenter"
    v-debounce="
      () => {
        buyBag();
      }
    "
  >
    <div class="top">
      <img
        :src="
          bagMsg.icon
            ? bagMsg.icon
            : type == 1
            ? 'https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/img_gift_bag_blue.png'
            : 'https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/img_gift_bag.png'
        "
        alt=""
      />
      <div class="content flexColumnCenter">
        <div class="f1">
          <span>推荐</span>
          <span>{{ bagMsg.name }}</span>
          <span class="look">浏览详情</span>
        </div>
        <div class="f2">
          <span v-for="(gift, index) in bagMsg.lists" :key="gift.id"
            >{{ gift.name }}*{{ gift.num }}
            <b v-if="index != bagMsg.lists.length - 1">、</b>
          </span>
          <!-- <span>{{bagMsg.gift}}</span> -->
        </div>
        <!-- <span class="look">浏览详情</span> -->
        <div class="f3">
          <span>￥{{ bagMsg.oldprice }}</span>
          <div class="innerCenter"><b>￥</b>{{ bagMsg.price }}</div>
        </div>
      </div>
    </div>
    <div class="btm">
      <b
        >本<span v-if="type == 1">日</span> <span v-else>周</span>限购
        {{ buyNum }} / {{ bagMsg.limit_num }}</b
      >
      <span class="btn">点击购买</span>
    </div>
  </div>
</template>
<script>
import { mapState } from "vuex";
export default {
  name: "Bag",
  props: {
    bagMsg: {
      type: Object,
      required: true,
    },
    type: {
      type: Number,
      required: true,
    },
  },
  data() {
    return {};
  },
  methods: {
    buyBag() {
      // 判断是否超过购买限定
      //   if (this.buyNum >= this.bagMsg.limit_num) {
      //     let text =
      //       this.type == 1 ? "今日购买次数用完咯~" : "本周购买次数用完咯~";
      //     this.$toast(text);
      //     return;
      //   }
      this.$emit("setIsMaskShow", "secondConfirm");
      this.$emit("setMaskTitle", this.bagMsg.name);
      this.$nextTick(() => {
        this.$bus.$emit("setBagMsg", { ...this.bagMsg, type: this.type });
      });
    },
    // 判断是否有用户登录
    // judgeUserInfo(func, params, flag = true) {
    //   if (Object.keys(this.loginUserMsg).length == 0) {
    //     // 未登录
    //     this.$emit("setIsMaskShow", "chooseLoginWay");
    //     return;
    //   }
    //   if (!this.roleMsg.role_id) {
    //     //   已登录 未绑定
    //     this.$emit("setIsMaskShow", "bindRole");
    //     this.$emit("setMaskTitle", "绑定角色");
    //     this.$emit("getRoleInfo");
    //     return;
    //   }
    //   // 已登录
    //   func(params);
    // },
  },
  mounted() {},
  computed: {
    ...mapState(["loginUserMsg", "roleMsg"]),
    // 购买当前礼包的次数
    buyNum() {
      let orders = this.loginUserMsg.orders
        ? this.loginUserMsg.orders[this.type]
        : null;
      if (!orders || Object.keys(orders).length == 0) return 0;
      return orders[this.bagMsg.cid] ? orders[this.bagMsg.cid] : 0;
    },
  },
};
</script>
<style scoped lang='scss'>
.bag{
    width: 86%;
    height: 30.2vw;
    flex-shrink: 0;
    background-image: imgUrl("btn_gift_bag.png");
    &:not(:nth-of-type(1)){
        margin:4vw 0 0 0
    }
    .top{
        width:90%;
        height: 26.6vw;
        display: flex;
        justify-content: space-between;
        img{
            width: 29vw;
            height: auto;
            flex-shrink: 0;
            object-fit:contain
        }
        .content{
            width:52%;
            .f1{
                width:100%;
                display: flex;
                align-items: center;
                margin:3vw 0 0.5vw 0;
                padding:0 0 0.5vw 0;
                border-bottom: 0.01vw dotted #000000;
                .look{
                    margin-left: auto;
                    font-size:2.75vw;
                    color:#A98EFE;
                    text-decoration:underline;
                }
                span{
                    &:nth-of-type(1){
                        width:7.3vw;
                        height: 3.9vw;
                        margin:0 1vw 0 0 ;
                        line-height: 3.9vw;
                        text-align: center;
                        font-size: 2.8vw;
                        color:#fff;
                        display: block;
                        background-color: #FF7A7A ;
                        border-radius: 0.7vw 1.3vw 1.3vw 1.3vw;
                    }
                    &:nth-of-type(2){
                        font-size:3.3vw;
                        color:#6C5BA4 ;
                        float: left;
                        font-weight: bolder;
                    }
                }
            }
            .f2{
                width: 100%;
                height:6.5vw;
                margin: 1vw 0 0 0;
                text-align: justify;
                /* 关键代码 ！！！！ 以下5行 */
                overflow: hidden;
                /* 超出部分设为... */
                text-overflow: ellipsis;
                /* 盒子模型 */
                display: -webkit-box;
                /* 最多2行文本 多余部分隐藏*/
                -webkit-line-clamp: 2;
                /* 从顶部向底部垂直布置子元素 */
                -webkit-box-orient: vertical;
                font-size:2.75vw;
                color:#6C5BA4;
                line-height: 3.5vw;
            }
            &>span{
                margin: 1.3vw 0 0 0;
                font-size:2.4vw;
                color:#2C7AE4;
                text-decoration:underline;
                align-self: flex-end;
            }
            .f3{
                display: flex;
                margin:2vw 0 0 0;
                justify-content: flex-end;
                align-items: center;
                span{
                    width:18vw;
                    font-size:3.5vw;
                    color:#55487B ;
                    text-decoration: line-through red;
                    b{
                        font-size: 3vw;
                    }
                }
                div{
                    width: 15.4vw;
                    height:6vw;
                    // padding:0 0 0 2vw;
                    margin:0 0 0 2vw;
                    background-image: imgUrl("bg_price.png");
                    font-size:3.8vw;
                    color:#fff;
                     b{
                        font-size: 3vw;
                    }
                }
            }
        }
    }
    .btm{
        width: 91%;
        display: flex;
        justify-content: space-between;
        align-items: center;
				font-size: 3.3vw;
				color: #FFFFFF;
        .btn{
					font-size: 2.7vw;
        }
    }
}
</style>