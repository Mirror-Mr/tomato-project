export const midPreview = [
  //   言情甜宠礼包
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/1.png",
    name: "资质券碎片",
    num: 1,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/2.png",
    name: "红与糊Ⅰ",
    num: 1,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/3.png",
    name: "尖叫鸡汤Ⅰ",
    num: 1,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/4.png",
    name: "薄黑学Ⅰ",
    num: 1,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/5.png",
    name: "小蛋糕",
    num: 5,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/6.png",
    name: "随机徽章Ⅰ",
    num: 5,
  },
  // 狗血苦情礼包
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/7.png",
    name: "哑铃",
    num: 5,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/8.png",
    name: "北极贝刺身",
    num: 2,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/9.png",
    name: "大冒险卡",
    num: 3,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/10.png",
    name: "珍珠奶茶",
    num: 5,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/11.png",
    name: "粉玫瑰",
    num: 5,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/12.png",
    name: "小鱼干罐头",
    num: 100,
  },
  // 沙雕情景礼包
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/13.png",
    name: "幸运扭蛋券",
    num: 9,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/14.png",
    name: "复活卡",
    num: 1,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/15.png",
    name: "经验水晶",
    num: 5,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/16.png",
    name: "派对卡",
    num: 2,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/17.png",
    name: "邀约卡",
    num: 2,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/18.png",
    name: "对决卡",
    num: 3,
  },
  // 成功邀请3人
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/19.png",
    name: "肥宅水",
    num: 10,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/5.png",
    name: "小蛋糕",
    num: 10,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/20.png",
    name: "黑金卡",
    num: 10,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/12.png",
    name: "小鱼干罐头",
    num: 15,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/10.png",
    name: "珍珠奶茶",
    num: 3,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/17.png",
    name: "邀约卡",
    num: 1,
  },
  // 成功邀请7人
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/19.png",
    name: "肥宅水",
    num: 20,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/5.png",
    name: "小蛋糕",
    num: 20,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/20.png",
    name: "黑金卡",
    num: 20,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/12.png",
    name: "小鱼干罐头",
    num: 30,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/10.png",
    name: "珍珠奶茶",
    num: 5,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/17.png",
    name: "邀约卡",
    num: 3,
  },
];
export const morePreview = [
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/21.png",
    name: "钻石",
    num: 1000,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/22.png",
    name: "时空盲盒券",
    num: 900,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/23.png",
    name: "心愿卡",
    num: 100,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/24.png",
    name: "高级对决卡",
    num: 1,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/12.png",
    name: "小鱼干罐头",
    num: 100,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/25.png",
    name: "高级经验水晶",
    num: 1,
  },

  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/5.png",
    name: "小蛋糕",
    num: 30,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/19.png",
    name: "肥宅水",
    num: 30,
  },
  {
    imgUrl: "https://wcdn.tomatogames.com/static/WoBenQianJin/xjdds/img/icon/20.png",
    name: "黑金卡",
    num: 30,
  },
];
export const normalGiftList = [
  {
    id: 1,
    name: "头像框-殿堂影后",
    num: 1,
    percent: "8.8%",
    icon:"icon/36"
  },
  {
    id: 2,
    name: "友谊的小船",
    num: 1,
    percent: "0.44%",
    icon:"icon/26"
  },
  {
    id: 3,
    name: "时空盲盒券",
    num: 100,
    percent: "0.88%",
    icon:"icon/22"
  },
  {
    id: 4,
    name: "时空盲盒券",
    num: 10,
    percent: "8.8%",
    icon:"icon/22"
  },
  {
    id: 5,
    name: "心愿卡",
    num: 100,
    percent: "0.18%",
    icon:"icon/23"
  },
  {
    id: 6,
    name: "心愿卡",
    num: 10,
    percent: "1.76%",
    icon:"icon/23"
  },
  {
    id: 7,
    name: "幸运扭蛋券",
    num: 1,
    percent: "1.76%",
    icon:"icon/13"
  },
  {
    id: 8,
    name: "对决卡",
    num: 1,
    percent: "1.76%",
    icon:"icon/18"
  },
  {
    id: 9,
    name: "珍珠奶茶",
    num: 1,
    percent: "5.87%",
    icon:"icon/10"
  },
  {
    id: 10,
    name: "小鱼干罐头",
    num: 5,
    percent: "3.52%",
    icon:"icon/12"
  },
  {
    id: 11,
    name: "随机徽章Ⅰ",
    num: 1,
    percent: "3.52%",
    icon:"icon/6"
  },
  {
    id: 12,
    name: "资质券碎片",
    num: 1,
    percent: "4.4%",
    icon:"icon/1"
  },
  {
    id: 13,
    name: "芒果",
    num: 1,
    percent: "4.4%",
    icon:"icon/27"
  },
  {
    id: 14,
    name: "榛果",
    num: 1,
    percent: "4.4%",
    icon:"icon/28"
  },
  {
    id: 15,
    name: "杏仁",
    num: 1,
    percent: "4.4%",
    icon:"icon/29"
  },
  {
    id: 16,
    name: "芝士",
    num: 1,
    percent: "4.4%",
    icon:"icon/30"
  },
  {
    id: 17,
    name: "小蛋糕",
    num: 1,
    percent: "8.8%",
    icon:"icon/5"
  },
  {
    id: 18,
    name: "肥宅水",
    num: 1,
    percent: "8.8%",
    icon:"icon/19"
  },
  {
    id: 19,
    name: "黑金卡",
    num: 1,
    percent: "8.8%",
    icon:"icon/20"
  },
  {
    id: 20,
    name: "薰衣草种子",
    num: 1,
    percent: "14.32%",
    icon:"icon/31"
  },
];
export const highGiftList = [
  {
    id: 1,
    name: "iphone13（128G）",
    num: 1,
    percent: "0.01%",
    icon:"icon/32"
  },
  {
    id: 2,
    name: "Air Pods 3",
    num: 1,
    percent: "0.03%",
    icon:"icon/33"
  },
  {
    id: 3,
    name: "周边大礼包（抱枕+支架+钥匙扣）",
    num: 1,
    percent: "5%",
    icon:"icon/33"
  },
  {
    id: 4,
    name: "手机支架",
    num: 1,
    percent: "10%",
    icon:"icon/33"
  },
  {
    id: 5,
    name: "抱枕",
    num: 1,
    percent: "8%",
    icon:"icon/33"
  },
  {
    id: 6,
    name: "100元京东卡",
    num: 1,
    percent: "2.5%",
    icon:"icon/34"
  },
  {
    id: 7,
    name: "50元京东卡",
    num: 1,
    percent: "5%",
    icon:"icon/35"
  },
  {
    id: 8,
    name: "普通盲盒*5",
    num: 1,
    percent: "69.46%",
    icon:"normal-box"
  },
];
