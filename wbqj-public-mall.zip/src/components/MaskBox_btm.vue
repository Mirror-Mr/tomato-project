<template>
  <van-popup
    v-model="isShowMask"
    class="mask-box-btm"
    :class="{ 'btm-mask': maskShow_btm }"
    @closed="closeMask"
    round
    position="bottom"
  >
    <div class="bg-maskBox-btm">
      <!-- 底部弹框 -->
      <van-picker
        class="picker"
        :default-index="2"
        show-toolbar
        :columns="platform_list"
        @confirm="onConfirm($event, 'platform')"
        @cancel="onCancel"
        @change="onChange"
        v-if="maskShow_btm == 'platform'"
      />
      <van-picker
        class="picker"
        :default-index="2"
        show-toolbar
        :columns="allRoleServer_list"
        @confirm="onConfirm($event, 'roleServer')"
        @cancel="onCancel"
        @change="onChange"
        v-if="maskShow_btm == 'roleServer'"
      />
      <van-picker
        class="picker"
        title="请选择要登录的账号"
        :default-index="2"
        show-toolbar
        :columns="user_list"
        value-key="username"
        @confirm="onConfirm($event, 'user')"
        @cancel="onCancel"
        @change="onChange"
        v-if="maskShow_btm == 'userList'"
      />
    </div>
  </van-popup>
</template>
<script>
import { mapState } from "vuex";
export default {
  name: "MasBoxBtm",
  components: {},
  props: {
    maskShow_btm: {
      type: String,
      default: "",
    },
  },
  data() {
    return {
      // 控制弹框是否显示
      isShowMask: false,
      // 平台列表
      platform_list: ["安卓", "IOS"],
      platform: "",
      user_list: [],
      username_list: [],
    };
  },
  methods: {
    closeMask() {
      // 弹框的关闭是通过修改父组件的变量传值来控制的
      this.$emit("setIsMaskShow_btm", "");
    },
    // 确认底部弹框
    onConfirm(item, type) {
      if (type == "platform") {
        // 确认平台
        this.platform = item;
        this.$bus.$emit("checkPlatform", item);
      } else if (type == "roleServer") {
        // 确认角色区服
        this.$bus.$emit("checkRoleServer", item);
      } else {
        //   确认uid
        // item = this.user_list.find((n) => {
        //   return n.username == item;
        // });
        this.$bus.$emit("plogin", item);
      }
      this.closeMask();
    },
    // 取消底部弹框
    onCancel() {
      this.closeMask();
    },
    // 改变
    onChange() {},
  },
  computed: {
    ...mapState(["roleList"]),
    // 角色id列表
    allRoleServer_list() {
      if (!this.roleList || this.roleList.length == 0) return [];
      return this.roleList
        .filter((role) => role.role_name.length >= 2)
        .map((role) => role.server_name);
    },
  },
  watch: {
    maskShow_btm(newVal) {
      this.isShowMask = !!newVal;
    },
  },
  mounted() {
    this.$bus.$off(event).$on("setUserList", (res) => {
      console.log("btm_userList", res);
      this.user_list = [...res];
    //   this.username_list = this.user_list.map((item) => item.username);
    });
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.mask-box-btm{
  overflow:visible;
  background-color: transparent;
  &.btm-mask{
    width: 100vw;
    height: 62vw;
    background-color: #fff;
  }
  .bg-maskBox-btm{
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    .btn-close{
      position: absolute;
      top:-10vw;
      div{
        &:nth-of-type(1){
          width: 5.61vw;
          height: 5.61vw;
          background-image: imgUrl("btn-close.png");
        } 
        &:nth-of-type(2){
          width: 0.6vw;
          height:6.67vw;
          background-color: #BF0088;
        }
      }
    }
    // 底部弹框
    .picker{
      // width:100vw;
      /deep/ .van-picker__toolbar{
        width: 90vw;
      }
    }
  }
}
</style>
