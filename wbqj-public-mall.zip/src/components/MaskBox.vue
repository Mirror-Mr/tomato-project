<template>
  <transition name="fade">
    <van-popup
      v-model="isShowMask"
      @close="closeMask"
      @closed="closedMask"
      @open="openMask"
      :lock-scroll="true"
      :overlay="maskShow == 'blank' ? false : true"
      :class="{
        visible: maskShow == 'secondConfirm' || maskShow == 'checkOrder' || maskShow == 'historyOrder',
      }"
    >
      <div class="bg-maskBox" :class="`${maskShow}`">
        <!-- 不是所以弹框都有标题 -->
        <div class="title innerCenter" v-if="title">
          {{ title }}
        </div>
        <slot />
        <div class="btn-close flexColumnCenter" @click="closeMask"></div>
      </div>
    </van-popup>
  </transition>
</template>
<script>
import { mapState } from "vuex";
import clickLog from "@/api/toDots.js";
export default {
  name: "MasBox",
  components: {},
  props: {
    maskShow: {
      type: String,
      default: "",
    },
    title: {
      type: String,
      default: "",
    },
  },
  data() {
    return {
      // 控制弹框是否显示
      isShowMask: false,
    };
  },
  methods: {
    // 关闭弹框开始时
    closeMask() {
      let maskShow,
        maskTitle = "";
      // 弹框的关闭是通过修改父组件的变量传值来控制的
      this.$emit("setIsMaskShow", maskShow);
      this.$emit("setMaskTitle", maskTitle);
    },
    // 关闭弹框完成后
    closedMask() {},
    // 打开弹框
    openMask() {},
    // 处理手指触屏的回调函数
    handler(e) {
      e.preventDefault();
    },
  },
  computed: {
    ...mapState(["loginUserMsg"]),
  },
  watch: {
    maskShow: {
      handler(newVal) {
        this.isShowMask = !!newVal;
        // console.log("isShowMask:",this.isShowMask)
      },
      // 初始化时立即执行
      immediate: true,
      // deep 深度监听 - 监听对象的对象属性变化
    },
  },
  mounted() {},
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.fade-enter-active, .fade-leave-active {
  transition: opacity .3s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
.van-popup{
	max-height: 80vh;
	padding:0 0 10vw 0;
  background-color: transparent;
	&.visible{
		overflow: visible;
	}
  .bg-maskBox{
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    .btn-close{
      width: 6.61vw;
      height: 7vw;
      position: absolute;
      bottom:-9vw;
      background-image: imgUrl("btn-close.png");
    }
    .title{
      width: 100%;
      height: 9.6vw;
      margin:2vw 0 0 0;
      font-size: 5.24vw;
      color: #FFFFFF;
      flex-shrink: 0;
    }
    &.chooseLoginWay{
      width: 84.27vw;
      height: 66vw;
      background-image: imgUrl("bg_login.png");
    }
     &.bindRole{
        width: 84.27vw;
        height: 73vw;
        background-image: imgUrl("bg_common_mask.png")
     }
    &.activityRule{
        width:88vw;
        height:98vw;
        background-image: imgUrl("activity_rule.png");
    }
    &.checkOrder{
        width:90vw;
        background-image: imgUrl("bg_check_order_mid.png");
				background-repeat: repeat;
    }
    &.secondConfirm,
    &.historyOrder{
        width:85vw;
        height: 112vw;
        background-image: imgUrl("bg_second_confirm.png");
    }
    &.buySuccess,
    &.cantBuy{
        width:80vw;
        height:69vw;
        background-image: imgUrl("bg_common_mask.png");
    }
		&.blank{
			opacity: 0;
			pointer-events: none;
		}
  }
}
</style>
