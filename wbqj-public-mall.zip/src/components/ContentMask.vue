<template>
  <div class="content-mask flexColumnCenter">
    <!-- 弹框内容 -->
    <!-- <transition name="fade"> -->
    <!-- 二次确认 -->
    <div
      class="secondConfirm flexColumnCenter"
      v-if="maskShow == 'secondConfirm' || maskShow == 'historyOrder'"
    >
      <img
        :src="
          bagMsg.icon
            ? bagMsg.icon
            : bagMsg.type == 1
            ? 'https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/img_gift_bag_blue.png'
            : 'https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/img_gift_bag.png'
        "
        alt=""
      />
      <div
        class="bag-detail-list innerCenter"
        :class="{
          singleReward: bagMsg.lists && bagMsg.lists.length < 3,
          toBottom: maskShow == 'historyOrder',
        }"
      >
        <div
          class="bag-detail flexColumnCenter"
          v-for="bag in maskShow == 'secondConfirm'
            ? bagMsg.lists
            : bagMsg.content && JSON.parse(bagMsg.content)"
          :key="bag.id"
        >
          <img
            :src="
              bag.icon
                ? bag.icon
                : 'https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/img_gift_bag_blue.png'
            "
            v-if="maskShow == 'secondConfirm'"
          />
          <img
            :src="
              bag.img
                ? bag.img
                : 'https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/img_gift_bag_blue.png'
            "
            v-else
          />
          <span v-if="maskShow == 'secondConfirm'"
            >{{ bag.name }}*{{ bag.num }}</span
          >
          <span v-else>{{ bag.gif_name }}*{{ bag.num }}</span>
        </div>
        <!-- 占位符 -->
        <i
          v-if="
            (bagMsg.lists && bagMsg.lists.length > 3) ||
            (bagMsg.content && JSON.parse(bagMsg.content).length > 3)
          "
        ></i>
        <i
          v-if="
            (bagMsg.lists && bagMsg.lists.length > 3) ||
            (bagMsg.content && JSON.parse(bagMsg.content).length > 3)
          "
        ></i>
      </div>
      <div class="decorate"></div>
      <div class="tag innerCenter">
        <span>{{
          maskShow == "secondConfirm" ? "是否将礼包购买至" : "购买角色："
        }}</span>
        <div>
          {{
            maskShow == "secondConfirm"
              ? $store.state.roleMsg.role_name
              : bagMsg.role_name
          }}
        </div>
        <span v-if="maskShow == 'secondConfirm'">？</span>
      </div>
      <div
        class="btn-to-buy innerCenter"
        v-debounce="
          () => {
            judgeUserInfo(checkBuyNum);
          }
        "
        v-if="maskShow == 'secondConfirm'"
      >
        <span
          ><b v-if="maskShow == 'secondConfirm'">确认</b
          ><b v-else>已</b>支付</span
        >
        <span>￥</span>
        <span>{{ bagMsg.price }}</span>
      </div>
    </div>
    <!-- 订单查询 -->
    <div class="checkOrder" v-if="maskShow == 'checkOrder'">
      <img
        src="https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/bg_check_order_top.png"
        alt=""
      />
      <span v-if="shopHistory.length == 0">暂无订单信息</span>
      <div class="order-list flexColumnCenter" v-else>
        <div
          class="order flexColumnCenter"
          v-for="item in shopHistory"
          :key="item.id"
          @click="showHistoryOrder(item)"
        >
          <div class="top">
            <span>{{ item.role_name }}</span>
            <span>{{ item.create_time }}</span>
          </div>
          <div class="mid">
            <img
              :src="
                item.icon
                  ? item.icon
                  : item.type == 1
                  ? 'https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/img_gift_bag_blue.png'
                  : 'https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/img_gift_bag.png'
              "
              alt=""
            />
            <div>
              <span>{{ item.gname.replace("微信", "") }}</span>
              <div>
                <span
                  v-for="(prize, index) in item.content &&
                  JSON.parse(item.content)"
                  :key="prize.id"
                >
                  {{ prize.gif_name }}*{{ prize.num
                  }}<b
                    v-if="
                      index !=
                      (item.content && JSON.parse(item.content).length - 1)
                    "
                    >、</b
                  ></span
                >
              </div>
            </div>
          </div>
          <div class="btm">
            <b>
              价格：￥
              <span>{{ item.price }}</span>
            </b>
          </div>
        </div>
      </div>
      <img
        src="https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/bg_check_order_btm.png"
        alt=""
      />
    </div>

    <!-- 购买成功 -->
    <div class="buySuccess flexColumnCenter" v-if="maskShow == 'buySuccess'">
      <span>{{ payMsg.name }}</span>
      <div class="innerCenter">
        <img
          :src="
            payMsg.icon
              ? payMsg.icon
              : payMsg.type == 1
              ? 'https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/img_gift_bag_blue.png'
              : 'https://wcdn.tomatogames.com/static/WoBenQianJin/public-mall/img/img_gift_bag.png'
          "
          alt=""
        />
      </div>
      <span>*请到游戏邮箱内领取道具</span>
      <div class="btn-sure innerCenter" @click="$emit('setIsMaskShow', '')">
        好的
      </div>
    </div>
    <!-- 选择登录方式 -->
    <div
      class="choose-login-way flexColumnCenter"
      v-if="maskShow == 'chooseLoginWay'"
    >
      <div class="btn-group">
        <div
          class="innerCenter"
          :class="{ choose: loginType == 1 }"
          @click="loginType = 1"
        >
          手机号登录
        </div>
        <div
          class="innerCenter"
          :class="{ choose: loginType == 2 }"
          @click="loginType = 2"
        >
          账号登录
        </div>
      </div>
      <!-- 手机号/账号登录 -->
      <div class="login flexColumnCenter">
        <input
          class="phoneNum"
          type="tel"
          placeholder="请输入手机号"
          v-model="loginMsg.phoneNum"
          v-if="loginType == 1"
        />
        <input
          class="phoneNum"
          type="text"
          placeholder="请输入账号"
          v-model="loginMsg.accountNum"
          v-else
        />
        <div class="codeGroup" v-if="loginType == 1">
          <input
            class="phoneCode"
            type="tel"
            placeholder="请输入验证码"
            maxlength="6"
            v-model="loginMsg.phoneCode"
          />
          <div class="getCode innerCenter" v-debounce="getCode">
            {{ loginMsg.codeMsg }}
          </div>
        </div>
        <div class="codeGroup account" v-else>
          <input
            class="phoneCode"
            type="password"
            placeholder="请输入密码"
            v-model="loginMsg.password"
          />
        </div>
        <!--  $emit('setIsMaskShow', 'bindRole');
            $emit('setMaskTitle', '绑定角色'); -->
        <div class="btn-sure innerCenter" @click="login">登录</div>
      </div>
    </div>
    <!-- 绑定角色 -->
    <div class="bind-role flexColumnCenter" v-if="maskShow == 'bindRole'">
      <div class="platform" @click="$emit('setIsMaskShow_btm', 'platform')">
        <b>平台</b>
        <div class="input">
          <div class="innerCenter">{{ roleMsg.platform }}</div>
          <div class="innerCenter"><span></span></div>
        </div>
      </div>
      <div class="role_id" @click="$emit('setIsMaskShow_btm', 'roleServer')">
        <b>区服</b>
        <div class="input">
          <div class="innerCenter">
            {{ roleMsg.server_name ? roleMsg.server_name : "" }}
          </div>
          <div class="innerCenter"><span></span></div>
        </div>
      </div>
      <div class="role_name">
        <b>角色</b>
        <div class="input">
          <div class="innerCenter">{{ roleMsg.role_name }}</div>
        </div>
      </div>
      <div
        class="innerCenter btn-sure"
        v-debounce="
          () => {
            checkBindRole(roleMsg);
          }
        "
      >
        确认
      </div>
    </div>
    <!-- 无法购买 -->
    <div class="cantBuy flexColumnCenter" v-if="maskShow == 'cantBuy'">
      <div>礼包需要在<span>角色所在服开服满七日</span>后方可购买</div>
      <div class="btn-sure innerCenter" @click="$emit('setIsMaskShow', '')">
        好的
      </div>
    </div>
    <!-- 空白页 -->
    <div class="blank" v-if="maskShow == 'blank'"></div>
    <!-- </transition> -->
  </div>
</template>
<script>
import QRCode from "qrcode";
import { validatePhone } from "@/utils/validate";
import {
  login,
  getRoleInfo,
  bindRole,
  getUserInfo,
  getAccountList,
  plogin,
  pay,
} from "@/api";
import getDateDiff from "@/utils/getDateDiff.js";
import { isWeChat } from "@/utils/debounce.js";
import sendCode from "@/api/sendCode";
import {} from "./awards.js";
import { mapState, mapMutations } from "vuex";
import { Swiper, SwiperSlide } from "vue-awesome-swiper";
import "swiper/dist/css/swiper.css";
export default {
  name: "ContentMask",
  props: {
    maskShow: {
      type: String,
      default: "",
    },
    shopHistory: {
      type: Array,
      default: () => [],
    },
    payMsg: {
      type: Object,
      default: () => ({ icon: "", good_name: "" }),
    },
  },
  components: {
    Swiper,
    SwiperSlide,
  },
  data() {
    return {
      //要购买的礼包
      bagMsg: {
        lists: [1, 2, 3],
      },
      // 登录方式 默认进入是手机号登录
      loginType: 1,
      time: Date.now(),
      timer: null,
      project_id: 30,
      // 手机登录信息1
      loginMsg: {
        phoneNum: "",
        phoneCode: "",
        accountNum: "",
        password: "",
        // 短信验证码定时器
        timer: null,
        codeMsg: "获取验证码",
      },
      // 平台
      platform: ["安卓", "IOS"],
      // 角色信息
      roleMsg: {
        platform: "IOS",
        role_id: "",
        server_name: "",
        role_name: "",
        server_open_time: "",
      },
      // 选择的哪个剧本
      script: {},
      // 选择盲盒id
      blindBox: 0,
      // 领取的哪个奖励
      gift: [],
      // 盲盒中奖看哪个
      boxIndex: 1,
      // 中将记录轮播图
      swiperOption_winnerList: {
        direction: "vertical",
        slidesPerView: "auto",
        //自动切换
        autoplay: {
          delay: 0, //自动切换时间间隔
          stopOnLastSlide: false, //切换到最后一个slide时 不会 自动停止
          disableOnInteraction: false, //用户操作swiper后自动切换不会停止 每次都会重新启动
        },
        centeredSlides: true,
        allowTouchMove: false, //不允许触摸滑动
        spaceBetween: 10,
        loop: true,
        watchSlidesProgress: true,
        speed: 2000, //切换速度
        // observer:true,
        // observerParents:true
      },
      slogan: "",
      //普通盲盒奖励
      normalBoxGift: {},
      //通过查看中奖记录进入的高级盲盒奖励
      tempHighGift: {},
    };
  },
  methods: {
    setIsMaskShow(n) {
      this.$emit("setIsMaskShow", n);
    },
    // 买礼包
    buyBag(bagMsg) {
      let { roleMsg } = this.$store.state;
      if (this.maskShow == "historyOrder") return;
      localStorage.setItem("payMsg", JSON.stringify(bagMsg));
      //   判断当前角色所在服务器开服7天没
      let openTime = roleMsg.server_open_time
        ? roleMsg.server_open_time.split(" ")[0] + " 00:00:00"
        : null;
      let nowTime =
        new Date().Format("yyyy-MM-dd hh:mm:ss").split(" ")[0] + " 00:00:00";
      // nowTime = '2022-02-18 00:00:00';
      // console.log(openTime,nowTime)
      // console.log(getDateDiff(openTime, nowTime, "day") + 1<8);
      if (openTime && getDateDiff(openTime, nowTime, "day") + 1 < 8) {
        //  角色的服务器小于7天 则提示不可以领
        this.$emit("setIsMaskShow", "cantBuy");
        this.$emit("setMaskTitle", "无法购买");
        return;
      }
      //   return;
      // 支付
      this.pay(bagMsg.cid);
    },
    // 支付
    pay(goodid) {
      const { time } = this;
      const { token, uid } = this.loginUserMsg;
      let wxid = "";
      if (isWeChat()) {
        wxid = sessionStorage.getItem("wxid");
      }
      pay({ time, token, uid, goodid, wxid }, { time, token }).then((res) => {
        if (res.status == 1) {
          let payMsg = JSON.parse(localStorage.getItem("payMsg"));
          localStorage.setItem(
            "payMsg",
            JSON.stringify({ ...payMsg, orderid: res.data.orderid })
          );
          location.href = res.data.url;
          let i = 0;
          //   在支付页面通过滑动屏幕返回时生效
          this.timer = setInterval(() => {
            this.$emit("getOrderStatus", res.data.orderid);
            i++;
            if (i > 30) {
              clearInterval(this.timer);
            }
          }, 1000);
        } else {
          this.$toast.fail(res.msg);
        }
      });
    },
    // 获取验证码
    getCode() {
      let { phoneNum, timer } = this.loginMsg;
      if (timer) return;
      if (this.checkPhone(phoneNum)) {
        sendCode(phoneNum).then((res) => {
          if (res.status == 1) {
            this.$toast.success(res.msg);
            let num = 180;
            this.loginMsg.timer = setInterval(() => {
              this.loginMsg.codeMsg = `${num--}s后重新发送`;
              if (num == 0) {
                this.loginMsg.codeMsg = "重新发送";
                clearInterval(this.loginMsg.timer);
                this.loginMsg.timer = null;
              }
            }, 1000);
          } else {
            this.$toast.fail(res.msg);
          }
        });
      }
    },
    // 登录
    login() {
      let { phoneNum, phoneCode, accountNum, password } = this.loginMsg;
      let { project_id, time, loginType } = this;
      phoneNum = phoneNum ? phoneNum.trim() : "";
      phoneCode = phoneCode ? phoneCode.trim() : "";
      accountNum = accountNum ? accountNum.trim() : "";
      password = password ? password.trim() : "";
      if (loginType == 1) {
        // 手机号登录 获取userList列表 需要选择uid才能获取到token
        if (this.checkPhone(phoneNum) && this.checkCode(phoneCode)) {
          const params = { time, code: phoneCode, phone: phoneNum, project_id };
          getAccountList(params, {
            time,
            phone: phoneNum,
            code: phoneCode,
          }).then((res) => {
            if (res.status == 1) {
              // 成功拿到用户列表 放到底部选择栏里
              this.$emit("setIsMaskShow_btm", "userList");
              this.$nextTick(() => {
                this.$bus.$emit("setUserList", res.data);
              });
            } else {
              this.$emit("setIsMaskShow_btm", "");
              this.$toast.fail(res.msg);
            }
          });
        }
      } else {
        // 账号登录
        if (this.checkNull(accountNum) && this.checkNull(password)) {
          const params = { time, account: accountNum, password };
          login(params, params).then((res) => {
            if (res.status == 1) {
              // 登录成功获取用户信息
              // 获取用户带token的用户信息 存到vuex里
              this.$store.commit("SET_lOGINUSERMSG", res.data);
              // 把token和uid存本地
              localStorage.setItem(
                "userInfo",
                JSON.stringify({ token: res.data.token, uid: res.data.uid })
              );
              this.getUserInfo();
            } else {
              this.$toast.fail(res.msg);
            }
          });
        }
      }
    },
    // 判断手机号是否合规
    checkPhone(phoneNum) {
      try {
        if (!phoneNum) throw "请输入手机号";
        if (!validatePhone(phoneNum)) throw "请输入正确的手机号";
      } catch (err) {
        this.$toast(err);
        return false;
      }
      return true;
    },
    // 判断验证码是否合规
    checkCode(phoneCode) {
      try {
        if (!phoneCode) throw "请输入验证码";
        if (phoneCode.length != 6) throw "请输入6位数验证码";
      } catch (err) {
        this.$toast(err);
        return false;
      }
      return true;
    },
    // 判断传入数值是否为空
    checkNull(msg) {
      if (!msg) this.$toast.fail("信息不能为空");
      return !!msg;
    },
    // 确定绑定角色
    checkBindRole(roleMsg) {
      // 不是已绑定过的角色 则要进行判断该角色所在服务器是否开服满7天
      const {
        platform,
        role_id,
        server_id,
        server_name,
        role_name,
        server_open_time,
      } = roleMsg;
      if (!platform || !role_id || !server_name || !role_name) {
        this.$toast.fail("信息不能为空");
        return;
      }
      let { time } = this;
      const { token, uid } = this.loginUserMsg;
      const channel = platform == "安卓" ? 2 : 1;
      const sid = server_id;
      const sname = server_name;
      const rolename = role_name;
      const roleid = role_id;
      const params = {
        time,
        token,
        channel,
        sid,
        sname,
        rolename,
        roleid,
        uid,
        server_open_time,
      };
      bindRole(params, { time, token }).then((res) => {
        if (res.status == 1) {
          // 绑定角色成功
          this.$toast.success("绑定角色成功！");
          this.$store.commit("SET_ROLEMSG", this.roleMsg);
          localStorage.setItem("roleMsg", JSON.stringify(this.roleMsg));
          this.roleMsg = {
            ...this.roleMsg,
            platform: "IOS",
            role_id: "",
            server_name: "",
            role_name: "",
            server_open_time: "",
          };
          // 获取新的用户信息
          this.$emit("getUserInfo");
          this.setIsMaskShow("");
        } else {
          this.$toast.fail("绑定角色失败！");
        }
      });
    },
    // 获取角色列表
    getRoleInfo() {
      let { time } = this;
      const { token, uid } = this.loginUserMsg;
      getRoleInfo({ time, token, uid }, { time, token }).then((res) => {
        if (res.status == 1) {
          this.$store.commit("SET_ROLELIST", res.data);
        } else {
          let errMsg = res.status == 4040 ? "登录过期，请重新登录" : res.msg;
          this.$toast.fail(errMsg);
          res.status == 4040
            ? this.logOut()
            : this.$store.commit("SET_ROLELIST", []);
          // setTimeout(()=>{
          // 	this.$emit("setIsMaskShow_btm", "roleServer");
          // },500)
          // this.$nextTick(() => {
          //   this.$bus.$emit("setUserList", []);
          // });
        }
      });
    },
    // 获取用户信息
    getUserInfo() {
      let { time } = this;
      const { token, uid } = this.loginUserMsg;
      getUserInfo({ time, token, uid }, { time, token }).then((res) => {
        if (res.status == 1) {
          this.$store.commit("SET_lOGINUSERMSG", res.data);
          console.log(res.data);
          if (res.data.info.role_id && res.data.info.server_open_time) {
            // 有已绑定的角色 则直接绑定
            const {
              channel,
              role_id,
              role_name,
              server_id,
              server_name,
              server_open_time,
            } = res.data.info;
            this.roleMsg = {
              ...this.roleMsg,
              platform: channel == "1" ? "IOS" : "安卓",
              role_id,
              role_name,
              server_id,
              server_name,
              server_open_time,
            };
            this.checkBindRole(this.roleMsg);
            return;
          }
          //   有曾经绑定的角色 但无开服时间 需重新绑定角色信息
          if (res.data.info.role_id && !res.data.info.server_open_time)
            this.$toast("角色信息过期，请重新绑定~");
          // 若无则获取角色列表
          this.getRoleInfo();
          // 进入绑定角色弹框
          this.roleMsg = {
            ...this.roleMsg,
            platform: "IOS",
            role_id: "",
            server_name: "",
            role_name: "",
            server_open_time: "",
          };
          this.setIsMaskShow("bindRole");
          this.$emit("setMaskTitle", "绑定角色");
        } else {
          let errMsg =
            res.status == 4040 ? "登录过期，请重新登录" : "获取用户信息失败";
          this.$toast.fail(errMsg);
          res.status == 4040 ? this.logOut() : "";
        }
      });
    },
    // 注销
    logOut() {
      this.$store.commit("SET_lOGINUSERMSG", {});
      this.$store.commit("SET_ROLEMSG", {});
      localStorage.removeItem("userInfo");
      localStorage.removeItem("roleMsg");
    },
    // 通过uid uname获取token
    plogin(uid, uname) {
      const { time } = this;
      plogin({ time, uid, uname }, { time, uid, uname }).then((res) => {
        if (res.status == 1) {
          // 清掉验证码
          this.loginMsg.phoneCode = "";
          // 获取用户带token的用户信息 存到vuex里
          this.$store.commit("SET_lOGINUSERMSG", res.data);
          // 把token和uid存本地
          localStorage.setItem(
            "userInfo",
            JSON.stringify({ token: res.data.token, uid: res.data.uid })
          );
          this.getUserInfo();
        } else {
          this.$toast.fail(res.msg);
        }
      });
    },
    // 展示历史订单
    showHistoryOrder(order) {
      this.$emit("setIsMaskShow", "historyOrder");
      this.$emit("setMaskTitle", order.gname.replace("微信", ""));
      this.bagMsg = { ...order };
    },
    // // 判断是否有用户登录
    judgeUserInfo(func, params, flag = true) {
      if (Object.keys(this.loginUserMsg).length == 0) {
        // 未登录
        this.$emit("setIsMaskShow", "chooseLoginWay");
        this.$emit("setMaskTitle", "");
        return;
      }
      let { roleMsg } = this.$store.state;
      if (!roleMsg.role_id) {
        //   已登录 未绑定
        this.$emit("setIsMaskShow", "bindRole");
        this.$emit("setMaskTitle", "绑定角色");
        this.$emit("getRoleInfo");
        return;
      }
      // 已登录
      func(params);
    },
    // 判断是否超过购买限定次数
    checkBuyNum() {
      if (this.buyNum >= this.bagMsg.limit_num) {
        let text =
          this.bagMsg.type == 1 ? "今日购买次数用完咯~" : "本周购买次数用完咯~";
        this.$toast(text);
        return;
      }
      this.buyBag(this.bagMsg);
    },
    // // 判断该账号是否满足七天条件
    // checkSevenDay(roleMsg) {
    //   //   判断当前角色所在服务器开服7天没
    //   let openTime = roleMsg.server_open_time
    //     ? roleMsg.server_open_time.split(" ")[0] + " 00:00:00"
    //     : null;
    //   let nowTime =
    //     new Date().Format("yyyy-MM-dd hh:mm:ss").split(" ")[0] + " 00:00:00";
    //   //   console.log(openTime, nowTime);
    //   //   console.log(getDateDiff(openTime, nowTime, "day"));
    //   if (openTime && getDateDiff(openTime, nowTime, "day") + 1 < 8) {
    //     //  角色的服务器小于7天 则提示不可以领 无法绑定角色
    //     this.$emit("setIsMaskShow", "cantBuy");
    //     this.$emit("setMaskTitle", "无法购买");
    //     return;
    //   }
    //   this.checkBindRole(roleMsg);
    // },
  },
  computed: {
    ...mapState(["loginUserMsg", "roleList"]),
    // 购买当前礼包的次数
    buyNum() {
      let orders = this.loginUserMsg.orders
        ? this.loginUserMsg.orders[this.bagMsg.type]
        : null;
      if (!orders || Object.keys(orders).length == 0) return 0;
      return orders[this.bagMsg.cid] ? orders[this.bagMsg.cid] : 0;
    },
  },
  mounted() {
    // 设置要买的礼包详情
    this.$bus.$off(event).$on("setBagMsg", (bagMsg) => {
      this.bagMsg = bagMsg;
    });
    this.$bus.$off(event).$on("checkPlatform", (platform) => {
      // 选择了平台
      this.roleMsg = {
        ...this.roleMsg,
        platform,
        role_id: "",
        server_name: "",
        role_name: "",
        server_open_time: "",
      };
    });
    this.$bus.$off(event).$on("getUserInfo", () => {
      this.getUserInfo();
    });
    this.$bus.$off(event).$on("showNowRole", (n) => {
      // 显示当前角色
      const { platform, role_id, server_name, role_name, server_id } =
        this.roleMsg;
      this.roleMsg.platform = platform;
      this.roleMsg.role_id = role_id;
      this.roleMsg.server_name = server_name;
      this.roleMsg.role_name = role_name;
      this.roleMsg.server_id = server_id;
    });
    this.$bus.$off(event).$on("checkRoleServer", (server_name) => {
      // 选择了角色区服
      this.roleMsg.server_name = server_name;
      // 确定角色(名)
      this.roleList.forEach((role) => {
        if (role.server_name == server_name) {
          this.roleMsg = Object.assign({}, this.roleMsg, role);
        }
      });
    });
    this.$bus.$off(event).$on("plogin", (msg) => {
      this.plogin(msg.uid, msg.uname);
    });
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.content-mask{
    width:100%;
  // .fade-enter-active, .fade-leave-active {
  //   transition: opacity .3s;
  // }
  // .fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  //   opacity: 0;
  // }
  /**
    弹出框内容样式
    */
		// 订单
  .checkOrder{
		width:100%;
		max-height: 70vh;
		img{
			&:nth-of-type(1){
				width: 100%;
			}
			&:nth-of-type(2){
				width: 100%;
				position: relative;
				top:1vw;
                z-index:9;
			}
		}
		.order-list{
			width: 100%;
            position: relative;
			max-height: 52vh;
            min-height: 30vh;
			margin:0 0 -45vw 0;
			overflow: auto;
            z-index: 10;
			.order{
				width: 86%;
				height: 30.2vw;
                position: relative;
				flex-shrink: 0;
				background-image: imgUrl("btn_gift_bag.png");
				&:not(:nth-of-type(1)){
					margin:4vw 0 0 0
				}
				.top{
					width:93%;
					height: 7.7vw;
					display: flex ;
					justify-content: space-between;
					line-height: 8.3vw;
					flex-shrink: 0;
					border-bottom: 1px dotted #000;
					span{
						font-size: 2.7vw;
						color:#6C5BA4;
						&:nth-of-type(1){
							
						}
						&:nth-of-type(2){
							
						}
					}
				}
				.mid{
					width:100%;
					height:18vw;
					display: flex;
					position:relative;
					justify-content: flex-end;
					img{
						width: 27vw;
						height: auto;
						position:absolute;
						top:0.5vw;
						left: 4vw;
						flex-shrink: 0;
						object-fit:contain
					}
					&>div{
						width:54%;
						margin:1vw 2vw 0 0;
						color:#6C5BA4;
						text-align: left;
						&>span{
							font-size:3.2vw;
						}
						div{
							font-size:2.1vw;
							margin:1vw 0 0 0;
							line-height: 2.5vw;
							/* 关键代码 ！！！！ 以下5行 */
							overflow: hidden;
							/* 超出部分设为... */
							text-overflow: ellipsis;
							/* 盒子模型 */
							display: -webkit-box;
							/* 最多2行文本 多余部分隐藏*/
							-webkit-line-clamp: 4;
							/* 从顶部向底部垂直布置子元素 */
							-webkit-box-orient: vertical;
						}
					}
				}
				.btm{
					width:90%;
					color:#fff;
					b{
						font-size: 3.2vw;
						float: right;
						span{
							font-size:4.3vw;
						}
					}
				}
			}
		}
	}
  // 二次确认
  .secondConfirm{
    width:100%;
		height: 100vw;
    position:relative;
    &>img{
			width:32%;
			position:absolute;
			top:-15vw;
			left: -6vw;
    }
		.bag-detail-list{
			width:80%;
			height:66vw;
			margin:7.5vw 0 0 0;
			// background-color: red;
			justify-content: space-around;
 		  flex-wrap: wrap;
			overflow: auto;
			&.toBottom{
				margin: 10vw 0 0 0;
			}
			&.singleReward{
				flex-wrap: nowrap;
				.bag-detail{
					width:31vw;
					span{
						width: 100%;
						height: 1rem;
						font-size: 3.4vw;
						// 文字不换行
						// white-space: nowrap;
					}
				}
			}
			.bag-detail{
				width:22vw;
				margin:0 0 1.7vw 0;
				img{
					width:68%;
					border: 1px solid #594A8C;
					border-radius:0.5vw 1.6vw;
				}
				span{
					width:100%;
					height: 1rem;
					margin:1vw 0 0 0;
					font-size:3.4vw;
					color:#6C5BA4;
					// 文字不换行
					// white-space: nowrap
				}
			}
			i{
				width:22vw;
			}
		}
		.decorate{
			width:80%;
			height: 3.2vw;
			background-image: imgUrl("line_decorate.png");
		}
		.tag{
			width:100%;
			height: 9vw;
            color:#4D4187;
			div{
				background-image: imgUrl("bg_buy_name.png");
				background-position: bottom;
			}
		}
		.btn-to-buy{
			width:100%;
			height:13.6vw;
			position: absolute;
			left: 0;
			bottom: 0;
			background-image: imgUrl("btn_buy.png");
			span{
				color:#fff;
				&:nth-of-type(1){
					font-size: 4.3vw;
				}
				&:nth-of-type(2){
					font-size:4.3vw;
					vertical-align:bottom
				}
				&:nth-of-type(3){
					font-size:7.2vw;
				}
			}
		}
  }
  // 购买成功
  .buySuccess{
		padding: 3vw 0 0 0;
		span{
			&:nth-of-type(1){
				font-size:4.3vw;
				color:#6C5BA4;
			}
			&:nth-of-type(2){
				font-size:3.3vw;
				color:#FD8787;
				margin:0 0 2vw 0
			}
		
		}
		div{
			height: 30vw;
			&:nth-of-type(1){
				width:50%;
			}
			&:nth-of-type(2){
				width: 32vw;
				height: 10vw;
				margin:2vw 0 0 0;
				color:#fff;
				background-image: imgUrl("btn_common.png");
			}
		}
  }
	// 公共按钮样式
	.btn-sure{
		width: 32vw;
		height: 10vw;
		margin:2vw 0 0 0;
		color:#fff;
		background-image: imgUrl("btn_common.png");
	}
  // 选择登录方式
  .choose-login-way{
    .btn-group{
			width: 78vw;
      display: flex;
			justify-content: space-between;
      margin: 3vw 0 0 0;
      color: #FCB2DB;
      font-size: 4.5vw;
      div{
				width:38.5vw;
				height: 9vw;
				color:#57488B;
				border-radius: 2.1vw  1.3vw   0 0;
				background-color: #C9C4DD;
				&.choose{
					background-color: #fff;
				}	
      }
    }
  }
  // 手机登录1
  .login{
    margin:4vw 0 0 0;
    // 输入框placeholder字体颜色
    input::-webkit-input-placeholder {
      /* WebKit browsers */
      color: #9589BF;
    }
    input:-moz-placeholder {
      /* Mozilla Firefox 4 to 18 */
      color: #9589BF;
    }
    input::-moz-placeholder {
      /* Mozilla Firefox 19+ */
      color: #9589BF;
    }
    input:-ms-input-placeholder {
      /* Internet Explorer 10+ */
      color: #9589BF;
    }
    input{
      width: 67.7vw;
      height: 11.5vw;
      padding: 0 0 0 2vw;
      margin: 0 0 2vw 0;
      background: #fff;
      font-size: 4vw;
      color: #57488B ;
      border: 1px solid #57488B;
			border-radius: 1.6vw 0.5vw;
			// outline: none;
    }
    // & > div{
    //   width: 100%;
    //   height: 100%;
    //   display: flex;
    //   flex-direction: column;
    //   align-items: center;
    // }
    .codeGroup{
      display: flex;
			&.account{
				 .phoneCode{
					 width: 67.7vw;
					 border-right:1px solid #57488B;
					 border-radius: 1.6vw 0.5vw;
				 }
			}
      .phoneCode{
          width: 44vw;
          border-right: none;
					border-radius: 1.6vw 0.5vw 0 0;
        }
      .getCode{
        width: 23.7vw;
        height: 11.5vw;
        font-size:3.2vw;
        color: #FFFFFF;
        background-color:#CCA170;
        border: 1px solid #CCA170;
        border-left: none;
				border-radius: 0vw 0.6vw 1.3vw 0vw;
      }
    }
    span{
      margin: 0 1vw 0 0;
      align-self: flex-end;
      font-size: 3.5vw;
      color: #f3abcc;
    }
    .btn_group{
      width: 100%;
      display: flex;
      justify-content: space-around;
      margin:2vw 0 0  0;
      div{
        width: 23.6vw;
        height: 10vw;
        color: #FFFFFF;
        font-size: 4vw;
        &:nth-of-type(1){
          background-image: imgUrl("btn-confirm.png");
        }
        &:nth-of-type(2){
          background-image: imgUrl("btn-cancel.png");
        }
      }
    }
  }
  // 绑定角色
  .bind-role{
    margin: 4vw 0 0 0;
    .platform,.role_id,.role_name{
      width: 80%;
      display: flex;
      align-items: center;
      b{
        width: 25%;
        color: #57488B;
        text-align: left;
        font-size: 4vw;
      }
      .input{
        width: 75vw;
        height: 11.8vw;
				display: flex;
				justify-content: space-between;
        padding:0 0 0 2vw;
        font-size: 5vw;
        color: #57488B;
        background: #fff;
        border: 1px solid #57488B;
				border-radius: 1.6vw 0.5vw;
				div{
					height: 100%;
					&:nth-of-type(1){
						width: 79%;
					}
					&:nth-of-type(2){
						width: 22%;
						border-left: 1px solid #57488B;
						span{
							width: 4.2vw;
							height: 3.4vw;
							display: block;
							background-image: imgUrl("arrow.png");
						}
					}
				}
      }
      &:nth-of-type(2),
      &:nth-of-type(3){
        margin: 2vw 0 0 0;
      }
      &:nth-of-type(3){
          span{
            display: none;
          }
      }
    }
  }
	// 无法购买
	.cantBuy{
		div{
			&:nth-of-type(1){
				width: 85.5%;
				height: 8rem;
				padding: 3rem 0 0 0;
				color: #6C5BA4;
				text-align: left;
				line-height: 1.5rem;
				span{
					color: #FD8787;
				}
			}	
			&:nth-of-type(2){

			}
		}
	}
}
</style>
