import axios from "axios";
import qs from "qs";
import handleHeaders from "@/utils/handleHeaders";

axios.defaults.baseURL = "https://api.xianyuyouxi.com/service";

axios.defaults.timeout = 6000;

axios.defaults.headers.post["Content-Type"] =
  "application/x-www-form-urlencoded;charset=UTF-8";

export function post(url, params, headersObj) {
  params = qs.stringify(params);
  const headers = handleHeaders(headersObj);
  return new Promise((resolve, reject) => {
    axios.post(url, params, { headers }).then(
      (res) => {
        resolve(res.data);
      },
      (err) => {
        reject(err);
      }
    );
  });
}

export function get(url, params, headersObj) {
  const headers = handleHeaders(headersObj);
  return new Promise((resolve, reject) => {
    axios.get(url, { params, headers }).then(
      (res) => {
        resolve(res.data);
      },
      (err) => {
        reject(err);
      }
    );
  });
}

export default { post, get };
