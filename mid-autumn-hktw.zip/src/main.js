import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
// 初始化页面样式
import '@/assets/style/reset.scss'
// 全局样式
import '@/assets/style/common.scss'
// rem
import "@/utils/flexible";
// 引入icon样式
import "@/assets/font/iconfont.css";

// 引入弹出框
import { Popup , Toast , Picker  } from "vant";

// 若是没有开启Devtools工具，在开发环境中开启，在生产环境中开启
if (process.env.NODE_ENV == 'development') {
  Vue.config.devtools = true;
} else {
  Vue.config.devtools = true;
}
// 和谷歌三方登录有关
Vue.directive('google-signin-button', {
  bind: function (el, binding, vnode) {
    CheckComponentMethods()
    let clientId = binding.value
    let googleSignInAPI = document.createElement('script')
    googleSignInAPI.setAttribute('src', 'https://apis.google.com/js/api:client.js')
    document.head.appendChild(googleSignInAPI)

    googleSignInAPI.onload = InitGoogleButton

    function InitGoogleButton () {
      gapi.load('auth2', () => {
        const auth2 = gapi.auth2.init({
          client_id: clientId,
          cookiepolicy: 'single_host_origin'
        })
        auth2.attachClickHandler(el, {},
          OnSuccess,
          Onfail
        )
      })
    }

    function OnSuccess (googleUser) {
      // console.log(googleUser)
      vnode.context.onGoogleAuthSuccess(googleUser.getId())
      googleUser.disconnect()
    }

    function Onfail (error) {
      vnode.context.onGoogleAuthFail(error)
    }

    function CheckComponentMethods () {
      if (!vnode.context.onGoogleAuthSuccess) {
        throw new Error('The method onGoogleAuthSuccess must be defined on the component')
      }

      if (!vnode.context.onGoogleAuthFail) {
        throw new Error('The method onGoogleAuthFail must be defined on the component')
      }
    }
  }
})

router.afterEach((to, from, next) => {
  window.scrollTo(0, 0);

  // 或

  // window.scroll(0, 0);
});
Vue.config.productionTip = false;
Vue.use(Popup);
Vue.use(Toast);
Vue.use(Picker);
new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount("#app");
