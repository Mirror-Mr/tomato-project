/**
 * 大陆接口
 */

import { post , get } from "@/utils/request_mainland";

const baseUrl = "https://api.xianyuyouxi.com/service/activity/Zjfh_zhongqiu";

// 大陆登录
export function login(params,headers){
    return post(baseUrl+"/login",params,headers)
}

// 获取用户信息
export function getUserInfo(params,headers){
    return post(baseUrl+"/getUserInfo",params,headers)
}

// 获取角色信息
export function getRoleInfo(params,headers){
    return post(baseUrl+"/getRoleInfo",params,headers)
}

// 绑定角色
export function bindRole(params,headers){
    return post(baseUrl+"/bindRole",params,headers)
}
// 抽奖
export function lottery_draw(params,headers){
    return post(baseUrl+"/lottery_draw",params,headers)
}
// 领奖或兑换
export function subPrize(params,headers){
    return post(baseUrl+"/subPrize",params,headers)
}
// 购买幸运币
export function pay(params,headers){
    return post(baseUrl+"/pay",params,headers)
}
// 获取订单状态
export function get_order_status(params,headers){
    return post(baseUrl+"/get_order_status",params,headers)
}
// 快捷登录
export function xy_login(params,headers){
    return post(baseUrl+"/xy_login",params,headers)
}
// 获取活动时间
export function getActivityTime(params,headers){
    return get(baseUrl+"/getActivityTime",params,headers)
}