<template>
  <div id="app">
    <router-view />
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import {
  getRoleInfo,
  lottery_draw,
  subPrize,
  getUserInfo,
  xy_login,
  getActivityTime,
} from "@/api/hktw";
export default {
  name: "App",
  data() {
    return {};
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_GRAWLIST",
      "SET_USERMSG",
      "SET_ISLOGIN",
      "SET_ISBIND",
    ]),
    // 重新获取用户信息
    getUserInfo() {
      const time = Date.now();
      const { token } = this.userMsg;
      getUserInfo({ time, token }, { time, token }).then((res) => {
        console.log(res);
        if (res.code == 1) {
          // 获取用户信息成功
          this.userMsg = Object.assign({}, this.userMsg, res.data);
          // console.log(this.userMsg);
          this.SET_USERMSG(this.userMsg);
          // 获取用户礼包 如果为null 则无法盖过原来的数据
          if (res.data.info.content != "") {
            this.SET_GRAWLIST(JSON.parse(res.data.info.content));
          } else {
            this.SET_GRAWLIST(null);
          }
        } else {
          if (res.code == 4040) {
            // 登录失效 需要重新登录
            this.$toast.fail("登錄過期，請重新登錄");
            this.SET_ISLOGIN(false);
            this.SET_ISBIND(false);
            this.SET_ISMASKSHOW(true);
            this.SET_MASKCONTENT("hktwLogin");
            // this.SET_MAINLANDLOGIN("chooseWay");
            this.SET_USERMSG({});
          }
          this.$toast.fail(res.msg);
        }
      });
    },
  },
  computed: {
    userMsg: {
      get() {
        return this.$store.state.userMsg;
      },
      set(n) {
        this.SET_USERMSG(n);
      },
    },
  },
  created() {
    //在页面加载时读取sessionStorage里的状态信息
    if (sessionStorage.getItem("store")) {
      this.$store.replaceState(
        Object.assign(
          {},
          this.$store.state,
          JSON.parse(sessionStorage.getItem("store"))
        )
      );
    }
    //在页面刷新时将vuex里的信息保存到sessionStorage里
    window.addEventListener("beforeunload", () => {
      this.SET_ISMASKSHOW(false);
      sessionStorage.setItem("store", JSON.stringify(this.$store.state));
    });
  },
  mounted() {
    // 重新获取用户信息
    if (this.userMsg.token) {
      this.getUserInfo();
    }
  },
};
</script>
<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  
}

</style>
