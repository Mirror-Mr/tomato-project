<template>
  <!-- 确认获取累计奖励 -->
  <div class="confirmGetEggPrize">
    <div class="confirmGetEggPrize_container">
      <div class="close" @click="SET_ISMASKSHOW(false)"></div>
      <div class="confirmGetEggPrize_content">
        <span>
          當前為{{ draw_list.start }}星，可領取獎勵為
          <b class="red">
            {{ prizeList[draw_list.start] }}
          </b>。<br />領取獎勵后，當前扭蛋等級將歸零，是否將獎勵領取到{{
            userMsg.info ? userMsg.info.rolename : ""
          }}？
        </span>
        <div class="btn_group">
          <div class="innerCenter" @click="SET_ISMASKSHOW(false)">取消</div>
          <div class="innerCenter" @click="subPrize()">確認</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { subPrize } from "@/api/mainland";
export default {
  name: "ConfirmGetAccum",
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
      prizeList: [
        `月餅*4`,
        `月餅*24`,
        `月餅*64`,
        `月餅*108`,
        `月餅*320`,
        `月餅*960`,
        `桂花酒*3`,
        `桂花酒*9`,
      ],
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_ISLOGIN",
      "SET_ISBIND",
    ]),
    // 兑换
    subPrize() {
      this.$emit("subPrize", { type: 4, rid: this.draw_list.start, num: 1 });
    },
  },
  mounted() {},
  computed: {
    userMsg() {
      return this.$store.state.userMsg;
    },
    // 可领取奖励
    draw_list() {
      return this.$store.state.draw_list;
    },
  },
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.confirmGetEggPrize{
     .confirmGetEggPrize_container{
        .close{
            top: 0.1rem;
            right: 0.3rem;
        }
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .confirmGetEggPrize_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
              width: 75%;
              line-height: 0.5rem;
              margin:0.4rem 0 0 0;
              // text-align: justify;
            }
            .btn_group{
                width: 95%;
                margin: 0.5rem 0 0 0;
                display: flex;
                justify-content: space-around;
                div{
                    &:nth-of-type(1){
                        @include btn("bg_btn_blue.png",#fff)
                    }
                     &:nth-of-type(2){
                        @include btn;
                    }
                }
            }
        }
     }
}
</style>