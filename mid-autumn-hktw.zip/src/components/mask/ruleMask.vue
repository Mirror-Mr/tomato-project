<template>
  <!-- 规则框 -->
  <div class="rule_mask">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="rule_title innerCenter">
      <span></span>
      <span>活動規則</span>
      <span></span>
    </div>
    <div class="rule_content">
      <div v-for="(item, index) in content" :key="index">
        <span v-html="item.name"></span>
        <span v-html="item.desc"></span>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
export default {
  name: "RuleMask",
  data() {
    return {
      content: [
        {
          name: `玩法簡介：`,
          desc: `啟動扭蛋機，能隨機獲得一個扭蛋，每個扭蛋等級能對應領取相應的獎勵;繼續追加能再次隨機獲得一個扭蛋，當追加得到的扭蛋類型與當前的扭蛋類型一致，則能提升您的扭蛋等級獎勵;當追加得到的扭蛋類型與當前的扭蛋類型不一致，則本輪活動結束`,
        },
        {
          name: `領取獎勵：`,
          desc: `點擊領取獎勵，可以領取當前扭蛋等級所對應的獎勵，領取獎勵后則本輪結束，積累的扭蛋等級將被清空`,
        },
        {
          name: `普通追加：`,
          desc: `普通追加不收取追加費用，追加得到的扭蛋類型與當前扭蛋類型不一致，則本輪活動結束`,
        },
        {
          name: `保護追加：`,
          desc: `保護追加不會降低扭蛋等級，並且追加三次必定能提升扭蛋等級;保護追加需要消耗一定的幸運幣，扭蛋等級越高，保護追加消耗的幸運幣數量越多（1星*1；2星*3；3星*8；4星*26；5星*75；6星*138)`,
        },
        {
          name: `追加失敗：`,
          desc: `非保護狀態下追加失敗，會隨機降低1~2級扭蛋等級;降低后的扭蛋等級大於0則領取扭蛋等級對應的獎勵;降低后的扭蛋等級小於0則領取保底獎勵`,
        },
        {
          name: `保底獎勵：`,
          desc: `當前星級降至0時，則獲得保底月餅*4;`,
        },
        {
          name: `月餅：`,
          desc: `可用於兌換商店兌換各種稀有道具，僅在活動時間內有效，活動結束後道具將會清空`,
        },
        {
          name: `獎勵補發：`,
          desc: `本期活動結束時，會清空當期的扭蛋等級，未領取的星級獎勵將將會自動消失請注意領取時間`,
        },
        {
          name: `幸運幣：`,
          desc: `活動參與道具，可通過購買禮包，僅在活動時間內有效，活動結束後道具將會清空`,
        },
        {
          name: `概率展示`,
          desc: `<br>扭蛋類型隨機概率<br>每個類型扭蛋隨出的概率均為20%<br>扭蛋星級隨機概率1星82%，2星17%，3星1%<br>追加失敗扭蛋等級降低概率降低1星75%，降低2星25%<br>*注意事項：本頁面活動道具購買不參與遊戲內儲值活動，活動最終解釋權歸官方所有`,
        },
      ],
    };
  },
  methods:{
      ...mapMutations(["SET_ISMASKSHOW"])
  }
};
</script>
<style lang="scss" scoped>
.rule_mask{
    width:9.9rem;
    // padding: 1rem 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    .close{
        top: 1rem;
        right: 0.3rem;
    }
    .rule_title{
        width: 70%;
        height: 0.9rem;
        display: flex;
        font-size: 0.48rem;
        color: #FFEFB1;
        background-image: imgUrl("bg_title.png");
        span{
        &:nth-of-type(1),&:nth-of-type(3){
            width: 0.26rem;
            height: 0.26rem;
            display: block;
            background-image: imgUrl("rule_title_deco.png");
        }
        &:nth-of-type(2){
            margin: 0 0.2rem;
        }
    }
    }
    .rule_content{
        width: 95%;
        height: 19.3rem;
        padding: 0.8rem 0 0 0.2rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin:0.2rem 0 0 0rem;
        background-image: imgUrl("bg_rule_mask.png");

        // text-align: left;
        div{
            width: 84%;
            position: relative;
            margin: 0 0 0.3rem 0 ;
            text-align: justify;
            &::before{
                content:"";
                width: 0.31rem;
                height: 0.19rem;
                position: absolute;
                top: 0.1rem;
                left: -0.4rem;
                display: block;
                background-image: imgUrl("rule_content_deco.png");
                background-size: 100%;
                background-repeat: no-repeat;
            }
            span{
                font-size:0.32rem;   
                line-height: 0.4rem;
                &:nth-of-type(1){
                color: #268BC5;
                }
                &:nth-of-type(2){
                color: #153A4E;
                }
            }
        } 
        
    }
}
</style>