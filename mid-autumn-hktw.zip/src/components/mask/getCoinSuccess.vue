<template>
  <!-- 规则框 -->
  <div class="getCoinSuccess">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="getCoinSuccess_container" >
      <div class="getCoinSuccess_content" >
        <span>恭喜你获得x幸运币</span>
        <div class="checkBox" @click="coin_tag = !coin_tag">
          <i
            :class="{
              iconfont: true,
              'icon-no-check': coin_tag,
              'icon-check': !coin_tag,
            }"
          ></i
          >今日不再提示
        </div>
        <div class="innerCenter btn" @click="confirmDraw()">确认</div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { getUserInfo , lottery_draw } from "@/api/hktw";
export default {
  name: "GetCoinSuccess",
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations(["SET_ISMASKSHOW", "SET_MASKCONTENT", "SET_COINTAG","SET_USERMSG","SET_GRAWLIST"]),
   
  },
  computed: {

  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.getCoinSuccess{
    .close{
        top: 0.1rem;
        right: 0.3rem;
        z-index: 2;
    }
    .confirmGetEgg_container{
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .confirmGetEgg_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
                margin:0.4rem 0 0 0;
            }
            .checkBox{
                display: flex;
                align-items: center;
                margin: 0.9rem 0 0 0;
                font-size: 0.33rem;
                i{
                    font-size:0.4rem;
                    margin: 0 0.2rem 0 0;
                }
            }
            .btn{
               margin:1.5rem 0 0 0;
               @include btn;
            }
           
        }
     }
}
</style>