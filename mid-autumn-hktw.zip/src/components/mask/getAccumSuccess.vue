<template>
  <!-- 确认获取累计奖励 -->
  <div class="getAccumSuccess">
    <div class="getAccumSuccess_container" >
      <div class="close" @click="SET_ISMASKSHOW(false)"></div>
      <div class="exchangeSuccess_content">
        <span v-if="isGetEggPrize">領取成功！請到活動内查看。</span>
        <span v-else>領取成功！請到游戲郵箱内查看。</span>
        <div class="innerCenter" @click="success">确认</div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { subPrize } from "@/api/mainland";
export default {
  name: "getAccumSuccess",
  props:{
    isGetEggPrize:{
      type:Boolean,
      default:false
    }
  },
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_ISLOGIN",
      "SET_ISBIND",
    ]),
    success() {
      this.SET_ISMASKSHOW(false);
    },
  },
  mounted() {
  },
  computed: {
  },
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.getAccumSuccess{
     .getAccumSuccess_container{
        .close{
            top: 0.1rem;
            right: 0.3rem;
        }
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .exchangeSuccess_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
                margin:0.4rem 0 0 0;
            }
            div{
                margin:1.5rem 0 0 0;
                @include btn;
            }
        }
     }
}
</style>