<template>
  <!-- 确认获取累计奖励 -->
  <div class="confirmGetAccum">
    <div class="confirmGetAccum_container">
      <div class="close" @click="SET_ISMASKSHOW(false)"></div>
      <div class="confirmGetAccum_content">
        <span
          >是否將{{ accumPrizeMsg.prize[0] }}、{{ accumPrizeMsg.prize[1] }}、{{
            accumPrizeMsg.prize[2]
          }}獎勵領取到{{
            userMsg.info ? userMsg.info.rolename : ""
          }}（角色名）？</span
        >
        <div class="btn_group">
          <div class="innerCenter" @click="SET_ISMASKSHOW(false)">取消</div>
          <div class="innerCenter" @click="subPrize()">確認</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { subPrize } from "@/api/mainland";
export default {
  name: "confirmGetEggPrize",
  props: {
    accumPrizeMsg: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_ISLOGIN",
      "SET_ISBIND",
    ]),
    // 兑换
    subPrize() {
      this.$emit("subPrize", { type: 2, rid: this.accumPrizeMsg.id, num: 1 });
    },
  },
  mounted() {},
  computed: {
    userMsg() {
      return this.$store.state.userMsg;
    },
  },
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.confirmGetAccum{
     .confirmGetAccum_container{
        .close{
            top: 0.1rem;
            right: 0.3rem;
        }
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .confirmGetAccum_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
              width: 75%;
              line-height: 0.5rem;
              margin:0.4rem 0 0 0;
              text-align: justify;
            }
            .btn_group{
                width: 95%;
                margin: 0.5rem 0 0 0;
                display: flex;
                justify-content: space-around;
                div{
                    &:nth-of-type(1){
                        @include btn("bg_btn_blue.png",#fff)
                    }
                     &:nth-of-type(2){
                        @include btn;
                    }
                }
            }
        }
     }
}
</style>