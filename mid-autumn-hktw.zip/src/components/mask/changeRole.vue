<template>
  <!-- 规则框 -->
  <div class="changeRole">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="changeRole_content">
      <div class="inputGroup" @click="chooseServer()">
        <div class="server">
          {{ roleMsg.server_name ? roleMsg.server_name : "" }}
        </div>
        <div class="tag innerCenter">
          <span></span>
        </div>
      </div>
      <div class="inputGroup">
        <div class="role">
          {{ roleMsg.role_name ? roleMsg.role_name : "1" }}
        </div>
        <div class="tag innerCenter">
          <span></span>
        </div>
      </div>
      <div class="innerCenter btn" @click="checkBindRole">確認</div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { bindRole  } from "@/api/hktw";
export default {
  name: "RuleMask",
  data() {
    return {};
  },
  methods: {
    ...mapMutations(["SET_ISMASKSHOW", "SET_ISSHOWPOP"]),
    // 选择区服
    chooseServer() {
      this.isShowPop.status = true;
      this.isShowPop.type = 3;
    },
    // 绑定角色
    checkBindRole() {
      const time = Date.now();
      const { token } = this.userMsg;
      console.log(this.userMsg);
      const channel = 4;
      const sid = this.roleMsg.server_id;
      const sname = this.roleMsg.server_name;
      const rolename = this.roleMsg.role_name ? this.roleMsg.role_name : 1;
      const rid = this.roleMsg.role_id;
      bindRole(
        { time, token, channel, sid, sname, rolename, rid },
        { time, token }
      ).then((res) => {
        if (res.code == 1) {
          // 绑定成功
          this.$toast.success(res.msg);
          // this.SET_ISBIND(true);
          this.SET_ISMASKSHOW(false);
          // 获取登录用户信息
          this.$emit("getUserInfo");
        } else {
          this.$toast.fail(res.msg);
        }
      });
    },
  },
  computed: {
    isShowPop() {
      return this.$store.state.isShowPop;
    },
    roleMsg() {
      return this.$store.state.roleMsg;
    },
    userMsg() {
      return this.$store.state.userMsg;
    },
  },
};
</script>
<style lang="scss" scoped>
.changeRole{
    width:9.9rem;
    // padding: 1rem 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    .close{
        top: 0.1rem;
        right: 0.3rem;
    }
    .changeRole_content{
        width: 95%;
        height: 5rem;
        padding: 0.8rem 0 0 0.2rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin:0.2rem 0 0 0rem;
        background-image: imgUrl("bg_chooseWayLogin1.png");
        // 输入框placeholder字体颜色
        input::-webkit-input-placeholder {
          /* WebKit browsers */
          color: #94CAF8;
        }
        input:-moz-placeholder {
          /* Mozilla Firefox 4 to 18 */
          color: #94CAF8;
        }
        input::-moz-placeholder {
          /* Mozilla Firefox 19+ */
          color: #94CAF8;
        }
        input:-ms-input-placeholder {
          /* Internet Explorer 10+ */
          color: #94CAF8;
        }
        
        .inputGroup{
          display: flex;
          .server,
          .role{
              width: 5.81rem;
              height: 0.85rem;
              display: flex;
              justify-content: flex-start;
              align-items: center;
              padding: 0 0 0 0.32rem;
              background: #3071A9;
              font-size: 0.4rem;
              color: #94CAF8;
              border: 0.01px solid #EEF7FF;
              border-right: none;
          }
          .tag{
              width: 0.69rem;
              height: 0.85rem;
              background: #4FAEFF;
              border: 0.01px solid #EEF7FF;
              border-left: none;
              span{
                width: 0.37rem;
                height: 0.22rem;
                display: block;
                background-image: imgUrl("arrow1.png");
              }
          }
          &:nth-of-type(1){
            margin: 0.2rem 0 0 0 ;
          }
          &:nth-of-type(2){
            margin: 0.4rem 0 0 0 ;
          }
        }
        .btn{
          @include btn;
          margin: 0.43rem 0 0 0;
        }
      
        
    }
}
</style>