<template>
  <!-- 规则框 -->
  <div class="confirmPurchase">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="confirmPurchase_container">
      <div class="confirmPurchase_content">
        <span
          >是否購買NT${{ good.money }}禮包到角色
          {{ roleMsg.role_name }} 上？</span
        >
        <div class="checkBox" @click="purchase_tag = !purchase_tag">
          <i
            :class="{
              iconfont: true,
              'icon-no-check': purchase_tag,
              'icon-check': !purchase_tag,
            }"
          ></i
          >今日不再提示
        </div>
        <div class="btn_group">
          <div class="innerCenter" @click="SET_ISMASKSHOW(false)">取消</div>
          <div class="innerCenter" @click="confirmPay()">確認</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { getUserInfo, lottery_draw } from "@/api/hktw";
export default {
  name: "ConfirmGetEgg",
  props: {
    good: {
      type: Object,
    },
  },
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_COINTAG",
      "SET_USERMSG",
      "SET_GRAWLIST",
      "SET_PURCHASETAG",
    ]),
    // 确定购买
    confirmPay() {
      this.$emit("pay", this.good.id);
    },
  },
  computed: {
    roleMsg() {
      return this.$store.state.roleMsg;
    },
    purchase_tag: {
      get() {
        return this.$store.state.purchase_tag;
      },
      set(n) {
        this.SET_PURCHASETAG(n);
      },
    },
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.confirmPurchase{
    .close{
        top: 0.1rem;
        right: 0.3rem;
        z-index: 2;
    }
    .confirmPurchase_container{
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .confirmPurchase_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
              width: 70%;
              line-height: 0.45rem;
              margin:0.4rem 0 0 0;
            }
            .checkBox{
                display: flex;
                align-items: center;
                margin: 0.6rem 0 0 0;
                font-size: 0.33rem;
                i{
                    font-size:0.4rem;
                    margin: 0 0.2rem 0 0;
                }
            }
            .btn_group{
                width: 90%;
                display: flex;
                justify-content: space-around;
                margin:0.4rem 0 0  0;
                div{
                    &:nth-of-type(1){
                        @include btn("bg_btn_blue.png",#fff)
                    }
                    &:nth-of-type(2){
                        @include btn;
                    }
                }
            }
        }
     }
}
</style>