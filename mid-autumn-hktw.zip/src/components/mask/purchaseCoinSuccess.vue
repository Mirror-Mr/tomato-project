<template>
  <!-- 规则框 -->
  <div class="purchaseCoinSuccess">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="purchaseCoinSuccess_container" >
      <div class="purchaseCoinSuccess_content">
        <span>購買成功！獲得幸運幣*{{good.coin}},裏堡内包含元寶請到游戲内郵件檢查</span>
        <div class="innerCenter" @click="SET_ISMASKSHOW(false)">確認</div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { getUserInfo , lottery_draw } from "@/api/hktw";
export default {
  name: "PurchaseCoinSuccess",
  props:{
    good:{
       type: Object,
    }
  },
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations(["SET_ISMASKSHOW", "SET_MASKCONTENT", "SET_COINTAG","SET_USERMSG"]),
  },
  computed: {
   
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.purchaseCoinSuccess{
    .close{
        top: 0.1rem;
        right: 0.3rem;
        z-index: 2;
    }
     .purchaseCoinSuccess_container{
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .purchaseCoinSuccess_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
              width: 75%;
              line-height: 0.5rem;
              margin:0.4rem 0 0 0;
            }
            div{
                margin:1rem 0 0 0;
                @include btn;
            }
        }
     }
}
</style>