<template>
  <!-- 规则框 -->
  <div class="getEggSuccess">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="getEggSuccess_container">
      <div class="getEggSuccess_content">
        <span
          >恭喜您獲得
          <b> {{ addStar.num }}</b>
          星扭蛋 “
          <b>{{ addStar.type }}</b>
          ” 一枚！</span
        >
        <div class="innerCenter" @click="SET_ISMASKSHOW(false)">確認</div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { getUserInfo, lottery_draw } from "@/api/hktw";
export default {
  name: "GetEggSuccess",
  props: {
    addStar: {
      type: Object,
    },
  },
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_COINTAG",
      "SET_USERMSG",
    ]),
  },
  computed: {
    // 登录的用户信息
    userMsg: {
      get() {
        return this.$store.state.userMsg;
      },
      set(n) {
        this.SET_USERMSG(n);
      },
    },
    // 获取的扭蛋
    draw_list() {
      return this.$store.state.draw_list;
    },
    addStarType(){
      let el;
      if(this.addStar.type == "中"){
        el = "中"
      }else if(this.addStar.type == "秋"){
        el = "秋"
      }else if(this.addStar.type == "节"){
        el = "節"
      }else if(this.addStar.type == "快"){
        el = "快"
      }else{
        el = "樂"
      }
      return el;
    }
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.getEggSuccess{
    .close{
        top: 0.1rem;
        right: 0.3rem;
        z-index: 2;
    }
     .getEggSuccess_container{
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .getEggSuccess_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
                margin:0.4rem 0 0 0;
                b{
                  color: red;
                }
            }
            div{
                margin:1.5rem 0 0 0;
                @include btn;
            }
        }
     }
}
</style>