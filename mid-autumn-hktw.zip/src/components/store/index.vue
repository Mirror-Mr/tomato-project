<template>
  <div class="store">
    <div class="store_title"></div>
    <div class="store_box">
      <div class="suitShow">
        <div class="user_thing">
          <span>{{ userMsg.ynum ? userMsg.ynum : 0 }}</span>
          <span>{{ userMsg.jnum ? userMsg.jnum : 0 }}</span>
        </div>
      </div>
      <ul>
        <!-- item是个对象 包含一行的商品 有个数组属性包含商品属性 id表示第几排，从1开始  -->
        <li v-for="item in goods_list" :key="item.id">
          <div :class="`goods${item.id}_1`">
            <div class="goods_img">
              <img :src="`${baseUrl}${item.goods[0].goods_img}`" alt="" />
              <span
                >{{ item.goods[0].name }} * {{ item.goods[0].goods_num }}</span
              >
              <!-- <span>限购：{{exchanged[((item.id-1)*3+1).toString()]}} / {{ item.goods[0].limit }}</span> -->
              <span
                >限購：{{
                  exchanged[((item.id - 1) * 3 + 1).toString()]
                    ? exchanged[((item.id - 1) * 3 + 1).toString()]
                    : 0
                }}
                / {{ item.goods[0].limit }}</span
              >
            </div>
            <div
              class="btn_getGoods"
              @click="exchangeProp(item.goods[0], { x: item.id, y: 1 })"
            >
              <img :src="`${baseUrl}${item.goods[0].thing_img}`" alt="" />*
              {{ item.goods[0].thing_num }}
            </div>
          </div>
          <div :class="`goods${item.id}_2`">
            <div class="goods_img">
              <img :src="`${baseUrl}${item.goods[1].goods_img}`" alt="" />
              <span
                >{{ item.goods[1].name }} * {{ item.goods[1].goods_num }}</span
              >
              <span
                >限購：{{
                  exchanged[((item.id - 1) * 3 + 2).toString()]
                    ? exchanged[((item.id - 1) * 3 + 2).toString()]
                    : 0
                }}
                / {{ item.goods[1].limit }}</span
              >
            </div>
            <div
              class="btn_getGoods"
              @click="exchangeProp(item.goods[1], { x: item.id, y: 2 })"
            >
              <img :src="`${baseUrl}${item.goods[1].thing_img}`" alt="" />*
              {{ item.goods[1].thing_num }}
            </div>
          </div>
          <div :class="`goods${item.id}_3`" v-if="item.id != 6">
            <div class="goods_img">
              <img :src="`${baseUrl}${item.goods[2].goods_img}`" alt="" />
              <span
                >{{ item.goods[2].name }} * {{ item.goods[2].goods_num }}</span
              >
              <span
                >限購：{{
                  exchanged[((item.id - 1) * 3 + 3).toString()]
                    ? exchanged[((item.id - 1) * 3 + 3).toString()]
                    : 0
                }}
                / {{ item.goods[2].limit }}</span
              >
            </div>
            <div
              class="btn_getGoods"
              @click="exchangeProp(item.goods[2], { x: item.id, y: 3 })"
            >
              <img :src="`${baseUrl}${item.goods[2].thing_img}`" alt="" />*
              {{ item.goods[2].thing_num }}
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import { mapState, mapMutations } from "vuex";
export default {
  name: "store",
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
      // 累抽奖励列表
      goods_list: [
        {
          id: 1,
          goods: [
            {
              rid: 1,
              id: 4225,
              name: "衣服",
              goods_num: 1,
              limit: "5",
              goods_img: "thing1_2.png",
              thing_img: "thing3_2.png",
              thing_num: "3",
            },
            {
              rid: 2,
              id: 898,
              name: "髮飾",
              goods_num: 1,
              limit: "5",
              goods_img: "thing1_1.png",
              thing_img: "thing3_2.png",
              thing_num: "1",
            },
            {
              rid: 3,
              id: 598,
              name: "髮型-垂棠",
              goods_num: 1,
              limit: "5",
              goods_img: "thing1_3.png",
              thing_img: "thing3_2.png",
              thing_num: "1",
            },
          ],
        },
        {
          id: 2,
          goods: [
            {
              rid: 4,
              id: 6236,
              name: "耳飾",
              goods_num: 1,
              limit: "5",
              goods_img: "thing2_1.png",
              thing_img: "thing3_2.png",
              thing_num: "1",
            },

            {
              rid: 5,
              id: 1088,
              name: "背景",
              goods_num: 1,
              limit: "5",
              goods_img: "thing2_3.png",
              thing_img: "thing3_2.png",
              thing_num: "1",
            },
            {
              rid: 6,
              id: 3162,
              name: "寵物",
              goods_num: 1,
              limit: "5",
              goods_img: "thing3_1.png",
              thing_img: "thing3_2.png",
              thing_num: "1",
            },
          ],
        },
        {
          id: 3,
          goods: [
            {
              rid: 7,
              id: null,
              name: "桂花酒",
              goods_num: 1,
              limit: "不限",
              goods_img: "thing3_2.png",
              thing_img: "thing6_2.png",
              thing_num: "960",
            },
            {
              rid: 8,
              id: 235,
              name: "頭像框",
              goods_num: 1,
              limit: "5",
              goods_img: "thing3_3.png",
              thing_img: "thing6_2.png",
              thing_num: "960",
            },
            {
              rid: 9,
              id: 19,
              name: "头像",
              goods_num: 1,
              limit: "5",
              goods_img: "thing4_1.png",
              thing_img: "thing6_2.png",
              thing_num: "960",
            },
          ],
        },
        {
          id: 4,
          goods: [
            {
              rid: 10,
              id: 157,
              name: "黃銅腰牌",
              goods_num: 9,
              limit: "99",
              goods_img: "thing4_2.png",
              thing_img: "thing6_2.png",
              thing_num: "320",
            },
            {
              rid: 11,
              id: 128,
              name: "保養油",
              goods_num: 10,
              limit: "99",
              goods_img: "thing4_3.png",
              thing_img: "thing6_2.png",
              thing_num: "320",
            },
            {
              rid: 12,
              id: 1202,
              name: "玲瓏棋盒",
              goods_num: 1,
              limit: "99",
              goods_img: "thing5_1.png",
              thing_img: "thing6_2.png",
              thing_num: "108",
            },
          ],
        },
        {
          id: 5,
          goods: [
            {
              rid: 13,
              id: 1205,
              name: "秦蒙筆",
              goods_num: 3,
              limit: "99",
              goods_img: "thing5_2.png",
              thing_img: "thing6_2.png",
              thing_num: "108",
            },
            {
              rid: 14,
              id: 1206,
              name: "焦尾琴",
              goods_num: 2,
              limit: "99",
              goods_img: "thing5_3.png",
              thing_img: "thing6_2.png",
              thing_num: "108",
            },
            {
              rid: 15,
              id: 1,
              name: "元寶",
              goods_num: 10,
              limit: "99",
              goods_img: "thing6_1.png",
              thing_img: "thing6_2.png",
              thing_num: "4",
            },
          ],
        },
        {
          id: 6,
          goods: [
            {
              rid: 16,
              id: null,
              name: "月餅",
              goods_num: 4,
              limit: "99",
              goods_img: "thing6_2.png",
              thing_img: "one_coin.png",
              thing_num: "1",
            },
            {
              rid: 17,
              id: null,
              name: "月餅",
              goods_num: 960,
              limit: "不限",
              goods_img: "thing6_3.png",
              thing_img: "thing3_2.png",
              thing_num: "1",
            },
            // {
            //   rid: 18,
            //   id: null,
            //   name: "月饼",
            //   goods_num: 960,
            //   limit: "10",
            //   goods_img: "thing6_3.png",
            //   thing_img: "thing3_2.png",
            //   thing_num: "1",
            // },
          ],
        },
      ],
    };
  },
  methods: {
    ...mapMutations(["SET_ISMASKSHOW", "SET_MASKCONTENT", "SET_MAINLANDLOGIN"]),
    // 兑换道具
    exchangeProp(obj1, obj2) {
      this.$emit("setPrevMask", "exchangeProp");
      // 第x排第y个商品
      if (this.isBind) {
        this.SET_ISMASKSHOW(true);
        this.SET_MASKCONTENT("exchangeProp");
        let obj = Object.assign(obj1, obj2);
        this.$emit("propMsg", obj);
      } else {
        if (this.isLogin) {
          //没绑定 但登陆了
          this.SET_ISMASKSHOW(true);
          this.SET_MASKCONTENT("mainland");
          this.SET_MAINLANDLOGIN("binding");
        } else {
          // 没绑定 且没登录
          this.SET_ISMASKSHOW(true);
          this.SET_MASKCONTENT("hktwLogin");
        }
      }
    },
  },
  computed: {
    userMsg() {
      if (this.isLogin) {
        return this.$store.state.userMsg;
      }
      return {};
    },
    isBind() {
      return this.$store.state.isBind;
    },
    isLogin() {
      return this.$store.state.isLogin;
    },
    // 兑换商店中已兑换的东西
    exchanged() {
      if (this.userMsg.prize) {
        return this.userMsg.prize["3"] ? this.userMsg.prize["3"] : {};
      }
      return {};
    },
  },
};
</script>
<style lang="scss" scoped>
 @import './goods_img.scss';
.store{
    width: 100%;
    z-index: 2;
    margin:-0.5rem 0 0 0;
    .store_title{
    width: 100%;
    height: 1.7rem;
    margin: 0.7rem 0 0 0;
    background-image: imgUrl("store_title1.png");
    }
    .store_box{
        width: 96%;
        height: 22.1rem;
        display: flex;
        flex-direction: column;
        margin:-0.5rem 0 0 0.4rem;
        padding-top: 0.01rem;
        background-image: imgUrl("bg_store_box.png");
        .suitShow{
            width: 86%;
            height: 5.2rem;
            margin: 0.85rem 0 0 0.5rem;
            flex-shrink: 0;
            background-image: imgUrl("suitShow1.png");
            .user_thing{
                width: 2.7rem;
                height: 0.99rem;
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                margin: 1.1rem 0 0 5.2rem;
                color: #FFFFFF;
                font-size: 0.32rem;
                background-image: imgUrl("user_thing1.png");
                span{
                  &:nth-child(1){
                    margin: 0.1rem 0 0 1.4rem;
                  } 
                  &:nth-child(2){
                    margin: 0.13rem 0 0 1.7rem;
                  } 
                }
            }
        }
    }
    ul{
        width: 93%;
        height: 15rem;
        margin: 0.26rem 0 0 0.14rem;
        display: flex;
        flex-direction: column;
        overflow: auto;
        li{
            display: flex;
            flex-shrink: 0;
            justify-content: space-around;
            // 第一个li
            &:not(:nth-of-type(1)){
                margin: 0.3rem 0 0 0;
            }
            div{
                width: 25.5%;
                display: flex;
                flex-direction: column;
                align-items: center;
                .goods_img{
                    width: 100%;
                    height: 2.3rem;
                    position:relative;
                    flex-shrink: 0;
                    display: flex;
                    align-items: center;
                    background-image: imgUrl("bg_goods.png");
                    img{
                      width: auto;
                    }
                   span{
                     position: absolute;
                     &:nth-of-type(1){
                       bottom: 0.69rem;
                       color: #2A78BB;  
                       font-size: 0.34rem;
                       font-weight: bold;
                       -webkit-text-stroke: 0.2px #FFFFFF;
                       text-stroke: 0.2px #FFFFFF;
                     }
                     &:nth-of-type(2){
                       bottom: 0.15rem;
                       font-size: 0.32rem;
                       color: #FFEFB3;
                     }
                   }
                }
                .btn_getGoods{
                    width: 2.09rem;
                    height: 0.63rem;
                    flex-shrink: 0;
                    display: flex;
                    flex-direction: row;
                    justify-content: center;
                    align-items:center;
                    margin:0.21rem 0 0 0;
                    background-image: imgUrl("btn_getGoods.png");
                    img{
                      width: 0.5rem;
                      margin: 0 0.1rem 0 -0.1rem;
                    }
                }
                
            }
        }
    }
}
</style>