/*
 * @Author: your name
 * @Date: 2021-01-29 15:28:28
 * @LastEditTime: 2021-02-22 10:53:20
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\styy_order\js\index.js
 */
// 第一页
$Box1 = $(".Box1");
// 第一页高度
let h_box1 = $Box1.css("height");
// 第二页
$Box2 = $(".Box2");
// 第三页
$Box3 = $(".Box3");
// 第四页
$Box4 = $(".Box4");
// 遮罩层
let $mask = $(".mask");
// 关闭遮罩层按钮
let $close = $(".close");
// 预约框
let $mask_box = $(".mask_box");
// 预约获得抽奖资格按钮
let $getChance = $(".getChance");
// 立即预约按钮
let $nowOrder = null;
// IOS按钮
let $btn_ios = null;
// 安卓按钮
let $btn_andr = null;
// 判断是安卓 2 还是 ios 1
let pType = isiOS ? 1 : 2;
// 当前手机号对应的手机型号
let cType = 1;
// 用户有几次抽奖机会
let userChance = 100;
// 用户是否预约
let isOrder = 0;
// 当前预约的手机号
let number = null;
// 验证码输入框
let $code = null;
// 输入的验证码
let code = null;
// container容器
let $container = $("#container");
// 线上还是线下奖品 默认线上
let gift = 0;
// 线上礼品回复
let gift0 = `<div class='gift0'>
                <b>注意事项：</b>
                <p>恭喜您获得《盛唐烟雨》新春特辑礼包码，礼包奖励将在游戏上线后将礼包码发送到手机上</p>
             </div>`;
let gift1 = `<div class='gift1'>
                <form action='' method='post'>
                  <div>
                    姓名：<input type="text" class="name" />
                  </div>
                  <div>
                    电话：<input type="text" class="phone" />
                  </div>
                  <div>
                    地址：<input type="text" class="address" />
                  </div>
                    <a href='#' type="submit" class = 'submit'>确认提交</a>
                    <p>注意事项：</p>
                    <p>恭喜你获得《盛唐烟雨》实物奖励，需要您正确填写收获地址，奖励将在20个工作日内寄出</p>
                </form>
            </div>`;
// 是否点击分享按钮
let isShare = 0;
// 显示用户有几次抽奖机会的容器
let $chanceNum = $(".chanceNum");
// 规则说明
let rule = `<div class='ruleText'>
                <b>规则：</b>
                <p>本活动从即日起至2021年2月18日截止，可以通过预约、抽奖获得两次抽奖资格。</p>
                <p>实物奖品将在活动结束后14个工作日左右寄出，游戏礼包奖励将在游戏上线后，以短信形式发送到预约的手机号上。</p>
            </div>`;
// 手机号预约
let phoneOrder = `<form action="" method="post">
                    <div>
                      选择设备：
                      <a href="#" class="andr">安卓</a>
                      <a href="#" class="ios">IOS</a>
                    </div>
                    <div>手机号 ：<input type="tel" class="p_num"  maxlength ="11"/></div>
                    <div>
                      验证码：
                      <a href="#" class="getCode">发送验证码</a>
                      <input type="text" class="code"  type="tel" maxlength = '6' />
                    </div>
                    <!-- 立即预约按钮 -->
                    <a href="#" class="nowOrder"></a>
                  </form>`;

// 中奖名单文字框
let $rollText = $(".rollBox span:eq(0)");
let left = 0;

// 上一个奖品
let $toLeft_G = null;
// 下一个奖品
let $toRight_G = null;

// 奖品轮播
let swiper1 = null;

// 图片轮播
let swiper2 = null;

// 上一个奖品
let $toLeft_P = $(".Box4 .toLeft");
// 下一个奖品
let $toRight_P = $(".Box4 .toRight");

// 视频播放器
let $video = $(".myVideo");

// 手机号
let $phoneNum = null;
/**
 * 传递的参数
 */
let key = "0391591aafc5db68b08787645b837b4f";
let timer = null;
// 历史预约用户
let historyUsers = [];
// 中奖记录按钮
let $record = $(".record");
// 当前手机号的奖品集
let gifts = [];
// 假数据
gifts = [
  // { phone: "15616009529", rname: "盛唐正方形抱枕", rid: "5" },
  // { phone: "15616009529", rname: "春节专属预约礼包码", rid: "7" },
];
// 确认提交用户地址数据按钮
$submit = null;
//手机号列表
let $numList = $(".numList");
// 分享再抽一次按钮
let $again = null;
// 点击领取奖励按钮
let $getGift = $(".getGift");
// 动画效果计数器
let sum = 0;
// -----------------------------------------模拟当前用户

// localStorage.setItem("currentUser", JSON.stringify("15674485091"));
// localStorage.setItem("currentUser", JSON.stringify("15616009529"));
// historyUsers = ["15674485091","15616009529"];
// localStorage.setItem("historyUsers", JSON.stringify(historyUsers));

// ------------------------------------------模拟当前用户
// 进入首页埋点
point(1);
number = JSON.parse(localStorage.getItem("currentUser"));
if (number) {
  //有已登录的手机号
  isOrder = 1;
  getChanceNum();
  getGifts();
}
// 获取该手机号的抽奖次数函数
function getChanceNum() {
  timer = parseInt(Date.parse(new Date()) / 1000);
  $.ajax({
    type: "post",
    url: "https://api.xianyuyouxi.com/service/test/styy_appoint/get_userinfo",
    data: {
      time: timer,
      phone: number,
    },
    headers: {
      "Access-s": $.md5(`${key}${timer}${number}`),
    },
    dataType: "json",
    success: function (res) {
      // userChance = 100
      if (res.status) {
        // 获取抽奖次数成功
        console.log("抽奖次数");
        console.log(res);
        userChance = res.data;
        $chanceNum.text(`您有${userChance}次抽奖机会`);
        if (userChance) {
          $(".getChance").addClass("draw");
        }
      } else {
        console.log("获取抽奖次数失败");
      }
    },
  });
}
// 获取该手机号的奖品集
function getGifts() {
  timer = parseInt(Date.parse(new Date()) / 1000);
  $.ajax({
    type: "post",
    url: "https://api.xianyuyouxi.com/service/test/styy_appoint/get_prize_log",
    data: {
      time: timer,
      phone: number,
    },
    headers: {
      "Access-s": $.md5(`${key}${timer}${number}`),
    },
    dataType: "json",
    success: function (res) {
      console.log("奖品清单");
      console.log(res);
      gifts = res.data;
    },
  });
}
// ------------------------------第一页开始
// 中将名单轮播
setInterval(() => {
  if (left < -44) {
    left = 5;
  }
  left = left - 0.02;
  $rollText.css("marginLeft", left + "rem");
}, 100);

// 从本地获取历史预约手机号
showPhoneList();
// 历史预约列表点击事件
$(".history .set").click(function () {
  var ul = $(".numList");
  if (ul.css("display") == "none") {
    ul.slideDown();
  } else {
    ul.slideUp();
  }
});

function numList_click() {
  // 切换手机号点击事件
  $(".history li").click(function () {
    var num = $(this).text();
    if (num == "注销") {
      userChance = 0;
      isOrder = 0;
      number = null;
      localStorage.setItem("currentUser", JSON.stringify(number));
      $(".history .set").text("切换手机号");
      $chanceNum.text(`您有${userChance}次抽奖机会`);
      $(".getChance").removeClass("draw");
      $(".numList").hide();
      showPhoneList();
    } else if (num != number && num != "无") {
      $(".history .set").text(num);
      // 替换当前登录手机号的信息
      number = num;
      isOrder = 1;
      getChanceNum();
      getGifts();
      localStorage.setItem("currentUser", JSON.stringify(number));
      showPhoneList();
    } else {
    }

    $(".numList").hide();
  });
}

// 将本地存储的历史预约手机号展示函数
function showPhoneList() {
  number = JSON.parse(localStorage.getItem("currentUser"));
  if (number) {
    $(".history .set").text(number);
  }
  let arr = JSON.parse(localStorage.getItem("historyUsers"));

  if (arr) {
    historyUsers = arr;
  }
  let temp = "";
  if (!number && historyUsers.length > 0) {
    for (let i = 0; i < historyUsers.length; i++) {
      temp += `<li>${historyUsers[i]}</li>`;
    }
  } else if (number && historyUsers.length > 0) {
    //曾有过预约
    for (let i = 0; i < historyUsers.length; i++) {
      temp += `<li>${historyUsers[i]}</li>`;
    }
    temp += `<li class='destory'>注销</li>`;
  } else {
    temp = "<li class = 'no'>无</li>";
  }
  $numList.html(temp);
  numList_click();
}
// 点击规则说明按钮
$(".rule").click(() => {
  $mask_box.html(rule);
  $mask_box.css("display", "block");
  $close.css("display", "block");
  $mask.css("background", "rgba(0,0,0,0.4)");
  $mask.fadeIn();
});
// 点击中奖记录按钮
$record.click(() => {
  if (isOrder && gifts.length) {
    //有手机号登录且抽过奖才允许点击
    $Box1.fadeOut();
    $Box3.fadeIn();
    box3_click();
    showGift();
  } else {
    alert("当前无中奖记录");
  }
});
// 点击分享按钮
$('.share').click(() => {
  console.log(111)

  if (isOrder && userChance) {
    //有手机号登录且抽过奖才允许点击
    point(2);
    addChance()
    $mask.text("请分享到微信好友或朋友圈")
    $mask_box.css("display", "none");
    $close.css("display", "none");
    $mask.fadeIn();
    isShare = 1;
  } else {
    alert("请先预约");
  }
  // if (isX) {
  //   $mask
  //     .css(
  //       "background",
  //       "url(https://wcdn.tomatogames.com/web/guonei/styy/order/img/iX/share.png) no-repeat"
  //     )
  //     .css("backgroundSize", "100%");
  // } else {
  //   $mask
  //     .css(
  //       "background",
  //       "url(https://wcdn.tomatogames.com/web/guonei/styy/order/img/i6/share.png) no-repeat"
  //     )
  //     .css("backgroundSize", "100%");
  // }


})
// 点击获得抽奖机会/立即抽奖按钮
$getChance.click(() => {
  //若用户已预约 且有抽奖机会
  if (isOrder && userChance) {
    // 进入抽奖动画
    $Box1.fadeOut(1200);
    $Box2.css("height", h_box1);
    // $(".cardsBox li").fadeIn(400);
    $Box2.fadeIn(400);
    cardsBox_click();
    userChance--;
    timer = parseInt(Date.parse(new Date()) / 1000);
    // 发送抽奖请求
    $.ajax({
      type: "post",
      url: "https://api.xianyuyouxi.com/service/test/styy_appoint/subReward",
      data: {
        time: timer,
        phone: number,
      },
      headers: {
        "Access-s": $.md5(`${key}${timer}${number}`),
      },
      dataType: "json",
      success: function (res) {
        console.log(res);
        $(".desc").text(res.data.name);
        let img = document.createElement('img')
        img.src = "https://wcdn.tomatogames.com/web/guonei/styy/order/img/i6/" + res.data.id + ".png"
        // $(".currentPic").attr(
        //   "src",
        //   "https://wcdn.tomatogames.com/web/guonei/styy/order/img/i6/" +
        //   res.data.id +
        //   ".png"
        // );
        $(".currentPic").append(img)
        // 成功抽到奖 获取奖品名单
        getGifts();
      },
    });
  } else if (isOrder && !userChance) {
    //若用户已预约 抽奖机会已用完
    alert("您已无抽奖机会");
  } else {
    //预约获得抽奖机会按钮点击
    $mask_box.html(phoneOrder);
    $nowOrder = $(".nowOrder");
    $phoneNum = $(".p_num");
    $btn_ios = $(".ios");
    $btn_andr = $(".andr");
    $code = $(".code");
    maskBoxClick();
    if (pType) {
      $btn_ios.css("color", "#fff2e2").css("backgroundColor", " #b53c09");
      $btn_andr.css("color", "#b53c09").css("backgroundColor", " #fff2e2");
    } else {
      $btn_ios.css("color", "#b53c09").css("backgroundColor", " #fff2e2");
      $btn_andr.css("color", "#fff2e2").css("backgroundColor", " #b53c09");
    }
    $mask.fadeIn();
  }
});

// 绑定手机号预约框内函数
function maskBoxClick() {
  // 点击选择ios型号
  $btn_ios.click(() => {
    cType = 1;
    $btn_ios.css("color", "#fff2e2").css("backgroundColor", " #b53c09");
    $btn_andr.css("color", "#b53c09").css("backgroundColor", " #fff2e2");
  });

  // 点击选择安卓型号
  $btn_andr.click(() => {
    cType = 2;
    $btn_ios.css("color", "#b53c09").css("backgroundColor", " #fff2e2");
    $btn_andr.css("color", "#fff2e2").css("backgroundColor", " #b53c09");
  });

  // 点击发送验证码按钮
  $(".getCode").click(() => {
    number = $phoneNum.val();
    if (!number) {
      $phoneNum.attr("placeholder", "手机号不能为空！");
    } else {
      getCode();
    }
  });
  // 发送验证码函数
  function getCode() {
    timer = parseInt(Date.parse(new Date()) / 1000);
    // 发送请求
    $.ajax({
      type: "post",
      url: "https://api.xianyuyouxi.com/service/test/styy_appoint/sendCode",
      data: {
        // 手机型号 + 手机号
        time: timer,
        phone: number,
      },
      headers: {
        "Access-s": $.md5(`${key}${timer}${number}`),
      },
      dataType: "json",
      success: function (res) {
        //接收传回的数据
        console.log(res);
        if (res.status) {
          let time = 180;
          let id = setInterval(() => {
            $(".getCode").text(time + "s");
            time--;
            if (time < 0) {
              $(".getCode").text("发送验证码");
              clearInterval(id);
            }
          }, 1000);
        } else {
          alert("发送验证码失败！ 请重新发送！");
        }
      },
    });
  }
  // 点击立即预约按钮
  $nowOrder.click(() => {
    number = $phoneNum.val();
    if (!number) {
      $phoneNum.attr("placeholder", "手机号不能为空！");
    } else {
      code = $code.val();
      if (!code) {
        $code.attr("placeholder", "不能为空！");
      } else {
        timer = parseInt(Date.parse(new Date()) / 1000);
        // 发送请求
        $.ajax({
          type: "post",
          url: "https://api.xianyuyouxi.com/service/test/styy_appoint/login",
          data: {
            // 手机型号 + 手机号
            time: timer,
            phone: number,
            code: code,
            dev: cType,
          },
          headers: {
            "Access-s": $.md5(`${key}${timer}${number}${code}`),
          },
          dataType: "json",
          success: function (res) {
            // 预约失败
            if (!res.status) {
              $code.val("");
              $code.attr("placeholder", res.msg);
              number = null;
            } else {
              //预约成功
              isOrder = 1;
              localStorage.setItem("currentUser", JSON.stringify(number));

              historyUsers.unshift(number);
              localStorage.setItem(
                "historyUsers",
                JSON.stringify(historyUsers)
              );
              showPhoneList();
              // 获取该用户有多少次抽奖机会
              $.ajax({
                type: "post",
                url:
                  "https://api.xianyuyouxi.com/service/test/styy_appoint/get_userinfo",
                data: {
                  // 手机型号 + 手机号
                  time: timer,
                  phone: number,
                },
                headers: {
                  "Access-s": $.md5(`${key}${timer}${number}`),
                },
                dataType: "json",
                success: function (res) {
                  console.log(res);
                  if (res.status) {
                    // 获取抽奖次数成功
                    userChance = res.data;
                    $chanceNum.text(`您有${userChance}次抽奖机会`);
                    $mask_box.html(
                      "<span class='getOne'>预约成功！恭喜你获得一次抽奖资格！</span>"
                    );
                    $(".getChance").addClass("draw");
                  } else {
                    alert("获取抽奖次数失败");
                  }
                },
              });
            }
          },
        });
      }
    }
  });
}
// 点击遮罩层关闭
$close.click(() => {
  $mask.fadeOut();
});

//点击跳转游戏介绍页
$(".game").click(() => {
  $Box1.fadeOut();
  $Box3.fadeOut();
  $Box4.fadeIn();
  swiper2 = new Swiper(".swiper-container_2", {
    allowTouchMove: false,
    loop: true,
    pagination: {
      el: ".swiper-pagination",
    },
  });
});

// ------------------------------第一页结束
// ------------------------------第二页开始
// 监听卡牌组旋转动画结束
function cardsBox_click() {
  $(".cardsBox")[0].addEventListener("animationend", myStartFunction);
  // 回调函数
  function myStartFunction(e) {
    e.stopPropagation();
    // sum++;
    // if (sum == 1) {
    //   console.log(1);
    // 获取除了抽中卡牌之外的牌 都消失
    $(".cardsBox li:not(:eq(9))").fadeOut();
    $(".cardsBox").addClass("anima");
    $(".cardsBox li:eq(9)").addClass("anima");
    // $(".cardsBox li:eq(9) .back").hide()
    // }
  }
  // 监听抽中卡牌旋转动画结束
  $(".cardsBox li:eq(9) ")[0].addEventListener("animationend", (e) => {
    e.stopPropagation();
    // sum++;
    // console.log('sum', sum)
    // if (sum == 3) {
    console.log(2);
    $Box3.css("display", "block");

    $Box2.css("display", "none");
    $(".cardsBox.anima").removeClass("anima");
    $(".cardsBox li:eq(9).anima").removeClass("anima");
    box3_click();
    showGift();
    //   sum = 0;
    // }
  });
}


// ------------------------------第二页结束
// ------------------------------第三页开始
// 奖品展示函数
function showGift() {
  swiper1 = new Swiper(".swiper-container_1", {
    allowTouchMove: false,
  });
  // 奖品展示
  // for (let i = gifts.length - 1; i >= gifts.length - 2; i--) {
  for (let i = gifts.length - 1, j = 1; i >= 0; i--, j++) {
    // $(".gift" + (i + 1) + " .desc").text(gifts[i].rname);
    $(".gift" + j + " .desc").text(gifts[i].rname);
    // $(".gift" + (i + 1) + " img").attr(
    //   "src",
    //   "./img/i6/" + gifts[i].rid + ".png"
    // );
    $(".gift" + j + " img").attr(
      "src",
      "https://wcdn.tomatogames.com/web/guonei/styy/order/img/i6/" +
      gifts[i].rid +
      ".png"
    );
    if (gifts[i].rid == 7) {
      $(".gift" + j + " .getGift").attr("data-type", "0");
    } else {
      $(".gift" + j + " .getGift").attr("data-type", "1");
    }
  }
  $toLeft_G = $(".Box3 .toLeft");
  $toRight_G = $(".Box3 .toRight");
  if (gifts.length > 1) {
    $toLeft_G.fadeIn();
    $toRight_G.fadeIn();
    $again.css("display", "none");
  }
  toClick();
}

// 点击领取抽奖获取的奖品
$(".getGift").click(function () {
  $mask.css("background", "rgba(0, 0, 0, 0.4)");

  // 判断是线上还是线下奖品
  gift = $(this).attr("data-type");
  if (gift == 1) {
    //线下
    $mask_box.html(gift1);
    $submit = $(".submit");
    $submit.click(() => {
      let name = $(".name").val();
      let phone = $(".phone").val();
      let address = $(".address").val();
      timer = parseInt(Date.parse(new Date()) / 1000);
      // 提交用户地址数据
      $.ajax({
        type: "post",
        url: "https://api.xianyuyouxi.com/service/test/styy_appoint/subData",
        data: {
          time: timer,
          phone: number,
          mobile: phone,
          name: name,
          addr: address,
        },
        headers: {
          "Access-s": $.md5(`${key}${timer}${number}`),
        },
        dataType: "json",
        success: function (res) {
          console.log('res', res);
          alert(res.msg)
        },
      });
    });
  } else {
    //线上
    $mask_box.html(gift0);
  }
  $mask_box.fadeIn();
  $close.fadeIn();
  $mask.fadeIn();
});
// box3内点击事件的绑定函数
function box3_click() {
  $again = $(".Box3 .again");
  // 点击再抽一次
  $again.click(function () {
    point(2);
    // if (isX) {
    //   $mask
    //     .css(
    //       "background",
    //       "url(https://wcdn.tomatogames.com/web/guonei/styy/order/img/iX/share.png) no-repeat"
    //     )
    //     .css("backgroundSize", "100%");
    // } else {
    //   $mask
    //     .css(
    //       "background",
    //       "url(https://wcdn.tomatogames.com/web/guonei/styy/order/img/i6/share.png) no-repeat"
    //     )
    //     .css("backgroundSize", "100%");
    // }
    addChance()
    $mask_box.css("display", "none");
    $close.css("display", "none");
    $mask.fadeIn();
    isShare = 1;
  });
}

// 遮罩层被点击
$(".mask").click(function () {
  // 且是点击分享后 被点击 则取消遮罩层
  if (isShare) {
    $(this).fadeOut();
    isShare = 0;
  }
});
// 绑定奖品轮播左右点击事件函数
function toClick() {
  // 点击上一个奖品
  $toLeft_G.unbind("click").on("click", () => {
    swiper1.slidePrev();
  });
  // 点击下一个奖品
  $toRight_G.unbind("click").on("click", () => {
    swiper1.slideNext();
  });
}

// ------------------------------第三页结束
// ------------------------------第四页开始

// 点击视频播放按钮
$(".play").click(function () {
  $video.show()
  $video.attr("controls", "true");
  $video[0].play();
  $(this).fadeOut();
});

// 点击上一个图片
$toLeft_P.click(() => {
  swiper2.slidePrev();
});
// 点击下一个图片
$toRight_P.click(() => {
  swiper2.slideNext();
});
$(".toHome").click(() => {
  $Box3.fadeOut();
  $Box4.fadeOut();
  $Box1.fadeIn();
  $chanceNum.text(`您有${userChance}次抽奖机会`);
  window.location.reload();
});
// ------------------------------第四页结束
//  ----------------------------------调起微信分享
timer = parseInt(Date.parse(new Date()) / 1000);
$.ajax({
  type: "post",
  url: "https://api.xianyuyouxi.com/service/test/styy_appoint/getSignPackage",
  data: {
    time: timer,
    url: location.href,
  },
  dataType: "json",
  headers: {
    "Access-s": $.md5(`${key}${timer}`),
  },
  success: function (res) {
    // console.log(res)
    wx.config({
      debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
      appId: res.data.appId, // 必填，公众号的唯一标识
      timestamp: res.data.timestamp, // 必填，生成签名的时间戳
      nonceStr: res.data.nonceStr, // 必填，生成签名的随机串
      signature: res.data.signature, // 必填，签名
      jsApiList: ["onMenuShareTimeline", "onMenuShareAppMessage"], // 必填，需要使用的JS接口列表
    });
    wx.checkJsApi({
      jsApiList: ["onMenuShareTimeline", "onMenuShareAppMessage"], // 需要检测的JS接口列表，所有JS接口列表见附录2,
      success: function (res) { },
    });
    wx.ready(function () {
      //分享到朋友圈
      wx.onMenuShareTimeline({
        title: "预约《盛唐烟雨》抽欧舒丹护手霜、迪奥润唇膏、M.A.C 口红等奖品。", // 分享标题
        desc:
          "预约《盛唐烟雨》，选择属于你的盛世情缘！两朝迭代，一唐盛世，半生浮沉，几分情缘。进入《盛唐烟雨》的世界里，你将在家仇国恨与个人情仇中不断抉择，一边是家族使命、一边是个人情感，所有故事的转折尽在你一念间.....", // 分享描述
        link: 'https://styy.tomatogames.com/newyear/', // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl:
          "https://wcdn.tomatogames.com/web/guonei/styy/order/img/i6/icon.png", // 分享图标
        success: function () {
          point(3);
          $mask.fadeOut();
          addChance();
          $Box3.fadeOut();
          $Box4.fadeOut();
          $Box1.fadeIn();
          getChanceNum();
          location.reload()
        },
      });
      //分享给朋友
      wx.onMenuShareAppMessage({
        title: "预约《盛唐烟雨》抽欧舒丹护手霜、迪奥润唇膏、M.A.C 口红等奖品。", // 分享标题
        desc:
          "预约《盛唐烟雨》，选择属于你的盛世情缘！两朝迭代，一唐盛世，半生浮沉，几分情缘。进入《盛唐烟雨》的世界里，你将在家仇国恨与个人情仇中不断抉择，一边是家族使命、一边是个人情感，所有故事的转折尽在你一念间.....", // 分享描述
        link: 'https://styy.tomatogames.com/newyear/', // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl:
          "https://wcdn.tomatogames.com/web/guonei/styy/order/img/i6/icon.png", // 分享图标
        success: function () {
          // 用户点击了分享后执行的回调函数
          point(3);
          $mask.fadeOut();
          addChance();
          $Box3.fadeOut();
          $Box4.fadeOut();
          $Box1.fadeIn();
          getChanceNum();
          location.reload()
        },
      });
    });
  },
});

// 增加分享后的抽奖数函数
function addChance() {
  timer = parseInt(Date.parse(new Date()) / 1000);
  $.ajax({
    type: "post",
    url: "https://api.xianyuyouxi.com/service/test/styy_appoint/subPnum",
    data: {
      // 手机型号 + 手机号
      time: timer,
      phone: number,
    },
    headers: {
      "Access-s": $.md5(`${key}${timer}${number}`),
    },
    dataType: "json",
    success: function (res) {
      //接收传回的数据
      console.log(res);
      if (res.status == 1) {
        console.log("分享成功抽奖数加1");
      } else {
      }
    },
  });
}
// 埋点请求函数
function point(n) {
  timer = parseInt(Date.parse(new Date()) / 1000);
  $.ajax({
    type: "post",
    url: "https://api.xianyuyouxi.com/service/test/styy_appoint/click",
    data: {
      time: timer,
      type: n,
      dev: pType,
    },
    headers: {
      "Access-s": $.md5(`${key}${timer}`),
    },
    dataType: "json",
    success: function (res) { },
  });
}
