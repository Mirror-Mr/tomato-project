/*
 * @Author: your name
 * @Date: 2021-01-21 14:21:39
 * @LastEditTime: 2021-03-11 10:49:34
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\sezg_extra\js\PCIndex.js
 */
new Vue({
  data() {
    return {
      // 是不是PC端
      isPC: isPC,
      // 是不是iX
      isX: isX,
      // 轮播图
      swiper: null,
      swiper1: null,
      // 标题
      // titles: ["新服集结", "死神联动", "年度锦鲤", "攻略征集", "召回福利"],
      titles: ["新服集结", "死神联动", "年度锦鲤", "攻略征集"],
      // 当前显示的是哪一个活动
      isPage: 0,
      // 活动1的当前按钮 默认点击第一个按钮
      isBtn: 0,
      // 指针的top
      f_top: 0.35,
      // 指针的left
      f_left: 0.9,
      // 标题是否有动画类
      isTrans: true,
      // 视频是否显示
      isVideo:false
    };
  },
  methods: {
    createSwiper() {
      var swiper = null;
      var swiper1 = null;
      that = this;
      if (isPC) {
        //PC端
        swiper = new Swiper(".swiper-container_00", {
          direction: "vertical",
          speed: 830,
          allowTouchMove: false,
          initialSlide: 0, //默认显示第张在中心位置
          mousewheel: true,
          pagination: {
            el: ".swiper-pagination",
            clickable: true,
          },
          on: {
            slideChangeTransitionStart() {
              that.isTrans = false;
              that.isPage = this.realIndex;
              // that.f_top = 0.35 + this.realIndex * 0.32;
              that.f_top = 0.35 + this.realIndex * 0.43;
            },
            slideChangeTransitionEnd() {},
          },
        });
        swiper1 = new Swiper(".swiper-container_01", {
          direction: "vertical",
          nested: true, //切换该轮播图时 阻止父轮播图的切换
          mousewheel: true,
          allowTouchMove: false,
          speed: 830,

          pagination: {
            el: ".swiper-pagination",
            clickable: true,
          },
          on: {
            slideChangeTransitionStart() {
              that.isBtn = this.realIndex;
            },
          },
        });
      } else {
        swiper = new Swiper(".swiper-container_00", {
          initialSlide: 0, //默认显示第张在中心位置
          speed: 830,

          on: {
            slideChangeTransitionStart() {
              that.isTrans = false;
              that.isPage = this.realIndex;
              // that.f_left = 0.45 + this.realIndex * 1.78;
              that.f_left = 0.9 + this.realIndex * 2;
            },
            slideChangeTransitionEnd() {},
          },
        });
        swiper1 = new Swiper(".swiper-container_01", {
          nested: true, //切换该轮播图时 阻止父轮播图的切换
          resistanceRatio: 0,
          speed: 830,

          pagination: {
            el: ".swiper-pagination",
            clickable: true,
          },
          on: {
            slideChangeTransitionStart() {
              that.isBtn = this.realIndex;
            },
          },
        });
      }

      this.swiper = swiper;
      this.swiper1 = swiper1;
    },
    toPage(index) {
      this.isPage = index;
      this.swiper.slideTo(index);
    },
    showVideo(){
      this.isVideo = !this.isVideo;
    }
  },
  mounted() {
    this.createSwiper();
  },
  watch: {
    isPage: function (newPage, oldPage) {
      var that = this;

      setTimeout(() => {
        that.isTrans = true;
      }, 50);
    },
    isBtn() {
      this.swiper1.slideTo(this.isBtn);
    },
  },
}).$mount("#app");
