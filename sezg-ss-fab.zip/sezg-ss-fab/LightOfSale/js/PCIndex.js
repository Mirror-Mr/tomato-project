/*
 * @Author: your name
 * @Date: 2021-01-18 14:16:12
 * @LastEditTime: 2021-01-27 20:12:15
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\LightOfSale\js\PCIndex.js
 */
new Vue({
  data() {
    return {
      // 当前页面
      currentP: 0,
      // 是否在切换页面
      isTrans:false,
      // 当前显示人物
      currentC: 0,
      Top: 0.1,
      character: [
        {
          name: "黑崎一护",
          info: `卍解后的代理死神。自身的速度、灵压和战斗力因卍解得到了质的飞跃。`,
          skills: [
            {
              skillName: "主动技能：天舞连讯",
              skillImg: "https://wcdn.tomatogames.com/web/guonei/sezg/ssldfab/img/page02/c1_01.png",
              skillInfo: `技能描述：召唤卍解·黑崎一护快速挥刀对周围目标造成伤害，挥刀时免疫伤害`,
            },
            {
              skillName: "被动技能：天锁斩月",
              skillImg: "https://wcdn.tomatogames.com/web/guonei/sezg/ssldfab/img/page02/c1_02.png",
              skillInfo: `技能描述：黑崎一护斩魂刀的变小，但能力得到增强，攻击后大幅提高攻击力、移动速度、冷却缩减，持续10秒，每60秒触发一次`,
            },
          ],
        },
        {
          name: "朽木露琪亚",
          info: `失去力量后借用义骸恢复灵力，并在现世活动的死神，擅长鬼道。`,
          skills: [
            {
              skillName: "主动技能：次舞·白涟",
              skillImg: "https://wcdn.tomatogames.com/web/guonei/sezg/ssldfab/img/page02/c2_01.png",
              skillInfo: `技能描述：召唤始解·朽木露琪亚用刀尖朝前刺击，释放出强大的冷气， 对目标造成伤害并附加寒气。 \n寒气：持续受到伤害，移速减缓，受到的控制效果和伤害被增强`,
            },
            {
              skillName: "被动技能：死神",
              skillImg: "https://wcdn.tomatogames.com/web/guonei/sezg/ssldfab/img/page02/c2_02.png",
              skillInfo: `技能描述：生命值提升，进入死神状态，受到伤害超过最大生命值50% 的时候，免疫接下来3秒的伤害，同时提升自身的暴抗和韧性，持续10秒。死神状态恢复需要90秒`,
            },
          ],
        },
      ],
      // 角色展示框位置
      Left: "-3rem",
      // 侧边栏位置
      s_left: "0.01rem",
      swiper: null,
      swiper1: null,
      swiper2: null,
      // 当前图片
      currentImg: 0,
      page03_Img: [
        "https://wcdn.tomatogames.com/web/guonei/sezg/ssldfab/img/page03/01.jpg",
        "https://wcdn.tomatogames.com/web/guonei/sezg/ssldfab/img/page03/02.jpg",
        "https://wcdn.tomatogames.com/web/guonei/sezg/ssldfab/img/page03/03.jpg",
      ],
      page03_Content: [
        {
          title: "全新联动副本次元之战",
          content: ["夜空掠过黑色身影，斩魄刀起刃光凌厉。《塞尔之光》X《BLEACH境•界》第一期联动定档2月5日 ！黑崎一护与朽木露琪亚正式登场，全新次元之战、异界伙伴悉数登场，你将有机会获得露琪亚魔灵碎片、技能石-露琪亚、露琪亚头像、死神聊天框、露琪亚星灵等珍稀道具。这次，灵魂与你共战！"],
        },
        {
          title: "春节新年年兽BOSS降临",
          content: ["每到年关之时，年兽王都会带着大大小小的年兽降临塞尔大陆、为祸四方。但若是能将之击败，你将有机会获得新年红包、露琪亚魔灵蛋、新春头像、新春头像框等豪礼。赶紧招募你的队友，一起驱赶捣乱的年兽吧！"],
        },
        {
          title: "春节年度新服开启",
          content: ["岁月不居，时节如流。转眼间，《塞尔之光》已经陪伴千万勇士们走过一大段时光，在新的一年，《塞尔之光》将开设牛年年度大服【2021庆典服】，不仅海量专属活动齐力助阵，还有空前绝后的千万福利等着各位勇士，一起来看看吧！",
          "预注册时间：1月28日9:00，先行预约，领取千万福利就能快人一步！",
          "正式开服时间：2月5日8:00，万人重聚，享受有情有礼有兄弟的美好时刻！"],
        },
        
      ],
      // 视频是否展示
      isVideo: false,
      // 切换人物按钮是否禁用
      isFinish: false,
      // 切换图片按钮是否禁用
      isFinish1: false,
    };
  },
  methods: {
    // 改变页面
    changePage(page) {
      this.swiper.slideTo(page);
      this.currentP = page;
    },
    // 展示角色信息
    showDetails() {
      this.Left = this.Left == "0rem" ? "-3rem" : "0rem";
      this.s_left = this.s_left == "0.01rem" ? "-0.9rem" : "0.01rem";
    },
    // 切换下一个角色
    changeNextCha() {
      this.swiper1.slideNext();
      this.currentC =
        this.currentC == this.character.length - 1 ? 0 : this.currentC + 1;
    },
    // 切换上一个角色
    changePrevCha() {
      this.swiper1.slidePrev();
      this.currentC =
        this.currentC == 0 ? this.character.length - 1 : this.currentC - 1;
    },
    // 人物按钮点击
    changeCha(index) {
      if (this.currentC == index) {
        return;
      }
      this.changeNextCha();
    },
    // 切换下一个图片
    changeNextImg() {
      this.currentImg =
        this.currentImg == this.page03_Img.length - 1 ? 0 : this.currentImg + 1;
      this.swiper2.slideNext();
      
    },
    // 切换上一个图片
    changePrevImg() {
      this.currentImg =
      this.currentImg == 0 ? this.page03_Img.length - 1 : this.currentImg - 1;
      this.swiper2.slidePrev();
     
    },
    // 触碰轮播图
    touchswiper(flag) {
      flag ? this.swiper2.autoplay.stop() : this.swiper2.autoplay.start();
    },
    // 展示视频
    showVideo() {
      this.isVideo = !this.isVideo;
    },
    // 创建轮播图对象方法
    createSwiper() {
      var that = this;
      // 定义主体上下轮播图
      var swiper = new Swiper(".swiper-container_00", {
        direction: "vertical",
        slidesPerView: 1,
        // 每张之间的间隙
        spaceBetween: 0,
        mousewheel: true,
        shortSwipes: false, //进行快速且短距离的滑动无法触发切换
        // followFinger : false,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        on: {
          slideChangeTransitionStart: function () {
            that.isTrans = true;
            that.currentP = this.activeIndex;
            that.Top = 0.1 + 0.62 * that.currentP;
           
          },
          slideChangeTransitionEnd: function () {
            that.isTrans = false;
          },
        },
      });
      // 定义第二页左右轮播图
      var swiper1 = new Swiper(".swiper-container_01", {
        effect: "flip",
        grabCursor: false,
        mousewheel: false,
        loop: true,
        allowTouchMove: false,
        pagination: {
          el: ".swiper-pagination",
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
        on: {
          slideChangeTransitionStart: function () {
            that.isFinish = true;
          },
          slideChangeTransitionEnd: function () {
            that.isFinish = false;
          },
        },
      });
      // 定义第三页异型轮播图
      var swiper2 = new Swiper(".swiper-container_02", {
        slidesPerView: "auto", //按自己定义的item的宽度来自适应 否则按默认的宽度
        spaceBetween: -330,
        centeredSlides: true,
        loop: true,
        simulateTouch: false, //禁止鼠标模拟
        centeredSlidesBounds: true,
        autoplay: {
          delay: 3000,
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        on:{
          slideChangeTransitionStart: function () {
            that.isFinish1 = true;

          },
          slideChangeTransitionEnd: function () {
            that.currentImg = this.realIndex;
            that.isFinish1 = false;
          },
        }
      });
      this.swiper = swiper;
      this.swiper1 = swiper1;
      this.swiper2 = swiper2;
    },
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {
    this.createSwiper();
  },
}).$mount("#app");
