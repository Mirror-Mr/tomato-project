/*
 * @Author: your name
 * @Date: 2021-02-23 10:57:53
 * @LastEditTime: 2021-03-12 16:33:47
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\babel.config.js
 */
module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset'
  ],
}
