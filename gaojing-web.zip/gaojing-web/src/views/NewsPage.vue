<!--
 * @Author: your name
 * @Date: 2021-02-23 10:57:53
 * @LastEditTime: 2021-05-27 14:24:19
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\News.vue
-->
<template>
  <div class="newsPage">
    <Header />
    <div class="container">
      <div class="theme">
        <h2 :class="{ active: newsActive }">{{ $t("x.newsPage.theme") }}</h2>
      </div>
      <el-tabs class="tabs" tab-position="top" @tab-click="changeTab">
        <!-- label是展示的导航栏内容 -->
        <el-tab-pane :label="$t('x.newsPage.tabsLabel[0]')">
          <div
            v-loading="true"
            element-loading-text="拼命加载中"
            element-loading-spinner="el-icon-loading"
            v-if="isLoading"
            class="mask"
          ></div>
          <NewsPageItem
            v-for="(item, i) in filterNewest"
            :key="i"
            :news="filterNewest[i]"
            v-else
          />
          <!-- 没得新闻 -->
          <template v-if="newest.length == 0">
            <span class="noMore">暂无相关新闻</span>
          </template>
          <!-- 加载完 -->
          <template
            v-else-if="!isNewestLoading && newest.length != filterNewest.length"
          >
            <a href="#" class="seemore" @click.prevent="moreNews"
              >{{ $t("x.newsPage.seeMore") }} <i class="el-icon-arrow-down"></i>
            </a>
          </template>
          <!-- 没有更多内容 -->
          <template v-else-if="!isNewestLoading && !isLoading">
            <span class="noMore">没有更多内容了</span>
          </template>
          <!-- 正在加载 -->
          <template v-else>
            <span
              class="loading"
              v-loading="isNewestLoading"
              background="#ff7915"
              text="ss"
            ></span>
          </template>
        </el-tab-pane>
        <el-tab-pane :label="$t('x.newsPage.tabsLabel[1]')">
          <div
            v-loading="true"
            element-loading-text="拼命加载中"
            element-loading-spinner="el-icon-loading"
            v-if="isLoading"
            class="mask"
          ></div>
          <NewsPageItem
            v-for="(item, i) in filterNews"
            :key="i"
            :news="filterNews[i]"
            v-else
          />
          <!-- 没得新闻 -->
          <template v-if="news.length == 0">
            <span class="noMore">暂无相关新闻</span>
          </template>
          <!-- 加载完 -->
          <template
            v-else-if="!isNewsLoading && news.length != filterNews.length"
          >
            <a href="#" class="seemore" @click.prevent="moreNews"
              >{{ $t("x.newsPage.seeMore") }} <i class="el-icon-arrow-down"></i>
            </a>
          </template>
          <!-- 没有更多内容 -->
          <template v-else-if="!isNewsLoading && !isLoading">
            <span class="noMore">没有更多内容了</span>
          </template>
          <!-- 正在加载 -->
          <template v-else>
            <span
              class="loading"
              v-loading="isNewsLoading"
              background="#ff7915"
              text="ss"
            ></span>
          </template>
        </el-tab-pane>
        <el-tab-pane :label="$t('x.newsPage.tabsLabel[2]')">
          <div
            v-loading="true"
            element-loading-text="拼命加载中"
            element-loading-spinner="el-icon-loading"
            v-if="isLoading"
            class="mask"
          ></div>
          <NewsPageItem
            v-for="(item, i) in filterNotice"
            :key="i"
            :news="filterNotice[i]"
            v-else
          />
          <!-- 没得新闻 -->
          <template v-if="notice.length == 0">
            <span class="noMore">暂无相关新闻</span>
          </template>
          <!-- 加载完 -->
          <template
            v-else-if="!isNoticeLoading && notice.length != filterNotice.length"
          >
            <a href="#" class="seemore" @click.prevent="moreNews"
              >{{ $t("x.newsPage.seeMore") }} <i class="el-icon-arrow-down"></i>
            </a>
          </template>
          <!-- 没有更多内容 -->
          <template v-else-if="!isNoticeLoading && !isLoading">
            <span class="noMore">没有更多内容了</span>
          </template>
          <!-- 正在加载 -->
          <template v-else>
            <span
              class="loading"
              v-loading="isNoticeLoading"
              background="#ff7915"
              text="ss"
            ></span>
          </template>
        </el-tab-pane>
        <el-tab-pane :label="$t('x.newsPage.tabsLabel[3]')">
          <div
            v-loading="true"
            element-loading-text="拼命加载中"
            element-loading-spinner="el-icon-loading"
            v-if="isLoading"
            class="mask"
          ></div>
          <NewsPageItem
            v-for="(item, i) in filterActivity"
            :key="i"
            :news="filterActivity[i]"
            v-else
          />
          <!-- 没得新闻 -->
          <template v-if="activity.length == 0">
            <span class="noMore">暂无相关新闻</span>
          </template>
          <!-- 加载完 -->
          <template
            v-else-if="
              !isActivityLoading && activity.length != filterActivity.length
            "
          >
            <a href="#" class="seemore" @click.prevent="moreNews"
              >{{ $t("x.newsPage.seeMore") }} <i class="el-icon-arrow-down"></i>
            </a>
          </template>
          <!-- 没有更多内容 -->
          <template v-else-if="!isActivityLoading && !isLoading">
            <span class="noMore">没有更多内容了</span>
          </template>
          <!-- 正在加载 -->
          <template v-else>
            <span
              class="loading"
              v-loading="isActivityLoading"
              background="#ff7915"
              text="ss"
            ></span>
          </template>
        </el-tab-pane>
      </el-tabs>
    </div>
    <Footer />
  </div>
</template>
<script>
import Header from "@/components/Header.vue";
import Footer from "@/components/Footer.vue";
import NewsPageItem from "@/components/NewsPageItem.vue";
export default {
  name: "newsPage",
  components: {
    Header,
    Footer,
    NewsPageItem
  },
  data() {
    return {
      // 标题动画效果
      newsActive: false,

      // 当前看的是哪类消息 0-最新 1-新闻 2-通知 3-活动
      newsType: 0,
      // 最新 新闻 通知  活动
      index: {
        newest: 0,
        news: 0,
        notice: 0,
        active: 0
      },
      // 是否正在加载
      isNewestLoading: false,
      isNewsLoading: false,
      isNoticeLoading: false,
      isActivityLoading: false,
      isLoading: true,
      key: "0391591aafc5db68b08787645b837b4f",
      // 时间戳
      timer: parseInt(Date.parse(new Date()) / 1000),
      // 新闻列表
      newest: [],
      news: [],
      notice: [],
      activity: []
    };
  },
  computed: {
    filterNewest() {
      // return this.$t("x.newsPage.newest").slice(0, (this.index.newest + 1) * 6);
      return this.newest.slice(0, (this.index.newest + 1) * 6);
    },
    filterNews() {
      // return this.$t("x.newsPage.news").slice(0, (this.index.news + 1) * 6);
      return this.news.slice(0, (this.index.news + 1) * 6);
    },
    filterNotice() {
      // return this.$t("x.newsPage.notice").slice(0, (this.index.notice + 1) * 6);
      return this.notice.slice(0, (this.index.notice + 1) * 6);
    },
    filterActivity() {
      // return this.$t("x.newsPage.activity").slice(
      //   0,
      //   (this.index.active + 1) * 6
      // );
      return this.activity.slice(0, (this.index.active + 1) * 6);
    },
    area: function() {
      return localStorage.getItem("isEn") == "true" ? 2 : 1;
    }
  },
  watch: {
    filterNewest(newValue) {
      // console.log(newValue.length);
      if (this.$t("x.newsPage.newest").length == newValue.length) {
        console.log("到头了");
      }
    },
    filterNews(newValue) {
      console.log(newValue.length);
    },
    filterNotice(newValue) {
      console.log(newValue.length);
    },
    filterActivity(newValue) {
      console.log(newValue.length);
    }
  },
  methods: {
    // 选择不同类别新闻
    changeTab(vue, event) {
      this.isLoading = true;
      setTimeout(() => {
        if (event.target.id == "tab-0") {
          this.newsType = 0;
          this.requestNews(0);
        } else if (event.target.id == "tab-1") {
          this.newsType = 1;
          this.requestNews(1);
        } else if (event.target.id == "tab-2") {
          this.newsType = 2;
          this.requestNews(2);
        } else {
          this.newsType = 3;
          this.requestNews(3);
        }
      }, 1000);
    },
    // 点击更多新闻
    moreNews() {
      if (this.newsType == 0) {
        this.isNewestLoading = true;
      } else if (this.newsType == 1) {
        this.isNewsLoading = true;
      } else if (this.newsType == 2) {
        this.isNoticeLoading = true;
      } else {
        this.isActivityLoading = true;
      }
      setTimeout(() => {
        if (this.newsType == 0) {
          this.index.newest++;
          this.requestNews(0, this.index.newest);
        } else if (this.newsType == 1) {
          this.index.news++;
          this.requestNews(1, this.index.news);
        } else if (this.newsType == 2) {
          this.index.notice++;
          this.requestNews(2, this.index.notice);
        } else {
          this.index.active++;
          this.requestNews(3, this.index.active);
        }
      }, 1000);
    },
    // 请求新闻
    requestNews(type, page = 1) {
      this.$axios({
        methods: "get",
        url:
          "https://hw.xianyuyouxi.com/service/Tomato_webhome/getNewsList/" +
          page,
        headers: {
          "Access-s": this.$md5(`${this.key}${this.timer}`)
        },
        params: {
          time: this.timer,
          area: this.area,
          // area: 1,
          company: 2,
          type: type
        }
      }).then(res => {
        // res.data.data.data  新闻列表
        console.log(res.data.data.data);
        if (type == 0) {
          this.newest = res.data.data.data;
          this.isNewestLoading = false;
        } else if (type == 1) {
          this.news = res.data.data.data;
          this.isNewsLoading = false;
        } else if (type == 2) {
          this.notice = res.data.data.data;
          this.isNoticeLoading = false;
        } else {
          this.activity = res.data.data.data;
          this.isActivityLoading = false;
        }
        this.isLoading = false;
      });
    }
  },
  mounted() {
    this.newsActive = true;
    setTimeout(() => {
      this.isLoading = false;
    }, 1000);
    // 进入默认加载最新第一页的新闻
    this.requestNews(0);
  }
};
</script>
<style scoped>
.container {
  margin: 0 0 0.3rem 0;
}
/* 标题 */
.theme {
  width: 69%;
  height: 0.865rem;
  margin: 0.57rem auto 0;
  border-bottom: 0.01rem solid #999999;
}
.theme::after {
  content: "";
  display: block;
  clear: both;
}
.theme h2 {
  margin: 0.26rem 0 0.13rem 0;
  font-size: 0.29rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
  float: left;
  transition: all 0.5s;
}

h2.active {
  margin: 0.35rem 0 0.13rem 0;
}
.en h2.active {
  margin: 0.35rem 0 0.17rem 0;
}

/* 改elementui样式 */
.tabs {
  width: 100%;
  margin: 0.07rem auto 0;
}
.tabs >>> .el-tabs__header {
  position: absolute;
  top: 0.93rem;
  right: 1.53rem;
}
.en .tabs >>> .el-tabs__header {
  top: 0.97rem;
  right: 1.53rem;
}
.tabs >>> .el-tabs__item:hover {
  color: #0b2475;
}
.tabs >>> .el-tabs__nav-wrap::after {
  display: none;
}
.tabs >>> .el-tabs__item.is-active {
  color: #0b2475;
}
.tabs >>> .el-tabs__active-bar {
  display: none;
}
.tabs >>> .el-tabs__item {
  margin: 0 0 0 0.33rem;
  padding: 0;
  line-height: 0.4rem;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #000000;
  line-height: 0.3rem;
}
.tabs >>> .el-tabs__content {
  min-height: calc(100vh - 3rem);
}
.seemore,
.noMore {
  margin: 0.3rem 0 0.3rem 0;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.seemore i {
  margin: 0 0 0 0.05rem;
  font-size: 0.07rem;
  font-weight: bold;
}

/* 正在加载 */
.loading {
  margin: 0.37rem 0 0.36rem 0;
}
.container >>> .el-loading-spinner i,
.container >>> .el-loading-spinner .el-loading-text {
  font-size: 0.08rem;

  color: #0b2475;
}
.container >>> .el-loading-spinner .path {
  stroke: #0b2475;
}
.mask >>> .el-loading-mask {
  height: 3.5rem;
  position: relative;
}
</style>
