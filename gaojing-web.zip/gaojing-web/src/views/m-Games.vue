<!--
 * @Author: your name
 * @Date: 2021-03-01 19:11:15
 * @LastEditTime: 2021-05-25 15:32:11
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\Games.vue
-->
<template>
  <div class="mgames">
    <MHeader />
    <div class="theme">
      <h2 :class="{ active: gamesActive }">{{ $t("x.games.theme") }}</h2>
    </div>
    <div class="container">
      <div
        class="gameItem"
        v-for="(item, i) in $t('x.games.m_gamesList')"
        :key="i"
        v-cloak
        @click="clickGame(item.id)"
      >
        <div class="top">
          <span
            :style="{
              background: 'url(' + item.icon + ')',
              backgroundSize: '100%'
            }"
            class="icon"
          ></span>
          <h3>{{ item.title }}</h3>
          <!-- <span class="hot" v-if="i == 0 || i == 1">H</span> -->
        </div>
        <div class="mid">
          <span class="content" v-html="item.content"> </span>
          <span class="more" v-if="item.id != 2"
            >{{ $t("x.games.more") }}<br />
            <template v-if="$t('x.games.website[' + item.id + '][0]') == '#'">
              <a href="#">{{ $t("x.games.website[" + item.id + "][1]") }}</a>
            </template>
            <template v-else>
              <a
                :href="$t('x.games.website[' + item.id + '][0]')"
                target="_blank"
                >{{ $t("x.games.website[" + item.id + "][1]") }}</a
              >
            </template>
          </span>
        </div>
        <div class="bottom">
          <span
            class="pic"
            :class="'pic' + i"
            :style="{
              backgroundImage: 'url(' + item.pic + ')'
            }"
          ></span>
        </div>
      </div>
    </div>
    <MFooter />
  </div>
</template>
<script>
import MHeader from "@/components/m-Header.vue";
import MFooter from "@/components/m-Footer.vue";
export default {
  name: "MGames",
  data() {
    return {
      // 切换次数
      changeNum: 0,
      // 标题动画效果
      gamesActive: false
    };
  },
  components: {
    MHeader,
    MFooter
  },
  methods: {
    clickGame(id) {
      //  id 0-4
      if (this.$i18n.t("x.games.website[" + id + "][0]") == "#") {
        return;
      }
      let url = this.$i18n.t("x.games.website[" + id + "][1]");
      window.open(url, "_blank");
    }
  },
  mounted() {
    this.gamesActive = true;
  },
  watch: {}
};
</script>
<style scoped>
/* 主题 */
.theme {
  width: 85%;
  height: 0.75rem;
  margin: 1.5rem auto 0;
  border-bottom: 0.01rem solid #666;
}

.theme h2 {
  margin: 0.2rem auto 0;
  font-size: 0.48rem;
  font-family: Arial;
  font-weight: bold;
  color: #333333;
  line-height: 0.76rem;
  transition: all 0.5s;
  float: none;
}
h2.active {
  margin: 0.1rem auto 0;
}

/* 主体内容 */
.container {
  width: 85%;
  margin: 0.7rem auto 0.4rem;
}
.gameItem {
  width: 100%;
  margin: 0 auto 0.8rem;
  border-bottom: 0.01rem solid #ccc;
}
.gameItem:last-of-type{
  border: none;
}
.top {
  width: 100%;
  height: 1.5rem;
  line-height: 1.5rem;
}
.top .icon {
  width: 1.48rem;
  height: 1.46rem;
  display: inline-block;
  border-radius: 0.1rem;
  float: left;
  opacity: 1;
  transition: all 0.3s;
}
.top h3 {
  height: 100%;
  line-height: 1.5rem;
  vertical-align: top;
  display: inline-block;
  margin: 0 0 0 0.4rem;
  font-size: 0.43rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
  float: left;
  opacity: 1;
  transition: all 0.3s;
}
.hot {
  width: 0.4rem;
  height: 0.4rem;
  margin: 0.55rem 0 0 0.2rem;
  vertical-align: middle;
  line-height: 0.45rem;
  color: #fff;
  font-size: 0.3rem;
  text-align: center;
  background: #fe5600;
  border-radius: 0.1rem;
  float: left;
}
.mid {
  width: 100%;
  margin: 0.3rem 0 0 0;
  text-align: left;
}
.mid .content {
  width: 100%;
  font-size: 0.32rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #999999;
  line-height: 0.48rem;
  opacity: 1;
  transition: all 0.4s;
}

.mid .more {
  margin: 0.2rem 0 0 0;
  font-size: 0.24rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #999999;
  line-height: 0.4rem;
  opacity: 1;
  transition: all 0.4s;
}
.more a {
  font-size: 0.24rem;
   font-family: Microsoft YaHei;
  font-weight: 400;
  color: #00a8ff;
}
.bottom {
  width: 100%;
  overflow: hidden;
}
.bottom .pic {
  width: 100%;
  height: 4.61rem;
  margin: 0.19rem 0 0.9rem 0rem;
  border-radius: 0.3rem;
  opacity: 1;
  transition: all 0.4s;
}
.pic0 {
  background-size: 110% !important;
  background-position: 0rem -1.6rem;
}
.pic1 {
  background-size: 100% !important;
  background-position: 0rem 0rem;
}
.pic2 {
  background-size: 100% !important;
  background-position: 0rem 0rem;
}
.pic3 {
  background-size: 100% !important;
  background-position: 0rem 0rem;
}
.pic4 {
  background-size: 100% !important;
  background-position: 0rem;
}
</style>
