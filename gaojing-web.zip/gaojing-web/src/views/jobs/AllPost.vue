<!--
 * @Author: your name
 * @Date: 2021-03-30 16:20:36
 * @LastEditTime: 2021-06-08 15:13:17
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\jobs\AllPost.vue
-->
<template>
  <div class="allPost">
    <Header :campus="campus" />
    <span class="banner"> </span>
    <!-- 搜索区 -->
    <div class="container">
      <!-- 输入框 -->
      <div class="inputBox">
        <el-input
          :placeholder="$t('y.overlay.placeholder')"
          prefix-icon="el-icon-search"
          v-model="keyword"
          class="search-button"
          @keyup.enter.native="getList"
        >
        </el-input>
        <a href="#" class="search" @click="getList">{{
          $t("y.overlay.search")
        }}</a>
      </div>
      <div class="container-body">
        <!-- 筛选条件 -->
        <div class="left">
          <div class="search-title">
            <span class="theme">{{ $t("y.allPost.left.title") }}</span>
            <span class="clear" @click="clear">{{
              $t("y.allPost.left.clear")
            }}</span>
          </div>
          <div class="path">
            <span
              :class="{ 'span-active': catogery == 1 }"
              @click="tabSwitch('1')"
              >{{ $t("y.allPost.left.path[0]") }}</span
            >
            <span
              :class="{ 'span-active': catogery == 2 }"
              @click="tabSwitch('2')"
              >{{ $t("y.allPost.left.path[1]") }}</span
            >
          </div>
          <div class="choose">
            <div class="address">
              <span class="title">{{
                $t("y.allPost.left.address.title")
              }}</span>
              <div class="menu-list">
                <span
                  @click="cityIndex = 0"
                  :class="{ 'chose-span': 0 === cityIndex }"
                  >不限</span
                >
                <span
                  @click="choseCity(key)"
                  :class="{ 'chose-span': key == cityIndex }"
                  v-for="(item, key, index) in filterCondition.citys"
                  :key="index"
                  >{{ item }}</span
                >
              </div>
            </div>
            <div class="type">
              <span class="title">{{ $t("y.allPost.left.type.title") }}</span>
              <div class="menu-list">
                <span
                  @click="choseProfession(key)"
                  :class="{ 'chose-span': key == professionIndex }"
                  v-for="(item, key, idx) in filterCondition.posts"
                  :key="idx"
                  >{{ item }}</span
                >
              </div>
            </div>
            <div class="nature">
              <span class="title">{{ $t("y.allPost.left.nature.title") }}</span>
              <div class="menu-list">
                <span
                  @click="natureIndex = idx"
                  :class="{ 'chose-span': idx === natureIndex }"
                  v-for="(item, idx) in $t('y.allPost.left.nature.list')"
                  :key="idx"
                  >{{ item }}</span
                >
              </div>
            </div>
          </div>
        </div>
        <!-- 职位 -->
        <div class="right">
          <div class="right-top">
            <p>
              {{ $t("y.allPost.right.title[0]") }}<span>{{ total }}</span>
              {{ $t("y.allPost.right.title[1]") }}
            </p>
            <span>{{ $t("y.allPost.right.new") }}</span>
          </div>
          <div class="right-list">
            <div
              class="public-list"
              v-for="(item, index) in jobList"
              :key="index"
              @click="checkDetails(item.id)"
            >
              <div class="job-title">
                <p>{{ item.post_name }}</p>
                <span>{{ item.createtime.split(" ")[0] }}更新</span>
              </div>
              <div class="job-city">
                {{ item.city }} -
                {{ item.post_type }}

                <!-- <template v-if="item.work_time != 0">
                  - 经验 {{ item.work_time }} 年
                </template>
                <template v-else>
                  - 经验不限
                </template> -->
              </div>
              <div
                class="job-des"
                v-html="item.content"
                style="font-size: 0.07rem;line-height:0.15rem"
              >
                <!-- 1，人力资源各大模块轮岗学习机会，全面培训，专向发展；
                <br />
                2，招聘：寻找合适的招聘渠道，对候选人进行评测，为公司引进优秀人才； -->
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="page">
        <el-pagination
          background
          layout="prev, pager, next"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage"
          :page-size="10"
          :total="total"
        >
        </el-pagination>
      </div>
    </div>
    <Footer :type="true"></Footer>
  </div>
</template>
<script>
import Header from "@/components/jobs/Header1.vue";
import Footer from "@/components/Footer.vue";
export default {
  name: "AllPost",
  components: {
    Header,
    Footer
  },

  data() {
    return {
      // controlSwitch: true,
      cityIndex: 0,
      professionIndex: 0,
      natureIndex: 0,
      key: "0391591aafc5db68b08787645b837b4f",
      page: 1,
      currentPage: 1,
      total: 0,
      jobList: [],
      jobType: [],
      filterCondition: {
        citys: {},
        posts: {}
      },
      catogery: 0,
      keyword: "",
      // 是否校园招聘
      campus: false
    };
  },
  watch: {
    cityIndex(val, oldVal) {
      this.getList();
    },
    professionIndex(val, oldVal) {
      this.getList();
    },
    natureIndex(val, oldVal) {
      this.getList();
    },
    page(val, oldVal) {
      this.getList();
    }
  },
  methods: {
    tabSwitch(id) {
      // this.controlSwitch = !this.controlSwitch;
      this.catogery = id;
      this.getList();
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      this.page = val;
      this.getList();
      console.log(`当前页: ${val}`);
    },
    choseCity(id) {
      this.cityIndex = id;
    },
    choseProfession(id) {
      this.professionIndex = id;
    },
    // 清除按钮重置搜索条件
    clear() {
      // this.controlSwitch = true;
      this.cityIndex = 0;
      this.professionIndex = 0;
      this.natureIndex = 0;
      this.page = 1;
      this.currentPage = 1;
      this.catogery = 0;
      this.getList();
    },
    // 点击查看详情
    checkDetails(id) {
      // 将当前选择的条件保存
      let saveCondition = {
        lang: "1",
        time: parseInt(Date.parse(new Date()) / 1000),
        catogery: this.catogery,
        type: this.campus ? 1 : 0,
        keyword: this.keyword,
        job_type: this.natureIndex,
        post_type: this.professionIndex,
        city: this.cityIndex,
        company: 1
      };
      localStorage.setItem("saveCondition", JSON.stringify(saveCondition));
      if (this.campus) {
        this.$router.push({
          path: "/campus/detail",
          query: { id: id }
        });
      } else {
        this.$router.push({
          path: "/hr/detail",
          query: { id: id}
        });
      }
    },
    // 获取岗位列表
    getList() {
      this.$axios({
        method: "post",
        url:
          "https://hw.xianyuyouxi.com/service/tomato_webhome/search/" +
          this.page,
        headers: {
          "Access-s": this.$md5(
            `${this.key}${parseInt(Date.parse(new Date()) / 1000)}`
          )
        },
        data: {
          lang: "1",
          time: parseInt(Date.parse(new Date()) / 1000),
          catogery: this.catogery,
          type: this.campus ? 1 : 0,
          keyword: this.keyword,
          job_type: this.natureIndex,
          post_type: this.professionIndex,
          city: this.cityIndex,
          company: 1
        }
      }).then(res => {
        // console.log(res.data);
        this.total = parseInt(res.data.data.total);
        this.jobList = res.data.data.data;
        // console.log(this.jobList)
      });
    },
    // 获取搜索条件
    getSearchcondition() {
      this.$axios({
        method: "get",
        url: "https://hw.xianyuyouxi.com/service/tomato_webhome/get_condition",
        headers: {
          "Access-s": this.$md5(
            `${this.key}${parseInt(Date.parse(new Date()) / 1000)}`
          )
        },
        params: {
          lang: "1",
          time: parseInt(Date.parse(new Date()) / 1000),
          catogery: 1
        }
      }).then(res => {
        this.filterCondition = res.data.data;
        // 只显示六个
        // let obj = res.data.data;
        // // console.log(obj.citys)
        // this.filterCondition.citys = obj.citys
        // let keyarr = Object.keys(obj.posts);
        // keyarr.length = 6;
        // keyarr.map(key => {
        //   this.$set(this.filterCondition.posts, key, obj.posts[key]);
        // });
      });
    }
    // 获取z只能分类分类
    // getType() {
    //   this.$axios({
    //     method: "get",
    //     url: "https://hw.xianyuyouxi.com/service/tomato_webhome/get_post_type",
    //     headers: {
    //       "Access-s": this.$md5(
    //         `${this.key}${parseInt(Date.parse(new Date()) / 1000)}`
    //       ),
    //     },
    //     params: {
    //       lang: "1",
    //       time: parseInt(Date.parse(new Date()) / 1000),
    //     },
    //   }).then((res) => {
    //     console.log(res.data);
    //     1;
    //   });
    // },
  },
  mounted() {
    this.campus = this.$route.path == "/hr/allPost" ? false : true;

    // 岗位类型
    this.professionIndex = this.$route.query.id;
    if (!this.professionIndex) {
      this.professionIndex = 0;
    }
    this.keyword = this.$route.query.keyword;
    if (!this.keyword) {
      //有关键字
      this.keyword = "";
    }

    this.getSearchcondition();

    let saveCondition = localStorage.getItem("saveCondition");
    if (saveCondition) {
      saveCondition = JSON.parse(saveCondition);
      this.catogery = saveCondition.catogery;
      this.cityIndex = saveCondition.city;//工作地点
      this.natureIndex = saveCondition.job_type;//工作性质
      this.keyword = saveCondition.keyword;
      this.professionIndex = saveCondition.post_type;//工作类别
    }
    this.getList();
    // this.getType();
  }
};
</script>
<style scoped>
.allPost {
  background: #fafafa;
}

.banner {
  width: 100%;
  height: 2.02rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/banner.png");
  background-size: 100%;
}
.container {
  width: 58%;
  margin: 0 auto 0.5rem;
}
.container::after {
  content: "";
  display: block;
  clear: both;
}
.container-body {
  display: flex;
  justify-content: space-between;
}
.page {
  display: flex;
  justify-content: flex-end;
  /* width: 2rem; */
}
.inputBox {
  width: 4.28rem;
  position: relative;
  margin: -0.16rem auto 0;
}
.inputBox >>> .el-input input {
  width: 4.28rem;
  height: 0.28rem;
  background: #ffffff;
  border: 0.001rem solid transparent;
  border-radius: 0.2rem;
}
.inputBox >>> .el-input input::-webkit-input-placeholder {
  font-size: 0.1rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #999999;
}
.inputBox >>> .el-input--prefix .el-input__inner {
  padding: 0 0 0 0.3rem;
}
.inputBox >>> .el-input input:focus {
  outline: none;
}
.inputBox >>> .el-input__prefix {
  margin: 0 0 0 0.04rem;
}
.inputBox >>> .el-input__icon {
  line-height: 0.28rem;
  font-size: 0.1rem;
}
.search-button {
  border: 0.001rem solid transparent;
  border-radius: 0.3rem;
  display: flex;
  align-items: center;
  transition: all 0.3s;
}
.search-button:hover {
  border: 0.001rem solid #18278a;
  box-shadow: 0rem 0.01rem 0.1rem 0.01rem rgb(0 0 0 / 10%);
}

.search {
  width: 0.63rem;
  height: calc(100% + 0.001rem);
  line-height: 0.28rem;
  position: absolute;
  top: 0rem;
  right: -0.01rem;
  color: #fff;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  background: #18278a;
  border-radius: 0.2rem;
}
.search:hover {
  background: #18278a;
}
/* 筛选条件 */
.left {
  width: 1.36rem;
  /* height: 2rem; */
  margin: 0.27rem 0 0 0;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666666;
  text-align: left;
}

.left .theme {
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.search-title {
  display: flex;
  justify-content: space-between;
}
.left .clear {
  /* margin: 0 0 0 0.74rem; */
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #00a8ff;
  cursor: pointer;
}
.left .path {
  width: 100%;
  margin-top: 0.1rem;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  text-align: center;
  border-bottom: 1px solid #18278a;
  display: flex;
  justify-content: space-between;
}
.left .path span {
  width: 50%;
  display: inline-block;
  height: 0.18rem;
  line-height: 0.18rem;
  cursor: pointer;
  font-size: 0.08rem;
}
.left .path .span-active {
  width: 50%;
  display: inline-block;
  height: 0.18rem;
  color: #18278a;
  background-color: #d8dbe9;
}
.left .choose {
  width: 100%;
  height: 3.03rem;
  margin: 0.14rem 0 0 0;
  padding: 0 0.1rem;
  background: #ffffff;
  box-shadow: 0rem 0.01rem 0.05rem 0.01rem rgba(184, 184, 184, 0.18);
  border-radius: 0.05rem;
  box-sizing: border-box;
}
.left .title {
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
  margin: 0.1rem 0;
}
.right {
  width: 4.23rem;
  /* background: darkolivegreen; */
  /* float: right; */
  margin-top: 0.15rem;
  text-align: left;
}
.right-top {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin-top: 0.27rem;
}
.right-top p {
  font-size: 0.1rem;
}
.right-top span {
  color: #18278a;
  font-size: 0.07rem;
  cursor: pointer;
  margin: 0 0 0 0.04rem;
}
.right-top p span {
  font-size: 0.23rem;
  color: #333333;
  font-weight: 700;
}
.right-list {
  padding-top: 0.12rem;
}
.public-list {
  width: 4.23rem;
  max-height: 0.95rem;
  padding: 0.17rem 0.12rem;
  background: #ffffff;
  box-shadow: 0rem 0.01rem 0.05rem 0.01rem rgb(184 184 184 / 18%);
  border-radius: 0.05rem;
  margin-bottom: 0.1rem;
  cursor: pointer;
  overflow: hidden;
  /* box-sizing: border-box; */
}
.public-list:hover {
  box-shadow: 0rem 0.01rem 0.05rem 0.01rem rgb(184 184 184 / 60%);
  transform: scale(1.01);
  transition: 0.2s;
}
.public-list:hover p {
  color: #18278a;
}
.job-new {
  color: #18278a;
}
.job-title {
  display: flex;
  justify-content: space-between;
}
.job-title p {
  font-size: 0.11rem;
  font-weight: bold;
}
.job-title span {
  font-size: 0.07rem;
  color: #999999;
}
.job-city {
  font-size: 0.08rem;
  margin: 0.05rem 0 0.08rem;
  color: #666666;
}
.job-des {
  /* max-height: 0.2rem; */
  /* overflow: hidden; */
  height: 0.3rem;
  font-size: 0.07rem;
  color: #999999;
  -webkit-box-orient: vertical;
  text-overflow: ellipsis;
  overflow: hidden;
  word-break: break-all;
  display: -webkit-box;
  -webkit-line-clamp: 2;
}
.job-des p,
.job-des span {
  font-size: 0.07rem !important;
  text-overflow: -o-ellipsis-lastline;
  /* 关键代码 ！！！！ 以下5行 */
  overflow: hidden;
  /* 超出部分设为... */
  text-overflow: ellipsis;
  /* 盒子模型 */
  display: -webkit-box;
  /* 最多2行文本 多余部分隐藏*/
  -webkit-line-clamp: 2;
  /* 从顶部向底部垂直布置子元素 */
  -webkit-box-orient: vertical;
}
.job-des p {
  display: block !important;
}
.job-des span {
  color: red;
  display: inline !important;
}

.menu-list {
  display: flex;
  /* justify-content: space-between; */
  flex-wrap: wrap;
  text-align: center;
  flex-direction: row;
}
.menu-list span {
  display: inline-block;
  width: 0.49rem;
  font-size: 0.08rem;
  height: 0.18rem;
  margin-right: 0.08rem;
  margin-bottom: 0.05rem;
  line-height: 0.18rem;
  border-radius: 0.02rem;
  cursor: pointer;
}
.chose-span {
  color: #18278a;
  background: #dddfee;
}
.el-pagination.is-background .btn-next,
.el-pagination.is-background .btn-prev,
.el-pagination.is-background .el-pager li {
  background-color: #fff;
}
</style>
<style>
.el-pagination.is-background .btn-next,
.el-pagination.is-background .btn-prev,
.el-pagination.is-background .el-pager li {
  background: none;
  border: 1px solid #d2d2d2;
  border-radius: 0.02rem;
}
.el-pager li:hover {
  color: #18278a !important;
  border: 1px solid !important;
}
.el-pager li,
.el-pager li.btn-quicknext:hover,
.el-pager li.btn-quickprev:hover {
  color: #18278a;
  border: 1px solid #18278a;
}
.el-pagination.is-background .el-pager li:not(.disabled).active {
  color: #18278a;
  background: none;
  border: 1px solid #18278a;
}
.el-pagination.is-background .btn-next,
.el-pagination.is-background .btn-prev,
.el-pagination.is-background .el-pager li {
  color: #333333;
}
</style>
