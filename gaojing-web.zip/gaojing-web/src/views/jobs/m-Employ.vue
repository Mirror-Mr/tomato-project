<!--
 * @Author: your name
 * @Date: 2021-03-22 10:27:16
 * @LastEditTime: 2021-06-08 12:20:45
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\Employ.vue
-->
<template>
  <div class="employ">
    <!-- <template v-if="isPC">
      <Header :home="true" :campus="campus"/>
      <Overlay />
      <GameJob :campus="campus" />
      <Culture />
      <Welfare />
      <Footer :type="true" />
    </template>
    <template v-else> -->
    <MHeader :home="true" :campus="campus" />
    <MOverlay :campus="campus" />
    <MGameJob :campus="campus" />
    <MCulture />
    <MWelfare />
    <MFooter :type="true" />
    <!-- </template> -->
  </div>
</template>
<script>
import Header from "@/components/jobs/Header.vue";
import MHeader from "@/components/jobs/m-Header.vue";
import Overlay from "@/components/jobs/Overlay.vue";
import MOverlay from "@/components/jobs/m-Overlay.vue";
import GameJob from "@/components/jobs/GameJob.vue";
import MGameJob from "@/components/jobs/m-GameJob.vue";
import Culture from "@/components/jobs/Culture.vue";
import MCulture from "@/components/jobs/m-Culture.vue";
import Welfare from "@/components/jobs/Welfare.vue";
import MWelfare from "@/components/jobs/m-Welfare.vue";
import Footer from "@/components/Footer.vue";
import MFooter from "@/components/m-Footer.vue";
export default {
  name: "Employ",
  components: {
    Header,
    MHeader,
    Overlay,
    MOverlay,
    GameJob,
    MGameJob,
    Culture,
    MCulture,
    Welfare,
    MWelfare,
    Footer,
    MFooter
  },
  data() {
    return {
      campus: false,
      isPC: false
    };
  },
  methods: {},
  mounted() {
    let path = this.$route.path;
    if (path == "/m/campus") {
      this.campus = true;
    }
    this.isPC = JSON.parse(localStorage.getItem("isPC"));
  }
};
</script>
<style scoped>
.employ {
  width: 100%;
  background: #fafafa;
}
</style>
