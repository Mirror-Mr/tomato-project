<!--
 * @Author: your name
 * @Date: 2021-03-30 16:20:36
 * @LastEditTime: 2021-06-08 15:40:09
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\jobs\AllPost.vue
-->
<template>
  <div class="allPost" @click="showMask">
    <Header :campus="campus" />
    <span class="banner"> </span>
    <!-- 搜索区 -->
    <div class="container">
      <!-- 输入框 -->
      <div class="inputBox">
        <el-input
          :placeholder="$t('y.overlay.placeholder')"
          prefix-icon="el-icon-search"
          v-model="keyword"
          class="search-button"
          @keyup.native.13="getList"
        >
        </el-input>
        <!-- <a href="#" class="search" @click="getList">{{
          $t("y.overlay.search")
        }}</a> -->
      </div>
      <!-- 选择条件框 -->
      <div class="chooseBox">
        <!-- 自研线 -->
        <span
          :class="{ 'span-active': catogery == 1 }"
          @click="tabSwitch('1')"
          >{{ $t("y.allPost.left.path[0]") }}</span
        >
        <!-- 发行线 -->
        <span
          :class="{ 'span-active': catogery == 2 }"
          @click="tabSwitch('2')"
          >{{ $t("y.allPost.left.path[1]") }}</span
        >
        <!-- 岗位类别 -->
        <span
          @click="changeDropdown(1)"
          :class="{ 'span-active': dropDownType == 1 || isProfession }"
        >
          <template v-if="isProfession">
            {{ professionName }}
          </template>
          <template v-else>
            {{ $t("y.allPost.left.type.title") }}
          </template>
          <i class="el-icon-caret-bottom"></i>
        </span>
        <!-- 工作地点 -->
        <span
          @click="changeDropdown(2)"
          :class="{ 'span-active': dropDownType == 2 || isCity }"
        >
          <template v-if="isCity">
            {{ cityName }}
          </template>
          <template v-else>
            {{ $t("y.allPost.left.address.title") }}
          </template>

          <i class="el-icon-caret-bottom"></i>
        </span>
        <!-- 工作性质 -->
        <span
          @click="changeDropdown(3)"
          :class="{ 'span-active': dropDownType == 3 || isNature }"
        >
          <template v-if="isNature">
            {{ natureName }}
          </template>
          <template v-else>
            {{ $t("y.allPost.left.nature.title") }}
          </template>

          <i class="el-icon-caret-bottom"></i>
        </span>
      </div>
      <!-- 下拉框 -->
      <div
        class="chooseDropdown"
        :class="{ notActive: dropDownType == 0 || isChose }"
      >
        <ul class="chooseItems">
          <!-- 岗位类别 -->
          <template v-if="dropDownType == 1">
            <li
              @click="choseProfession(key, item)"
              :class="{ 'chose-span': key == professionIndex }"
              v-for="(item, key, idx) in filterCondition.posts"
              :key="idx"
            >
              {{ item }}
            </li>
          </template>
          <!-- 工作地点 -->
          <template v-else-if="dropDownType == 2">
            <li
              @click="choseCity(0, '不限')"
              :class="{ 'chose-span': 0 === cityIndex }"
            >
              不限
            </li>
            <li
              @click="choseCity(key, item)"
              :class="{ 'chose-span': key == cityIndex }"
              v-for="(item, key, index) in filterCondition.citys"
              :key="index"
            >
              {{ item }}
            </li>
          </template>
          <!-- 工作性质 -->
          <template v-else>
            <li
              @click="choseNature(idx, item)"
              :class="{ 'chose-span': idx === natureIndex }"
              v-for="(item, idx) in $t('y.allPost.left.nature.list')"
              :key="idx"
            >
              {{ item }}
            </li>
          </template>
        </ul>
      </div>

      <div class="container-body">
        <!-- 清空 -->
        <!-- <span class="clear" @click="clear">{{
          $t("y.allPost.left.clear")
        }}</span> -->

        <!-- 职位 -->
        <div class="right">
          <div class="right-top">
            <p>
              {{ $t("y.allPost.right.title[0]") }}<span>{{ total }}</span>
              {{ $t("y.allPost.right.title[1]") }}
            </p>
            <!-- <span>{{ $t("y.allPost.right.new") }}</span> -->
          </div>
          <div class="right-list">
            <div
              class="public-list"
              v-for="(item, index) in jobList"
              :key="index"
              @click="checkDetails(item.id)"
            >
              <div class="job-title">
                <p>{{ item.post_name }}</p>
                <span>{{ item.createtime.split(" ")[0] }}更新</span>
              </div>
              <div class="job-city">
                {{ item.city }} -
                {{ item.post_type }}

                <!-- <template v-if="item.work_time != 0">
                  - 经验 {{ item.work_time }} 年
                </template>
                <template v-else>
                  - 经验不限
                </template> -->
              </div>
              <div
                class="job-des"
                v-html="item.content"
                style="font-size: 0.07rem"
              >
                <!-- 1，人力资源各大模块轮岗学习机会，全面培训，专向发展；
                <br />
                2，招聘：寻找合适的招聘渠道，对候选人进行评测，为公司引进优秀人才； -->
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="page">
        <el-pagination
          background
          layout="prev, pager, next"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage"
          :page-size="10"
          :total="total"
        >
        </el-pagination>
      </div>
    </div>
    <Footer :type="true"></Footer>
    <div class="mask" :class="{ show: isShow }"></div>
  </div>
</template>
<script>
import Header from "@/components/jobs/m-Header.vue";
import Footer from "@/components/m-Footer.vue";
export default {
  name: "AllPost",
  components: {
    Header,
    Footer
  },
  data() {
    return {
      // 是否选择路线
      controlSwitch: false,
      // 选择城市
      cityIndex: 0,
      // 选择城市名称
      cityName: "",
      // 选择职位类别
      professionIndex: 0,
      // 选择职位类别名称
      professionName: "",
      // 选择职位性质
      natureIndex: 0,
      // 选择职位性质名称
      natureName: "",
      key: "0391591aafc5db68b08787645b837b4f",
      page: 1,
      // 职位表是第几页
      currentPage: 1,
      total: 0,
      // 职位列表
      jobList: [],
      jobType: [],
      // 后台获取的工作地点和职位类型
      filterCondition: {
        citys: {},
        posts: {}
      },
      // 线路
      catogery: 0,
      keyword: "",
      // 下拉框类型
      dropDownType: 0,
      isProfession: false,
      isCity: false,
      isNature: false,
      // 是否选好 选好下拉框消失 控制下拉框是否显示
      isChose: true,
      // 是否为校招
      campus: false,
      // 遮罩层是否显示
      isShow: false
    };
  },
  watch: {
    cityIndex(val, oldVal) {
      this.getList();
    },
    professionIndex(val, oldVal) {
      this.getList();
    },
    natureIndex(val, oldVal) {
      this.getList();
    },
    page(val, oldVal) {
      this.getList();
    }
  },
  methods: {
    // 选线路
    tabSwitch(id) {
      // this.controlSwitch = !this.controlSwitch;
      this.catogery = id;
      this.getList();
      this.controlSwitch = true;
    },
    // 	pageSize 改变时会触发
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    // currentPage 改变时会触发
    handleCurrentChange(val) {
      this.page = val;
      // this.getList();
      console.log(`当前页: ${val}`);
    },
    // 选择城市
    choseCity(id, content) {
      this.cityIndex = id;
      this.isCity = true;
      this.cityName = content;
      this.isChose = true;
      this.isShow = false;
    },
    // 选择职位类别
    choseProfession(id, content) {
      this.professionIndex = id;
      // this.dropDownType = 0
      this.isProfession = true;
      this.professionName = content;
      this.isChose = true;
      this.isShow = false;
    },
    // 选择职位性质
    choseNature(idx, content) {
      this.natureIndex = idx;
      this.isNature = true;
      this.natureName = content;
      this.isChose = true;
      this.isShow = false;
    },
    // 清除按钮重置搜索条件
    clear() {
      this.controlSwitch = false;
      this.cityIndex = 0;
      this.professionIndex = 0;
      this.natureIndex = 0;
      this.page = 1;
      this.currentPage = 1;
      this.catogery = 1;
      this.getList();
    },
    // 点击查看详情
    checkDetails(id) {
      let saveCondition = {
        lang: "1",
        time: parseInt(Date.parse(new Date()) / 1000),
        catogery: this.catogery,
        type: this.campus ? 1 : 0,
        keyword: this.keyword,
        job_type: this.natureIndex,
        jtype_name:this.natureName,
        post_type: this.professionIndex,
        ptype_name:this.professionName,
        city: this.cityIndex,
        city_name:this.cityName,
        company: 1
      };
      localStorage.setItem("saveCondition", JSON.stringify(saveCondition));
      
      if (this.campus) {
        this.$router.push({
          path: "/m/campus/detail",
          query: { id: id }
        });
      } else {
        this.$router.push({
          path: "/m/hr/detail",
          query: { id: id}
        });
      }
    },
    // 获取岗位列表
    getList() {
      this.$axios({
        method: "post",
        url:
          "https://hw.xianyuyouxi.com/service/tomato_webhome/search/" +
          this.page,
        headers: {
          "Access-s": this.$md5(
            `${this.key}${parseInt(Date.parse(new Date()) / 1000)}`
          )
        },
        data: {
          lang: "1",
          time: parseInt(Date.parse(new Date()) / 1000),
          catogery: this.catogery,
          type: this.campus ? 1 : 0,
          keyword: this.keyword,
          job_type: this.natureIndex,
          post_type: this.professionIndex,
          city: this.cityIndex,
          company: 1
        }
      }).then(res => {
        // console.log(res.data);
        this.total = parseInt(res.data.data.total);
        this.jobList = res.data.data.data;
        // console.log(this.jobList)
      });
    },
    // 获取筛选选项
    getSearchcondition() {
      this.$axios({
        method: "get",
        url: "https://hw.xianyuyouxi.com/service/tomato_webhome/get_condition",
        headers: {
          "Access-s": this.$md5(
            `${this.key}${parseInt(Date.parse(new Date()) / 1000)}`
          )
        },
        params: {
          lang: "1",
          time: parseInt(Date.parse(new Date()) / 1000),
          catogery: "1"
        }
      }).then(res => {
        // console.log(res.data);
        this.filterCondition = res.data.data;
      });
    },
    // 根据点击的按钮 展示不同的下拉列表
    changeDropdown(num) {
      // alert(this.isChose)
      if (this.dropDownType == num && this.isChose) {
        //点击相同项且下拉框无
        this.isChose = false;
        this.isShow = true;
      } else if (this.dropDownType == num && !this.isChose) {
        //点击相同项且下拉框有
        this.isChose = true;
        this.isShow = false;
      } else if (this.dropDownType != num && !this.isChose) {
        //点击不同项且下拉框有
      } else if (this.dropDownType != num && this.isChose) {
        //点击不同项且下拉框无
        this.isChose = false;
        this.isShow = true;
      }
      this.dropDownType = num;
    },
    // 控制阴影层的展示
    showMask(e) {
      // console.log(e.target.className);
      if (
        e.target.className != "span-active" &&
        e.target.className != "chose-span" &&
        e.target.className != "el-icon-caret-bottom" &&
        e.target.className != "chooseItems"
      ) {
        // alert("进了showMask");
        this.isShow = false;
        this.isChose = true;
      }
    }
    // 获取z只能分类分类
    // getType() {
    //   this.$axios({
    //     method: "get",
    //     url: "https://hw.xianyuyouxi.com/service/tomato_webhome/get_post_type",
    //     headers: {
    //       "Access-s": this.$md5(
    //         `${this.key}${parseInt(Date.parse(new Date()) / 1000)}`
    //       ),
    //     },
    //     params: {
    //       lang: "1",
    //       time: parseInt(Date.parse(new Date()) / 1000),
    //     },
    //   }).then((res) => {
    //     console.log(res.data);
    //     1;
    //   });
    // },
  },
  mounted() {
    this.professionIndex = this.$route.query.id;

    this.campus = this.$route.path == "/m/hr/allPost" ? false : true;

    if (!this.professionIndex) {
      this.professionIndex = 0;
    } else {
      this.isProfession = true;
      this.isChose = true;
      this.dropDownType = 1;
      this.professionName = this.$route.query.name;
    }
    this.keyword = this.$route.query.keyword;
    if (!this.keyword) {
      //有关键字
      this.keyword = "";
    }
    this.getSearchcondition();
    let saveCondition = localStorage.getItem("saveCondition");
    if (saveCondition) {
      saveCondition = JSON.parse(saveCondition);
      this.catogery = saveCondition.catogery;
      this.cityIndex = saveCondition.city;
      if(this.cityIndex != 0){
        this.isCity = true;
        this.cityName = saveCondition.city_name
      }
      this.natureIndex = saveCondition.job_type;
      if(this.natureIndex != 0){
        this.isNature = true;
        this.natureName = saveCondition.jtype_name
      }
      this.keyword = saveCondition.keyword;
      this.professionIndex = saveCondition.post_type;
      if(this.professionIndex != 0){
        this.isProfession = true;
        this.professionName = saveCondition.ptype_name
      }
    }

    this.getList();
    // this.getType();
  }
};
</script>
<style scoped>
.allPost {
  min-height: 100vh;
  background: #fafafa;
}

.banner {
  width: 100%;
  height: 1.7rem;
  display: block;
  position: relative;
  margin: 1rem 0 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/banner.png");
  background-position: 0 99%;
  background-size: 120%;
  z-index: 2;
}
.mask {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: -1;
}
.show.mask {
  z-index: 1;
}
.container {
  width: 100%;
  margin: 0 auto 0.5rem;
  z-index: 12;
  /* background: #fff; */
}
.container::after {
  content: "";
  display: block;
  clear: both;
}
.container-body {
  min-height: 10rem;
  display: flex;
  justify-content: space-between;
}

.inputBox {
  width: 6.87rem;
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  margin: -0.35rem auto 0;
  z-index: 3;
}
.inputBox >>> .el-input input {
  width: 6.87rem;
  height: 0.61rem;
  line-height: 0.61rem;
  font-size: 0.2rem;
  background: #ffffff;
  border: 0.01rem solid transparent;
  border-radius: 0.3rem;
}
.inputBox >>> .el-input input::-webkit-input-placeholder {
  font-size: 0.2rem;
  line-height: 0.61rem;

  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #999999;
}
.inputBox >>> .el-input--prefix .el-input__inner {
  padding: 0 0 0 1rem;
  line-height: 0.61rem;
}

.inputBox >>> .el-input input:focus {
  outline: none;
}
.inputBox >>> .el-icon-search {
  /* height: auto; */
  line-height: 0.61rem;
}
.inputBox >>> .el-input__prefix {
  margin: 0 0 0 0.2rem;
  font-size: 0.25rem;
  line-height: 0.61rem;
}
.search-button {
  line-height: 0.61rem;

  border: 0.01rem solid transparent;
  border-radius: 30px;
  transition: all 0.3s;
  border-radius: 30px;
  display: flex;
  align-items: center;
  box-shadow: 0rem 0.01rem 0.1rem 0.01rem rgb(0 0 0 / 10%);
}
.inputBox >>> .el-input input:focus {
  border: 0.01rem solid #0b2475;
}
.search {
  width: 0.63rem;
  height: 0.28rem;
  line-height: 0.28rem;
  position: absolute;
  top: 1px;
  right: -1px;
  color: #fff;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  background: #0b2475;
  border-radius: 0.2rem;
}
.search:hover {
  background: #0b2475;
}
/* 筛选条件 */

.chooseBox {
  width: 100%;
  padding: 0.35rem 0 0.5rem 0;
  /* margin: 0.1rem  0 0 0; */
  position: relative;
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-start;
  background: #fff;
  z-index: 2;
}
.chooseBox span {
  height: 0.6rem;
  line-height: 0.5rem;
  padding: 0.05rem 0.35rem;
  margin: 0.34rem 0 0 0.4rem;
  background: #efefef;
  border-radius: 0.3rem;
  font-size: 0.32rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.chooseBox >>> .el-icon-caret-bottom {
  font-size: 0.25rem;
}
.chooseDropdown {
  width: 100%;
  position: relative;
  background: #f2f2f2;
  z-index: 2;
}
.notActive.chooseDropdown {
  z-index: -1;
}
.chooseDropdown ul {
  width: 100%;
  padding: 0.31rem 0 0.31rem 0;
  position: absolute;
  top: 0;
  left: 0;
  background: #f2f2f2;
}
.chooseDropdown li {
  width: 100%;
  margin: 0;
  text-align: left;
  padding: 0.36rem 0 0.36rem 0.3rem;
  font-size: 0.32rem;
}

.span-active {
  color: #18278a !important;
}
/* 下拉框动效 */
.chooseItems {
  /* transition: all 0.5s; */
}
/* .notActive .chooseItems {
  height: 0;
  opacity: 0;
  z-index: -1;
} */
/* .left .clear {
  margin: 0 0 0 0.74rem;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #00a8ff;
  cursor: pointer;
} */

.right {
  width: 100%;
  /* background: darkolivegreen; */
  margin-top: 0.15rem;
  text-align: left;
}
.right-top {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin: 0.27rem 0 0 0.8rem;
}
.right-top p {
  font-size: 0.32rem;
}
.right-top span {
  color: #0b2475;
  font-size: 0.07rem;
  cursor: pointer;
  margin: 0 0 0 0.15rem;
}
.right-top p span {
  font-size: 0.48rem;
  color: #333333;
  font-weight: 700;
}
.right-list {
  padding-top: 0.12rem;
}
.public-list {
  width: 9.37rem;
  height: 2.06rem;
  margin: 0 auto;
  background: #ffffff;
  box-shadow: 0rem 0.01rem 0.05rem 0.01rem rgb(184 184 184 / 18%);
  border-radius: 0.05rem;
  margin-bottom: 0.1rem;
  cursor: pointer;
  /* box-sizing: border-box; */
}
.public-list:hover {
  box-shadow: 0rem 0.01rem 0.05rem 0.01rem rgb(184 184 184 / 60%);
  transform: scale(1.01);
  transition: 0.2s;
}
.public-list:hover p {
  color: #0b2475;
}
.job-new {
  color: #0b2475;
}
.job-title {
  display: flex;
  justify-content: space-between;
}
.job-title p {
  width: 5.5rem;
  height: 0.6rem;
  margin: 0.36rem 0 0 0.59rem;
  font-size: 0.48rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
  overflow: hidden;
  /* 超出部分设为... */
  text-overflow: ellipsis;
  /* 盒子模型 */
  display: -webkit-box;
  /* 最多2行文本 多余部分隐藏*/
  -webkit-line-clamp: 1;
  /* 从顶部向底部垂直布置子元素 */
  -webkit-box-orient: vertical;
}
.job-title span {
  margin: 0.36rem 0.45rem 0 0;
  font-size: 0.27rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666666;
}
.job-city {
  font-size: 0.32rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  margin: 0.35rem 0 0 0.57rem;
}
.job-des {
  /* max-height: 0.2rem; */
  /* overflow: hidden; */
  font-size: 0.07rem;
  color: #999999;
  -webkit-box-orient: vertical;
  text-overflow: ellipsis;
  overflow: hidden;
  word-break: break-all;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  display: none;
}
.job-des p {
  font-size: 0.07rem !important;
  text-overflow: -o-ellipsis-lastline;
  overflow: hidden;
}
.menu-list {
  display: flex;
  /* justify-content: space-between; */
  flex-wrap: wrap;
  text-align: center;
  flex-direction: row;
}
.menu-list span {
  display: inline-block;
  width: 0.49rem;
  font-size: 0.08rem;
  height: 0.18rem;
  margin-right: 0.08rem;
  margin-bottom: 0.05rem;
  line-height: 0.18rem;
  border-radius: 0.02rem;
  cursor: pointer;
}
.chose-span {
  color: #0b2475;
  background: #fff;
}
/* 页码 */
.page {
  display: flex;
  justify-content: center;
  margin: 0.5rem 0 0 0;
  /* width: 2rem; */
}
.page >>> .el-pagination.is-background .btn-next,
.page >>> .el-pagination.is-background .btn-next i,
.page >>> .el-pagination.is-background .btn-prev,
.page >>> .el-pagination.is-background .btn-prev i,
.page >>> .el-pagination.is-background .el-pager li {
  width: 0.81rem;
  height: 0.81rem;
  line-height: 0.81rem;
  font-size: 0.36rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  background: none;
  border: 1px solid #d2d2d2;
  border-radius: 0.02rem;
}

.page >>> .el-pager li:hover {
  color: #0b2475 !important;
  border: 1px solid #0b2475 !important;
}
.page >>> .el-pager li,
.page >>> .el-pager li.btn-quicknext:hover,
.page >>> .el-pager li.btn-quickprev:hover {
  color: #0b2475;
  border: 1px solid #0b2475;
}
.page >>> .el-pagination.is-background .el-pager li:not(.disabled).active {
  color: #0b2475;
  background: none;
  border: 1px solid #0b2475;
}
.page >>> .el-pagination.is-background .btn-next,
.page >>> .el-pagination.is-background .btn-prev,
.page >>> .el-pagination.is-background .el-pager li {
  color: #333333;
}
</style>
