<!--
 * @Author: your name
 * @Date: 2021-03-01 19:11:15
 * @LastEditTime: 2021-06-02 20:23:48
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\Games.vue
-->
<template>
  <div class="games">
    <Header />
    <div class="container">
      <!-- 轮播图主体 -->
      <div class="leftP">
        <div class="swiperBox">
          <!-- Swiper -->
          <div class="swiper-container swiper-container_2" v-cloak>
            <div class="swiper-wrapper" v-cloak>
              <div
                class="swiper-slide"
                :class="{ active1: isChange1, active2: isChange2 }"
                :style="{
                  zIndex: gIndex == item.id ? 2000 : -1,
                  opacity: gIndex == item.id ? 1 : 0
                }"
                v-for="item in $t('x.games.gamesList')"
                :key="item.id"
                v-cloak
              >
                <div class="left">
                  <span
                    :style="{
                      backgroundImage: 'url(https://wcdn.tomatogames.com/web/haiwai/gaojing/img/gicon0' + item.id + '.png)',
                      backgroundSize: '100%'
                    }"
                    class="icon"
                  ></span>

                  <h3>{{ item.title }}</h3>
                  <i class="hr"></i>
                  <span class="content" v-html="item.content"> </span>
                  <span class="more" v-if="item.id != 2"
                    >{{ $t("x.games.more") }}<br />
                    <template
                      v-if="$t('x.games.website[' + item.id + '][0]') == '#'"
                    >
                      <a href="#">{{
                        $t("x.games.website[" + item.id + "][1]")
                      }}</a>
                    </template>
                    <template v-else>
                      <a
                        :href="$t('x.games.website[' + item.id + '][0]')"
                        target="_blank"
                        >{{ $t("x.games.website[" + item.id + "][1]") }}</a
                      >
                    </template>
                  </span>
                </div>
                <div class="right">
                  <span
                    class="pic"
                    :class="'pic' + item.id"
                    :style="{
                      backgroundImage: 'url(https://wcdn.tomatogames.com/web/haiwai/gaojing/img/gperson' + item.id + '.png)'
                    }"
                  ></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 轮播点点的存在 -->
      <div class="rightP">
        <ul class="navbar">
          <li
            @click="toPage(i)"
            v-for="(item, i) in $t('x.games.gamesName')"
            :key="i"
            :class="{ active: gIndex == i, hot: i == 0 || i == 1 }"
          >
            <span
              :style="{
                backgroundImage: 'url(https://wcdn.tomatogames.com/web/haiwai/gaojing/img/gicon0' + i + '.png)'
              }"
              class="icon"
              :class="'icon' + i"
            ></span>
            <a href="#" v-html="item"></a>
          </li>
        </ul>
      </div>
    </div>

    <Footer />
  </div>
</template>
<script>
import Swiper from "swiper";
import "swiper/dist/css/swiper.css";

import Header from "@/components/Header.vue";
import Footer from "@/components/Footer.vue";
export default {
  name: "Games",
  data() {
    return {
      swiper: null,

      // 当前游戏页
      gIndex: 0,

      // 是否正在切换（样式1）
      isChange1: true,
      // 是否正在切换（样式2）
      isChange2: false,

      // 切换次数
      changeNum: 0,
      // 标题动画效果
      gamesActive: false,
      key: "0391591aafc5db68b08787645b837b4f",
      // 时间戳
      timer: parseInt(Date.parse(new Date()) / 1000)
    };
  },
  components: {
    Header,
    Footer
  },
  methods: {
    createSwiper() {
      let that = this;
      var swiper = new Swiper(".swiper-container_2", {
        spaceBetween: 30,
        effect: "fade",
        mousewheel: true,
        // preventClicks: false,
        speed: 300,
        fadeEffect: {
          crossFade: true
        },
        simulateTouch: false, //禁止鼠标模拟
        direction: "vertical",
        // loop:true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true
        },
        on: {
          init: function() {
            that.isChange1 = false;
          },

          transitionStart: function() {
            that.gIndex = this.realIndex;
            that.changeNum++;
            if (that.changeNum % 2 == 0) {
              that.isChange1 = true;
            } else {
              that.isChange2 = true;
            }
          },
          transitionEnd: function() {
            that.isChange1 == true
              ? (that.isChange1 = false)
              : (that.isChange2 = false);
          }
        }
      });
      this.swiper = swiper;
    },
    toPage(num) {
      this.swiper.slideTo(num);
    }
  },
  computed: {
    lang: function() {
      return localStorage.getItem("isEn") == "true" ? 0 : 1;
    }
  },
  mounted() {
    this.createSwiper();
    this.gamesActive = true;
    // 获取游戏产品信息
    this.$axios({
      methods: "get",
      url: "https://hw.xianyuyouxi.com/service/Tomato_webhome/getGames",
      headers: {
        "Access-s": this.$md5(`${this.key}${this.timer}`)
      },
      params: {
        time: this.timer,
        lang: this.lang,
        company: 1
      }
    }).then(res => {
      console.log(res);
      // res.data.data 游戏产品列表
    });
  },
  watch: {
    gIndex(newValue, oldValue) {
      // alert(newValue);
      // alert(oldValue);
    }
  }
};
</script>
<style scoped>
.container {
  width: 100%;
  height: 4.6rem;
  margin: 0.46rem 0 0 0;
  display: flex;
}
/* 左半页轮播主主体部分 */
.leftP {
  width: 8.24rem;
  height: 100%;
}
/* 轮播图 */
.swiperBox {
  width: 100%;
  height: 100%;
  position: relative;
}
.swiper-container_2 {
  width: 100%;
  height: 100%;
}
.swiper-wrapper {
  /* !!!!!轮播图每次切换延缓几秒  */
  /* transition-delay: 0.3s; */
}
.swiper-container_2 .swiper-slide {
  width: 100%;
  height: 100%;
  display: flex;
  text-align: center;
  font-size: 18px;
  /* !!!!!轮播图每次切换延缓几秒 */
  transition-delay: 0.2s;
  /* opacity: 0; */
  pointer-events: auto;
}
.swiper-slide[opacity="1"] .left {
  color: #0b2475 !important;
}
.swiper-container_2 .swiper-slide .left {
  width: 50%;
  height: 100%;
  text-align: left;
}
/* 轮播图内容 */
.left .icon {
  width: 0.64rem;
  height: 0.625rem;
  margin: 0.48rem 0 0 0.77rem;
  border-radius: 0.1rem;
  opacity: 1;
  transition: all 0.3s;
}

.left h3 {
  margin: 0.2rem 0 0 0.77rem;
  font-size: 0.21rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #0b2475;
  opacity: 1;
  transition: all 0.3s;
}
.en .left h3 {
  font-family: Arial;
}

.left .hr {
  width: 3.04rem;
  height: 0.001rem;
  display: block;
  margin: 0.17rem 0 0 0.77rem;
  border-bottom: 0.001rem solid #999;
}
.en .left .hr {
  margin: 0.15rem 0 0 0.77rem;
}
.left .content {
  width: 3.45rem;
  margin: 0.17rem 0 0 0.77rem;
  font-size: 0.1rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  line-height: 0.17rem;
  color: #999999;
  opacity: 1;
  transition: all 0.4s;
}
.en .left .content {
  font-size: 0.08rem;
  font-family: Arial;
  line-height: 0.15rem;
  color: #989898;
}

.left .more {
  margin: 0.2rem 0 0 0.77rem;
  font-size: 0.08rem;
  font-family: Arial;
  font-weight: 400;
  color: #999999;
  line-height: 0.12rem;
  opacity: 1;
  transition: all 0.4s;
}

.more a {
  font-size: 0.08rem;
  font-family: Arial;
  font-weight: 400;
  color: #00a8ff;
  line-height: 0.12rem;
}
.swiper-slide .right {
  width: 50%;
  height: 100%;
  text-align: right;
}
.right .pic {
  width: 3.59rem;
  height: 1.98rem;
  margin-right: 0.17rem;
  opacity: 1;
  transition: all 0.4s;
  border-radius: 0.15rem;
}

.right .pic0 {
  margin-top: 1.33rem;
  background-size: 110%;
  background-position: 0rem -0.6rem;
}
.right .pic1 {
  margin-top: 1.33rem;
  background-size: 100%;
}
.pic2 {
  margin-top: 1.33rem;
  background-size: 100%;
}
.pic3 {
  margin: 0.45rem 0 0 -0.6rem;
}
.pic4 {
  margin: 0.53rem 0 0 -0.25rem;
}
/* 右半页 */
.rightP {
  width: 1.8rem;
  height: 100%;
}
.navbar {
  height: 3.72rem;
  display: flex;
  flex-direction: column;
  justify-content: center;
  border-left: 0.001rem solid #999;
  transform: translateY(12%);
}
.navbar li {
  height: 0.55rem;
}
.navbar li .icon {
  width: 0.42rem;
  height: 0.42rem;
  display: block;
  margin: 0 auto;
  border-radius: 0.075rem;
  background-size: 100%;

  transition: all 0.3s;
}
.navbar li .icon0 {
  background-size: 108%;
  background-position: center;
}
.navbar li .icon1 {
  background-size: 105%;
  background-position: center;
}
.navbar li .icon2 {
  background-size: 107%;
  background-position: center;
}
.navbar li.active .icon {
  transform: scale(1.07);
  box-shadow: 0 0.01rem 0.01rem 0.005rem #999;
}
.navbar {
  margin: 0 auto;
}
.navbar li {
  margin: 0 0 0.3rem 0;
  cursor: pointer;
}
.navbar li:nth-of-type(1) {
  margin-top: 0.47rem;
}
.navbar li a {
  width: 0.45rem;
  position: relative;
  display: inline-block;
  margin: 0.05rem 0 0 0;
  font-size: 0.09rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #000000;
  transition: all 0.3s;
}
.en .navbar li a {
  width: 0.65rem;
  margin: 0.03rem 0 0 0;
  font-size: 0.08rem;
  font-family: Arial;
  font-weight: normal;
  line-height: 0.09rem;
}
.navbar li.active a {
  color: #0b2475;
}
.en .navbar li.active a {
  margin: 0.05rem 0 0 0;
}
.navbar li:hover a {
  color:#0b2475;
}
.navbar li:hover .icon {
  /* transform: scale(1.03); */
  box-shadow: 0 0.01rem 0.01rem 0.005rem #999;
}

/* .navbar li.hot a::after {
  content: "H";
  display: inline-block;
  width: 0.08rem;
  height: 0.08rem;
  position: absolute;
  top: 50%;
  left: 100%;
  transform: translateY(-50%);
  line-height: 0.09rem;
  color: #fff;
  text-align: center;
  font-size: 0.01rem;
  background: #fe5600;
  border-radius: 0.02rem;
}
.en .navbar li.hot a::after {
  top: 26%;
} */
</style>
