<!--
 * @Author: your name
 * @Date: 2021-02-23 10:57:53
 * @LastEditTime: 2021-05-13 14:59:43
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\Home.vue
-->
<template>
  <div class="home">
    <!-- <template v-if="isPC"> -->
      <Header />
      <Carousel />
      <About />
      <NewsPart />
      <Contact />
      <Footer />
    <!-- </template>
    <template v-else>
      <MHeader />
      <MCarousel />
      <MAbout />
      <MNewsPart />
      <MContact />
      <MFooter />
    </template> -->
  </div>
</template>

<script>
// @ is an alias to /src
import Header from "@/components/Header.vue";
import MHeader from "@/components/m-Header.vue";
import Footer from "@/components/Footer.vue";
import MFooter from "@/components/m-Footer.vue";
import Carousel from "@/components/Carousel.vue";
import MCarousel from "@/components/m-Carousel.vue";
import About from "@/components/About.vue";
import MAbout from "@/components/m-About.vue";
import NewsPart from "@/components/NewsPart.vue";
import MNewsPart from "@/components/m-NewsPart.vue";
import Contact from "@/components/Contact.vue";
import MContact from "@/components/m-Contact.vue";
export default {
  name: "Home",
  components: {
    Header,
    MHeader,
    Footer,
    MFooter,
    Carousel,
    MCarousel,
    About,
    MAbout,
    NewsPart,
    MNewsPart,
    Contact,
    MContact
  },
  data() {
    return {
      // isPC: null
    };
  },
  mounted() {
    // this.isPC = JSON.parse(localStorage.getItem("isPC"));
    // console.log(this.$route.params.toContact);
    // 如果有传参 说明是点击联系我们 则滚到相应位置
    if (this.$route.params.toContact) {
      this.$nextTick(() => {
        let contactTop = document.getElementById("toContact").offsetTop;
        document.documentElement.scrollTop = contactTop;
        // if (document.getElementsByClassName("maskBox")[0]) {
        //   document.getElementsByClassName("maskBox")[0].style.display = "block";
        // } else {
        //   document.getElementsByClassName("mmaskBox")[0].style.display =
        //     "block";
        // }
      });
    }
   
   
  }
};
</script>
<style scoped></style>
