<!--
 * @Author: your name
 * @Date: 2021-02-23 17:08:17
 * @LastEditTime: 2021-06-08 14:23:51
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\Footer.vue
-->
<template>
  <div class="footer">
    <div class="top">
      <template v-if="type">
        <span class="title">{{ $t("x.footer.title[1]") }}</span>
      </template>
      <template v-else>
        <span class="title">{{ $t("x.footer.title[0]") }}</span>
      </template>

      <QRCode :type="type" />
    </div>
    <div class="bottom">
      <div class="left">
        <div>
          <p>{{ $t("x.footer.about[0]") }}</p>
          <router-link to="/" @click.native="toAbout">{{
            $t("x.footer.about[1]")
          }}</router-link>
          <!-- <template v-if="type">
            <router-link to="/games">{{ $t("x.footer.about[2]") }}</router-link>
          </template>
          <template v-else> -->
          <router-link to="/games">{{ $t("x.footer.about[2]") }}</router-link>
          <!-- </template> -->
        </div>
        <div>
          <p>{{ $t("x.footer.news[0]") }}</p>
          <!-- <template v-if="type">
            <router-link to="/newsPage">{{ $t("x.footer.news[1]") }}</router-link>
          </template>
          <template v-else> -->
          <router-link to="/newsPage">{{ $t("x.footer.news[1]") }}</router-link>
          <!-- </template> -->
        </div>
        <!-- <div>
          <p>{{ $t("x.footer.contact[0]") }}</p>
          <a href="javascript:void(0);">{{ $t("x.footer.contact[1]") }}</a>
          <a href="javascript:void(0);">{{ $t("x.footer.contact[2]") }}</a>
        </div> -->
        <div>
          <p>{{ $t("x.footer.join[0]") }}</p>
          <router-link target="_blank" :to="{ name: 'Hr' }">{{
            $t("x.footer.join[1]")
          }}</router-link>
          <router-link target="_blank" :to="{ name: 'Campus' }">{{
            $t("x.footer.join[2]")
          }}</router-link>
          <!-- <router-link target="_blank" to="/employ" >{{
            $t("x.footer.join[3]")
          }}</router-link> -->
        </div>
      </div>
      <div class="right">
        <!-- <div>
        <span>{{ $t("x.footer.attention") }}</span>
        <img
          src="https://wcdn.tomatogames.com/web/haiwai/tomato/img/icon0.png"
          alt="icon0"
        />
        <img
          src="https://wcdn.tomatogames.com/web/haiwai/tomato/img/icon1.png"
          alt="icon1"
        />
        <img
          src="https://wcdn.tomatogames.com/web/haiwai/tomato/img/icon2.png"
          alt="icon2"
        />
      </div> -->
        <!-- 图标点击事件 -->
        <template v-if="type">
          <template v-if="campus">
            <router-link
              to="/campus"
              @click.native="toEmploy"
              style="display:inline"
              ><img :src="$t('x.logo')" alt="logo"
            /></router-link>
          </template>
          <template v-else>
            <router-link
              to="/hr"
              @click.native="toEmploy"
              style="display:inline"
              ><img :src="$t('x.logo')" alt="logo"
            /></router-link>
          </template>
        </template>
        <template v-else>
          <router-link to="/" @click.native="toHome" style="display:inline"
            ><img :src="$t('x.logo')" alt="logo"
          /></router-link>
        </template>

        <span>高竞文化传媒有限公司版权所有</span>
      </div>
    </div>
  </div>
</template>
<script>
import QRCode from "@/components/QRCode.vue";
export default {
  name: "Footer",
  props: {
    // false官网 true招聘
    type: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      campus: false
    };
  },
  components: {
    QRCode
  },
  methods: {
    toHome() {
      if (this.$route.path == "/") {
        this.$nextTick(() => {
          let headerTop = document.getElementById("header").offsetTop;
          document.documentElement.scrollTop = headerTop;
        });
      }
    },
    toEmploy() {
      if (this.$route.path == "/hr" || this.$route.path == '/campus') {
        this.$nextTick(() => {
          let headerTop = document.getElementById("jheader").offsetTop;
          document.documentElement.scrollTop = headerTop;
        });
      }
    },
    toAbout() {
      this.$nextTick(() => {
        let aboutTop = document.getElementById("about").offsetTop;
        document.documentElement.scrollTop = aboutTop;
      });
    }
  },
  mounted() {
    let path = this.$route.path;
    if (path.indexOf("/hr") == -1) {
      this.campus = true;
    }
  }
};
</script>
<style scoped>
.footer {
  width: 100%;
  padding: 0.001rem 0 0.13rem 0;
  color: #fff;
  background: #0b2475;
  text-align: left;
}
a {
  color: #fff;
  font-size: 0.07rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
}
p {
  font-size: 0.1rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
}
.top {
  width: 8.75rem;
  margin: 0.13rem auto 0.11rem;
}
.top .title {
  font-size: 0.07rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
}

.bottom {
  width: 8.75rem;
  margin: 0 auto;
  padding: 0.13rem 0;
  border-top: 1.5px solid rgba(255, 255, 255, 0.5);
  border-bottom: 1.5px solid rgba(255, 255, 255, 0.5);
}
.bottom::after {
  content: "";
  display: block;
  clear: both;
}
.left {
  height: 80%;
  float: left;
}
.left div {
  display: inline-block;
  /* 默认下对齐 修改为上对齐 */
  vertical-align: top;
  margin: 0 0.4rem 0 0;
}

.left div a {
  display: block;
  margin: 0.1rem 0 0 0;
  transition: all 0.3s;
}
.left div a:hover {
  /* text-shadow: 0 0 0.1rem rgb(255, 0, 43); */
}

.right {
  width: 50%;
  height: 80%;
  float: right;
  text-align: right;
}
.right div {
  display: inline-block;
  margin: 0.28rem 0.8rem 0rem 0;
  vertical-align: top;
}
/* logo */
.right img {
  width: 0.97rem;
  height: 0.43rem;
  margin: 0rem 0 0 2.31rem;
  vertical-align: top;
}
/* icon */
/* .right div img {
  width: 0.12rem;
  height: 0.11rem;
  margin: 0 0 0 0.1rem;
} */
/* copyright */
.right span {
  margin: 0.05rem 0 0 0;
  font-size: 0.08rem;
  font-family: Arial;
  font-weight: 400;
}
/* 关注我们 */
.right div span {
  display: inline;
  font-size: 0.1rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
}
</style>
