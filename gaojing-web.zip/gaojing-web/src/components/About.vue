<!--
 * @Author: your name
 * @Date: 2021-02-25 11:39:46
 * @LastEditTime: 2021-06-02 15:34:35
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\About.vue
-->
<template>
  <div class="about" id="about" :class="{ active: isActive }">
    <div class="orange">
      <!-- 切换的内容部分 -->
      <div
        :class="['box', { run: change }, { run1: change1 }]"
        :style="{ display: change ? 'block' : 'none' }"
      >
        <template v-if="msgIndex == 0">
          <div class="part">
            <span class="number">{{ $t("x.about.orange.special[0]") }}</span>
            <span class="thing">{{ $t("x.about.orange.special[1]") }}</span>
          </div>
          <div class="part">
            <span class="number">{{ $t("x.about.orange.special[2]") }}</span>
            <span class="thing">{{ $t("x.about.orange.special[3]") }}</span>
          </div>
          <div class="part">
            <span class="number">{{ $t("x.about.orange.special[4]") }}</span>
            <span class="thing">{{ $t("x.about.orange.special[5]") }}</span>
          </div>
        </template>
        <template v-else>
          <!-- 内容标题 -->
          <span class="title">{{
            $t("x.about.orange.aboutTitle[" + msgIndex + "]")
          }}</span>
          <!-- 内容主体 -->
          <ul>
            <li
              v-for="(item, i) in $t(
                'x.about.orange.aboutMsg[' + msgIndex + ']'
              )"
              :key="i"
            >
              {{ item }}
            </li>
          </ul>
        </template>
      </div>
      <!-- 切换内容按钮 -->
      <a href="#" class="next" @click.prevent="nextMsg()"
        ><i class="el-icon-arrow-right"></i
      ></a>
    </div>
    <div class="white">
      <div class="box">
        <h2>{{ $t("x.about.white.title") }}</h2>
        <span
          >{{ $t("x.about.white.content[0]") }}
          <br />
          {{ $t("x.about.white.content[1]") }}</span
        >
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "About",
  data() {
    return {
      screenHeight: document.documentElement.clientHeight,

      //   关于我们信息号
      msgIndex: 1,
      change: true,
      change1: false,
      //动画效果是否动起来
      isActive: false,
      
    };
  },
  methods: {
    handleScroll(e) {
      var scrollTop =
        e.target.documentElement.scrollTop || e.target.body.scrollTop;
      if (scrollTop > this.screenHeight - 700) {
        this.isActive = true;
      }
    },

    nextMsg() {
      this.msgIndex = this.msgIndex == 6 ? 1 : this.msgIndex + 1;
    },
  },
  watch: {
    msgIndex(newName, oldName) {
      this.change = false;
      this.change1 = true;
      setTimeout(() => {
        this.change = true;
      }, 20);
    },
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true);

   
  },
};
</script>
<style scoped>
.about {
  width: 100%;
  height: 5.2rem;
  /* margin: 0.05rem 0 0 0; */
  position: relative;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/about_bg.png");
  background-size: 101%;
  text-align: left;
  overflow: hidden;
}
.white {
  width: 6.48rem;
  height: 100%;
  padding-top: 0.001rem;
  background: rgba(255, 255, 255, 0.8);
  position: absolute;
  top: 100%;
  /* top: -50%; */
  left: 0;
}
.active .white {
  animation: white-run 1.7s linear;
  animation-fill-mode: forwards;
}
@keyframes white-run {
  0% {
    top: 100%;
  }
  100% {
    top: -50%;
  }
}
.white .box {
  width: 4.4rem;
  margin: 3.3rem 0 0 0.63rem;
  opacity: 0;
}
.en .white .box {
  width: 4.33rem;
}
.active .white .box {
  animation: wbox-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2.3s;
}
@keyframes wbox-run {
  0% {
    margin: 3.3rem 0 0 0.63rem;
    opacity: 0;
  }
  100% {
    margin: 2.9rem 0 0 0.63rem;
    opacity: 1;
  }
}
.white h2 {
  font-size: 0.26rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.en .white h2 {
  font-family: Arial;
  font-weight: bold;
}
.white span {
  margin-top: 0.17rem;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  text-align: justify;
  line-height: 0.21rem;
  color: #666666;
}
.en .white span {
  margin-top: 0.2rem;
  font-family: Arial;
}
.orange {
  width: 6.48rem;
  height: 100%;
  background: rgba(11, 36, 117, 0.8);
  position: absolute;
  top: -100%;
  /* top: 50%; */
  left: 0;
}
.active .orange {
  animation: orange-run 1.7s linear;
  animation-fill-mode: forwards;
  animation-delay: 1.2s;
}
@keyframes orange-run {
  0% {
    top: -100%;
  }
  100% {
    top: 50%;
  }
}
.orange .box {
  margin-top: -0.3rem;
  opacity: 0;
}
.active .orange .box.run {
  animation: obox-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2.9s;
}
.active .orange .box.run1 {
  animation: obox-run 1s;
  animation-fill-mode: forwards;
}
@keyframes obox-run {
  0% {
    margin-top: -0.3rem;
    opacity: 0;
  }
  100% {
    margin-top: 0rem;
    opacity: 1;
  }
}
/* 切换按钮 */
.orange .next {
  width: 0.28rem;
  height: 0.28rem;
  line-height: 0.26rem;
  text-align: center;
  position: absolute;
  top: 0.7rem;
  right: 0.62rem;
  display: block;
  font-size: 0.15rem;
  color: #fff;
  vertical-align: baseline;
  border: 0.015rem solid #ffffff;
  opacity: 0;
  border-radius: 100%;
}
.active .orange .next {
  animation: next-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 3.5s;
}
@keyframes next-run {
  0% {
    top: 0.7rem;
    opacity: 0;
  }
  100% {
    top: 1.1rem;
    opacity: 1;
  }
}
.orange .title {
  width: 4rem;
  margin: 0.35rem 0 0 0.63rem;
  color: #fff;
  font-size: 0.26rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
}
.en .orange .title {
  font-family: Arial;
  font-weight: bold;
}
.orange ul {
  width: 3.7rem;
  margin: 0.14rem 0 0 0.6rem;
  list-style-type: disc;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
  line-height: 0.21rem;
}
.en .orange ul {
  width: 3.79rem;
  font-size: 0.1rem;
  font-family: Arial;
  line-height: 0.2rem;
}
/* 包括每个带个数的工作是啥的 */
.orange .part {
  width: 0.5rem;
  display: inline-block;
  margin: 0.6rem 0 0 0.7rem;
  vertical-align: top;
}
/* 关于我们 数目 */
.orange .number {
  display: block;
  font-size: 0.3rem;
  font-family: Arial;
  font-weight: bold;
  color: #ffffff;
  line-height: 0.13rem;
}
/* 关于我们 工作室啥的 */
.orange .thing {
  margin: 0.1rem 0 0 0;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
  line-height: 0.1rem;
}
</style>