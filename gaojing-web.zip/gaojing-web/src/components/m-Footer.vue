<!--
 * @Author: your name
 * @Date: 2021-02-23 17:08:17
 * @LastEditTime: 2021-06-08 11:20:49
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\Footer.vue
-->
<template>
  <div class="mfooter">
    <div class="top">
      <template v-if="type">
        <span class="title">{{ $t("x.footer.title[1]") }}</span>
      </template>
      <template v-else>
        <span class="title">{{ $t("x.footer.title[0]") }}</span>
      </template>
      <QRCode :type="type" />
    </div>
    <div class="middle">
      <el-collapse class="tabList">
        <el-collapse-item :title="$t('x.footer.about[0]')">
          <div>
            <router-link to="/m" @click.native="toAbout">{{
              $t("x.footer.about[1]")
            }}</router-link>
          </div>
          <div>
            <router-link to="/m/games">
              {{ $t("x.footer.about[2]") }}</router-link
            >
          </div>
        </el-collapse-item>
        <el-collapse-item :title="$t('x.footer.news[0]')">
          <div>
            <router-link to="/m/newsPage">{{
              $t("x.footer.news[1]")
            }}</router-link>
          </div>
        </el-collapse-item>
        <!-- <el-collapse-item :title="$t('x.footer.contact[0]')">
          <div>{{ $t("x.footer.contact[1]") }}</div>
          <div>{{ $t("x.footer.contact[2]") }}</div>
        </el-collapse-item> -->
        <el-collapse-item :title="$t('x.footer.join[0]')">
          <div>
            <router-link
              target="_blank"
              :to="{ name: 'MHr' }"
              >{{ $t("x.footer.join[1]") }}</router-link
            >
          </div>
          <div>
            <router-link
              target="_blank"
              :to="{ name: 'MCampus'}"
              >{{ $t("x.footer.join[2]") }}</router-link
            >
          </div>
          <!-- <div>{{$t('x.footer.join[3]')}}</div> -->
        </el-collapse-item>
      </el-collapse>
    </div>
    <div class="bottom">
      <span class="copyright"
        >高竞文化传媒有限公司版权所有</span
      >
    </div>
  </div>
</template>
<script>
import QRCode from "@/components/m-QRCode.vue";
export default {
  name: "MFooter",
  props: {
    // false官网 true招聘
    type: {
      type: Boolean,
      default: false
    }
  },
  components: {
    QRCode
  },
  data() {
    return {
      // isPC: null,
    };
  },
  methods: {
    toAbout() {
      this.$nextTick(() => {
        let aboutTop = document.getElementById("about").offsetTop;
        document.documentElement.scrollTop = aboutTop;
      });
    }
  },
  mounted() {
    // this.isPC = JSON.parse(localStorage.getItem("isPC"));
    // if (this.isPC) {
    //   require("./../assets/css/footer.css");
    // } else {
    //   require("./../assets/css/m-footer.css");
    // }
  }
};
</script>
<style scoped>
.mfooter {
  width: 100%;
  padding-top: 0.01rem;
  color: #fff;
  background: #0b2475;
  text-align: left;
}
.mfooter::after {
  content: "";
  display: block;
  clear: both;
}
a {
  color: #fff;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
}
p {
  font-size: 0.1rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
}
.top {
  width: 85%;
  margin: 0.32rem auto 0.25rem;
}
.top .title {
  font-size: 0.4rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
}
.middle {
  width: 85%;
  margin: 0.1rem auto 0;
  border-top: 0.01rem solid rgba(255, 255, 255, 0.5);
  border-bottom: 0.01rem solid rgba(255, 255, 255, 0.5);
}
.middle .tabList {
  width: 100%;
}

.bottom {
  width: 85%;
  margin: 0 auto;
}

/* copyright */
.bottom .copyright {
  margin: 0.3rem 0 0.3rem 0;
  font-size: 0.19rem;
  font-family: Arial;
  font-weight: 400;
  color: #ffffff;
  float: right;
}

.mfooter >>> .el-collapse {
  /* margin: 0.5rem 0 0 0.6rem; */
  border: none;
}
.mfooter >>> .el-collapse-item__header {
  height: 0.8rem;
  font-size: 0.35rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
  line-height: 0.14rem;
  background: none;
  border: none;
}
.mfooter >>> .el-dropdown {
  margin: 0.2rem 0 0 3.5rem;
  color: #fff;
}
.mfooter >>> .el-dropdown .el-dropdown-link {
  font-size: 0.25rem;
}
.mfooter >>> .el-collapse-item__wrap {
  border-bottom: 0;
  background: transparent;
  margin: 0 0 0.2rem 0;
}
.mfooter >>> .el-collapse-item__content {
  padding-bottom: 0 !important;
}
.mfooter >>> .el-collapse-item__content div {
  line-height: 0.55rem;
  background: #0b2475;
  font-size: 0.29rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
}
.mfooter >>> .el-collapse-item__content div a {
  font-size: 0.29rem;
  color: #ffffff;
}
.el-dropdown-menu__item {
  color: #0b2475;
}
</style>
