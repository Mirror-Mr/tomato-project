<!--
 * @Author: your name
 * @Date: 2021-03-22 15:23:06
 * @LastEditTime: 2021-06-08 15:35:25
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\jobs\GamesJob.vue
-->
<template>
  <div class="gameJob">
    <!-- 校招流程 -->
    <!-- <div class="campus" v-if="campus">
      <div class="item" v-for="item in $t('y.gamejob.m_campus')" :key="item.id">
        <div>
          <img :class="'campusIcon' + item.id" :src="item.icon" alt="" />
        </div>

        <span>{{ item.content }}</span>
        <img
          class="next"
          :class="'next' + item.id"
          v-show="item.id != 4"
          src="https://wcdn.tomatogames.com/web/haiwai/tomato/img/next.png"
          alt=""
        />
      </div>
    </div> -->
    <div class="game">
      <div class="title">
        <span class
        ="">{{ $t("y.gamejob.game.title[0]") }}</span>
        <span class="">{{ $t("y.gamejob.game.title[1]") }}</span>
      </div>

      <br />
      <ul class="gameList">
        <li
          v-for="item in $t('y.gamejob.game.gameList')"
          :key="item.id"
          @click="clickGame(item.id - 1)"
          @mouseover="hoverGame(item.id - 1)"
          @mouseleave="leaveGame()"
          :class="{ active: item.id - 1 == gameIndex }"
        >
          <img :src="item.icon" alt="" class="gameIcon" />
          <span class="name">{{ item.name }}</span>
          <!--<br />
           <span class="desc desc1" v-html="item.desc1"></span><br />
          <span class="desc desc2">{{ item.desc2 }}</span> -->
        </li>
        <div class="lineBall">
          <span
            class="ball"
            :style="{
              left: gameBall + 'rem'
            }"
          ></span>
        </div>
      </ul>
    </div>
    <div class="job">
      <span class="title">{{ $t("y.gamejob.job.title") }}</span>
      <ul class="jobList">
        <li
          v-for="(item, key, index) in filterCondition"
          :key="key"
          @click="chosePosition(key, item)"
        >
          <el-card shadow="always">
            <span class="name">{{ item }}</span>
            <span class="jobIcon" :class="'jIcon' + (index + 1)"></span>
            <a href="#" class="look"
              >{{ $t("y.gamejob.job.look") }}<i class="el-icon-arrow-right"></i
            ></a>
          </el-card>
        </li>
      </ul>
      <router-link :to="{ name: 'MAllPost', query: { campus } }"
        ><span class="more">{{ $t("y.gamejob.job.more") }} </span></router-link
      >
    </div>
  </div>
</template>
<script>
export default {
  name: "GameJob",
  props: {
    campus: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      // 当前选择游戏号
      gameIndex: 0,
      // 记录
      lastGame: null,
      key: "0391591aafc5db68b08787645b837b4f",
      filterCondition: {}
    };
  },
  computed: {
    gameBall() {
      return 3.18 + this.gameIndex * 3.6;
    }
  },
  methods: {
    clickGame(id) {
      //  id 0-4
      if (this.$i18n.t("x.games.website[" + id + "][0]") == "#") {
        return;
      }
      let url = this.$i18n.t("x.games.website[" + id + "][1]");
      window.open(url, "_blank");
    },
    hoverGame(id) {
      // this.lastGame = this.gameIndex;
      this.gameIndex = id;
    },
    leaveGame() {
      // this.gameIndex = this.lastGame;
      this.gameIndex = null;
    },
    chosePosition(id, name) {
       let path;
      if (this.campus) {
        path = "/m/campus/allPost";
      } else {
        path = "/m/hr/allPost";
      }
      this.$router.push({
        path: path,
        query: { id: id, name: name }
      });
    },
    // 获取z只能分类分类
    getType() {
      this.$axios({
        method: "get",
        url: "https://hw.xianyuyouxi.com/service/tomato_webhome/get_post_type",
        headers: {
          "Access-s": this.$md5(
            `${this.key}${parseInt(Date.parse(new Date()) / 1000)}`
          )
        },
        params: {
          lang: "1",
          time: parseInt(Date.parse(new Date()) / 1000)
        }
      }).then(res => {
        let arr = res.data.data;
        let keyarr = Object.keys(arr);
        keyarr.length = 3;
        keyarr.map(key => {
          this.$set(this.filterCondition, key, arr[key]);
        });
      });
    }
  },
  mounted() {
    this.getType();
  }
};
</script>
<style scoped>
.gameJob {
  width: 100%;
  /* height: 5rem; */
}
.game {
  position: relative;
  margin: 0.15rem 0 0 0;
}
.game .title {
  width: 100%;
  margin: 0.87rem 0 0 0;
  font-size: 0.32rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.game .title span {
  margin-bottom: 0.25rem;
}
.en .game .title {
  width: 9.16rem;
  font-size: 0.37rem;
  font-family: Arial;
  font-weight: 400;
  color: #333333;

  line-height: 0.52rem;
}
.campus {
  margin: 0.4rem 0 0 0;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}
.campus .item {
  width: 2rem;
  vertical-align: top;
  position: relative;
  display: inline-block;
  margin: 1.2rem 1.1rem;
  font-size: 0.37rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.13rem;
}
.en .campus .item {
  width: 3.5rem;
  margin: 1.2rem 0rem;
  font-family: Arial;
}
.campus .item div {
  height: 2.3rem;
}
.en .campus .item div {
  height: 2.3rem;
}
.campusIcon1 {
  width: 1.7rem;
}
.campusIcon2 {
  width: 1.7rem;
}

.campusIcon4 {
  width: 2.1rem;
}
.campusIcon3 {
  width: 1.5rem;
}
.campus .item span {
  /* width: 1rem; */
  margin: 0.1rem 0 0 0;
}
.campus .next {
  width: 0.32rem;
  position: absolute;
}
.next1 {
  top: 0.8rem;
  right: -1.8rem;
}
.en .next1 {
  right: -0.8rem;
}
.next2 {
  transform: rotateZ(90deg);
  top: 3.5rem;
  right: 0.8rem;
}
.en .next2 {
  right: 1.5rem;
}
.next3 {
  transform: rotateZ(180deg);
  top: 0.8rem;
  right: -1.8rem;
}
.en .next3 {
  right: -0.8rem;
}
.gameList {
  position: relative;
  display: flex;
  justify-content: center;
  margin: 0 auto;
}
.gameList li {
  width: 3rem;
  height: 2rem;
  display: flex;
  flex-direction: column;
  cursor: pointer;
  text-align: left;
  /* margin: 1rem 0 0 0; */
  display: flex;
}

.gameIcon {
  width: 2.01rem;
  height: 2.01rem;
  margin: 0 auto;
  border-radius: 0.3rem;
  transform: scale(1);
  transition: all 0.3s;
}
.gameIcon + div {
  width: 5.9rem;
  display: flex;
  flex-direction: column;
}
.gameList .name {
  vertical-align: top;
  margin: 0.5rem auto 0;
  font-size: 0.27rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  transition: all 0.3s;
  cursor: pointer;
}
.active .name {
  color: #18278a;
  -webkit-text-stroke: 0.01px #182789;
  text-stroke: 0.01px #182789;
}
.game .lineBall {
  width: 100%;
  height: 0.00001rem;
  position: absolute;
  top: 2.3rem;
  left: 0;
  border-top: 0.01rem solid #eaeaea;
}
.game .ball {
  width: 0.15rem;
  height: 0.15rem;
  position: absolute;
  top: -0.08rem;
  left: 3.07rem;
  border-radius: 100%;
  background: #18278a;
  transition: all 0.3s;
}
.gameList .desc {
  vertical-align: top;
  font-size: 0.32rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #999999;
}
.en .desc {
  display: none;
}
.desc1 {
  margin: 0.1rem 0 0 0.28rem;
}
.desc2 {
  /* margin: 0 0 0 0.1rem; */
  display: none;
}
.job {
  margin: 3rem 0 0 0;
}
.job .title {
  font-size: 0.48rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
}
.jobList {
  width: 85%;
  margin: 0 auto;
  display: flex;
  justify-content: flex-start;
  flex-wrap: wrap;
  text-align: left;
}
.jobList li {
  width: 9.19rem;
  height: 3.03rem;
  margin: 0.55rem 0 0.16rem 0.12rem;
  transform: scale(1);
  transition: all 0.5s;
  cursor: pointer;
}
.jobList li:hover {
  transform: scale(1.03);
}
.jobList >>> .el-card {
  width: 100%;
  height: 100%;
}
.jobList >>> .el-card__body {
  width: 100%;
  height: 100%;
  border-radius: 0.05rem;
  padding: 0;
}
.jobList .name {
  margin: 0.63rem 0 0 0.65rem;
  font-size: 0.47rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  transition: all 0.3s;
}
.jobList li:hover .name {
  color: #18278A;
}
.jobList .jobIcon {
  display: block;
  float: right;
  transition: all 0.3s;
}
.jobList .jIcon1 {
  width: 0.57rem;
  height: 0.71rem;
  margin: 0.75rem 0.72rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill00.png");
  background-size: 100%;
}
.jobList li:hover .jIcon1 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill10.png");
  background-size: 100%;
}
.jobList .jIcon2 {
  width: 0.65rem;
  height: 0.65rem;
  margin: 0.7rem 0.69rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill01.png");
  background-size: 100%;
}
.jobList li:hover .jIcon2 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill11.png");
  background-size: 100%;
}
.jobList .jIcon3 {
  width: 0.63rem;
  height: 0.63rem;
  margin: 0.7rem 0.68rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill02.png");
  background-size: 100%;
}
.jobList li:hover .jIcon3 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill12.png");
  background-size: 100%;
}
.jobList .jIcon4 {
  width: 0.59rem;
  height: 0.61rem;
  margin: 0.7rem 0.68rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill03.png");
  background-size: 100%;
}
.jobList li:hover .jIcon4 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill13.png");
  background-size: 100%;
}
.jobList .jIcon5 {
  width: 0.84rem;
  height: 0.63rem;
  margin: 0.7rem 0.53rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill04.png");
  background-size: 100%;
}
.jobList li:hover .jIcon5 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill14.png");
  background-size: 100%;
}
.jobList .jIcon6 {
  width: 0.6rem;
  height: 0.61rem;
  margin: 0.7rem 0.61rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill05.png");
  background-size: 100%;
}
.jobList li:hover .jIcon6 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill15.png");
  background-size: 100%;
}
.jobList .look {
  display: block;
  margin: 0.65rem 0 0 0.63rem;
  font-size: 0.31rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #18278A;
}
.more {
  width: 3.81rem;
  height: 0.95rem;
  margin: 0.45rem 0 0.4rem 0;
  line-height: 0.95rem;
  font-size: 0.37rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
  background: #18278A;
  border-radius: 0.5rem;
}
.en .more {
  width: 4.49rem;
  height: 0.95rem;
  margin: 0.64rem 0 2.2rem 0;
  line-height: 0.95rem;
  font-size: 0.37rem;
  font-family: Arial;
  font-weight: 400;
  color: #ffffff;
  background: #18278A;
  border-radius: 0.5rem;
}
.more:hover {
  background-color: #18278A;
}
</style>
