<!--
 * @Author: your name
 * @Date: 2021-03-22 11:37:04
 * @LastEditTime: 2021-06-08 14:08:52
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\jobs\Overlay.vue
-->

<template>
  <div class="joverlay">
    <div class="center">
      <!-- 输入框 -->
      <div class="inputBox">
        <el-input
          :placeholder="$t('y.overlay.placeholder')"
          prefix-icon="el-icon-search"
          v-model="keyword"
          class="search-button"
          @keyup.enter.native="searchPost"
        >
        </el-input>
        <a href="#" class="search" @click.prevent="searchPost">{{
          $t("y.overlay.search")
        }}</a>
      </div>
      <span class="title"></span>
    </div>
    <!-- 向下的箭头 -->
    <div class="bottomBox">
      <span href="#" class="toBottom"></span>
    </div>
  </div>
</template>
<script>
export default {
  name: "JOverlay",
  props: {
    campus: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      keyword: ""
    };
  },
  methods: {
    searchPost() {
      let name;
      if(this.campus){
        name = 'CallPost'
      }else{
        name = 'HallPost'
      }
      this.$router.push({
        name: name,
        query: { keyword: this.keyword}
      });
    }
  }
};
</script>
<style scoped>
.joverlay {
  width: 100%;
  /* min-width: 6rem; */
  height: 5.1rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/employ_bg.png") no-repeat;
  background-size: 100%;
  position: relative;
}
.center {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -9%);
}
.en h1 {
  letter-spacing: 0.005rem;
}
h1 {
  margin: 0 0 0.16rem 0;
  font-size: 0.26rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  font-style: italic;
  letter-spacing: 0.035rem;
  color: #ffffff;
}
.title {
  width: 4.46rem;
  height: 0.75rem;
  margin: 0.3rem 0 0.1rem 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/overlay_title.png");
  background-size: 100%;
}
.en .title {
  width: 2.81rem;
  height: 0.24rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/en_overlay_title.png");
  background-size: 100%;
}
.inputBox {
  width: 2.29rem;
  margin: 0 auto;
  position: relative;
  display: flex;
  align-items: center;
}
.inputBox >>> .el-input input {
  width: 100%;;
  height: 0.28rem;
  background: #ffffff;
  border: 0;
  border-radius: 0.2rem;
}
.inputBox >>> .el-input--prefix .el-input__inner {
  padding: 0 0 0 0.3rem;
}
.inputBox >>> .el-input input:focus {
  outline: none;
}
.inputBox >>> .el-input__prefix {
  margin: 0 0 0 0.04rem;
}
.inputBox >>> .el-input__icon {
  line-height: 0.28rem;
}
.search-button {
  border: 1px solid transparent;
}
.search-button:hover {
  /* border: 1px solid #FF7915; */
  /* border-radius: 30px;
  display: flex;
  align-items: center; */
}

.search {
  width: 0.63rem;
  height: 0.28rem;
  line-height: 0.28rem;
  position: absolute;
  top: 1px;
  right: 0rem;
  color: #fff;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;

  background: #18278a;
  border-radius: 0.2rem;
}
.search:hover {
  background: #18278a;
}
.bottomBox {
  width: 0.5rem;
  height: 0.5rem;
  position: absolute;
  bottom: 0rem;
  left: 50%;
  transform: translateX(-50%);
  z-index: 2;
}
.toBottom {
  width: 0.14rem;
  height: 0.36rem;
  position: absolute;
  bottom: 0.1rem;
  left: 50%;
  transform: translateX(-50%);
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/toBottom.png");
  background-size: 100%;
  animation: toBottom-run 1.5s linear infinite;
}
@keyframes toBottom-run {
  0% {
    bottom: 0.1rem;
  }
  50% {
    bottom: 0.2rem;
  }
  100% {
    bottom: 0.1rem;
  }
}
</style>
