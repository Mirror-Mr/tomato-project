<!--
 * @Author: your name
 * @Date: 2021-03-23 20:15:13
 * @LastEditTime: 2021-05-25 19:07:57
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\jobs\Welfare.vue
-->
<template>
  <div class="welfare">
    <!-- 左边固定不动 -->
    <div class="left">
      <h2>{{ $t("y.welfare.left.title") }}</h2>
      <i class="hr"></i>
      <p class="content content1">
        <span>{{ $t("y.welfare.left.content[0][0]") }}</span>
        <span>{{ $t("y.welfare.left.content[0][1]") }}</span>
      </p>
      <p class="content content2">
        <span>{{ $t("y.welfare.left.content[1][0]") }}</span>
        <span>{{ $t("y.welfare.left.content[1][1]") }}</span>
        <span>{{ $t("y.welfare.left.content[1][2]") }}</span>
      </p>
      <p class="content content3">
        <span>{{ $t("y.welfare.left.content[2][0]") }}</span>
        <span>{{ $t("y.welfare.left.content[2][1]") }}</span>
      </p>
      <!-- 装饰的点点 -->
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
    <!-- 右边轮播图 -->
    <div class="right">
      <!-- Swiper -->
      <div class="swiper-container_3">
        <div class="swiper-wrapper">
          <div
            class="swiper-slide"
            v-for="item in $t('y.welfare.right.welfares')"
            :key="item.id"
          >
            <span class="title">{{ item.title }}</span>

            <img class="icon" :src="item.icon" />
            <span
              class="pic"
              :class="'pic' + item.id"
              :style="{
                backgroundImage: 'url(' + item.pic + ')',
                backgroundSize: '100%'
              }"
            ></span>

            <span class="specific">{{ item.specific }}</span>
          </div>
        </div>
      </div>
      <!-- 滚动条 -->
      <div class="line" :style="{ width: length + 'rem' }">
        <span
          class="slip"
          :style="{
            width: length / 9 + 'rem',
            left: index * (length / 9) + 'rem'
          }"
        ></span>
      </div>
      <div class="toLeft" @click="toLeft">
        <i class="el-icon-arrow-right"></i>
      </div>
    </div>
  </div>
</template>
<script>
import Swiper from "swiper";
import "swiper/dist/css/swiper.css";
export default {
  name: "Welfare",
  data() {
    return {
      swiper: null,
      // 底部滚动条整体长度
      length: 6.22,
      // 第几张图
      index: 0
    };
  },
  methods: {
    createSwiper() {
      let that = this;
      this.swiper = new Swiper(".swiper-container_3", {
        slidesPerView: "auto",
        allowTouchMove: false,
        spaceBetween: 94,
        freeMode: true,
        loop: true,
        slidesOffsetBefore: 88,
        pagination: {
          el: ".swiper-pagination",
          clickable: true
        },
        on: {
          slideChangeTransitionStart: function() {
            that.index = this.realIndex;
          }
        }
      });
    },
    toLeft() {
      this.swiper.slideNext();
    }
  },
  mounted() {
    this.createSwiper();
  }
};
</script>
<style scoped>
.welfare {
  width: 100%;
  height: 5.21rem;
  display: flex;
  text-align: left;
}
.left {
  width: 2.71rem;
  height: 100%;
  padding-top: 0.001rem;
  border-right: 0.001rem solid #666;
}
.left h2 {
  margin: 0.95rem 0 0 0.62rem;
  font-size: 0.26rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.left i {
  width: 1.7rem;
  height: 0.00001rem;
  display: block;
  margin: 0.23rem 0 0 0.61rem;
  border-top: 0.0001rem solid #666;
}
.content {
  margin: 0.24rem 0 0 0.61rem;
  font-size: 0.09rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.en .content {
  width: 1.66rem;
  font-family: Arial;
}
.dots {
  margin: 0.98rem 0 0 0.63rem;
}
.en .dots {
  margin: 0.4rem 0 0 0.63rem;
}
.dots span {
  width: 0.02rem;
  height: 0.02rem;
  border-radius: 50%;
  margin: 0 0.05rem 0 0;
}
.dots span:nth-of-type(1) {
  background: #18278a;
}
.dots span:nth-of-type(2) {
  background: #242a50;
}
.dots span:nth-of-type(3) {
  background: #999999;
}
.right {
  width: 7.18rem;
  height: 100%;
  position: relative;
}
.swiper-container_3 {
  width: 100%;
  height: 4.1rem;
  border-bottom: 0.01rem solid #666;
  overflow: hidden;
}

.swiper-container_3 .swiper-slide {
  width: 2.78rem;
  position: relative;
}
.title {
  display: inline-block;
  position: absolute;
  top: 0.7rem;
  left: 0.01rem;
  padding-bottom: 0.1rem;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666666;
  border-bottom: 0.01rem solid #666;
}
.icon {
  width: 0.21rem;
  height: 0.21rem;
  position: absolute;
  top: 0.71rem;
  right: 0.01rem;
  vertical-align: top;
}
.pic {
  width: 2.78rem;
  height: 1.97rem;
  margin: 1.12rem 0 0 0;
  display: block;
}
.pic1 {
  background-size: 107% !important;
}
.pic2 {
  background-size: 112% !important ;
}
.pic3 {
  background-size: 107% !important;
}
.pic4 {
  background-position: 0rem -1.7rem;
  background-size: 100% !important;
}
.pic6 {
  background-position: -0.08rem 0rem;
  background-size: 106% !important;
}
.pic7 {
  background-position: -0.08rem 0rem;
  background-size: 106% !important;
}
.pic8 {
  background-position: -0.08rem 0rem;
  background-size: 107% !important;
}
.specific {
  margin: 0.15rem 0 0 0;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
  line-height: 0.23rem;
}
.line {
  /* width: 6.22rem; */
  height: 0.001rem;
  position: relative;
  display: inline-block;
  margin: 0.29rem 0 0 0.44rem;
  padding-top: 1px;
  border-bottom: 0.001rem solid #666666;
}
.slip {
  height: 0.02rem;
  position: absolute;
  top: -0.005rem;
  /* left: 0; */
  background: #18278a;
  transition: all 0.4s;
}
.toLeft {
  width: 0.2rem;
  height: 0.2rem;
  vertical-align: top;
  margin: 0.18rem 0 0 0.18rem;
  display: inline-block;
  line-height: 0.2rem;
  text-align: center;
  font-size: 0.12rem;
  font-weight: bolder;
  color: #fff;
  background: #18278a;
  border-radius: 50%;
  cursor: pointer;
}
.toLeft:hover {
  background-color: #18278a;
}
</style>
