<!--
 * @Author: your name
 * @Date: 2021-03-23 17:26:20
 * @LastEditTime: 2021-05-28 14:25:43
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\jobs\Cutrure.vue
-->
<template>
  <div class="culture">
    <!-- Swiper -->
    <div
      class="cultureItem"
      :class="['cultureItem0' + item.id]"
      v-for="item in $t('y.culture.pageList')"
      :key="item.id"
    >
      <span
        class="pic"
        :style="{
          backgroundImage:
            'url(https://wcdn.tomatogames.com/web/haiwai/gaojing/img/page0' +
            item.id +
            '_r.png)',
          backgroundSize: '100%'
        }"
      ></span>
      <div class="content">
        <h2>{{ item.title }}</h2>
        <i class="hr"></i>
        <p>{{ item.content1 }}</p>
        <p>{{ item.content2 }}</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Culture",
  data() {
    return {};
  },
  methods: {},
  mounted() {}
};
</script>
<style scoped>
.culture {
  width: 100%;
  /* height: 5.21rem; */
  position: relative;
  text-align: left;
  margin: 2rem 0 0 0;
}
.en .culture {
  margin: 0;
}
.cultureItem {
  width: 93%;
  height: 9.13rem;
  margin: 0 auto 1.39rem;
  box-shadow: 0rem 0rem 0.1rem 0.05rem rgba(184, 184, 184, 0.18);
}
.en .cultureItem {
  height: auto;
}
.cultureItem .pic {
  width: 100%;
  height: 4.46rem;
}
.cultureItem01 .pic {
  background-position: 0rem -0.9rem;
  background-size: 100% !important;
}
.cultureItem02 .pic {
  background-image: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/page02_l.png") !important;
  background-position: 0rem -1.2rem;
  background-size: 100% !important;
}
.cultureItem03 .pic {
  background-position: -0.1rem -0.6rem;
  background-size: 110% !important;
}
.content {
  width: 100%;
  height: 4.53rem;
  background: #fff;
  overflow: hidden;
}

.en .content {
  height: auto;
  padding: 0 0 0.8rem 0;
}
.content h2 {
  width: 3.5rem;
  margin: 0.67rem 0 0 0.57rem;
  font-size: 0.48rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.en .content h2 {
  width: 4.5rem;
  font-family: Arial;
  font-weight: bold;
}
.content .hr {
  width: 8.15rem;
  height: 0.000001rem;
  display: block;
  margin: 0.23rem 0 0 0.44rem;
  border-bottom: 0.00001rem solid #666666;
}
.content p {
  width: 8.45rem;
  margin: 0.24rem 0 0 0.44rem;
  font-size: 0.41rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666666;
  line-height: 0.67rem;
}
.en .content p {
  width: 8.08rem;
  font-family: Arial;
  color: #999999;
}
.content p:nth-of-type(2) {
  margin-top: -0.07rem;
}
</style>
