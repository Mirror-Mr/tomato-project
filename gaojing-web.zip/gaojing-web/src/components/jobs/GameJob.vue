<!--
 * @Author: your name
 * @Date: 2021-03-22 15:23:06
 * @LastEditTime: 2021-06-08 14:10:35
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\jobs\GamesJob.vue
-->
<template>
  <div class="gameJob">
    <div class="campus" v-if="campus">
      <!-- <div class="item" v-for="item in $t('y.gamejob.campus')" :key="item.id">
        <div>
          <img :src="item.icon" alt="" />
        </div>
        <span>{{ item.content }}</span>
        <img
          class="next"
          v-show="item.id != 4"
          src="https://wcdn.tomatogames.com/web/haiwai/tomato/img/next.png"
          alt=""
        />
      </div> -->
      <span class="campus-route"></span>
    </div>
    <div class="game">
      <div class="title">
        <span class="">{{ $t("y.gamejob.game.title[0]") }}</span>
        <span class="">{{ $t("y.gamejob.game.title[1]") }}</span>
      </div>
      <br />
      <ul class="gameList">
        <li
          v-for="item in $t('y.gamejob.game.gameList')"
          :key="item.id"
          @click="clickGame(item.id - 1)"
          @mouseover="hoverGame(item.id - 1)"
          @mouseleave="leaveGame()"
          :class="{ active: item.id - 1 == gameIndex }"
        >
          <img :src="item.icon" alt="" class="gameIcon" />
          <span class="name">{{ item.name }}</span>
          <br />
          <span class="desc desc1" v-html="item.desc1"></span><br />
          <!-- <span class="desc desc2">{{ item.desc2 }}</span> -->
        </li>
      </ul>
      <div class="lineBall">
        <span
          class="ball"
          :style="{
            left: gameBall + 'rem',
            opacity: gameIndex == null ? 0 : 1
          }"
        ></span>
      </div>
    </div>
    <div class="job">
      <span class="title">{{ $t("y.gamejob.job.title") }}</span>
      <ul class="jobList">
        <li
          v-for="(item, key, index) in filterCondition"
          :key="key"
          @click="chosePosition(key)"
        >
          <el-card shadow="always">
            <span class="name">{{ item }}</span>
            <span class="jobIcon" :class="'jIcon' + (index + 1)"></span>
            <a href="#" class="look"
              >{{ $t("y.gamejob.job.look") }}<i class="el-icon-arrow-right"></i
            ></a>
          </el-card>
        </li>
      </ul>
      <template v-if="campus">
        <router-link :to="{ name: 'CallPost'}"
          ><span class="more"
            >{{ $t("y.gamejob.job.more") }}
          </span></router-link
        >
      </template>
      <template v-else>
        <router-link :to="{ name: 'HallPost' }"
          ><span class="more"
            >{{ $t("y.gamejob.job.more") }}
          </span></router-link
        >
      </template>
    </div>
  </div>
</template>
<script>
export default {
  name: "GameJob",
  props: {
    campus: {
      type: Boolean,
      require: true
    }
  },
  data() {
    return {
      // 当前选择游戏号
      gameIndex: null,
      // 记录
      lastGame: null,
      key: "0391591aafc5db68b08787645b837b4f",
      filterCondition: {}
    };
  },
  computed: {
    gameBall() {
      return 3.84 + this.gameIndex * 2.2;
    }
  },
  methods: {
    clickGame(id) {
      //  id 0-4
      if (this.$i18n.t("x.games.website[" + id + "][0]") == "#") {
        return;
      }
      let url = this.$i18n.t("x.games.website[" + id + "][1]");
      window.open(url, "_blank");
    },
    hoverGame(id) {
      // this.lastGame = this.gameIndex;
      this.gameIndex = id;
    },
    leaveGame() {
      // this.gameIndex = this.lastGame;
      this.gameIndex = null;
    },
    chosePosition(id) {
      let path;
      if (this.campus) {
        path = "/campus/allPost";
      } else {
        path = "/hr/allPost";
      }
      this.$router.push({
        path: path,
        query: { id: id }
      });
    },
    // 获取z只能分类分类
    getType() {
      this.$axios({
        method: "get",
        url: "https://hw.xianyuyouxi.com/service/tomato_webhome/get_post_type",
        headers: {
          "Access-s": this.$md5(
            `${this.key}${parseInt(Date.parse(new Date()) / 1000)}`
          )
        },
        params: {
          lang: "1",
          time: parseInt(Date.parse(new Date()) / 1000)
        }
      }).then(res => {
        let arr = res.data.data;
        // console.log(arr);
        let keyarr = Object.keys(arr);
        keyarr.length = 6;
        keyarr.map(key => {
          this.$set(this.filterCondition, key, arr[key]);
        });
      });
    }
  },
  mounted() {
    this.getType();
  }
};
</script>
<style scoped>
.gameJob {
  width: 100%;
  /* height: 5rem; */
}
.game {
  position: relative;
  margin: 0.15rem 0 0 0;
}
.game .title {
  margin: 0.3rem 0 0 0;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.en .game .title {
  width: 4.15rem;
  font-size: 0.11rem;
  font-family: Arial;
  font-weight: 400;
  color: #333333;
  line-height: 0.21rem;
}
.campus {
  margin: 0.4rem 0 0 0;
}
.campus .campus-route {
  width: 4.9rem;
  height: 0.905rem;
  background-image: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/route.png");
  background-size: 100%;
}
/* .campus .item {
  width: 1rem;
  vertical-align: top;
  position: relative;
  display: inline-block;
  margin: 0 0.25rem;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.13rem;
}
.campus .item span {
  width: 1rem;
  margin: 0.1rem 0 0 0;
}
.campus .item div {
  height: 0.6rem;
}
.campus .next {
  position: absolute;
  top: 0.3rem;
  right: -0.3rem;
} */

.gameList {
  display: flex;
  justify-content: center;
  margin: 0.3rem auto 0;
}
.gameList li {
  width: 0.8rem;
  height: 1.5rem;
  cursor: pointer;
  margin: 0 0.7rem;
}
.gameIcon {
  width: 0.62rem;
  height: 0.62rem;
  /* border-radius: 0.15rem; */
  transform: scale(1);
  transition: all 0.3s;
}

.gameList .name {
  position: relative;
  margin: 0.25rem 0 0 0;
  font-size: 0.1rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  transition: all 0.3s;
  cursor: pointer;
}
.gameList li:hover .name,
.gameList li.active .name {
  color: #18278a;
}
.gameList li .name:hover {
  transform: scale(1.03);
  box-shadow: 0rem 0.03rem 0.02rem 0rem rgba(23, 23, 23, 0.17);
}
.game .lineBall {
  width: 100%;
  height: 0.00001rem;
  position: absolute;
  bottom: 0.72rem;
  left: 0;
  border-top: 0.01rem solid #eaeaea;
}
.en .game .lineBall {
  top: 1.8rem;
}
.game .ball {
  width: 0.06rem;
  height: 0.06rem;
  position: absolute;
  top: -0.03rem;
  left: 3.87rem;
  border-radius: 100%;
  background: #18278a;
  transition: all 0.3s;
}
.gameList li:hover .ball {
  opacity: 1 !important;
}
.gameList .desc {
  width: 100%;
  font-size: 0.08rem;
  font-family: Adobe Heiti Std;
  font-weight: normal;
  color: #b9b9b9;
  opacity: 0;
  transition: all 0.3s;
}
.gameList li:hover .desc,
.gameList li.active .desc {
  opacity: 1;
}
.desc1 {
  margin: 0.07rem 0 0 0;
}
.desc2 {
  margin: 0.02rem 0 0 0;
}
.job {
  margin: 0.36rem 0 0 0;
}
.job .title {
  font-size: 0.3rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.jobList {
  width: 85%;
  margin: 0.36rem auto 0;
  display: flex;
  justify-content: flex-start;
  flex-wrap: wrap;
  text-align: left;
}
.jobList li {
  width: 2.67rem;
  height: 0.92rem;
  margin: 0 0 0.16rem 0.12rem;
  transform: scale(1);
  transition: all 0.5s;
  cursor: pointer;
}
.jobList li:hover {
  transform: scale(1.03);
}
.jobList >>> .el-card {
  width: 100%;
  height: 100%;
}
.jobList >>> .el-card__body {
  width: 100%;
  height: 100%;
  border-radius: 0.05rem;
  padding: 0;
}
.jobList .name {
  margin: 0.2rem 0 0 0.2rem;
  font-size: 0.13rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  transition: all 0.3s;
}
.jobList li:hover .name {
  color: #18278a;
}
.jobList .jobIcon {
  display: block;
  float: right;
  transition: all 0.3s;
}
.jobList .jIcon2 {
  width: 0.18rem;
  height: 0.22rem;
  margin: 0.22rem 0.21rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill00.png");
  background-size: 100%;
}
.jobList li:hover .jIcon2 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill10.png");
  background-size: 100%;
}
.jobList .jIcon5 {
  width: 0.23rem;
  height: 0.23rem;
  margin: 0.23rem 0.21rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill01.png");
  background-size: 100%;
}
.jobList li:hover .jIcon5 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill11.png");
  background-size: 100%;
}
.jobList .jIcon3 {
  width: 0.22rem;
  height: 0.22rem;
  margin: 0.22rem 0.2rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill02.png");
  background-size: 100%;
}
.jobList li:hover .jIcon3 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill12.png");
  background-size: 100%;
}
.jobList .jIcon4 {
  width: 0.2rem;
  height: 0.21rem;
  margin: 0.22rem 0.19rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill03.png");
  background-size: 100%;
}
.jobList li:hover .jIcon4 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill13.png");
  background-size: 100%;
}
.jobList .jIcon1 {
  width: 0.29rem;
  height: 0.21rem;
  margin: 0.22rem 0.16rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill04.png");
  background-size: 100%;
}
.jobList li:hover .jIcon1 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill14.png");
  background-size: 100%;
}
.jobList .jIcon6 {
  width: 0.21rem;
  height: 0.21rem;
  margin: 0.22rem 0.2rem 0 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill05.png");
  background-size: 100%;
}
.jobList li:hover .jIcon6 {
  background: url("https://wcdn.tomatogames.com/web/haiwai/gaojing/img/skill15.png");
  background-size: 100%;
}
.jobList .look {
  display: block;
  margin: 0.26rem 0 0 0.19rem;
  font-size: 0.09rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #18278a;
}
.more {
  width: 1.49rem;
  height: 0.37rem;
  margin: 0.38rem 0 0.63rem 0;
  line-height: 0.37rem;
  font-size: 0.15rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
  background: #18278a;
  border-radius: 0.2rem;
}
.en .more {
  width: 1.71rem;
  height: 0.37rem;
  margin: 0.38rem 0 0.63rem 0;
  line-height: 0.37rem;
  font-size: 0.15rem;
  font-family: Arial;
  font-weight: 400;
  color: #ffffff;
  background: #18278a;
  border-radius: 0.2rem;
}
.more:hover {
  background-color: #18278a;
}
</style>
