<!--
 * @Author: your name
 * @Date: 2021-03-25 11:49:01
 * @LastEditTime: 2021-05-25 18:40:15
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\QRCode.vue
-->
<template>
  <div class="qrcode">
    <el-popover placement="top-start" trigger="click" popper-class="mwechat ">
      <img src="https://wcdn.tomatogames.com/web/haiwai/gaojing/img/wx_code.jpeg" alt="" />
      <span>{{ $t("x.footer.icon[0]") }}</span>
      <el-button slot="reference" class=""
        ><span class="mwechatIcon" href="#"></span
      ></el-button>
    </el-popover>
    <el-popover placement="top-start" trigger="click" popper-class="mweibo ">
      <img src="https://wcdn.tomatogames.com/web/haiwai/gaojing/img/wb_code.png" alt="" />
      <span>{{ $t("x.footer.icon[1]") }}</span>
      <el-button slot="reference"
        ><span href="#" class="mweiboIcon"></span
      ></el-button>
    </el-popover>
    <el-popover placement="top-start" trigger="click" popper-class="mqq ">
      <img src="https://wcdn.tomatogames.com/web/haiwai/gaojing/img/qq_code.png" alt="" />
      <template v-if="type">
        <span>{{ $t("x.footer.icon[3]") }}</span>
      </template>
      <template v-else>
        <span>{{ $t("x.footer.icon[2]") }}</span>
      </template>
      <el-button slot="reference"
        ><span href="#" class="mqqIcon"></span
      ></el-button>
    </el-popover>
  </div>
</template>
<script>
export default {
  name: "QRCode",
  props: {
    type: Boolean,
    default: false
  }
};
</script>
<style scoped>
.qrcode {
  display: inline-block;
}
.mwechat img {
  width: 1.97rem !important;
  height: 1.96rem !important;
}
.mweibo img {
  width: 2.5rem !important;
  height: 2.5rem !important;
}
.mqq img {
  width: 2.2rem !important;
  height: 2.2rem !important;
}
.mwechatIcon {
  width: 0.57rem;
  height: 0.54rem;
  display: block;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/wechat.png");
  background-size: 100%;
}

.mweiboIcon {
  width: 0.59rem;
  height: 0.55rem;
  display: block;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/weibo.png");
  background-size: 100%;
}

.mqqIcon {
  width: 0.46rem;
  height: 0.46rem;
  display: block;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/qq.png");
  background-size: 100%;
}
.el-button {
  padding: 0;
  margin: 0 0 0 0.5rem;
  background: transparent;
  border: none;
}
</style>
<style>
.el-popover.mwechat,
.el-popover.mweibo,
.el-popover.mqq {
  /* width: 3rem; */
  min-width: 0.1rem !important;
  text-align: center;
  box-sizing: border-box;
  padding: 0.3rem;
}
.el-popover.mwechat {
  left: 1.5rem !important;
}
.el-popover.mwechat .popper__arrow {
  left: 1.5rem !important;
}
.el-popover.mweibo {
  left: 2.6rem !important;
}
.el-popover.mweibo .popper__arrow {
  left: 1.5rem !important;
}
.el-popover.mqq {
  left: 3.65rem !important;
}
.el-popover.mqq .popper__arrow {
  left: 1.5rem !important;
}
.el-popover img {
  display: block;
  margin: 0 auto;
}
.el-popover.mwechat span,
.el-popover.mweibo span,
.el-popover.mqq span {
  margin: 0.4rem 0 0 0;
  font-size: 0.4rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.06rem;
}
</style>
