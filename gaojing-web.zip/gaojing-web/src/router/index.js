/*
 * @Author: your name
 * @Date: 2021-02-23 10:57:53
 * @LastEditTime: 2021-06-08 12:22:20
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\router\index.js
 */
import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

// router文件夹下等index.js文件中写入
//解决编程式路由往同一地址跳转时会报错的情况
const originalPush = VueRouter.prototype.push;
const originalReplace = VueRouter.prototype.replace;
//push
VueRouter.prototype.push = function push(location, onResolve, onReject) {
  if (onResolve || onReject)
    return originalPush.call(this, location, onResolve, onReject);
  return originalPush.call(this, location).catch(err => err);
};
//replace
VueRouter.prototype.replace = function push(location, onResolve, onReject) {
  if (onResolve || onReject)
    return originalReplace.call(this, location, onResolve, onReject);
  return originalReplace.call(this, location).catch(err => err);
};

const routes = [
  {
    path: "/",
    name: "Home",
    component: () => import("../views/Home.vue")
  },
  {
    path: "/m",
    name: "MHome",
    component: () => import("../views/m-Home.vue")
  },

  {
    path: "/newsPage",
    name: "NewsPage",
    component: () => import("../views/NewsPage.vue")
  },
  {
    path: "/m/newsPage",
    name: "MNewsPage",
    component: () => import("../views/m-NewsPage.vue")
  },

  {
    path: "/games",
    name: "Games",
    component: () => import("../views/Games.vue")
  },
  {
    path: "/m/games",
    name: "MGames",
    component: () => import("../views/m-Games.vue")
  },
  {
    path: "/singleNews",
    name: "SingleNews",
    component: () => import("../views/SingleNews.vue")
  },
  {
    path: "/m/singleNews",
    name: "MSingleNews",
    component: () => import("../views/m-SingleNews.vue")
  },
  {
    path: "/hr",
    name: "Hr",
    component: () => import("../views/jobs/Employ.vue")
  },
  {
    path: "/campus",
    name: "Campus",
    component: () => import("../views/jobs/Employ.vue")
  },
  {
    path: "/m/hr",
    name: "MHr",
    component: () => import("../views/jobs/m-Employ.vue")
  },
  {
    path: "/m/campus",
    name: "MCampus",
    component: () => import("../views/jobs/m-Employ.vue")
  },

  {
    path: "/hr/allPost",
    name: "HallPost",
    component: () => import("../views/jobs/AllPost.vue"),
    
  },
  {
    path: "/campus/allPost",
    name: "CallPost",
    component: () => import("../views/jobs/AllPost.vue"),
    
  },
  {
    path: "/m/hr/allPost",
    name: "MHallPost",
    component: () => import("../views/jobs/m-AllPost.vue"),
    
  },
  {
    path: "/m/campus/allPost",
    name: "MCallPost",
    component: () => import("../views/jobs/m-AllPost.vue"),
    
  },
  {
    path: "/campus/detail",
    name: "Detail",
    component: () => import("../views/jobs/Detail.vue")
  },
  {
    path: "/hr/detail",
    name: "Detail",
    component: () => import("../views/jobs/Detail.vue")
  },
  {
    path: "/m/hr/detail",
    name: "MDetail",
    component: () => import("../views/jobs/m-Detail.vue")
  },
  {
    path: "/m/campus/detail",
    name: "MDetail",
    component: () => import("../views/jobs/m-Detail.vue")
  }
];
// 路由跳转后页面在最顶端
const router = new VueRouter({
  mode:"history",
  routes,
  scrollBehavior(to, from, saveTop) {
    if (saveTop) {
      return saveTop;
    } else {
      return { x: 0, y: 0 };
    }
  }
});

export default router;
