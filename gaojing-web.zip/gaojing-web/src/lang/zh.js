/*
 * @Author: your name
 * @Date: 2021-03-09 10:58:46
 * @LastEditTime: 2021-06-03 16:42:01
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\lang\cn.js
 */
export const x = {
  logo: "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/logo.png",
  clogo: "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/clogo.png",
  header: {
    currentLang: "简体中文",
    lang: ["简体中文", "English"],
    nav: ["关于我们", "产品中心", "新闻资讯", "联系我们", "加入我们"]
  },
  carousel: {
    desc: [
      [
        "我们的愿景",
        "连接全球年轻人，到2030年覆盖100个国家和地区，累计服务5亿用户。"
      ]
    ]
  },
  about: {
    white: {
      title: "关于我们",
      content: [
        `高竞文化传媒有限公司成立于2016年，是一家专业运营电子竞技赛事、电竞语音社交、电竞俱乐部以及电竞整合营销的新兴互联网企业。`,
        `公司主体业务为电子竞技赛事运营，旗下举办的世界大学生电子竞技联赛（WUCG）融合了电竞、音乐、二次元等元素，旨在打造“一场世界级的文娱盛会”。2018年公司旗下的高校电竞社交APP“不鸽电竞”正式发布，基于优质电竞赛事内容和赛事服务构建互动性极强的“电竞-语音-社交”生态。2020年公司旗下STE电子竞技俱乐部在深圳创立，旨在成为“具有全球影响力的行业领军者”。`
      ]
    },
    orange: {
      special: ["05", "研发工作室", "01", "独立编制工作室", "500", "现有员工"],
      aboutTitle: [
        "",
        "协作共赢",
        "正直务实",
        "追求卓越",
        "长期主义",
        "主人翁精神",
        "用户至上"
      ],
      aboutMsg: [
        [],
        [
          "公司全体成员均要有全局观，以公司整体利益为重。 ",
          "杜绝山头主义，杜绝拉帮结派，公司的人才、业务、管理体系均为公司资源，杜绝划分“地盘”的情形。",
          "在与外部合作伙伴合作时，也要秉承持协作共赢的精神，以追求长远可持续发展的良性合作。",
          "我们不单要有主动积极的协作精神，同时也要有专业科学的协同能力，才能达到最终的共赢目的。"
        ],
        [
          "在公司经营过程中，我们要将正直诚信作为基础。",
          "深入实际，以务实严谨的态度对待每一项工作。",
          " 当遇到问题时，不粉饰现状，直面现实，提出改善方案。",
          "当遇到挑战时，积极应对，勇于创新。"
        ],
        [
          "持续提高要求，勇于挑战，不放过任何一个问题，注重事物的关键本质，持续学习与成长。"
        ],
        [
          "用前瞻思维持续构建组织能力及员工能力，用发展的眼光看待我们的事业，不能为了获得一时的短期利益而牺牲长期利益。"
        ],
        [
          "热爱自己的工作，将工作当成自己的事业对待。",
          "工作要有热情及高度的责任感。",
          "开展工作要从全局思考并权衡最优实施方案。",
          "用长线思维思考并规划工作，要有前瞻性及开拓创新精神。"
        ],
        [
          "一切以用户的需求作为我们的行动纲领。",
          "以帮助用户提升核心价值为根本目的，时刻审视我们的核心竞争力是否可以帮助用户提升其核心价值。",
          "每一位同事均要有“用户至上”的理念。用户分为外部用户、内部用户，用户评价是检验工作价值的重要手段。"
        ]
      ]
    }
  },
  newsPart: {
    title: "新闻资讯",
    news: [
      {
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        start_time: "2020/08/01",
        title: `希望能给全世界的AVG游戏爱好者
          提供更多更精品的AVG手机游戏希望能给全世界的AVG游戏爱好者
          提供更多更精品的AVG手机游戏希望能给全世界的AVG游戏爱好者
          提供更多更精品的AVG手机游戏`,
        desc:
          "公司现有员工500多人，且在北上深、香港、台湾、新加坡、等地区建立多个分公司。公司现有员工500多人，且在北上深、香港、台湾、新加坡、等地区建立多个分公司。"
      }
    ]
  },
  contact: {
    title: "联系我们",
    note: [
      "在“高竞官方”网站上 对我们有任何疑问或评论",
      "请填写以下信息与我们的团队联系，我们会阅读收到的每封电子邮件。<br>对于紧急的问题和评论，您也可以联系"
    ],
    boxMsg: [
      ["商务合作", "changliu@", "chinaesport.com"],
      ["媒体合作", "jiayunhe@", "chinaesport.com"],
      ["市场合作", "adadong@", "chinaesport.com"],
      ["渠道合作", "bugequdao@chinaesport.com", ""]
    ]
  },
  footer: {
    title: ["关注我们", "招聘信息"],
    icon: ["微信", "微博", "QQ", "QQ群"],
    about: ["关于我们", "企业文化", "赛事相关"],
    news: ["新闻资讯", "新闻资讯"],
    contact: ["联系我们", "客户服务", "合作洽谈"],
    join: ["加入我们", "社会招聘", "校园招聘", "国际招聘"],
    attention: "关注我们"
  },
  games: {
    theme: "产品中心",
    gamesName: [
      "WUCG",
      "不鸽APP",
      "STE"
      // "武炼巅峰之武道",
      // `葫芦娃<br>各显神通`
    ],
    gamesList: [
      {
        id: 0,
        title: "WUCG",
        content: `世界大学生电子竞技联赛（World University Cyber Games ，简称WUCG） 创办于2016年，由电竞明星伍声2009和若风领衔担任形象大使，赛事秉承为 大学生实现电竞梦想的理念，坚持高校赛事精品化的原则，积极打造全球高校 电竞标杆赛事。<br>WUCG设立电子竞技赛事、电音派对、宅舞大赛、歌手比赛等项目，通过聚集 电竞+电音+二次元等年轻人喜欢的元素，打造多元文化集群，把WUCG建设 成为年轻人真正的跨次元嘉年华盛会，并在此基础上，与地方政府合作，打造 城市品牌电竞节。`
      },

      {
        id: 1,
        title: "不鸽",
        content: `不鸽APP是一个游戏语音平台，主打游戏语音，语音交友，生活分享，如果你对某个人感兴趣，你可以通过观察他或者她的生活来了解Ta，近距离聆听他们的生活，听他们分享自己的一切：内容包括才艺，心声，内心情感等。<br>不鸽APP通过WUCG赛事聚集了海量的高校电竞玩家和核心游戏爱好者，高校电竞玩家通过不鸽可以参与WUCG及校园社团赛事，实现技能社交；核心游戏玩家通过不鸽可以发现游戏伙伴，提升游戏实力，沉淀游戏社交关系，不鸽希望连接高校玩家、核心玩家、电竞赛事、职业战队，为大学生和核心游戏玩家提供一个全球年轻人的电竞文化交流平台。`
      },
      {
        id: 2,
        title: "STE",
        content: `SixTwoEight电竞俱乐部于2020年6月28日在深圳正式创立，扎根于这座青年人的热血之都。<br> 6月28日是STE成立的日子，8月26日是深圳经济特区成立日， 因此STE更代表“敢闯、敢干、创新”的深圳精神，凭借着实干兴邦这股精神和深圳速度立足深圳，奋斗中国，奔向全球。`
      }
      // {
      //   id: 3,
      //   title: "武炼巅峰之武道",
      //   content: `《武炼巅峰之武道》是一款东方魔幻题材的3DMMO战斗手游，获得畅销榜首同名小说IP正版授权，玩家在游戏中扮演一个偶入异世界的神秘之人，随着剧情的展开，开启一段奇妙的冒险之旅...`
      // },
      // {
      //   id: 4,
      //   title: "葫芦娃各显神通",
      //   content: `《葫芦娃各显神通》是一款国风手绘风格的休闲放置手游，由上海美术电影制片厂正版授权，极致还原动画片《葫芦兄弟》原作剧情及设定，同时融入符合东方美学特色的国风手绘风格，力求复刻8090年代的国民记忆，带给玩家们毫无杂质的童趣与纯粹快乐。`
      // }
    ],
    m_gamesList: [
      {
        id: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/gicon00.png",
        title: "WUCG",
        content: `世界大学生电子竞技联赛（ World University Cyber  Games，简称WUCG）创办于2016年，由电竞明星伍声2009和若风领衔担任形象大使，赛事秉承为大学生实现电竞梦想的理念，坚持高校赛事精品化的原则，积极打造全球高校电竞标杆赛事。
        `,
        pic: "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/gperson0.png"
      },

      {
        id: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/gicon01.png",
        title: "不鸽APP",
        content: `不鸽APP是一个游戏语音平台，主打游戏语音，语音交友，生活分享，如果你对某个人感兴趣，你可以通过观察他或者她的生活来了解Ta，近距离聆听他们的生活，听他们分享自己的一切：内容包括才艺，心声，内心情感等。
        不鸽APP通过WUCG赛事聚集了海量的高校电竞玩家和核心游戏爱好者，高校电竞玩家通过不鸽可以参与WUCG及校园社团赛事，实现技能社交；核心游戏玩家通过不鸽可以发现游戏伙伴，提升游戏实力，沉淀游戏社交关系，不鸽希望连接高校玩家、核心玩家、电竞赛事、职业战队，为大学生和核心游戏玩家提供一个全球年轻人的电竞文化交流平台。<br>不鸽APP通过WUCG赛事聚集了海量的高校电竞玩家和核心游戏爱好者，高校电竞玩家通过不鸽可以参与WUCG及校园社团赛事，实现技能社交；核心游戏玩家通过不鸽可以发现游戏伙伴，提升游戏实力，沉淀游戏社交关系，不鸽希望连接高校玩家、核心玩家、电竞赛事、职业战队，为大学生和核心游戏玩家提供一个全球年轻人的电竞文化交流平台。`,
        pic: "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/gperson1.png"
      },
      {
        id: 2,
        title: "STE",
        icon: "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/gicon02.png",
        content: `SixTwoEight电竞俱乐部于2020年6月28日在深圳正式创立，扎根于这座青年人的热血之都。<br>6月28日是STE成立的日子，8月26日是深圳经济特区成立日，因此STE更代表“敢闯、敢干、创新”的深圳精神，凭借着实干兴邦这股精神和深圳速度立足深圳，奋斗中国，奔向全球。`,
        pic: "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/gperson2.png"
      }
      // {
      //   id: 3,
      //   title: "武炼巅峰之武道",
      //   icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon3.png",
      //   content: `《武炼巅峰之武道》是一款东方魔幻题材的3DMMO战斗手游，获得畅销榜首同名小说IP正版授权，玩家在游戏中扮演一个偶入异世界的神秘之人，随着剧情的展开，开启一段奇妙的冒险之旅...`,
      //   pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_wl_p.png"
      // },
      // {
      //   id: 4,
      //   title: "葫芦娃各显神通",
      //   icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon4.png",
      //   content: `《葫芦娃各显神通》是一款国风手绘风格的休闲放置手游，由上海美术电影制片厂正版授权，极致还原动画片《葫芦兄弟》原作剧情及设定，同时融入符合东方美学特色的国风手绘风格，力求复刻8090年代的国民记忆，带给玩家们毫无杂质的童趣与纯粹快乐。`,
      //   pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_lh_p.png"
      // }
    ],
    more: "了解更多信息，请访问：",
    website: [
      ["http://chinaesport.com", "http://chinaesport.com"],
      ["http://www.bugegaming.com/", "http://www.bugegaming.com/"],
      ["#", "https://www.tomato.com/"],
      ["https://wldf.tomatogames.com/", "https://wldf.tomatogames.com/"],
      ["https://hlw.tomatogames.com", "https://hlw.tomatogames.com"]
    ]
  },
  newsPage: {
    seeMore: "查看更多",
    share: "分享",
    theme: "新闻",
    m_theme: "新闻资讯",
    tabsLabel: ["最新", "新闻", "通知", "活动"],
    icon: ["微信扫一扫分享"],
    newest: [
      {
        // type将新闻分为两类
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "111111希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏",
        desc: `深圳市爱的番茄科技有限公司成立于2020年，公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的...`,
        start_time: "2020/10/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "恋世界全新2.0版本，一款民国风乙女向恋爱游戏",
        desc: `恋世界全新2.0版本，一款民国风乙女向恋爱游戏。讲述了北平新时代少女逃婚进入名为“易梦阁”的药店，并展开了一场奇幻之旅的故事~知名声优助阵、多结局走向剧情、沉浸式互玩玩法...`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "一款女性向3D古风恋爱换装手游，游戏内展现了盛唐时期的繁华风貌",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/07/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "深圳市爱的番茄科技有限公司成立于2020年",
        desc: `公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏`,
        start_time: "2020/07/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "这是一个有打有笑的武侠世界",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/10/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      },
      {
        // type将新闻分为两类
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏",
        desc: `深圳市爱的番茄科技有限公司成立于2020年，公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的...`,
        start_time: "2020/10/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "恋世界全新2.0版本，一款民国风乙女向恋爱游戏",
        desc: `恋世界全新2.0版本，一款民国风乙女向恋爱游戏。讲述了北平新时代少女逃婚进入名为“易梦阁”的药店，并展开了一场奇幻之旅的故事~知名声优助阵、多结局走向剧情、沉浸式互玩玩法...`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "一款女性向3D古风恋爱换装手游，游戏内展现了盛唐时期的繁华风貌",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/07/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "深圳市爱的番茄科技有限公司成立于2020年",
        desc: `公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏`,
        start_time: "2020/07/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "这是一个有打有笑的武侠世界",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/10/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      }
    ],
    news: [
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "222222希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏",
        desc: `深圳市爱的番茄科技有限公司成立于2020年，公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的...`,
        start_time: "2020/10/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "恋世界全新2.0版本，一款民国风乙女向恋爱游戏",
        desc: `恋世界全新2.0版本，一款民国风乙女向恋爱游戏。讲述了北平新时代少女逃婚进入名为“易梦阁”的药店，并展开了一场奇幻之旅的故事~知名声优助阵、多结局走向剧情、沉浸式互玩玩法...`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "一款女性向3D古风恋爱换装手游，游戏内展现了盛唐时期的繁华风貌",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/07/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "深圳市爱的番茄科技有限公司成立于2020年",
        desc: `公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏`,
        start_time: "2020/07/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "这是一个有打有笑的武侠世界",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/10/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      }
    ],
    notice: [
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "33333希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏",
        desc: `深圳市爱的番茄科技有限公司成立于2020年，公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的...`,
        start_time: "2020/10/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "恋世界全新2.0版本，一款民国风乙女向恋爱游戏",
        desc: `恋世界全新2.0版本，一款民国风乙女向恋爱游戏。讲述了北平新时代少女逃婚进入名为“易梦阁”的药店，并展开了一场奇幻之旅的故事~知名声优助阵、多结局走向剧情、沉浸式互玩玩法...`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "一款女性向3D古风恋爱换装手游，游戏内展现了盛唐时期的繁华风貌",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/07/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "深圳市爱的番茄科技有限公司成立于2020年",
        desc: `公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏`,
        start_time: "2020/07/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "这是一个有打有笑的武侠世界",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/10/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      }
    ],
    activity: [
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "44444希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏",
        desc: `深圳市爱的番茄科技有限公司成立于2020年，公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的...`,
        start_time: "2020/10/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "恋世界全新2.0版本，一款民国风乙女向恋爱游戏",
        desc: `恋世界全新2.0版本，一款民国风乙女向恋爱游戏。讲述了北平新时代少女逃婚进入名为“易梦阁”的药店，并展开了一场奇幻之旅的故事~知名声优助阵、多结局走向剧情、沉浸式互玩玩法...`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "一款女性向3D古风恋爱换装手游，游戏内展现了盛唐时期的繁华风貌",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/07/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "深圳市爱的番茄科技有限公司成立于2020年",
        desc: `公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏`,
        start_time: "2020/07/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "这是一个有打有笑的武侠世界",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/10/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      }
    ]
  },
  maskBox: {
    name: ["姓名", "请输入姓名"],
    email: ["邮箱", "请输入邮箱号"],
    subject: ["主题", "请输入主题"],
    content: ["内容", "请输入内容"],
    send: ["发送"]
  },
  singleNews: {
    return: "返回",
    more: "更多文章"
  }
};
export const y = {
  header: {
    tag: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/employ.png",
    ctag:
      "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/employ-details.png",
    nav: ["主页", "职位", "赛事相关", "校园招聘", "社会招聘"]
  },
  overlay: {
    title: "让我们改变世界",
    placeholder: "搜索工作岗位",
    search: "搜索"
  },
  gamejob: {
    campus: [
      {
        id: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step1.png",
        content: "网申"
      },
      {
        id: 2,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step2.png",
        content: "线上笔试"
      },
      {
        id: 3,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step3.png",
        content: "面试"
      },
      {
        id: 4,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step4.png",
        content: "发放offer"
      }
    ],
    m_campus: [
      {
        id: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step1.png",
        content: "网申"
      },
      {
        id: 2,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step2.png",
        content: "线上笔试"
      },

      {
        id: 3,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step4.png",
        content: "发放offer"
      },
      {
        id: 4,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step3.png",
        content: "面试"
      }
    ],

    game: {
      title: [
        "在专注运营电子竞技赛事、电竞语音社交、电竞整合营销的路上，",
        "高竞开创了一个属于年轻人的电竞多元化潮玩新时代"
      ],
      gameList: [
        {
          id: 1,
          icon:
            "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/gicon00.png",
          name: "WUCG",
          desc1: "全球认可度TOP1<br>的高校第三方电竞赛事",
          desc2: ""
        },
        {
          id: 2,
          icon:
            "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/gicon01.png",
          name: "不鸽APP",
          desc1:
            "Z世代人群的<br>兴趣社交语聊平台",
          desc2: ""
        }
        // {
        //   id: 3,
        //   icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon2.png",
        //   name: "花开易梦阁",
        //   desc1: "主线剧情丰富<br>打造专属于<br>你的定制形象<br>让你沉浸式体验<br>恋爱剧情",
        //   desc2: ""
        // },
        // {
        //   id: 4,
        //   icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon3.png",
        //   name: "武炼巅峰之武道",
        //   desc1: "东方魔幻题材<br>3DMMO战斗手游<br>畅销榜首同名小说<br>IP正版授权",
        //   desc2: ""
        // },
        // {
        //   id: 5,
        //   icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon4.png",
        //   name: "葫芦娃各显神通",
        //   desc1: "国风手绘风格<br>休闲放置手游<br>上海美术电影制片厂<br>正版授权",
        //   desc2: ""
        // }
      ],
      m_gameList: [
        {
          id: 1,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon0.png",
          name: "踏马江湖",
          desc1: "国风与水墨漫画风融合精品江湖AVG养成手游",
          desc2: ""
        },
        {
          id: 2,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon1.png",
          name: "盛唐烟雨",
          desc1: "一款展现了盛唐时期繁华风貌的女性向3D古风恋爱换装手游",
          desc2: ""
        },
        {
          id: 3,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon2.png",
          name: "花开易梦阁",
          desc1: "主线剧情丰富，打造专属于你的定制形象，让你沉浸式体验恋爱剧情",
          desc2: ""
        },
        {
          id: 4,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon3.png",
          name: "武炼巅峰之武道",
          desc1: "东方魔幻题材3DMMO战斗手游，畅销榜首同名小说IP正版授权",
          desc2: ""
        },
        {
          id: 5,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon4.png",
          name: "葫芦娃各显神通",
          desc1: "国风手绘风格休闲放置手游，上海美术电影制片厂正版授权",
          desc2: ""
        }
      ]
    },
    job: {
      title: "探寻你的工作",
      jobList: [
        {
          id: 1,
          name: "技术研发"
        },
        {
          id: 2,
          name: "美术表现"
        },
        {
          id: 3,
          name: "游戏运营"
        },
        {
          id: 4,
          name: "游戏策划"
        },
        {
          id: 5,
          name: "市场商务"
        },
        {
          id: 6,
          name: "综合职能"
        }
      ],
      look: "查看岗位",
      more: "更多岗位"
    }
  },
  culture: {
    pageList: [
      {
        id: 1,
        title: "开放文化",
        content1:
          "使你朝气蓬勃，可唐装、可汉服、可cosplay；撸猫、撸狗，你喜欢的，这里都可以有。",
        content2: ""
      },
      {
        id: 2,
        title: "丰富的社团活动",
        content1:
          "各类社团活动，让你丰富多彩:篮球社、足球社、羽毛球社、游泳社、健身社、电竞社、桌游社。",
        content2: "你热爱的，这里也都有。"
      },
      {
        id: 3,
        title: "办公环境",
        content1:
          "轻松舒适的办公氛围，打造自主创新，积极投身国际化的平台。助你不惧疲惫、守护梦想。",
        content2: ""
      }
    ]
  },
  welfare: {
    left: {
      title: "企业福利",
      content: [
        ["高于行业市场标准的薪资", "每年两次职级评审及调薪机会"],
        [
          "执行“按贡献分配”的原则，",
          "用绩效说话：【项目奖】【绩效奖】",
          "【评优奖】【年度服务奖】【专项奖】"
        ],
        ["坚持以“公平竞争”“动态激励”", "做为薪酬管理的基本原则"]
      ]
    },
    right: {
      welfares: [
        {
          id: 1,
          title: "关于健康",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon1.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare01.png",
          specific: "补充医疗/意外保险/年度体检"
        },
        {
          id: 2,
          title: "工作时间",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon2.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/welfare02.jpg",
          specific: "弹性上班/周末双休"
        },
        {
          id: 3,
          title: "吃喝玩乐",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon3.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/welfare03.jpeg",
          specific:
            "不定期团建/年度旅游/节假日礼物及创意活动/餐补/零食下午茶/撸猫撸狗/社团活动/办公室健身/崇尚生活工作两平衡"
        },
        {
          id: 4,
          title: "员工关怀",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon4.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare04.png",
          specific: "生日惊喜/红白事慰问"
        },
        {
          id: 5,
          title: "通勤便利",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon5.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare05.png",
          specific: "便利的办公位置/企业滴滴"
        },
        {
          id: 6,
          title: "安居才能乐业",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon6.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare06.png",
          specific: "核心人才50W无息贷款"
        },
        {
          id: 7,
          title: "关于假期",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon7.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/welfare07.JPG",
          specific: "入职可预支年假/每月1天全薪病假"
        },
        {
          id: 8,
          title: "人才补贴",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon8.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/welfare08.jpeg",
          specific: "及时为员工申请 各类政府补助"
        },
        {
          id: 9,
          title: "与大咖一起",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon9.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/gaojing/img/welfare09.png",
          specific: "电竞大咖（伍声/若风）不想见见吗"
        }
      ]
    }
  },
  allPost: {
    left: {
      title: "筛选条件",
      clear: "清除",
      path: ["自研线", "发行线"],
      address: {
        title: "工作地点",
        list: ["不限", "深圳", "北京", "上海"]
      },
      type: {
        title: "岗位类别",
        list: [
          "技术研发",
          "美术表现",
          "游戏运营",
          "游戏策划",
          "市场商务",
          "综合职能"
        ]
      },
      nature: {
        title: "工作性质",
        list: ["不限", "全职", "实习"]
      }
    },
    right: {
      title: ["共发现", "个岗位"],
      new: "最新发布岗位"
    }
  },
  applyBox: {
    name: ["姓名", "请输入姓名"],
    sex: ["性别", "男", "女"],
    phone: ["电话", "请输入手机号"],
    code: ["验证码", "请输入短信验证码", "获取短信验证码"],
    email: ["邮箱", "请输入邮箱号"],
    resume: ["上传简历", "浏览", "支持doc、pdf、zip文件，大小10M以内的附件"],
    sendApply: "提交申请"
  },
  detail: {
    postDesc: "岗位描述",
    postRequest: "岗位要求",
    applyPost: "申请岗位",
    newPost: "最新岗位",
    share: ["分享到", "微信/QQ", "QQ"]
  }
};
