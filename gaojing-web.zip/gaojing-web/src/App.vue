<!--
 * @Author: your name
 * @Date: 2021-02-23 10:57:53
 * @LastEditTime: 2021-06-08 14:41:51
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\App.vue
-->
<template>
  <div
    id="app"
    :class="{ en: isEn }"
    :style="[{ minWidth: !isDeviceMobile() ? '1200px' : 0 }]"
  >
    <router-view />
  </div>
</template>
<script>
export default {
  name: "About",
  data() {
    return {
      isEn: null,
      isAndroid: null,
      isiOS: null
    };
  },
  methods: {
    isDeviceMobile() {
      var u = navigator.userAgent;
      var isAndroid = u.indexOf("Android") > -1 || u.indexOf("Adr") > -1; //android终端
      var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
      if (isiOS || isAndroid) {
        return true;
      } else {
        return false;
      }
    }
  },
  mounted() {
    var u = navigator.userAgent;
    // 判断是android还是IOS
    this.isAndroid = u.indexOf("Android") > -1 || u.indexOf("Adr") > -1;
    this.isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);

    // if (isAndroid || isiOS) {
    //   //手机端
    //   this.$router.push("/m");
    //   localStorage.setItem("isPC", false);
    // } else {
    //   //PC端
    //   localStorage.setItem("isPC", true);
    //   this.$router.push("/");
    // }

    // 判断是否有语言曾选项
    this.isEn = JSON.parse(localStorage.getItem("isEn"));
    if (this.isEn == null) {
      localStorage.setItem("isEn", JSON.stringify(false));
    } else if (this.isEn == false) {
      this.$i18n.locale = "zh-CN";
    } else {
      this.$i18n.locale = "en-US";
    }
  },
  watch: {
    $route(to, from) {
      console.log("to  " + to.path);

      console.log("from  " + from.path);
      if (
        (to.path == "/hr/allPost" && from.path != "/hr/detail") ||
        (to.path == "/campus/allPost" && from.path != "/campus/detail") ||
        (to.path == "/m/hr/allPost" && from.path != "/m/hr/detail") ||
        (to.path == "/m/campus/allPost" && from.path != "/m/campus/detail") 
      ) {
        localStorage.removeItem("saveCondition");
      }
      if (this.isAndroid || this.isiOS) {
        //手机端
        if (this.$route.path.indexOf("/m") == -1) {
          this.$router.push({
            path: "/m" + this.$route.path,
            query: this.$route.query
          });
        }
        // else {
        //   this.$router.push({
        //     path: this.$route.path,
        //     query: this.$route.query
        //   });
        // }

        localStorage.setItem("isPC", false);
      } else {
        //PC端
        if (this.$route.path.indexOf("/m") != -1) {
          location.href = location.href.split("/m")[1];
        }
        localStorage.setItem("isPC", true);
        // this.$router.push({ path: this.$route.path, query: this.$route.query });
      }
    }
  }
};
</script>

<style>
/* @media (max-width: 1250px) {
  html {
    font-size: 125px !important;
  }
  body {
    max-width: 1250px;
  }
} */
* {
  margin: 0;
  padding: 0;
  /* font-size: 0.1rem; */
  box-sizing: border-box;
}
*,
*:hover,
*:active,
::before,
::after {
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}

h1,
h2,
h3,
h4,
h5,
h6,
p,
span {
  /* font-size: 0.1rem; */
}
a,
span {
  display: inline-block;
}
ul {
  list-style: none;
  padding: 0;
}
li {
  margin: 0 10px;
}
a {
  color: #000;
  text-decoration: none;
}
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none !important;
}
input[type="number"] {
  -moz-appearance: textfield;
}

#app {
  font-family: Microsoft YaHei;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  /* width: 100vw; */
  overflow-x: hidden;
  position: relative;
}

.red {
  color: red;
}
[v-cloak] {
  display: none;
}
/* 清除浮动 */
.clearfix:after {
  content: "";
  display: block;
  height: 0;
  clear: both;
  visibility: hidden;
}

.clearfix {
  /* 触发 hasLayout */
  zoom: 1;
}
.fl {
  float: left;
}
</style>
