/*
 * @Author: your name
 * @Date: 2020-12-21 11:03:33
 * @LastEditTime: 2021-05-14 19:55:58
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \fe-h5sdke:\code\web\Inland\WUCG\invite\src\assets\js\rem.js
 */


!(function (e, t) {
  console.log("rem");
  function isDeviceMobile() {
    var u = navigator.userAgent
    var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1 //android终端
    var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) //ios终端
    if (isiOS || isAndroid) {
      return true
    } else {
      return false
    }
  }

  function n() {
    t.body ?
      (t.body.style.fontSize = 12 * o + "px") :
      t.addEventListener("DOMContentLoaded", n);
  }

  function d() {
    var e = (isDeviceMobile() ? i.clientWidth : i.clientWidth <= 1200 ? 1200 : i.clientWidth) / 10;
    i.style.fontSize = e + "px";
  }
  var i = t.documentElement,
    o = e.devicePixelRatio || 1;
  if (
    (n(),
      d(),
      e.addEventListener("resize", d),
      e.addEventListener("pageshow", function (e) {
        e.persisted && d();
      }),
      o >= 2)
  ) {
    var a = t.createElement("body"),
      s = t.createElement("div");
    (s.style.border = ".5px solid transparent"),
    a.appendChild(s),
      i.appendChild(a),
      1 === s.offsetHeight && i.classList.add("hairlines"),
      i.removeChild(a);
  }
})(window, document);