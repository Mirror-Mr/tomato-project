import axios from "axios";
import qs from "qs";
import handleHeaders from "@/utils/handleHeaders";

const url = "https://api.xianyuyouxi.com/service/common/sendcode/sendCode";

// 发送验证码，只需传入手机号码
export default function (phone) {
  const time = Date.now();
  const to_user = phone;
  const project_id = "24";
  const type = "1";
  const flag = "0";
  let params = { time, project_id, to_user, type, flag };
  let headers = { time, project_id, to_user, type };
  params = qs.stringify(params);
  headers = handleHeaders(headers);
  return new Promise((resolve, reject) => {
    axios.post(url, params, { headers }).then(
      (res) => {
        resolve(res.data);
      },
      (err) => {
        reject(err);
      }
    );
  });
}
