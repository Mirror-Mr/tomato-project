<template>
  <div class="index" ref="index">
    <!-- 切换导航 -->
    <div class="changeNav" @click="changeNav">
      <div class="game" :class="{ choose: index == 1 }"></div>
      <div class="store" :class="{ choose: index == 2 }"></div>
    </div>
    <!-- 弹出框 -->
    <van-popup
      v-model="isMaskShow"
      @closed="closedMaskPop"
      @close="closeMaskPop"
      @open="openMaskPop"
      class="popup1"
      :lock-scroll="false"
    >
      <RuleMask v-show="maskContent == 'rule'" />
      <GiftShow v-show="maskContent == 'showGift'" />
      <SevenDay
        v-show="maskContent == 'sevenDay'"
        @setPrevMask="setPrevMask"
        @getUserInfo="getUserInfo"
        @subPrize="subPrize"
      />
      <ProbableShow v-show="maskContent == 'showProbable'" />
      <MainlandLogin
        v-show="maskContent == 'mainland'"
        @confirmPlatform="confirmPlatform"
        @getUserInfo="getUserInfo"
      />
      <HktwLogin
        v-show="maskContent == 'hktwLogin'"
        @getUserInfo="getUserInfo"
        @confirmPlatform="confirmPlatform"
      />
      <ExchangeProp
        v-show="maskContent == 'exchangeProp'"
        :propMsg="propMsg"
        @getUserInfo="getUserInfo"
        @setPrevMask="setPrevMask"
        :propShow="propShow"
        @changePropShow="changePropShow"
        :propNum="propNum"
        @setPropNum="setPropNum"
        @subPrize="subPrize"
      />
      <ChangeRole v-show="maskContent == 'changeRole'" />
      <ConfirmGetEgg
        v-show="maskContent == 'confirmGetEgg'"
        :isFirstDraw="isFirstDraw"
        @lottery_draw="lottery_draw"
      />
      <GetEggSuccess
        v-show="maskContent == 'getEggSuccess'"
        :addStar="addStar"
      />
      <GetEggFail v-show="maskContent == 'getEggFail'" />
      <GeneralGetEgg
        v-show="maskContent == 'generalGetEgg'"
        @lottery_draw="lottery_draw"
        @getUserInfo="getUserInfo"
      />
      <ProtectGetEgg
        v-show="maskContent == 'protectGetEgg'"
        @lottery_draw="lottery_draw"
        @getUserInfo="getUserInfo"
      />
      <ProtectDefeat v-show="maskContent == 'protectDefeat'" />
      <ConfirmGetAccum
        v-show="maskContent == 'confirmGetAccum'"
        :accumPrizeMsg="accumPrizeMsg"
        @subPrize="subPrize"
      />
      <GetAccumSuccess
        v-show="maskContent == 'getAccumSuccess'"
        :isGetEggPrize="isGetEggPrize"
      />
      <ConfirmGetEggPrize
        v-show="maskContent == 'confirmGetEggPrize'"
        @subPrize="subPrize"
      />
      <EggFailGetPrize
        v-show="maskContent == 'eggFailGetPrize'"
        :defeatStar="defeatStar"
      />
    </van-popup>
    <img class="flower" :src="`${baseUrl}flower.png`" alt="" />
    <div class="activity_title"></div>
    <div
      class="btn_showGift"
      @click="
        SET_ISMASKSHOW(true);
        SET_MASKCONTENT('showGift');
      "
    ></div>
    <div class="btnBox_rule_service btnBox">
      <div
        class="btn_rule innerCenter"
        @click="
          SET_ISMASKSHOW(true);
          SET_MASKCONTENT('rule');
        "
      >
        <span>查看<br />规则</span>
      </div>
      <div class="btn_service innerCenter" @click="toLink()">
        <span>联系<br />客服</span>
      </div>
    </div>
    <div class="btnBox_accumPrize_login btnBox">
      <div class="btn_accumPrize innerCenter" @click="toAccumPrize()">
        <span>累抽<br />奖励</span>
      </div>
      <div
        class="btn_sevenDay innerCenter"
        @click="
          SET_ISMASKSHOW(true);
          SET_MASKCONTENT('sevenDay');
        "
      >
        <span>七天<br />登录</span>
      </div>
    </div>
    <div class="activityTime">
      活动时间：{{ activityTime.start_time.split(" ")[0].replace(/-/g, "/") }} -
      {{ activityTime.end_time.split(" ")[0].replace(/-/g, "/") }}
    </div>
    <div class="login_module">
      <div class="no_login" v-if="!isBind || !isLogin">
        请<span
          @click="
            SET_ISMASKSHOW(true);
            SET_MASKCONTENT('mainland');
          "
          >{{ !isLogin || isBind ? "登录" : "绑定角色" }}</span
        >
      </div>
      <div class="logined" v-if="isBind">
        <div>
          欢迎您，<span>{{ userMsg.info?userMsg.info.roleid:"" }}</span>
          <span @click="logOut()" v-show="!isXYLogin">[注销]</span>
        </div>
        <div
          @click="
            SET_ISMASKSHOW(true);
            SET_MASKCONTENT('mainland');
            SET_MAINLANDLOGIN('binding');
          "
          v-show="!isXYLogin"
        ></div>
      </div>
    </div>
    <!-- 跳过动画+查看概率的按钮组 -->
    <div class="btnBox_jump_probable">
      <div class="btn_jumpAn" @click="isJumpAn = !isJumpAn">
        <div :class="{ choose: isJumpAn }"></div>
      </div>
      <div
        class="btn_showProbable"
        @click="
          SET_ISMASKSHOW(true);
          SET_MASKCONTENT('showProbable');
        "
      ></div>
    </div>
    <!-- 抽奖池 -->
    <div class="prizePool innerCenter">
      <div class="butterfly"></div>
      <div class="clound"></div>
      <div class="outerTable">
        <div class="outerPointer"></div>
      </div>
      <!-- 选星级 -->
      <div class="gearTable" style="transform: rotate(0deg)">
        <div
          v-for="(item, index) in star_list"
          :key="index"
          :style="{
            transform: `rotate(${index * 36}deg) translateY(-3.65rem)`,
          }"
        >
          <span
            class="bright"
            v-for="(item1, index1) in item"
            :key="index1"
          ></span>
        </div>
      </div>
      <div class="innerTable"></div>
      <div
        class="flowerLightBox run"
        style="transform: rotate(0deg)"
        @click="toShowDraw()"
      >
        <div class="zhong_light" style="transform: rotate(0deg)"></div>
        <div class="qiu_light" style="transform: rotate(0deg)"></div>
        <div class="jie_light" style="transform: rotate(0deg)"></div>
        <div class="kuai_light" style="transform: rotate(0deg)"></div>
        <div class="le_light" style="transform: rotate(0deg)"></div>
      </div>
    </div>
    <!-- 结果池 -->
    <div class="resultPool innerCenter">
      <div
        class="chooseLight"
        :class="`${draw_list.item ? starType[draw_list.item].name : 'zhong'}`"
      ></div>
      <div class="haveStar">
        <div
          v-for="(item, index) in 7"
          :key="index"
          :class="{ bright: index + 1 <= draw_list.start }"
        ></div>
      </div>
    </div>
    <!-- 抽奖提示 -->
    <div class="drawTag"></div>
    <!-- 抽奖按钮组 -->
    <div class="btnBox_draw">
      <div class="btn_general" v-show="!isFirstDraw" @click="freeDraw()"></div>
      <div
        class="btn_start"
        :class="{ btn_protect: !isFirstDraw }"
        @click="coinDraw(isFirstDraw)"
      >
        <span v-show="!isFirstDraw"></span>
        <span v-show="!isFirstDraw">{{ needCoin }}</span>
      </div>
      <div
        class="btn_getGift"
        v-show="!isFirstDraw"
        @click="toGetEggPrize()"
      ></div>
    </div>
    <!-- 幸运币数 -->
    <div class="coin_num">
      <span></span>
      {{ isLogin ? userMsg.num : 0 }}
      <span @click="addCoin"></span>
    </div>
    <AccumPrize
      v-show="index == 1"
      ref="accumPrize"
      @getUserInfo="getUserInfo"
      @setAccumPrize="setAccumPrize"
    />
    <Store
      v-show="index == 2"
      ref="store"
      @propMsg="setPropMsg"
      @setPrevMask="setPrevMask"
    />
    <!-- 弹出框 -->
    <van-popup
      v-model="isShowPop.status"
      round
      position="bottom"
      :style="{ height: '30%' }"
      class="popup2"
    >
      <van-picker
        title=""
        show-toolbar
        :columns="platform_list"
        @confirm="confirmPlatform"
        v-show="isShowPop.type == 1"
      />
      <van-picker
        title=""
        show-toolbar
        :columns="allRoleId_list"
        @confirm="confirmRoleId"
        v-show="isShowPop.type == 2"
      />
      <van-picker
        title=""
        show-toolbar
        :columns="allRoleServer_list"
        @confirm="confirmRoleServer"
        v-show="isShowPop.type == 3"
      />
    </van-popup>
  </div>
</template>
<script>
import AccumPrize from "@/components/accumPrize.vue";
import Store from "@/components/store";
import RuleMask from "@/components/mask/ruleMask.vue";
import GiftShow from "@/components/mask/giftShow.vue";
import SevenDay from "@/components/mask/sevenDay.vue";
import ProbableShow from "@/components/mask/probableShow.vue";
import MainlandLogin from "@/components/mask/mainlandLogin.vue";
import HktwLogin from "@/components/mask/hktwLogin.vue";
import ExchangeProp from "@/components/mask/exchangeProp.vue";
import ChangeRole from "@/components/mask/changeRole.vue";
import ConfirmGetEgg from "@/components/mask/confirmGetEgg.vue";
import GetEggSuccess from "@/components/mask/getEggSuccess.vue";
import GetEggFail from "@/components/mask/getEggFail.vue";
import GeneralGetEgg from "@/components/mask/generalGetEgg.vue";
import ProtectGetEgg from "@/components/mask/protectGetEgg.vue";
import ProtectDefeat from "@/components/mask/protectDefeat.vue";
import ConfirmGetAccum from "@/components/mask/confirmGetAccum";
import GetAccumSuccess from "@/components/mask/getAccumSuccess";
import ConfirmGetEggPrize from "@/components/mask/confirmGetEggPrize";
import EggFailGetPrize from "@/components/mask/eggFailGetPrize";

import { getQueryValue } from "@/utils/getQueryValue";
import { urlDelParams } from "@/utils/urlDelParams";

import { mapState, mapMutations } from "vuex";
import {
  getRoleInfo,
  lottery_draw,
  subPrize,
  getUserInfo,
  xy_login,
  getActivityTime,
} from "@/api/mainland";
import clickLog from "@/api/toDots.js";
export default {
  name: "index",
  components: {
    AccumPrize,
    Store,
    RuleMask,
    GiftShow,
    SevenDay,
    ProbableShow,
    MainlandLogin,
    HktwLogin,
    ExchangeProp,
    ChangeRole,
    ConfirmGetEgg,
    GetEggSuccess,
    GetEggFail,
    GeneralGetEgg,
    ProtectGetEgg,
    ProtectDefeat,
    ConfirmGetAccum,
    GetAccumSuccess,
    ConfirmGetEggPrize,
    EggFailGetPrize,
  },
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
      // 导航切换
      index: 1,
      star_list: [1, 1, 1, 2, 1, 1, 1, 1, 2, 3],
      propMsg: {
        id: null,
        name: "发饰*1",
        limit: "1",
        goods_img: "",
        thing_img: "thing3_2.png",
        thing_num: "3",
      },
      // 平台
      platform_list: ["安卓", "IOS"],
      // 是否跳动画
      isJumpAn: false,
      // 增加的星级
      addStar: { num: 0, type: "" },
      // 活动时间
      activityTime: {
        current_time: "",
        end_time: "",
        start_time: "",
      },
      // 上一个弹出框内容
      prevMask: "",
      // 扭蛋
      starType: {
        中: { name: "zhong", id: 1 },
        秋: { name: "qiu", id: 2 },
        节: { name: "jie", id: 3 },
        節: { name: "jie", id: 3 },
        快: { name: "kuai", id: 4 },
        樂: { name: "le", id: 5 },
        乐: { name: "le", id: 5 },
        1: "秋",
        2: "节",
        3: "快",
        4: "乐",
        5: "中",
      },
      // 控制兑换商店框内容的显示
      propShow: "prop",
      // 兑换商店商品兑换数
      propNum: 1,
      // 是否快捷登录
      isXYLogin: false,
      //要领取的累计奖励
      accumPrizeMsg: {
        id: 6,
        accum: 2000,
        prize: ["保养油*8", "黄铜腰牌*8", "秦蒙笔*25"],
      },
      // 是否是领取扭蛋奖励成功后
      isGetEggPrize: false,
      // 追加失败降至几星
      defeatStar: 0,
      // 标识是否再走动画
      isAnima: false,
    };
  },
  methods: {
    changeNav(e) {
      if (e.target.className.indexOf("game") == -1) {
        // 兑换商店
        this.index = 2;
        this.$nextTick(() => {
          this.$el
            .querySelector(".store_title")
            .scrollIntoView({ block: "start", behavior: "smooth" });
        });
      } else {
        // 中秋扭蛋
        this.index = 1;
        this.$nextTick(() => {
          this.$el
            .querySelector(".activity_title")
            .scrollIntoView({ block: "start", behavior: "smooth" });
        });
      }
    },
    // 跳转链接
    toLink() {
      window.open(
        "https://admin.qidian.qq.com/template/blue/mp/menu/qr-code-jump-market.html?linkType=0&env=ol&kfuin=3009024708&fid=1201&key=cff542a8735e584fcc97b80b698d82fa&cate=1&source=&isLBS=&isCustomEntry=&type=16&ftype=1&_type=wpa&qidian=true",
        "_blank"
      );
    },

    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_ISSHOWPOP",
      "SET_ROLEMSG",
      "SET_ALLROLELIST",
      "SET_USERMSG",
      "SET_GRAWLIST",
      "SET_ISBIND",
      "SET_MAINLANDLOGIN",
      "SET_ISLOGIN",
      "SET_DRAWDEFEAT",
      "SET_GENERALTAG",
      "SET_PROTECTTAG",
    ]),
    // 设置要兑换的商品信息
    setPropMsg(obj) {
      this.propMsg = { ...obj };
    },
    // 花币抽扭蛋
    coinDraw(isFirstDraw) {
      if (this.isAnima) {
        return;
      }
      
      if (this.isBind ) {
        // 已绑定
        // this.SET_ISMASKSHOW(true);
        // this.SET_MASKCONTENT("getEgg");

      // let compareCoin = isFirstDraw ? 1 : this.needCoin
      // if (this.userMsg.num > compareCoin) {
      //   // 有提示
      //   if(this.coin_tag) {
      //     this.SET_ISMASKSHOW(true);
      //     this.SET_MASKCONTENT(isFirstDraw ?"confirmGetEgg":"protectGetEgg");
      //   }else {
      //     this.lottery_draw(isFirstDraw ? 1 :3)
      //     if(isFirstDraw){
      //       clickLog({ type: 4, state: this.isLogin ? 1 : 2 });
      //     }
      //   }
      // }else {
      //   this.SET_ISMASKSHOW(true);
      //   this.SET_MASKCONTENT("getEggFail");
      // }

        if (isFirstDraw) {
          // 第一次抽
          if (this.coin_tag) {
            // 有提示
            this.SET_ISMASKSHOW(true);
            this.SET_MASKCONTENT("confirmGetEgg");
          } else {
            //没提示
            if (this.userMsg.num >= 1) {
              // 钱够
              this.lottery_draw(1);
            } else {
              this.SET_ISMASKSHOW(true);
              this.SET_MASKCONTENT("getEggFail");
            }
          }
        } else {
          // 保护追加
          if (this.protect_tag) {
            // 有提示
            this.SET_ISMASKSHOW(true);
            this.SET_MASKCONTENT("protectGetEgg");
          } else {
            // 没提示
            if (this.userMsg.num >= this.needCoin) {
              // 钱够
              this.lottery_draw(3);
              clickLog({ type: 4, state: this.isLogin ? 1 : 2 });
            } else {
              this.SET_ISMASKSHOW(true);
              this.SET_MASKCONTENT("getEggFail");
            }
          }
        }
      } else {
        //没绑定
        this.SET_ISMASKSHOW(true);
        this.SET_MASKCONTENT("mainland");
      }
    },
    // 免费抽扭蛋 能免费表示已登录且至少抽过一次
    freeDraw() {
      if (this.isAnima) {
        return;
      }
      // 判断当前已有扭蛋星级是否大于等于3 有且要提示则提示弹框
      if (this.draw_list.start >= 3 && this.general_tag) {
        // 有提示
        this.SET_ISMASKSHOW(true);
        this.SET_MASKCONTENT("generalGetEgg");
      } else {
        // 无提示 直接抽
        this.lottery_draw(2);
        clickLog({ type: 3, state: this.isLogin ? 1 : 2 });
      }
    },
    // 确定平台
    confirmPlatform(value, index) {
      this.roleMsg.platform = value;
      this.isShowPop.status = false;
      this.getRoleInfo();
    },

    // 获取用户所有角色信息
    getRoleInfo() {
      const time = Date.now();
      const { token } = this.userMsg;
      const channel = this.roleMsg.platform == "安卓" ? 1 : 3;
      getRoleInfo({ time, token, channel }, { time, token }).then((res) => {
        if (res.status == 1) {
          // 获取信息成功
          this.SET_ALLROLELIST(res.data);
          if (res.data.length == 0) {
            // 没有对应数据
            this.SET_ROLEMSG({ platform: this.roleMsg.platform });
          } else {
            this.SET_ROLEMSG(Object.assign({}, this.roleMsg, res.data[0]));
          }
        } else {
          this.$toast.fail(res.msg);
        }
      });
    },
    // 确定角色id
    confirmRoleId(value, index) {
      // this.roleMsg.id = value;
      this.allRole_list.forEach((role) => {
        if (role.role_id == value) {
          this.SET_ROLEMSG(role);
        }
      });
      this.isShowPop.status = false;
    },
    // 确定角色服务器
    confirmRoleServer(value, index) {
      this.allRole_list.forEach((role) => {
        if (role.server_name == value) {
          console.log(role);
          this.SET_ROLEMSG(role);
        }
      });
      this.isShowPop.status = false;
    },
    // 抽奖 1初始抽奖 2普通抽奖 3保护抽奖
    lottery_draw(type) {
      if (this.isAnima) {
        // 在动画中则不让点
        return;
      }
      this.SET_ISMASKSHOW(false);
      if (this.draw_list.start == 7) {
        // 七星 提示可以领奖了 游戏重新开始
        this.$toast.success("您已集齐七星扭蛋，点击领取奖励");
        return;
      }
      const time = Date.now();
      const { token } = this.userMsg;
      lottery_draw({ time, token, type }, { time, token }).then((res) => {
        this.isAnima = true;
        console.log(res);
        if (res.status == 1) {
          // 抽奖成功
          if (this.draw_list.start == res.data.start) {
            // 星级不变 说明抽奖失败但是保护成功
            /**
             * 抽奖花灯动效 传抽中的下一个...
             */
            let time = 0;
            if (!this.isJumpAn) {
              time = this.getDynamicTime(
                this.starType[this.starType[res.data.item].id]
              );
            }
            /**
             * 定时器
             */
            setTimeout(() => {
              this.SET_MASKCONTENT("protectDefeat");
              this.SET_ISMASKSHOW(true);
              this.getUserInfo();
              this.isAnima = false;
            }, time * 1000 + 200);
          } else {
            /**
             *  抽奖花灯动效 传抽中的...
             *  */
            if (!this.isJumpAn) {
              // 走动效
              let time = this.getDynamicTime(res.data.item);
              /**
               *  定时器花灯动效结束
               */
              setTimeout(() => {
                if (this.draw_list.start) {
                  this.addStar.num = res.data.start - this.draw_list.start;
                } else {
                  this.addStar.num = res.data.start - 0;
                }
                // 抽奖星级转盘动效
                this.drawStarDynamic(this.addStar.num);
                document
                  .querySelector(".gearTable")
                  .addEventListener("transitionend", () => {
                    this.addStar.type = res.data.item;
                    this.SET_GRAWLIST(res.data);
                    document
                      .getElementsByClassName("chooseLight")[0]
                      .setAttribute(
                        "class",
                        `chooseLight ${this.starType[this.addStar.type].name}`
                      );
                    this.SET_MASKCONTENT("getEggSuccess");
                    this.SET_ISMASKSHOW(true);
                    if (this.draw_list.start == 7) {
                      // 七星 提示可以领奖了 游戏重新开始
                      this.$toast.success("您已集齐七星扭蛋，点击领取奖励");
                    }
                    this.getUserInfo();
                    this.isAnima = false;
                  });
              }, time * 1000 + 200);
            } else {
              if (this.draw_list.start) {
                this.addStar.num = res.data.start - this.draw_list.start;
              } else {
                this.addStar.num = res.data.start - 0;
              }
              this.addStar.type = res.data.item;
              this.SET_GRAWLIST(res.data);
              document
                .getElementsByClassName("chooseLight")[0]
                .setAttribute(
                  "class",
                  `chooseLight ${this.starType[this.addStar.type].name}`
                );
              this.SET_MASKCONTENT("getEggSuccess");
              this.SET_ISMASKSHOW(true);
              if (this.draw_list.start == 7) {
                // 七星 提示可以领奖了 游戏重新开始
                this.$toast.success("您已集齐七星扭蛋，点击领取奖励");
              }
              this.getUserInfo();
              this.isAnima = false;
            }
          }
          this.SET_DRAWDEFEAT(false);
        } else {
          // 失败
          // 动效
          let time = 0;
          if (!this.isJumpAn) {
            // 走动效
            time = this.getDynamicTime(
              this.starType[this.starType[this.draw_list.item].id]
            );
          }
          setTimeout(() => {
            if (res.status == 4040) {
              // token过期了
              this.$toast.fail("登录过期，请重新登录");
              this.logOut();
            } else if (
              res.msg == "追加失败，奖励已发，请重新开始游戏" ||
              res.msg == "不符合抽奖条件"
            ) {
              // 追加失败 或不符合抽奖条件 则回归初始抽奖
              // 弹出提示抽奖失败奖励已发
              this.defeatStar = res.data.start;
              this.SET_ISMASKSHOW(true);
              this.SET_MASKCONTENT("eggFailGetPrize");
              this.SET_DRAWDEFEAT(true);
              this.getUserInfo();
            } else {
              this.$toast.fail(res.msg);
            }
            // 花灯归位
            const el = document.getElementsByClassName("flowerLightBox")[0];
            const lightList = document.querySelectorAll(".flowerLightBox div");
            setTimeout(() => {
              lightList.forEach((light) => {
                light.style.transition = "none";
                light.style.transform = "rotate(0deg)";
              });
            }, 100);
            setTimeout(() => {
              el.style.transition = "none";
              el.style.transform = "rotate(0deg)";
            }, 100);
            this.isAnima = false;
          }, time * 1000 + 200);
        }
      });
    },
    // 加币
    addCoin() {
      if (this.isBind) {
        // 链接带参数则不改参数
        let params = location.href.split("?")[1]; //参数
        let url;
        if (params) {
          url = `/purchase?${params}`;
        } else {
          url = "/purchase";
        }
        this.$router.push(url);
      } else {
        this.SET_ISMASKSHOW(true);
        this.SET_MASKCONTENT("mainland");
      }
    },
    // 领取抽奖奖励
    subPrize(obj) {
      if (this.isBind) {
        // 已绑定
        const time = Date.now();
        const { token } = this.userMsg;
        const { type, rid, num } = obj;
        // const type = 4;
        // 几星
        // const rid = this.draw_list.start;
        // const num = 1;
        // rid 第几个商品
        subPrize({ time, token, type, rid, num }, { time, token, num }).then(
          (res) => {
            if (res.status == 1) {
              // 兑换成功
              this.$toast.success(res.msg);
              this.isGetEggPrize = false;
              if (type == 4) {
                // 星级兑换
                this.isGetEggPrize = true;
                this.SET_MASKCONTENT("getAccumSuccess");
                this.SET_DRAWDEFEAT(true);
              }
              if (type == 2) {
                // 累计消耗兑换
                this.SET_MASKCONTENT("getAccumSuccess");
              }
              if (type == 3) {
                // 兑换商店
                // this.$emit("changePropShow", "success");
                this.changePropShow("success");
              }
              // 重获用户信息
              this.getUserInfo();
            } else {
              if (res.msg == "不符合领取条件" && type == 3) {
                this.$toast.fail("兑换所需道具不足！");
              } else {
                this.$toast.fail(res.msg);
              }
              if (res.status == 4040) {
                // 登录失效 需要重新登录
                this.$toast.fail("登录过期，请重新登录");
                this.logOut();
              }
            }
          }
        );
      } else {
        // 没绑定
        this.SET_ISMASKSHOW(true);
        this.SET_MASKCONTENT("mainland");
      }
    },
    // 重新获取用户信息
    getUserInfo() {
      const time = Date.now();
      const { token } = this.userMsg;
      getUserInfo({ time, token }, { time, token }).then((res) => {
        console.log(res);
        if (res.status == 1) {
          // 获取用户信息成功
          //如果当前是快捷登录 则直接从data.info中获取绑定的角色信息
          if (this.isXYLogin) {
            // 绑定角色
            this.SET_ROLEMSG({
              role_id: res.data.info.roleid,
              role_name: res.data.info.rolename,
              server_id: res.data.info.sid,
              server_name: res.data.info.sname,
              // server_name: res.data.info.sname,
            });
            // this.SET_ISMASKSHOW(false);
          }
          if (res.data.info.roleid && !this.isBind) {
            // 如果有綁定角色 且 当前未绑定
            this.SET_ISBIND(true);
            this.SET_ROLEMSG({
              role_id: res.data.info.roleid,
              role_name: res.data.info.rolename,
              server_id: res.data.info.sid,
              server_name: res.data.info.sname,
              // server_name: res.data.info.sname,
            });
            this.SET_ISMASKSHOW(false);
          }
          this.userMsg = Object.assign({}, this.userMsg, res.data);
          // console.log(this.userMsg);
          this.SET_USERMSG(this.userMsg);
          // 获取用户礼包 如果为null 则无法盖过原来的数据
          if (res.data.info.content != "") {
            this.SET_GRAWLIST(JSON.parse(res.data.info.content));
          } else {
            this.SET_GRAWLIST(null);
          }
        } else {
          if (res.status == 4040) {
            // 登录失效 需要重新登录
            this.$toast.fail("登录过期，请重新登录");
            this.logOut();
          }
          this.$toast.fail(res.msg);
        }
      });
    },
    // 快捷登录
    xy_login() {
      const time = Date.now();
      let xyid = getQueryValue("xyId");
      if(xyid.indexOf("#") != -1 ){
        xyid = xyid.split("#")[0];
      }
      let channel = getQueryValue("pt");
      if(channel.indexOf("#") != -1 ){
        channel = channel.split("#")[0];
      }
      let rid = getQueryValue("roleId");
      if(rid.indexOf("#") != -1 ){
        rid = rid.split("#")[0];
      }
      console.log(xyid,channel,rid)
      xy_login(
        { time, xyid, channel, sid: 1, sname: 1, rolename: 1, rid },
        { time, xyid }
      ).then((res) => {
        if (res.status == 1) {
          // 登录成功
          this.SET_ISLOGIN(true);
          this.SET_ISBIND(true);
          this.isXYLogin = true;
          this.$toast.success(res.msg);
          this.SET_USERMSG(res.data);
          // 获取用户信息
          this.getUserInfo();
          // 绑定角色
          // this.SET_ROLEMSG({
          //   role_id: res.data.info.roleid,
          //   role_name: res.data.info.rolename,
          //   server_id: res.data.info.sid,
          //   server_name: { zh: res.data.info.sname },
          // });
          // 存入本地 并且 删除链接上参数
          sessionStorage.setItem("userMsg", JSON.stringify(res.data));
          localStorage.setItem("userMsg", JSON.stringify(res.data));
          window.location.replace(location.href.split("?")[0]);
          // window.location.href = location.href.split("?")[0];
        }
      });
    },
    // 去累抽奖励那块
    toAccumPrize() {
      this.index = 1;
      this.$nextTick(() => {
        this.$el
          .querySelector(".accumPrize_title")
          .scrollIntoView({ block: "start", behavior: "smooth" });
      });
    },
    // 获取活动时间
    getActivityTime() {
      const time = Date.now();
      const project_id = 24;
      getActivityTime({ time, project_id }, { time, project_id }).then(
        (res) => {
          if (res.status == 1) {
            // 获取成功
            this.activityTime = { ...res.data };
          } else {
            this.$toast.fail(res.msg);
          }
        }
      );
    },
    // 关闭mask弹出层
    closeMaskPop() {
      if (this.prevMask == "sevenDay") {
        this.SET_ISMASKSHOW(true);
        this.SET_MASKCONTENT("sevenDay");
        this.prevMask = "";
      }
    },
    // 关闭mask弹出层后
    closedMaskPop() {
      if (this.prevMask == "exchangeProp") {
        this.propShow = "prop";
        this.propNum = 1;
      }
    },
    // 打开mask弹出层
    openMaskPop() {},
    // 设置上一个弹出框内容
    setPrevMask(prevMask) {
      this.prevMask = prevMask;
    },
    // 改变prop内容
    changePropShow(propShow) {
      this.propShow = propShow;
    },
    // 抽奖花灯特效 传"中"
    drawLightDynamic(m, n) {
      // 要转到的花灯是第几个
      // m = this.starType[m].id;
      // 获取当前花灯整体dom元素
      const el = document.getElementsByClassName("flowerLightBox")[0];
      const lightList = document.querySelectorAll(".flowerLightBox div");
      // 当前花灯整体度数
      const deg = parseInt(el.style.transform.replace(/[^\d|^\.|^\-]/g, ""));
      // 当前花灯度数
      const lightDeg = parseInt(
        lightList[0].style.transform.replace(/[^\d|^\.|^\-]/g, "")
      );
      // 当前花灯是第几个
      // const n = 5 - (deg % 360) / 72 + 1;
      // console.log("当前花灯整体度数" + deg);
      // console.log("当前花灯度数" + lightDeg);
      // console.log("当前花灯是第n " + n + "个");
      // console.log("要转到第m " + m + "个");
      let lightTransform, lightTransition, elTransform, elTransition;
      lightTransform = `rotate(${lightDeg + (720 + (n - m) * 72) * -1}deg)`;
      lightTransition = elTransition = `all ${3 - (m - n) * 0.3}s ease-out`;
      elTransform = `rotate(${deg + 720 + (n - m) * 72}deg)`;
      setTimeout(() => {
        lightList.forEach((light) => {
          light.style.transform = lightTransform;
          light.style.transition = lightTransition;
        });
      }, 100);
      setTimeout(() => {
        el.style.transform = elTransform;
        el.style.transition = elTransition;
      }, 100);
    },
    // 抽奖星级特效 传数字123
    drawStarDynamic(m) {
      const type = {
        1: [1, 2, 3, 5, 6, 7, 8],
        2: [4, 9],
        3: [10],
      };
      console.log(type[m]);
      // 确定要转到的位置
      m = type[m][Math.floor(Math.random() * type[m].length)];
      // 获取星级转盘
      const el = document.getElementsByClassName("gearTable")[0];
      // 获取当前星际转盘角度
      const currentDeg = parseInt(
        el.style.transform.replace(/[^\d|^\.|^\-]/g, "")
      );
      // 当前星级的位置
      const n = 10 - (currentDeg % 360) / 36 + 1;
      // console.log(currentDeg % 360);
      // console.log("当前位置:" + n);
      // console.log("要转到的位置:" + m);
      // console.log("当前星际转盘角度:" + currentDeg);
      let starTransform, starTransition;
      starTransform = `rotate(${currentDeg + 720 + (n - m) * 36}deg)`;
      starTransition = `all ${2 - (m - n) * 0.2}s ease-out`;
      setTimeout(() => {
        el.style.transform = starTransform;
        el.style.transition = starTransition;
      }, 100);
    },
    //获取动效时间
    getDynamicTime(item) {
      // 要转到的花灯是第几个
      let m = this.starType[item].id;
      // 获取当前花灯整体dom元素
      const el = document.getElementsByClassName("flowerLightBox")[0];
      // 当前花灯整体度数
      const deg = parseInt(el.style.transform.replace(/[^\d|^\.|^\-]/g, ""));
      // 当前花灯是第几个
      const n = 5 - (deg % 360) / 72 + 1;
      let time = 3 - (m - n) * 0.3;
      this.drawLightDynamic(m, n);
      return time;
    },
    // 设置兑换商店商品个数
    setPropNum(n) {
      this.propNum = n;
    },
    // 注销
    logOut() {
      this.SET_ISLOGIN(false);
      this.SET_ISBIND(false);
      this.SET_ISMASKSHOW(true);
      this.SET_MASKCONTENT("mainland");
      this.SET_MAINLANDLOGIN("chooseWay");
      this.SET_USERMSG({});
    },
    // 设置要领取的累计奖励
    setAccumPrize(item) {
      this.accumPrizeMsg = item;
    },
    //主动领取奖励
    toGetEggPrize() {
      if (this.isAnima) {
        return;
      }
      this.SET_ISMASKSHOW(true);
      this.SET_MASKCONTENT("confirmGetEggPrize");
    },
    // 展示抽奖
    toShowDraw() {
      this.$nextTick(() => {
        this.$el
          .querySelector(".clound")
          .scrollIntoView({ block: "start", behavior: "smooth" });
      });
    },
  },
  computed: {
    // 弹出框是否展示 用这种方式 无法从该页面改变store中的变量值
    // ...mapState(["isMaskShow","isLogin"]),
    // 用下面这种方式可以
    // 弹出框是否显示
    isMaskShow: {
      get() {
        return this.$store.state.isMaskShow;
      },
      set(n) {
        this.SET_ISMASKSHOW(n);
      },
    },
    // 是否有用户登录
    isLogin() {
      return this.$store.state.isLogin;
    },
    // 是否绑定角色
    isBind() {
      return this.$store.state.isBind;
    },
    // 弹出框内容
    maskContent() {
      return this.$store.state.maskContent;
    },
    // 底部弹出框是否显示
    isShowPop() {
      return this.$store.state.isShowPop;
    },
    // 登录的用户信息
    userMsg: {
      get() {
        return this.$store.state.userMsg;
      },
      set(n) {
        this.SET_USERMSG(n);
      },
    },
    // 当前登录用户所有角色信息
    allRole_list() {
      return this.$store.state.allRole_list;
    },
    allRoleId_list() {
      let list = [];
      this.allRole_list.forEach((role) => {
        list.push(role.role_id);
      });
      return list;
    },
    roleMsg() {
      return this.$store.state.roleMsg;
    },
    // 是否首次抽奖
    isFirstDraw() {
      if (!this.isLogin) {
        //没登录
        return true;
      } else {
        // 有抽奖纪律
        if (this.draw_list.start && !this.drawDefeat) {
          // 有抽奖数据且没有失败 则不是第一次
          return false;
        } else {
          // 没有数据 或 失败了 就是第一次
          return true;
        }

        // if (
        //   (this.userMsg.info ? this.userMsg.info.num == 1 : true) ||
        //   this.drawDefeat
        // ) {
        //   // 第一次抽 或 上次失败了
        //   return true;
        // } else {
        //   // 不是第一次抽 且 没失败
        //   return false;
        // }
      }
    },
    // 是否提示使用金币抽奖
    coin_tag() {
      return this.$store.state.coin_tag;
    },
    // 抽到的东西
    draw_list() {
      return this.$store.state.draw_list;
    },
    // 更新大陆登录框显示什么
    mainlandLogin() {
      return this.$store.state.mainlandLogin;
    },
    //  当前用户全部角色的区服
    allRoleServer_list() {
      let list = [];
      this.allRole_list.forEach((role) => {
        list.push(role.server_name);
      });
      return list;
    },
    // 是否追加失败
    drawDefeat() {
      return this.$store.state.drawDefeat;
    },
    // 是否进行普通追加提示
    general_tag() {
      return this.$store.state.general_tag;
    },
    // 控制是否保护追加弹框是否显示
    protect_tag() {
      return this.$store.state.protect_tag;
    },
    // 返回下次抽奖需要多少金币
    needCoin() {
      let num = 0;
      if (this.draw_list.start == 1) {
        num = 1;
      } else if (this.draw_list.start == 2) {
        num = 3;
      } else if (this.draw_list.start == 3) {
        num = 8;
      } else if (this.draw_list.start == 4) {
        num = 26;
      } else if (this.draw_list.start == 5) {
        num = 75;
      } else if (this.draw_list.start == 6) {
        num = 138;
      }
      return num;
    },
  },
  mounted() {
    // 如果有则是快捷登录
    if (getQueryValue("xyId")) {
      // 初始化apple登录
      this.xy_login();
      this.isXYLogin = true;
    } else {
      //没有 判断session中有无数据
      // 只有快捷登录会把userMsg存在session中
      let userMsg = sessionStorage.getItem("userMsg");
      if (userMsg) {
        userMsg = JSON.parse(userMsg)
        this.SET_USERMSG(userMsg);
        this.getUserInfo();
        this.SET_ISLOGIN(true);
        this.SET_ISBIND(true);
        // 有 快捷登录
        this.isXYLogin = true;
      } else {
        // 刷新退出登录问题
        let userMsg1 = localStorage.getItem("userMsg");
        if (userMsg1) {
          userMsg1 = JSON.parse(userMsg1)
          this.SET_USERMSG(userMsg1);
          this.getUserInfo();
          this.SET_ISLOGIN(true);
          this.SET_ISBIND(true);
        }
      }
    }

    clickLog({ type: 1, state: this.isLogin ? 1 : 2 });

    // 获取活动时间
    this.getActivityTime();
    // this.drawLightDynamic("乐");
    // this.drawStarDynamic(2);
    // 获取本地存储的token
    // let userMsg = sessionStorage.getItem("userMsg");
    // if (userMsg) {
    //   this.SET_USERMSG(JSON.parse(userMsg));
    //   this.getUserInfo();
    //   // this.getRoleInfo();
    //   this.SET_ISLOGIN(true);
    //   this.SET_ISBIND(true);
    // }
  },
};
</script>
<style lang="scss" scoped>
.index{
   width: 100%;
   height: 50.94rem;
   display: flex;
   flex-direction: column;
   align-items: center;
   position:relative;
   background-image:imgUrl("activity_bg.png") ;
   overflow: hidden;
  //  background-image:imgUrl("3.png") ;
  /deep/ .van-overlay{
    pointer-events: all;
  }
  /deep/ .van-popup{
    background-color:transparent !important;
    overflow-y: scroll;
    -webkit-overflow-scrolling: touch;
    &.popup1{
      max-height:80%;
    }
    &.popup2{
      overflow: hidden !important;
      /deep/ .van-picker{
        height:100%;
      }
    }
    .close{
        width: 0.7rem;
        height: 0.7rem;
        position: absolute;
        background-image: imgUrl("btn_close.png");
    }
  }

  .changeNav{
    width: 100%;
    height: 1.25rem;
    display: flex;
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 3;
    div{
      width: 50%;
      height: 100%;
      &.game{
        background-image: imgUrl("btn_gamePage.png");
        &.choose{
          background-image: imgUrl("btn_gamePage_c.png");
        }
      }
      &.store{
        background-image: imgUrl("btn_storePage.png");
        &.choose{
          background-image: imgUrl("btn_storePage_c.png");
        }
      }
    }
   }
 
   .flower{
     width: 100%;
     position:absolute;
     top:1.6rem;
     left:0;
     z-index: 2;
     pointer-events: none;
   }
   .activity_title{
       width: 7rem;
       height: 3rem;
       margin:0.9rem 0 0 0;
       background-image: imgUrl("activity_title.png");
   }
   .btn_showGift{
       width: 0.7rem;
       height: 4rem;
       margin: -3.1rem 0.2rem 0 0;
       background-image: imgUrl("btn_showGift1.png");
       align-self: flex-end;
       z-index: 2;
   }
  //  悬浮窗
   .btnBox{
     z-index: 2;
     div{
          width: 2rem;
          height: 1.8rem;
          span{
                margin:-0.15rem 0 0 0 ;
                font-size: 0.32rem;
          }
     }
     &.btnBox_rule_service{
        position:absolute;
        top: 1.2rem;
        left: 0;
        div{
              background-image: imgUrl("blue_bg.png");
              span{
                  color: #135375;
          }
        }
     }
     &.btnBox_accumPrize_login{
        position:absolute;
        top: 4.5rem;
        right: 0;
        div{
            background-image: imgUrl("yellow_bg.png");
            span{
              color: #723C19;
            }
        }
     }
   }
   .activityTime{
     color:#fff;
     font-size: 0.3rem;
     margin:-1rem 0 0 0;
   }
   .login_module{
     width: 62%;
     height: 0.5rem;
     margin:0.3rem 0 0 0;
     display: flex;
     align-items: center;
     justify-content: center;
     z-index: 2;
     .no_login{
       width: 100%;
       display: flex;
       justify-content: flex-end;
       font-size: 0.32rem;
       color: #fff;
       span{
         margin:0 0 0 0.2rem;
         color:#FFF0B5;
         border-bottom: 1px solid #FFF0B5;
       }
     }
     .logined{
       width: 90%;
       margin: 0 0 0 0.2rem;
       display: flex;
       justify-content: space-between;
       align-items: center;
       color: #fff;
       div{
        &:nth-of-type(1){
          span{
            &:nth-of-type(2){
              color:#000;
              margin: 0 0 0 0.1rem;
            }
          }
        }
        &:nth-of-type(2){
          width:1.5rem;
          height: 0.55rem;
          background-image: imgUrl("changeCha.png");
        }
       }
     }
   }
   .btnBox_jump_probable{
     width: 60%;
     margin:1.1rem 0 0 0;
     display: flex;
     justify-content: space-between;
     z-index: 3;
     .btn_jumpAn{
       width: 2.2rem;
       height: 0.53rem;
       display: flex;
       align-items: center;
       background-image: imgUrl("btn_jumpAn.png");
       div{
         width:0.26rem;
         height: 0.26rem;
         margin:0 0 0 0.24rem;
         background-image: imgUrl("square.png");
         &.choose{
           background-image: imgUrl("square_full.png");
         }
       }
     }
     .btn_showProbable{
       width: 1.93rem;
       height: 0.56rem;
       background-image: imgUrl("btn_showProbable.png");
     }
   }
   .prizePool{
     width: 100%;
     height: 17.1rem;
     position: relative;
     top:-4rem;
    //  margin:  -4.5rem ​0 0 0;
     background-image: imgUrl("prizePool_bg.png");
     .butterfly{
       width: 3rem;
       height: 4rem;
       position: absolute;
       top:3.6rem;
       left:0;
       background-image: imgUrl("butterfly.png");
       z-index: 2;
     }
     .clound{
       width: 95%;
       height: 1.4rem;
       position: absolute;
       bottom:4.3rem;
       background-image: imgUrl("clound.png");
       z-index: 2;
     }
     .outerTable{
       width: 8.33rem;
       height: 8.33rem;
       display: flex;
       justify-content: center;
       position: absolute;
       background-image: imgUrl("outerTable.png");
       .outerPointer{
         width: 1.25rem;
         height: 0.4rem;
         background-image: imgUrl("outerPointer.png");
         z-index: 2;
       }
     }
     .gearTable{
         width:8.1rem;
         height: 8.1rem;
         display: flex;
         justify-content: center;
         align-items: center;
         position: relative;
         position: absolute;
         background-image: imgUrl("gearTable.png");
        //  animation: circle-run 10s linear infinite;
         div{
           position: absolute;
           display: flex;
           z-index: 2;
           span{
              width: 0.35rem;
              height: 0.6rem;
              display: block;
              background-image: imgUrl("star_dark.png");
              &.bright{
                width: 0.5rem;
                height: 0.7rem;
                background-image:imgUrl("star_light.png")
              }
           }
           &:nth-of-type(4),
           &:nth-of-type(9),
           &:nth-of-type(10){
             span{
               margin: 0 0.1rem;
             }
           }
           
         }
         
      }
     .innerTable{
         width: 6.5rem;
         height: 6.5rem;
         position: absolute;
         background-image: imgUrl("innerTable.png");
      }
     .flowerLightBox{
       width: 6.5rem;
       height: 6.5rem;
       display: flex;
       justify-content: center;
       position: absolute;
        div{
         width: 2.03rem;
         height: 2.05rem;
         position: absolute;
         z-index: 3;
        &.zhong_light{
          top:0.35rem;
          background-image: imgUrl("zhong.png");
        }
        &.qiu_light{
          top: 1.7rem;
          right: 0.4rem;
          background-image: imgUrl("qiu.png");
        }
        &.jie_light{
          top: 3.7rem;
          right: 1.1rem;
          background-image: imgUrl("jie.png");
        }
        &.kuai_light{
          top: 3.7rem;
          left: 1.1rem;
          background-image: imgUrl("kuai.png");
        }
        &.le_light{
          top: 1.7rem;
          left: 0.35rem;
          background-image: imgUrl("le.png");
        }
       }
      //  星级和花灯动效
      //  &.run{
      //    animation: circle-run 10s linear infinite;
      //    div{
      //       animation: circle-run 10s linear infinite;
      //       animation-direction: reverse;
      //    }
      //  }
     }
   }
   .resultPool{
     width: 6.5rem;
     height: 6.5rem;
     position: relative;
     margin: -7.3rem 0 0 0.2rem;
     background-image: imgUrl("resultPool.png");
     .chooseLight{
       width: 2.7rem;
       height: 2.7rem;
       margin: -0.3rem 0 0 -0.25rem;
       &.zhong{
        background-image: imgUrl("zhong.png");
       }
       &.qiu{
        background-image: imgUrl("qiu.png");
       }
       &.jie{
        background-image: imgUrl("jie.png");
       }
       &.kuai{
        background-image: imgUrl("kuai.png");
       }
       &.le{
        background-image: imgUrl("le.png");
       }
     }
     .haveStar{
       width:4.5rem;
       position: absolute;
       bottom: 1.15rem;
       left: 1.12rem;
       display: flex;
       div{
          width: 0.35rem;
          width: 0.5rem;
          height: 0.6rem;
          height: 0.7rem;
          padding-top:0.01rem;
          background-image: imgUrl("star_dark.png");
          &.bright{
            // width: 0.5rem;
            // height: 0.7rem;
            background-image:imgUrl("star_light.png")
          }
          &:nth-of-type(1){
            margin: -1.7rem 0 0 -0.185rem;
          }
           &:nth-of-type(2){
            margin: -0.8rem 0 0 -0.15rem;
          }
           &:nth-of-type(3){
            margin:-0.2rem 0 0 0.2rem;
          }
           &:nth-of-type(4){
            margin:0rem 0 -0.05rem 0.4rem;
          }
           &:nth-of-type(5){
            margin:-0.25rem 0 0 0.4rem;
          }
           &:nth-of-type(6){
            margin: -0.85rem 0 0 0.2rem;
          }
           &:nth-of-type(7){
            margin: -1.7rem 0 0 -0.15rem;
          }
       }
     }
   }
   .drawTag{
     width: 4rem;
     height: 0.7rem;
     background-image: imgUrl("drawTag.png");
   }
   .btnBox_draw{
     width: 100%;
     display: flex;
     justify-content: space-around;
     div{
       width: 3rem;
       height: 1.2rem;
        &.btn_general{
          background-image: imgUrl("btn_general.png");
        }
        &.btn_start{
          background-image: imgUrl("btn_start.png");
          &.btn_protect{
            background-image: imgUrl("btn_protect.png");
            display: flex;
            justify-content: center;
            padding: 0.15rem 0 0 0;
            span{
              &:nth-of-type(1){
                width: 0.4rem;
                height: 0.4rem;
                display: block;
                background-image: imgUrl("one_coin.png");
              }
              &:nth-of-type(2){
                margin: 0 0 0 0.1rem;
                font-size: 0.4rem;
                color: #FFF386;
              }
            }
          }
        }
        &.btn_getGift{
          background-image: imgUrl("btn_getGift.png");
        }
     }
     
   }
   .coin_num{
    //  width: 3.2rem;
     height: 1rem;
     display: flex;
     align-items: center;
     justify-content: flex-start;
     margin: 0.35rem 0 0 0;
     color: #FFE09C;
     letter-spacing: 0.03rem;
     font-size: 0.4rem;
     background: rgba($color: #021D33, $alpha: 0.49);
     border: 0.01px solid rgba(255, 251, 216, 0.29);
     span{
        display: block;
        &:nth-of-type(1){
          width: 0.63rem;
          height: 0.6rem;
          margin:0 0.3rem 0 0.2rem;
          background-image: imgUrl("one_coin.png");
        }
        &:nth-of-type(2){
            width: 0.3rem;
            height: 0.3rem;
            flex-shrink: 0;
            margin: 0rem 0.2rem 0 0.2rem;
            background-image: imgUrl("icon_add.png");
        }
     }
   }
}

@keyframes circle-run {
  from{
    transform: rotate(1turn);
  }
}


</style>