<template>
  <div class="purchase">
    <span class="toIndex" @click="toIndex">X</span>
    <div class="purchase_title"></div>
    <div class="purchase_content">
      <ul>
        <li v-for="item in purchase_list" :key="item.id">
          <img class="coin" :src="`${baseUrl}${item.img}`" />
          <div class="desc">
            <div>
              幸运币*<span>{{ item.coin }}</span>
            </div>
            <div>
              赠：元宝*<span>{{ item.baby }}</span>
            </div>
          </div>
          <div class="btn innerCenter" @click="toPay(item)">
            ￥{{ item.money }}
          </div>
        </li>
      </ul>
    </div>
    <!-- 弹出框 -->
    <van-popup v-model="isMaskShow">
      <ConfirmPurchase
        v-show="maskContent == 'confirmPurchase'"
        :good="good"
        @pay="pay"
      />
      <PurchaseCoinSuccess
        v-show="maskContent == 'purchaseCoinSuccess'"
        :good="good"
      />
    </van-popup>
  </div>
</template>
<script>
import { pay, get_order_status, getUserInfo } from "@/api/mainland";
import ConfirmPurchase from "@/components/mask/confirmPurchase.vue";
import PurchaseCoinSuccess from "@/components/mask/purchaseCoinSuccess.vue";
import clickLog from "@/api/toDots.js";
import { mapState, mapMutations } from "vuex";

export default {
  name: "Purchase",
  components: {
    ConfirmPurchase,
    PurchaseCoinSuccess,
  },
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
      purchase_list: [
        {
          id: 1,
          money: 1,
          coin: 1,
          baby: 60,
          img: "one_coin.png",
        },
        {
          id: 2,
          money: 6,
          coin: 6,
          baby: 360,
          img: "one_coin.png",
        },
        {
          id: 3,
          money: 30,
          coin: 30,
          baby: 1800,
          img: "one_coin.png",
        },
        {
          id: 4,
          money: 68,
          coin: "68+3",
          baby: 4080,
          img: "one_coin.png",
        },
        {
          id: 5,
          money: 198,
          coin: "198+8",
          baby: 11880,
          img: "two_coin.png",
        },
        {
          id: 6,
          money: 328,
          coin: "328+28",
          baby: 19680,
          img: "three_coin.png",
        },
        {
          id: 7,
          money: 648,
          coin: "648 + 58",
          baby: 38880,
          img: "many_coin.png",
        },
      ],
      good: {},
      timer: null,
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_ROLEMSG",
      "SET_USERMSG",
      "SET_PURCHASETAG",
      "SET_GRAWLIST",
      "SET_MAINLANDLOGIN",
      "SET_ISLOGIN",
      "SET_ISBIND"
    ]),
    // 选择是否买币
    toPay(good) {
    //  alert("toPay:"+good.id)
      //   是否显示购买礼包确认弹框
      if (this.purchase_tag) {
        // 显示
        this.good = good;
        this.SET_ISMASKSHOW(true);
        this.SET_MASKCONTENT("confirmPurchase");
      } else {
        //   不显示直接买
        this.good = good;
        this.pay(good.id);
      }
    },
    // 买币
    pay(good_id) {
      // alert("pay:"+good_id)
      const time = Date.now();
      const { token } = this.userMsg;
      let winRef = window.open("","_blank");
      pay({ time, token, good_id }, { time, token }).then((res) => {
        console.log(res);
        if (res.status == 1) {
          // alert(9)
          // alert(res.data.url)
          // 下单成功
          // this.$toast.success(res.msg);
          winRef.location.href  = res.data.url;
          // winRef.open(res.data.url,"_blank")
          let i = 0;
          this.timer = setInterval(() => {
            this.get_order_status(res.data.orderid);
            i++;
            if (i > 30) {
              clearInterval(this.timer);
            }
          }, 2000);
        } else {
          this.$toast.fail(res.msg);
        }
      });
    },
    // 获取订单状态
    get_order_status(orderid) {
      const time = Date.now();
      // const { token } = this.userMsg;
      get_order_status({ time, orderid }, { time, orderid }).then((res) => {
        if (res.status == 1) {
          // 获取成功
          if (res.data.status == 2) {
            // 支付成功 已发货
            // 关闭定时器
            clearInterval(this.timer);
            this.SET_ISMASKSHOW(true);
            this.SET_MASKCONTENT("purchaseCoinSuccess");
            // 重新获取用户信息
            this.getUserInfo();
          }
        }
        console.log(res);
      });
    },
    // 重新获取用户信息
    getUserInfo() {
      const time = Date.now();
      const { token } = this.userMsg;
      getUserInfo({ time, token }, { time, token }).then((res) => {
        console.log(res);
        if (res.status == 1) {
          // 获取用户信息成功
          this.userMsg = Object.assign({}, this.userMsg, res.data);
          // console.log(this.userMsg);
          this.SET_USERMSG(this.userMsg);
          // 获取用户礼包 如果为null 则无法盖过原来的数据
          if (res.data.info.content != "") {
            this.SET_GRAWLIST(JSON.parse(res.data.info.content));
          } else {
            this.SET_GRAWLIST(null);
          }
        } else {
          if (res.status == 4040) {
            // 登录失效 需要重新登录
            this.$toast.fail("登录过期，请重新登录");
            this.SET_ISLOGIN(false);
            this.SET_ISBIND(false);
            this.SET_ISMASKSHOW(true);
            this.SET_MASKCONTENT("mainland");
            this.SET_MAINLANDLOGIN("chooseWay");
            this.SET_USERMSG({});
          }
          this.$toast.fail(res.msg);
        }
      });
    },
    // 去主页
    toIndex() {
      // 链接带参数则不改参数
      let params = location.href.split("?")[1]; //参数
      let url;
      if (params) {
        url = `/?${params}`;
      } else {
        url = "/";
      }
      this.$router.push(url);
    },
  },
  computed: {
    userMsg() {
      return this.$store.state.userMsg;
    },
    // 弹出框是否显示
    isMaskShow: {
      get() {
        return this.$store.state.isMaskShow;
      },
      set(n) {
        this.SET_ISMASKSHOW(n);
      },
    },
    // 弹出框内容
    maskContent() {
      return this.$store.state.maskContent;
    },
    // 是否绑定角色
    isBind() {
      return this.$store.state.isBind;
    },
    isLogin(){
      return this.$store.state.isLogin;
    },
    // 控制是否显示购买礼包确认框
    purchase_tag() {
      return this.$store.state.purchase_tag;
    },
  },
  mounted(){
    clickLog({type:2,state:this.isLogin?1:2});
  }
};
</script>
<style lang="scss" scoped>
.purchase{
    width: 100%;
    height: 23.4rem;
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    background-image: imgUrl("bg_purchase.png");
    .toIndex{
      position: absolute;
      top: 0.5rem;
      left: 0.5rem;
      font-size: 0.5rem;
    }
    .purchase_title{
        width: 8.27rem;
        height: 1.7rem;
        margin:1.5rem 0 0 0;
        background-image:imgUrl("purchase_title.png")
    }
    /deep/ .van-popup{
     background-color:transparent !important;
     overflow-y: scroll;
     .close{
         width: 0.7rem;
         height: 0.7rem;
         position: absolute;
         background-image: imgUrl("btn_close.png");
     }
     
   }
    .purchase_content{
        width: 9.27rem;
        height: 15.42rem;
        display: flex;
        justify-content: center;
        margin:0.3rem 0 0 0;
        background-image: imgUrl("bg_purchase_content.png");
        ul{
            margin:0.8rem 0 0 0;
            li{
                width:8rem;
                height:1.6rem;
                position: relative;
                display: flex;
                align-items: center;
                margin: 0 0 0.4rem 0;
                background-image: imgUrl("bg_purchase_li.png");
                .coin{
                    width: 10%;
                    height: auto;
                    margin: 0 0 0 0.5rem;
                }
                .desc{
                    margin: 0 0 0 0.7rem;
                    div{
                        &:nth-of-type(1){
                            font-size: 0.45rem;
                            color: #234469;
                            margin: 0 0 0.1rem 0 ;
                        }
                        &:nth-of-type(2){
                            font-size: 0.3rem;
                            color: #025C8C;
                        }
                    }
                }
                .btn{
                    position: absolute;
                    right: 0;
                    @include btn;
                }
            }
        }
    }
}
</style>