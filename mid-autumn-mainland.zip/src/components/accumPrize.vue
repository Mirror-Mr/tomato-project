<template>
  <!-- 累计奖励模块 -->
  <div class="accumPrize">
    <div class="accumPrize_title"></div>
    <div class="accumPrize_box">
      <div class="accumPrize_key">
        <span>累计消耗</span>
        <span>奖励</span>
      </div>
      <ul>
        <li v-for="item in accumPrize_list" :key="item.id">
          <div class="accum">
            {{ userMsg.use_start_num ? userMsg.use_start_num : 0 }}
            <br />
            / {{ item.accum }}
          </div>
          <div class="accum_prizes">
            <div>
              <!-- <img :src="`${baseUrl}accum${item.id}_1.png`" alt="" /> -->
              <img :src="`${baseUrl}accum1_1.png`" alt="" />
              <span>{{ item.prize[0] }}</span>
            </div>
            <div>
              <!-- <img :src="`${baseUrl}accum${item.id}_1.png`" alt="" /> -->
              <img :src="`${baseUrl}accum1_2.png`" alt="" />
              <span>{{ item.prize[1] }}</span>
            </div>
            <div>
              <!-- <img :src="`${baseUrl}accum${item.id}_3.png`" alt="" /> -->
              <img :src="`${baseUrl}accum1_3.png`" alt="" />
              <span>{{ item.prize[2] }}</span>
            </div>
          </div>
          <div
            class="btn_getAccumPrizes innerCenter"
            :class="{
              ban: userMsg.use_start_num
                ? userMsg.use_start_num < item.accum || exchanged[item.id] >= 1
                : true,
            }"
            @click="toSub(item)"
          >
            <template v-if="exchanged[item.id] >= 1"> 已领取 </template>
            <template v-else> 领取 </template>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import { subPrize } from "@/api/mainland";
import { mapState, mapMutations } from "vuex";

export default {
  name: "accumPrize",
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
      baseUrl1: "https://wcdn.tomatogames.com/static/zjfh/img/",
      // 累抽奖励列表
      accumPrize_list: [
        {
          id: 1,
          accum: 60,
          prize: ["保养油*1", "黄铜腰牌*1", "秦蒙笔*3"],
        },
        {
          id: 2,
          accum: 300,
          prize: ["保养油*2", "黄铜腰牌*2", "秦蒙笔*6"],
        },
        {
          id: 3,
          accum: 600,
          prize: ["保养油*3", "黄铜腰牌*3", "秦蒙笔*9"],
        },
        {
          id: 4,
          accum: 900,
          prize: ["保养油*4", "黄铜腰牌*4", "秦蒙笔*12"],
        },
        {
          id: 5,
          accum: 1500,
          prize: ["保养油*5", "黄铜腰牌*5", "秦蒙笔*15"],
        },
        {
          id: 6,
          accum: 2000,
          prize: ["保养油*8", "黄铜腰牌*8", "秦蒙笔*25"],
        },
      ],
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISBIND",
      "SET_MAINLANDLOGIN",
      "SET_ISLOGIN",
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
    ]),
    // 去兑换 参数奖品所有信息
    toSub(item) {
      // 已领取
      if (this.exchanged[item.id] >= 1) {
        this.$toast.fail("已领取");
      } else {
        this.$emit("setAccumPrize", item);
        this.SET_ISMASKSHOW(true);
        this.SET_MASKCONTENT("confirmGetAccum");
      }
    },
  },
  computed: {
    userMsg() {
      return this.$store.state.userMsg;
    },
    // 是否绑定角色
    isBind() {
      return this.$store.state.isBind;
    },
    isLogin() {
      return this.$store.state.isLogin;
    },
    // 消耗兑换已兑换的东西
    exchanged() {
      if (this.userMsg.prize) {
        return this.userMsg.prize["2"] ? this.userMsg.prize["2"] : {};
      }
      return {};
    },
  },
};
</script>
<style lang="scss" scoped>
.accumPrize{
    width: 100%;
    z-index: 2;
    .accumPrize_title{
    width: 100%;
    height: 1.7rem;
    margin: 0.7rem 0 0 0;
    background-image: imgUrl("accumPrize_title.png");
    }
    .accumPrize_box{
      width: 96%;
      height: 19rem;
      margin:-0.5rem 0 0 0.4rem;
      padding-top: 0.01rem;
      background-image: imgUrl("bg_accumPrize_box.png");
      .accumPrize_key{
          height: 0.8rem;
          display: flex;
          align-items: center;
          margin:2rem 0 0 0;
          font-size: 0.4rem;
          line-height: 0.41rem;
          color: #E45775;
          span{
            display: block;
            &:nth-of-type(1){
                width:0.9rem;
                margin:0 0 0 0.4rem;
            } 
            &:nth-of-type(2){
                margin:0 0 0 2.55rem;
                
            }
          }
      }
      ul{
      width: 100%;
      margin: 0 0 0 0.1rem;
        li{
          width: 98%;
          height:2.65rem;
          display: flex;
          align-items: center;
          background-image: imgUrl("accumPrize_cut.png");
          background-position:0.33rem 2.48rem;
          background-size: 85%;
          &:last-of-type{
          background-image:none;
          }
          div{
            height: 100%;
            &.accum{
                width: 1.5rem;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 0.4rem;
                color: #3C74AF;
                // background-color: red;
            }
            &.accum_prizes{
                display: flex;
                align-items: center;
                margin: 0 0 0 -0.1rem;
                div{
                width: 2rem;
                height: 1.69rem;
                position: relative;
                display: flex;
                justify-content: center;
                align-items: center;
                background-image: imgUrl("bg_accumPrize.png");
                &:nth-of-type(1){
                    margin:0 0 0 0.06rem;
                }
                &:nth-of-type(2){
                    margin:0 0 0 -0.1rem;
                }
                &:nth-of-type(3){
                    margin:0 0 0 -0.1rem;
                }
                img{
                    // width: 50%;
                    width:auto;
                    height: 40%;
                    margin: -0.2rem 0 0 0;
                }
                span{
                    position: absolute;
                    bottom: 0.22rem;
                    font-size: 0.27rem;
                    color: #4C89CB;
                }
              }
            }
            &.btn_getAccumPrizes{
                width: 1.71rem;
                height: 0.61rem;
                margin:-0.25rem 0 0 0rem;
                font-size: 0.33rem;
                color: #874B0C;
                background-image: imgUrl("btn_get.png");
                &.ban{
                  filter: grayscale(100%);
                }
            }
          }
        }
      }
    }
}
</style>