<template>
  <!-- 规则框 -->
  <div class="protectDefeat">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="protectDefeat_container" >
      <div class="protectDefeat_content">
        <span>追加失败，本次不掉星</span>
        <div class="innerCenter" @click="SET_ISMASKSHOW(false)">确认</div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { getUserInfo , lottery_draw } from "@/api/mainland";
export default {
  name: "ProtectDefeat",
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations(["SET_ISMASKSHOW", "SET_MASKCONTENT", "SET_COINTAG","SET_USERMSG"]),
  },
  computed: {
    // 登录的用户信息
    userMsg: {
      get() {
        return this.$store.state.userMsg;
      },
      set(n) {
        this.SET_USERMSG(n);
      },
    },
    // 获取的扭蛋
    draw_list(){
      return this.$store.state.draw_list;
    }
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.protectDefeat{
    .close{
        top: 0.1rem;
        right: 0.3rem;
        z-index: 2;
    }
     .protectDefeat_container{
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .protectDefeat_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
                margin:0.4rem 0 0 0;
            }
            div{
                margin:1.5rem 0 0 0;
                @include btn;
            }
        }
     }
}
</style>