<template>
  <!-- 规则框 -->
  <div class="rule_mask">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="rule_title innerCenter">
      <span></span>
      <span>活动规则</span>
      <span></span>
    </div>
    <div class="rule_content">
      <div v-for="(item, index) in content" :key="index">
        <span v-html="item.name"></span>
        <span v-html="item.desc"></span>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
export default {
  name: "RuleMask",
  data() {
    return {
      content: [
        {
          name: `玩法简介：`,
          desc: `启动扭蛋机，能随机获得一个扭蛋，每个扭蛋等级能对应领取相应的奖励；继续追加能再次随机获得一个扭蛋，当追加得到的扭蛋类型与当前的扭蛋类型一致，则能提升您的扭蛋等级奖励；当追加得到的扭蛋类型与当前的扭蛋类型不一致，则本轮活动结束`,
        },
        {
          name: `领取奖励：`,
          desc: `点击领取奖励，可以领取当前扭蛋等级所对应的奖励，领取奖励后则本轮结束，积累的扭蛋等级将被清空`,
        },
        {
          name: `普通追加：`,
          desc: `普通追加不收取追加费用，追加得到的扭蛋类型与当前扭蛋类型不一致，则本轮活动结束`,
        },
        {
          name: `保护追加：`,
          desc: `保护追加不会降低扭蛋等级，并且追加三次必定能提升扭蛋等级；保护追加需要消耗一定的幸运币，扭蛋等级越高，保护追加消耗的幸运币数量越多(1星*1；2星*3；3星*8；4星*26；5星*75；6星*138)`,
        },
        {
          name: `追加失败：`,
          desc: `非保护状态下追加失败，会随机降低1~2级扭蛋等级；降低后的扭蛋等级大于0则领取扭蛋等级对应的奖励；降低后的扭蛋等级小于0则领取保底奖励`,
        },
        {
          name: `保底奖励：`,
          desc: `当前星级降至0时，则获得保底月饼*4;`,
        },
        {
          name: `月饼：`,
          desc: `可用于兑换商店兑换各种稀有道具，仅在活动时间内有效，活动结束后道具将会清空`,
        },
        {
          name: `奖励补发：`,
          desc: `本期活动结束时，会清空当期的扭蛋等级，未领取的星级奖励将将会自动消失请注意领取时间`,
        },
        {
          name: `幸运币：`,
          desc: `活动参与道具，可通过购买礼包，仅在活动时间内有效，活动结束后道具将会清空`,
        },
        {
          name: `概率展示`,
          desc: `<br>扭蛋类型随机概率<br>每个类型扭蛋随出的概率均为20%<br>扭蛋星级随机概率1星82%，2星17%，3星1%<br>追加失败扭蛋等级降低概率降低1星75%，降低2星25%<br>*注意事项：本页面活动道具购买不参与游戏内充值活动，活动最终解释权归官方所有`,
        },
      ],
    };
  },
  methods:{
      ...mapMutations(["SET_ISMASKSHOW"])
  }
};
</script>
<style lang="scss" scoped>
.rule_mask{
    width:9.9rem;
    // padding: 1rem 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    .close{
        top: 1rem;
        right: 0.3rem;
    }
    .rule_title{
        width: 70%;
        height: 0.9rem;
        display: flex;
        font-size: 0.48rem;
        color: #FFEFB1;
        background-image: imgUrl("bg_title.png");
        span{
        &:nth-of-type(1),&:nth-of-type(3){
            width: 0.26rem;
            height: 0.26rem;
            display: block;
            background-image: imgUrl("rule_title_deco.png");
        }
        &:nth-of-type(2){
            margin: 0 0.2rem;
        }
    }
    }
    .rule_content{
        width: 95%;
        height: 19.3rem;
        padding: 0.8rem 0 0 0.2rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin:0.2rem 0 0 0rem;
        background-image: imgUrl("bg_rule_mask.png");

        // text-align: left;
        div{
            width: 84%;
            position: relative;
            margin: 0 0 0.3rem 0 ;
            text-align: justify;
            &::before{
                content:"";
                width: 0.31rem;
                height: 0.19rem;
                position: absolute;
                top: 0.1rem;
                left: -0.4rem;
                display: block;
                background-image: imgUrl("rule_content_deco.png");
                background-size: 100%;
                background-repeat: no-repeat;
            }
            span{
                font-size:0.32rem;   
                line-height: 0.4rem;
                &:nth-of-type(1){
                color: #268BC5;
                }
                &:nth-of-type(2){
                color: #153A4E;
                }
            }
        } 
        
    }
}
</style>