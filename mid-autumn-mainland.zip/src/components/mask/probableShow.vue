<template>
  <!-- 规则框 -->
  <div class="probableShow">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="probable_title innerCenter">
      <span></span>
      <span>概率展示</span>
      <span></span>
    </div>
    <div class="probable_content">
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
export default {
  name: "RuleMask",
  data() {
    return {
    };
  },
  methods:{
      ...mapMutations(["SET_ISMASKSHOW"])
  }
};
</script>
<style lang="scss" scoped>
.probableShow{
    width:9.9rem;
    // padding: 1rem 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    .close{
        top: 1rem;
        right: 0.3rem;
    }
    .probable_title{
        width: 70%;
        height: 0.9rem;
        display: flex;
        font-size: 0.48rem;
        color: #FFEFB1;
        background-image: imgUrl("bg_title.png");
        span{
        &:nth-of-type(1),&:nth-of-type(3){
            width: 0.26rem;
            height: 0.26rem;
            display: block;
            background-image: imgUrl("rule_title_deco.png");
        }
        &:nth-of-type(2){
            margin: 0 0.2rem;
        }
    }
    }
    .probable_content{
        width: 95%;
        height: 10.3rem;
        padding: 0.8rem 0 0 0.2rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin:0.2rem 0 0 0rem;
        background-image: imgUrl("bg_probableShow_mask.png");
    }
}
</style>