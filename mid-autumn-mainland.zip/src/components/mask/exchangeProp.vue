<template>
  <!-- 规则框 -->
  <div class="exchangeProp">
    <div class="exchangeProp_container" v-show="propShow == 'prop'">
      <div class="close" @click="SET_ISMASKSHOW(false)"></div>
      <div class="exchangeProp_title innerCenter">
        <span></span>
        <span>道具兑换</span>
        <span></span>
      </div>
      <div class="exchangeProp_content">
        <div class="top">
          <div class="goods_img innerCenter">
            <img :src="`${baseUrl}${propMsg.goods_img}`" alt="" />
          </div>
          <div>
            <span>{{ propMsg.name }}*{{ propMsg.goods_num }}</span>
            <span
              ><img :src="`${baseUrl}${propMsg.thing_img}`" alt="" />{{
                propMsg.thing_num
              }}</span
            >
          </div>
        </div>
        <div class="mid">
          <div>
            限购：{{ alreadyEx }} / <span>{{ propMsg.limit }}</span>
          </div>
          <div>
            <span @click="delPropNum" :class="{ ban: delBan }"></span>
            <span class="innerCenter">{{ propNum }}</span>
            <span @click="addPropNum" :class="{ ban: addBan }"></span>
          </div>
        </div>
        <div class="btm">
          <!-- <div>总计：</div> -->
          <div></div>
          <div class="innerCenter" @click="canExchange()">兑换</div>
        </div>
      </div>
    </div>
    <div class="exchangeResult_container" v-show="propShow == 'result'">
      <div class="close" @click="SET_ISMASKSHOW(false)"></div>
      <div class="exchangeResult_content">
        <span
          >是否将{{ propMsg.name }}*{{
            propMsg.goods_num * propNum
          }}奖励兑换到{{
            userMsg.info ? userMsg.info.rolename : ""
          }}（角色名）？</span
        >
        <div class="btn_group">
          <div class="innerCenter" @click="$emit('changePropShow', 'prop')">
            取消
          </div>
          <div class="innerCenter" @click="subPrize()">确认</div>
        </div>
      </div>
    </div>
    <div class="exchangeSuccess_container" v-show="propShow == 'success'">
      <div class="close" @click="SET_ISMASKSHOW(false)"></div>
      <div class="exchangeSuccess_content">
        <span v-if="propMsg.rid != 7 && propMsg.rid != 16 && propMsg.rid != 17"
          >兑换成功！请到游戏内邮箱领取。</span
        >
        <span v-else>兑换成功！请到活动内查看。</span>
        <div class="innerCenter" @click="successExchange">确认</div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { subPrize } from "@/api/mainland";
export default {
  name: "ExchangeProp",
  props: {
    propMsg: {
      type: Object,
      required: true,
    },
    propShow: {
      type: String,
      required: true,
    },
    propNum: {
      type: Number,
    },
  },
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_ISLOGIN",
      "SET_ISBIND",
    ]),
    successExchange() {
      this.SET_ISMASKSHOW(false);
    },
    // 添加购买量
    addPropNum() {
      if (
        this.propMsg.limit == "不限" ||
        this.propNum < this.propMsg.limit - this.alreadyEx
      ) {
        this.$emit("setPropNum", this.propNum + 1);
      }
    },
    // 减少购买量
    delPropNum() {
      if (this.propNum > 1) {
        this.$emit("setPropNum", this.propNum - 1);
      }
    },
    // 兑换
    subPrize() {
      this.$emit("subPrize", {
        type: 3,
        rid: this.propMsg.rid,
        num: this.propNum,
      });
    },
    // 判断能否兑换
    canExchange() {
      if (this.propMsg.limit == "不限") {
        this.$emit("changePropShow", "result");
        this.$emit("setPrevMask", "exchangeProp");
        return;
      }
      let limit = parseInt(this.propMsg.limit);
      let already = parseInt(this.alreadyEx);
      if (limit <= already) {
        // 已超限
        this.$toast.fail("兑换次数已超限");
        return;
      }
      this.$emit("changePropShow", "result");
      this.$emit("setPrevMask", "exchangeProp");
    },
  },
  mounted() {
    // console.log(this.propMsg);
    document
      .getElementsByClassName("top")[0]
      .classList.add(`goods${this.propMsg.x}_${this.propMsg.y}`);
  },
  watch: {
    propMsg() {
      document
        .getElementsByClassName("top")[0]
        .setAttribute("class", `top goods${this.propMsg.x}_${this.propMsg.y}`);
    },
  },
  computed: {
    userMsg() {
      return this.$store.state.userMsg;
    },
    // 兑换商店已兑换的东西
    exchanged() {
      if (this.userMsg.prize) {
        return this.userMsg.prize["3"] ? this.userMsg.prize["3"] : {};
      }
      return {};
    },
    // 是否禁用加号
    addBan() {
      if(this.propMsg.limit == "不限"){
        return false;
      }
      if (this.propNum >= this.propMsg.limit - this.alreadyEx) {
        // 按钮置灰
        return true;
      } else {
        return false;
      }
    },
    // 是否禁用减号
    delBan() {
      if (this.propNum <= 1) {
        // 按钮置灰
        return true;
      } else {
        return false;
      }
    },
    // 已买
    alreadyEx() {
      return this.exchanged[
        ((this.propMsg.x - 1) * 3 + this.propMsg.y).toString()
      ]
        ? this.exchanged[((this.propMsg.x - 1) * 3 + this.propMsg.y).toString()]
        : 0;
    },
  },
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.exchangeProp{
    .exchangeProp_container{
        .close{
            top: 1rem;
            right: 0.3rem;
        }
        width:9.9rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .exchangeProp_title{
            width: 70%;
            height: 0.9rem;
            display: flex;
            font-size: 0.48rem;
            color: #FFEFB1;
            background-image: imgUrl("bg_title.png");
            span{
                &:nth-of-type(1),&:nth-of-type(3){
                    width: 0.26rem;
                    height: 0.26rem;
                    display: block;
                    background-image: imgUrl("rule_title_deco.png");
                }
                &:nth-of-type(2){
                    margin: 0 0.2rem;
                }
            }
        }
        .exchangeProp_content{
            width: 95%;
            height: 7.3rem;
            padding: 0.8rem 0 0 0.2rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin:0.2rem 0 0 0rem;
            background-image: imgUrl("bg_exchangeProp.png");
            .top{
                display: flex;
                margin:0.2rem 0 0 0;
                div{
                    &:nth-of-type(1){
                        width: 2.27rem;
                        height: 1.76rem;
                        background-image:imgUrl("bg_prop.png");
                        img{
                            width: auto;
                            height: 78%;
                        }
                    }
                    &:nth-of-type(2){
                        // width: 2rem;
                        margin: 0 0 0 0.2rem;
                        display: flex;
                        flex-direction: column;
                        align-items: flex-start;
                        justify-content: center;
                        span{
                            &:nth-of-type(1){
                                font-size: 0.34rem;
                                color: #2A78BB;
                                letter-spacing: 0.05rem;
                            }
                            &:nth-of-type(2){
                                display: flex;
                                align-items: center;
                                margin: 0.2rem 0 0 0;
                                font-size: 0.32rem;
                                color: #2A78BB;
                                letter-spacing: 0.02rem;
                                img{
                                    width: 0.5rem;
                                    height: auto !important;
                                    margin: 0 0.1rem 0 0 !important;
                                }
                            }
                        }
                    }
                }
                &.goods1_1{
                    img{
                      height: 88% !important;
                      margin: 0rem 0 0 0rem !important;
                    }
                }
                &.goods1_2{
                    img{
                        height: 100% !important;
                    }
                }
                
                &.goods2_1{
                    img{
                      height: 65% !important;
                      margin: -0rem 0 0 -0.03rem !important;
                    }
                }&.goods2_2{
                    img{
                      height: 92% !important;
                      margin: -0rem 0 0 -0.03rem !important;
                    }
                }
                &.goods2_3{
                    img{
                      height: 80% !important;
                      margin: -0.05rem 0 0 -0.03rem !important;
                    }
                }
                &.goods5_3{
                  img{
                    height: 50% !important;
                    margin:0 0 0 0 !important;
                  }
                }
                &.goods6_1,
                &.goods6_2,
                &.goods6_3{
                    img{
                    height: 53% !important;
                    margin: 0rem 0 0 -0.03rem !important;
                    }
                }
                
            }
            .mid{
                div{
                    &:nth-of-type(1){
                        color: #327EBC;
                        font-size: 0.32rem;
                        margin: 0.53rem 0 0 0;
                    }
                    &:nth-of-type(2){
                        display: flex;
                        align-items: center;
                        margin:0.1rem 0 0 0;
                        span{
                            &:nth-of-type(1){
                                width: 0.75rem;
                                height: 0.75rem;
                                display: block;
                                background-image: imgUrl("btn_del.png");
                                &.ban{
                                  filter: grayscale(100%);
                                }
                            }
                            &:nth-of-type(2){
                                width: 2rem;
                                height: 0.55rem;
                                margin:0 0.13rem;
                                color: #fff;
                                font-size: 0.4rem;
                                background: #3071A9;
                                border-radius: 0.3rem;
                            }
                            &:nth-of-type(3){
                                width: 0.75rem;
                                height: 0.75rem;
                                display: block;
                                background-image: imgUrl("btn_add.png");
                                &.ban{
                                  filter: grayscale(100%);
                                }
                            }
                        }
                    }
                }
            }
            .btm{
                width: 85%;
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin:1rem 0 0 0;
                div{
                    &:nth-of-type(1){
                        font-size: 0.4rem;
                        color: #DCBE6F;
                        letter-spacing: 0.1rem;
                    }
                    &:nth-of-type(2){
                        @include btn;
                    }
                }
            }
        }
     }
     .exchangeResult_container{
        .close{
            top: 0.1rem;
            right: 0.3rem;
        }
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .exchangeResult_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
              width: 75%;
              margin:0.4rem 0 0 0;
            }
            .btn_group{
                width: 95%;
                margin: 1rem 0 0 0;
                display: flex;
                justify-content: space-around;
                div{
                    &:nth-of-type(1){
                        @include btn("bg_btn_blue.png",#fff)
                    }
                     &:nth-of-type(2){
                        @include btn;
                    }
                }
            }
        }
     }
     .exchangeSuccess_container{
        .close{
            top: 0.1rem;
            right: 0.3rem;
        }
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .exchangeSuccess_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
                margin:0.4rem 0 0 0;
            }
            div{
                margin:1.5rem 0 0 0;
                @include btn;
            }
        }
     }
}
</style>