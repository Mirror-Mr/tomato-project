<template>
  <!-- 规则框 -->
  <div class="hktwLogin">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="hktwLogin_title innerCenter">
      <span></span>
      <span>選擇登錄方式</span>
      <span></span>
    </div>
    <div class="hktwLogin_content">
      <div>
        <span
          v-for="(item, index) in 3"
          :key="index"
          @click="typeActive = index + 1"
        ></span>
      </div>
      <div @click="confirmLogin(typeActive)">確認</div>
    </div>
    <div class="btn-group">
      <button
        v-google-signin-button="clientId"
        class="google-signin-button"
        ref="google"
      ></button>
      <div class="apple-btn" ref="apple" id="appleid-signin"></div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
// import { getUserInfo } from "@/api/mainland";
import {
  hw_login
} from "@/api/hktw/index.js";
export default {
  name: "HktwLogin",
  data() {
    return {
      // 选择登录类型
      typeActive: 0,
      clientId:
        "595499418282-epmu56a6tluvalv8lofjecbdd7g7gh6i.apps.googleusercontent.com",
    };
  },
  methods: {
    ...mapMutations(["SET_ISMASKSHOW","SET_USERMSG","SET_MAINLANDLOGIN","SET_MASKCONTENT"]),
    // 选择登录方式
    confirmLogin(type) {
      if (type == 1) {
        this.FBLogin();
      } else if (type == 2) {
        this.$refs.google.click();
      } else if (type == 3) {
        this.$refs.apple.click();
      }
    },
    // 获取token
    getToken (id) {
      this.$toast.loading({
        message: "登錄中...",
        duration: 10000,
        overlay: true
      })
      const time = Date.now();
      const account_id = id;
      hw_login({time,account_id},{time,account_id}).then(res=>{
        if(res.code == 1){
          // 登录成功
          this.$toast.success(res.msg);
          this.SET_USERMSG(res.data);
          this.getUserInfo();
          // 弹出绑定角色
          this.SET_MASKCONTENT("mainland")
          this.SET_MAINLANDLOGIN("binding")
        }else{
          // 登录失败
          this.$toast.fail(res.msg);
        }
      })
    },
    // 获取用户信息
    getUserInfo(){
      this.$emit("getUserInfo")
    },
    // 谷歌登录回调
    onGoogleAuthSuccess (id) {
      // console.log(googleUser)
      this.getToken(id)
    },
    onGoogleAuthFail (error) {
      console.log(error)
    },
     // 苹果登录初始&&登录成功回调
    AppleInit () {
      const vm = this;
      this.$nextTick(() => {
        // Apple登录
        AppleID.auth.init({
          clientId: "com.zlihf.xianyugame.gat.service",
          redirectURI: "https://webtest.xianyuyouxi.com/haiwai/zjfh/taiwan/activity/mid-autumn/",
          usePopup: true, //or false defaults to false
          scope: "name",
          state: "state"
        });

        document.addEventListener("AppleIDSignInOnSuccess", data => {
          //handle successful response
          vm.getToken(data.detail.authorization.id_token);
        });
        //Listen for authorization failures
        document.addEventListener("AppleIDSignInOnFailure", error => {
          console.log(error);
          //handle error.
        });
      });
    },
    // facebook登錄
    FBLogin () {
      // 获取是否已登录状态
      const vm = this
      FB.getLoginStatus(function (response) {
        if (response.status == "connected") {
          FB.api("/me", function (response) {
            vm.getToken(response.id);
          });
        } else {
          FB.login(function (response) {
            if (response.authResponse) {
              FB.api("/me", function (response) {
                vm.getToken(response.id);
                // vm.publicLogin(1, response.id)
              });
            } else {
              console.log("User cancelled login or did not fully authorize.");
            }
          });
        }
      })
    },
  },
  mounted(){
    this.AppleInit();
  }
};
</script>
<style lang="scss" scoped>
.hktwLogin{
    width:9.9rem;
    // padding: 1rem 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    .close{
        top: 1rem;
        right: 0.3rem;
    }
    .hktwLogin_title{
        width: 70%;
        height: 0.9rem;
        display: flex;
        font-size: 0.48rem;
        color: #FFEFB1;
        background-image: imgUrl("bg_title.png");
        span{
        &:nth-of-type(1),&:nth-of-type(3){
            width: 0.26rem;
            height: 0.26rem;
            display: block;
            background-image: imgUrl("rule_title_deco.png");
        }
        &:nth-of-type(2){
            margin: 0 0.2rem;
        }
    }
    }
    .hktwLogin_content{
        width: 95%;
        height: 7rem;
        padding: 0.8rem 0 0 0.2rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin:0.2rem 0 0 0rem;
        background-image: imgUrl("bg_login.png");
        div{
            display: flex;
          &:nth-of-type(1){
            width: 75%;
            margin: 0.3rem 0 0 0;
            justify-content: space-between;
            span{
              width: 2rem;
              height: 2rem;
              display: block;
              &:nth-of-type(1){
                background-image: imgUrl("btn_facebook.png");
              }
              &:nth-of-type(2){
                background-image: imgUrl("btn_google.png");
              }
              &:nth-of-type(3){
                background-image: imgUrl("btn_apple.png");
              }
            }
          }
          &:nth-of-type(2){
              width: 2.68rem;
              height: 0.8rem;
              margin:0.6rem 0 0 0;
              justify-content: center;
              align-items: center;
              color:#874B0C;
              font-size: 0.4rem;
              background-image: imgUrl("btn_getGoods.png");
          }
        }
        
    }
    .btn-group{
      opacity: 0;
    }
}
</style>