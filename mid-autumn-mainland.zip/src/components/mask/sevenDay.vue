<template>
  <!-- 规则框 -->
  <div class="sevenDay">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="sevenDay_title innerCenter">
      <span></span>
      <span>七天登录领好礼</span>
      <span></span>
    </div>
    <div class="sevenDay_content">
      <div class="content_title">
        您已累计登录<span>{{ userMsg.login_num ? userMsg.login_num : 0 }}</span
        >天
      </div>
      <div class="group_dayCard1 group_dayCard">
        <div
          v-for="(item, index) in 3"
          :key="index"
          :class="`dayCard dayCard${index + 1}`"
        >
          <div>第{{ sevenDay_list[index].title }}天登录</div>
          <img :src="`${baseUrl}${sevenDay_list[index].img}`" />
          <span>{{ sevenDay_list[index].thing }}</span>
          <div
            @click="subPrize(index + 1)"
            class="innerCenter"
            :class="{
              ban: userMsg.login_num
                ? userMsg.login_num < index + 1 || exchanged[index + 1] >= 1
                : true,
            }"
          >
            <template
              v-if="exchanged[index + 1] ? exchanged[index + 1] >= 1 : false"
              >已领取</template
            >
            <template v-else>领取</template>
          </div>
        </div>
      </div>
      <div class="group_dayCard2 group_dayCard">
        <div
          v-for="(item, index) in 3"
          :key="index"
          :class="`dayCard dayCard${index + 4}`"
        >
          <div>第{{ sevenDay_list[index + 3].title }}天登录</div>
          <img :src="`${baseUrl}${sevenDay_list[index + 3].img}`" />
          <span>{{ sevenDay_list[index + 3].thing }}</span>
          <div
            @click="subPrize(index + 4)"
            class="innerCenter"
            :class="{
              ban: userMsg.login_num
                ? userMsg.login_num < index + 4 || exchanged[index + 4] >= 1
                : true,
            }"
          >
            <template
              v-if="exchanged[index + 4] ? exchanged[index + 4] >= 1 : false"
              >已领取</template
            >
            <template v-else>领取</template>
          </div>
        </div>
      </div>
      <div class="group_dayCard3 group_dayCard">
        <div class="dayCard dayCard7">
          <div>第{{ sevenDay_list[6].title }}天登录</div>
          <img :src="`${baseUrl}${sevenDay_list[6].img}`" />
          <span>{{ sevenDay_list[6].thing }}</span>
          <div
            @click="subPrize(7)"
            class="innerCenter"
            :class="{
              ban: userMsg.login_num
                ? userMsg.login_num < 7 || exchanged[7] >= 1
                : true,
            }"
          >
            <template v-if="exchanged[7] ? exchanged[7] >= 1 : false"
              >已领取</template
            >
            <template v-else>领取</template>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { subPrize } from "@/api/mainland";

export default {
  name: "RuleMask",
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
      sevenDay_list: [
        {
          id: 1,
          title: "一",
          img: "one_coin.png",
          thing: `幸运币*1`,
          t_id: null,
          kind: null,
        },
        {
          id: 2,
          title: "二",
          img: "one_coin.png",
          thing: `幸运币*3`,
          t_id: null,
          kind: null,
        },
        {
          id: 3,
          title: "三",
          img: "thing7_2.png",
          thing: `头像：萌二哈`,
          t_id: 18,
          kind: 98,
        },
        {
          id: 4,
          title: "四",
          img: "one_coin.png",
          thing: `幸运币*6`,
          t_id: null,
          kind: null,
        },
        {
          id: 5,
          title: "五",
          img: "thing7_1.png",
          thing: `头像框：汪汪大吉`,
          t_id: 229,
          kind: 94,
        },
        {
          id: 6,
          title: "六",
          img: "one_coin.png",
          thing: `幸运币*9`,
          t_id: null,
          kind: null,
        },
        {
          id: 7,
          title: "七",
          img: "dog.png",
          thing: `宠物：萌二哈`,
          t_id: 3151,
          kind: 95,
        },
      ],
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_ISLOGIN",
      "SET_ISBIND",
    ]),
    // 领取登录奖励
    subPrize(rid) {
      if (this.isBind) {
        if (this.exchanged[rid] >= 1) {
          // 已领取
          this.$toast.fail("已领取");
        } else {
          this.$emit("subPrize", { type: 1, rid, num: 1 });
        }
      } else {
        this.SET_ISMASKSHOW(true);
        this.SET_MASKCONTENT("mainland");
        // 关闭回到登录领取页
        this.$emit("setPrevMask", "sevenDay");
      }
    },
  },
  computed: {
    userMsg() {
      return this.$store.state.userMsg;
    },
    // 七天登录已兑换的东西
    exchanged() {
      if (this.userMsg.prize) {
        return this.userMsg.prize["1"] ? this.userMsg.prize["1"] : {};
      }
      return {};
    },
    isBind() {
      return this.$store.state.isBind;
    },
  },
};
</script>
<style lang="scss" scoped>
.sevenDay{
    width:9.9rem;
    // padding: 1rem 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    .close{
        top: 1rem;
        right: 0.45rem;
    }
    .sevenDay_title{
        width: 70%;
        height: 0.9rem;
        display: flex;
        font-size: 0.48rem;
        color: #FFEFB1;
        background-image: imgUrl("bg_title.png");
        span{
        &:nth-of-type(1),&:nth-of-type(3){
            width: 0.26rem;
            height: 0.26rem;
            display: block;
            background-image: imgUrl("rule_title_deco.png");
        }
        &:nth-of-type(2){
            margin: 0 0.2rem;
        }
    }
    }
    .sevenDay_content{
        width: 95%;
        height: 20.1rem;
        padding: 0.8rem 0 0 0.2rem;
        // display: flex;
        // flex-direction: column;
        // align-items: center;
        margin:0.2rem 0 0 0rem;
        background-image: imgUrl("bg_sevenDay_mask.png");
        .content_title{
            margin:0.03rem 0 0 0;
            font-size: 0.4rem;
            color: #3071A9;
        }
        .group_dayCard{
            padding-top: 0.01rem;
            text-align: left;
            display: flex;
            justify-content: flex-start;
            .dayCard{
                width: 2.36rem;
                height: 3.47rem;
                position: relative;
                display: flex;
                flex-direction: column;
                align-items: center;
                vertical-align: top;
                // display:inline-block;
                background-image: imgUrl("bg_dayCard.png");
                div{
                    &:nth-of-type(1){
                        width: 55%;
                        margin:0.03rem 0 0 0;
                        text-align: center;
                        font-size: 0.4rem;
                        color: #FFFFFF;
                        line-height: 0.4rem;
                    }
                    &:nth-of-type(2){
                        width: 2.23rem;
                        height: 0.65rem;
                        position: absolute;
                        bottom: -0.8rem;
                        color: #874B0C;
                        background-image: imgUrl("btn_getGoods.png");
                        &.ban{
                            filter:grayscale(100%);
                        }
                    }
                }
                img{
                    width: 40%;
                    margin: 0.75rem 0 0 0;
                }
                span{
                    position: absolute;
                    bottom: 0.2rem;
                    font-size: 0.29rem;
                    color: #4481C1;
                }
                
            }
            &.group_dayCard1{
                margin: 1.35rem 0 0 0;
                .dayCard1{
                    margin: 0.2rem 0 0 0.45rem;
                }
                .dayCard2{
                    margin: 0.6rem 0 0 0.45rem;
                }
                .dayCard3{
                    margin: 0 0 0 0.4rem;
                }
            }
            &.group_dayCard2{
                margin:1.9rem 0 0 0;
                .dayCard4{
                    margin:0 0 0 0.45rem;
                }
                .dayCard5{
                    margin: 0.2rem 0 0 0.45rem;
                }
                .dayCard6{
                    margin: 0.5rem 0 0 0.4rem;
                }
            }
            &.group_dayCard3{
                margin:2.15rem 0 0 3.25rem;
                 img{
                    width: 26%;
                    margin: 0.75rem 0 0 0;
                }
            }
        }
    }
}
</style>