<template>
  <!-- 确认获取累计奖励 -->
  <div class="eggFailGetPrize">
    <div class="eggFailGetPrize_container">
      <div class="close" @click="SET_ISMASKSHOW(false)"></div>
      <div class="eggFailGetPrize_content">
        <span
          >追加失败，降至{{ defeatStar }}星，对应奖励
          <b class="red"> {{ prizeList[defeatStar] }} </b
          >已发，请到活动内查看。</span
        >
        <div class="btn_group">
          <!-- <div class="innerCenter" @click="SET_ISMASKSHOW(false)">取消</div> -->
          <div class="innerCenter" @click="SET_ISMASKSHOW(false)">确认</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { subPrize } from "@/api/mainland";
export default {
  name: "eggFailGetPrize",
  props: {
    defeatStar: {
      type: Number,
    },
  },
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
      prizeList: [
        "月饼*4",
        "月饼*24",
        "月饼*64",
        "月饼*108",
        "月饼*320",
        "月饼*960",
        "桂花酒*3",
        "桂花酒*9",
      ],
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_ISLOGIN",
      "SET_ISBIND",
    ]),
  },
  mounted() {},
  computed: {
    userMsg() {
      return this.$store.state.userMsg;
    },
  },
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.eggFailGetPrize{
     .eggFailGetPrize_container{
        .close{
            top: 0.1rem;
            right: 0.3rem;
        }
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .eggFailGetPrize_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
              width: 75%;
              line-height: 0.55rem;
              margin:0.4rem 0 0 0;
              text-align: justify;
            }
            .btn_group{
                width: 95%;
                margin: 0.5rem 0 0 0;
                display: flex;
                justify-content: space-around;
                div{
                  @include btn;
                }
            }
        }
     }
}
</style>