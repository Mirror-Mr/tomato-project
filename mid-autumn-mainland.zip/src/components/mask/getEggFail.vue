<template>
  <!-- 规则框 -->
  <div class="getEggFail">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="getEggFail_container">
      <div class="getEggFail_content">
        <span>您的幸运币不足！</span>
        <span>是否需要充值？</span>
        <div class="btn_group">
          <div class="innerCenter" @click="cancelPurchase()">取消</div>
          <div class="innerCenter" @click="toPurchase()">去充值</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { getUserInfo, lottery_draw } from "@/api/mainland";
export default {
  name: "GetEggFail",
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_COINTAG",
      "SET_USERMSG",
    ]),
    // 取消充值
    cancelPurchase() {
      this.SET_ISMASKSHOW(false);
    },
    // 去充值
    toPurchase() {
      this.SET_ISMASKSHOW(false);
      // 链接带参数则不改参数
      let params = location.href.split("?")[1]; //参数
      let url;
      if (params) {
        url = `/purchase?${params}`;
      } else {
        url = "/purchase";
      }
      this.$router.push(url);
    },
  },
  computed: {},
  mounted() {},
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.getEggFail{
    .close{
        top: 0.1rem;
        right: 0.3rem;
        z-index: 2;
    }
     .getEggFail_container{
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .getEggFail_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
                margin:0.4rem 0 0 0;
            }
            .btn_group{
                width: 90%;
                display: flex;
                justify-content: space-around;
                margin:1rem 0 0  0;
                div{
                    &:nth-of-type(1){
                        @include btn("bg_btn_blue.png",#fff)
                    }
                    &:nth-of-type(2){
                        @include btn;
                    }
                }
            }
        }
     }
}
</style>