<template>
  <!-- 规则框 -->
  <div class="generalGetEgg">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="generalGetEgg_container">
      <div class="generalGetEgg_content">
        <span
          >普通追加获得不同类型的扭蛋将会降低扭蛋等级并结束本轮，是否继续？</span
        >
        <div class="checkBox" @click="general_tag = !general_tag">
          <i
            :class="{
              iconfont: true,
              'icon-no-check': general_tag,
              'icon-check': !general_tag,
            }"
          ></i
          >今日不再提示
        </div>
        <div class="btn_group">
          <div
            class="innerCenter"
            @click="
              SET_GENERALTAG(true);
              SET_ISMASKSHOW(false);
            "
          >
            取消
          </div>
          <div class="innerCenter" @click="confirmDraw()">确认</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { getUserInfo, lottery_draw } from "@/api/mainland";
import clickLog from "@/api/toDots.js";

export default {
  name: "GeneralGetEgg",
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_GENERALTAG",
      "SET_USERMSG",
      "SET_GRAWLIST",
      "SET_ISLOGIN",
      "SET_ISBIND",
      "SET_MAINLANDLOGIN",
      "SET_DRAWDEFEAT",
      "SET_GENERALTAG"
    ]),
    // 确认抽奖
    confirmDraw() {
      // this.lottery_draw(2);
      this.$emit("lottery_draw",2)
      clickLog({type:3,state:this.isLogin?1:2});
    },
    // 抽奖 1初始抽奖 2普通抽奖 3保护抽奖
    lottery_draw(type) {
      const time = Date.now();
      const { token } = this.userMsg;
      lottery_draw({ time, token, type }, { time, token }).then((res) => {
        console.log(res);
        if (res.status == 1) {
          // 抽奖成功
          this.SET_GRAWLIST(res.data);
          this.$emit("getUserInfo");
          // this.getUserInfo();
          this.SET_MASKCONTENT("getEggSuccess");
          this.SET_DRAWDEFEAT(false)
        } else {
          if (res.status == 4040) {
            // 登录失效 需要重新登录
            this.$toast.fail("登录过期，请重新登录");
            this.SET_ISLOGIN(false);
            this.SET_ISBIND(false);
            this.SET_ISMASKSHOW(true);
            this.SET_MASKCONTENT("mainland");
            this.SET_MAINLANDLOGIN("chooseWay");
            this.SET_USERMSG({});
          }else if(res.msg == '追加失败，奖励已发，请重新开始游戏'){
            // 追加失败
            this.SET_DRAWDEFEAT(true)
            this.$toast.fail(res.msg);
          } else {
            this.$toast.fail(res.msg);
          }
        }
      });
    },
  },
  computed: {
    // 登录的用户信息
    userMsg: {
      get() {
        return this.$store.state.userMsg;
      },
      set(n) {
        this.SET_USERMSG(n);
      },
    },
    general_tag: {
      set(n) {
        this.SET_GENERALTAG(n);
      },
      get() {
        return this.$store.state.general_tag;
      },
    },
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.generalGetEgg{
    .close{
        top: 0.1rem;
        right: 0.3rem;
        z-index: 2;
    }
    .generalGetEgg_container{
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .generalGetEgg_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
                width: 80%;
                line-height: 0.6rem;
                margin:0.3rem 0 0 0;
            }
            .checkBox{
                display: flex;
                align-items: center;
                margin: 0.5rem 0 0 0;
                font-size: 0.33rem;
                i{
                    font-size:0.4rem;
                    margin: 0 0.2rem 0 0;
                }
            }
            .btn_group{
                width: 90%;
                display: flex;
                justify-content: space-around;
                margin:0.3rem 0 0  0;
                div{
                    &:nth-of-type(1){
                        @include btn("bg_btn_blue.png",#fff)
                    }
                    &:nth-of-type(2){
                        @include btn;
                    }
                }
            }
        }
     }
}
</style>