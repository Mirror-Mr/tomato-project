<template>
  <!-- 规则框 -->
  <div class="mainlandLogin">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="chooseWay_title innerCenter">
      <span></span>
      <span>{{ login_title }}</span>
      <span></span>
    </div>
    <div class="login_content" :class="{ binding: mainlandLogin == 'binding' }">
      <!-- 选择登录方式 -->
      <div class="chooseWayLogin" v-show="mainlandLogin == 'chooseWay'">
        <div class="btnGroup_chooseWay" @click="chooseWay">
          <!-- 1手机号 默认方式1手机号   2账号 -->
          <div>
            <span
              class="phone"
              @click="loginWay = 1"
              :class="{ choose: loginWay == 1 }"
            ></span>
            <span>手机登录</span>
          </div>
          <div>
            <span
              class="account"
              @click="loginWay = 2"
              :class="{ choose: loginWay == 2 }"
            ></span>
            <span>账号登录</span>
          </div>
        </div>
        <div
          class="btn_check"
          @click="
            loginWay == 1
              ? SET_MAINLANDLOGIN('phone1')
              : SET_MAINLANDLOGIN('account')
          "
        ></div>
      </div>
      <!-- 手机登录1 -->
      <div class="way_phone1" v-show="mainlandLogin == 'phone1'">
        <input
          class="phoneNum"
          type="text"
          placeholder="请输入手机号"
          v-model="loginMsg[1].phoneNum"
        />
        <div class="codeGroup">
          <input
            class="phoneCode"
            type="text"
            placeholder="请输入验证码"
            v-model="loginMsg[1].phoneCode"
          />
          <div class="getCode innerCenter" @click="getCode">
            {{ loginMsg[1].codeMsg }}
          </div>
        </div>
        <span @click="SET_MAINLANDLOGIN('phone2')">密码登录</span>
        <div class="btn_group">
          <div class="innerCenter" @click="SET_MAINLANDLOGIN('chooseWay')">
            返回
          </div>
          <div class="innerCenter" @click="login(1)">确认</div>
        </div>
      </div>
      <!-- 手机登录2 -->
      <div class="way_phone2" v-show="mainlandLogin == 'phone2'">
        <input
          class="phoneNum"
          type="text"
          placeholder="请输入手机号"
          v-model="loginMsg[2].phoneNum"
        />
        <input
          class="password"
          type="password"
          placeholder="请输入密码"
          v-model="loginMsg[2].password"
        />
        <span @click="SET_MAINLANDLOGIN('phone1')">验证码登录</span>
        <div class="btn_group">
          <div class="innerCenter" @click="SET_MAINLANDLOGIN('chooseWay')">
            返回
          </div>
          <div class="innerCenter" @click="login(2)">确认</div>
        </div>
      </div>
      <!-- 账号登录 -->
      <div class="way_account" v-show="mainlandLogin == 'account'">
        <input
          class="accountNum"
          type="text"
          placeholder="请输入账号"
          v-model="loginMsg[3].phoneNum"
        />
        <input
          class="password"
          type="password"
          placeholder="请输入密码"
          v-model="loginMsg[3].password"
        />
        <div class="btn_group">
          <div class="innerCenter" @click="SET_MAINLANDLOGIN('chooseWay')">
            返回
          </div>
          <div class="innerCenter" @click="login(3)">确认</div>
        </div>
      </div>
      <!-- 绑定角色 -->
      <div class="binding_role" v-show="mainlandLogin == 'binding'">
        <div class="platform" @click="choosePlatForm">
          <b>平台：</b>
          <div>
            {{ roleMsg.platform }}
            <span></span>
          </div>
        </div>
        <div class="role_id" @click="chooseRoleId">
          <b>ID：</b>
          <div>
            {{ roleMsg.role_id }}
            <span></span>
          </div>
        </div>
        <div class="role_name">
          <b>角色：</b>
          <div>
            {{ roleMsg.server_name ? roleMsg.server_name : "" }}
            {{ roleMsg.role_name }}
            <span></span>
          </div>
        </div>
        <div class="innerCenter" @click="checkBindRole">确认</div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations, mapState } from "vuex";
import { validatePhone } from "@/utils/validate";
import sendCode from "@/api/sendCode";
import { login, getUserInfo, bindRole } from "@/api/mainland/index.js";

export default {
  name: "MainlandLogin",
  props: {},
  data() {
    return {
      project_id: 24,
      // 登录方式 默认手机1 账号2
      loginWay: 1,
      // 登录信息 1手机验证码登录 2手机密码登录 3账号密码登录
      loginMsg: [
        {},
        {
          phoneNum: "",
          phoneCode: "",
          timer: null,
          // 获取手机号验证码请求是否执行完
          isGetCode: true,
          codeMsg: "获取验证码",
        },
        {
          phoneNum: "",
          password: "",
        },
        {
          phoneNum: "",
          password: "",
        },
      ],
      // 用户信息
      loginUserMsg: {},
      // 平台
      platform: ["安卓", "IOS"],
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_ISLOGIN",
      "SET_USERMSG",
      "SET_ISSHOWPOP",
      "SET_ISBIND",
      "SET_MAINLANDLOGIN",
    ]),
    chooseWay() {},
    // 判断手机号是否合规 1手机验证 2手机密码 3账号密码
    checkPhone(n) {
      try {
        if (!this.loginMsg[n].phoneNum) throw "请输入手机号";
        if (!validatePhone(this.loginMsg[n].phoneNum))
          throw "请输入正确的手机号";
      } catch (err) {
        this.$toast(err);
        return false;
      }
      return true;
    },
    // 判断验证码是否合规
    checkCode() {
      try {
        if (!this.loginMsg[1].phoneCode) throw "请输入验证码";
        if (this.loginMsg[1].phoneCode.length != 6) throw "请输入6位数验证码";
      } catch (err) {
        this.$toast(err);
        return false;
      }
      return true;
    },
    // 获取验证码
    getCode() {
      if (this.checkPhone(1)) {
        this.loginMsg[1].isGetCode = false;
        sendCode(this.loginMsg[1].phoneNum).then((res) => {
          if (res.status == 1) {
            this.$toast.success(res.msg);
            let num = 90;
            this.loginMsg[1].timer = setInterval(() => {
              this.loginMsg[1].codeMsg = `${num--}s后重新发送`;
              if (num == 0) {
                this.loginMsg[1].codeMsg = "重新发送";
                clearInterval(this.loginMsg[1].timer);
                this.loginMsg[1].timer = null;
              }
            }, 1000);
          } else {
            this.$toast.fail(res.msg);
          }
          this.loginMsg[1].isGetCode = true;
        });
      }
    },
    // 国内登录 1手机号验证码 2手机号密码 3账号密码
    login(n) {
      if ((n == 3 || this.checkPhone(n)) && (n != 1 || this.checkCode())) {
        const time = Date.now();
        const { project_id } = this;
        const account = this.loginMsg[n].phoneNum;
        const type = n == 1 ? 2 : 1;
        const password = this.loginMsg[n].password
          ? this.loginMsg[n].password
          : "";
        const code = this.loginMsg[n].phoneCode
          ? this.loginMsg[n].phoneCode
          : "";
        const params = { time, account, type, password, code, project_id };
        const headers = { time, account, type };
        login(params, headers).then((res) => {
          if (res.status == 1) {
            // 登录成功
            this.$toast.success(res.msg);
            this.SET_ISLOGIN(true);
            this.loginUserMsg = { ...res.data };
            // res.data 登录用户的token和uid 本地存储
            localStorage.setItem("userMsg", JSON.stringify(res.data));
            this.SET_USERMSG(this.loginUserMsg);
            // 获取登录用户信息
            this.$emit("getUserInfo");
            // this.getUserInfo();
            // 弹出绑定角色
            this.SET_MAINLANDLOGIN("binding");
            // 默认安卓
            this.$emit("confirmPlatform", "安卓");
            if (this.loginMsg[n].password) {
              this.loginMsg[n].password = "";
            }
            if (this.loginMsg[n].phoneCode) {
              this.loginMsg[n].phoneCode = "";
            }
            this.loginMsg[n].phoneNum = "";
          } else {
            // 登录失败
            this.$toast.fail(res.msg);
          }
        });
      }
    },
    // 获取用户信息
    getUserInfo() {
      const time = Date.now();
      const { token } = this.loginUserMsg;
      getUserInfo({ time, token }, { time, token }).then((res) => {
        console.log(res);
        if (res.status == 1) {
          // 获取用户信息成功
          this.loginUserMsg = Object.assign({}, this.loginUserMsg, res.data);
          console.log(this.loginUserMsg);
          this.SET_USERMSG(this.loginUserMsg);
          this.SET_ISLOGIN(true);
        } else {
          this.$toast.fail(res.msg);
        }
      });
    },

    // 选择平台
    choosePlatForm() {
      this.isShowPop.status = true;
      this.isShowPop.type = 1;
    },
    // 选择角色id
    chooseRoleId() {
      this.isShowPop.status = true;
      this.isShowPop.type = 2;
    },
    // 确定绑定角色
    checkBindRole() {
      if (
        !this.roleMsg.platform ||
        !this.roleMsg.server_id ||
        !this.roleMsg.server_name
      ) {
        this.$toast.fail("请选择要绑定的角色信息");
      } else {
        const time = Date.now();
        const { token } = this.userMsg;
        // console.log(this.userMsg);
        const channel = this.roleMsg.platform == "安卓" ? 1 : 3;
        const sid = this.roleMsg.server_id;
        const sname = this.roleMsg.server_name;
        const rolename = this.roleMsg.role_name ? this.roleMsg.role_name : 1;
        const rid = this.roleMsg.role_id;
        bindRole(
          { time, token, channel, sid, sname, rolename, rid },
          { time, token }
        ).then((res) => {
          if (res.status == 1) {
            // 绑定成功
            this.$toast.success(res.msg);
            this.SET_ISBIND(true);
            this.SET_ISMASKSHOW(false);
            // 获取登录用户信息
            this.$emit("getUserInfo");
          } else {
            this.$toast.fail(res.msg);
          }
        });
      }
    },
  },
  computed: {
    login_title() {
      if (this.mainlandLogin == "chooseWay") {
        return "选择登录方式";
      } else if (
        this.mainlandLogin == "phone1" ||
        this.mainlandLogin == "phone2"
      ) {
        return "手机登录";
      } else if (this.mainlandLogin == "account") {
        return "账号登录";
      } else if (this.mainlandLogin == "binding") {
        return "绑定角色";
      } else {
        return null;
      }
    },
    userMsg() {
      return this.$store.state.userMsg;
    },
    roleMsg() {
      return this.$store.state.roleMsg;
    },
    isShowPop() {
      return this.$store.state.isShowPop;
    },
    mainlandLogin() {
      return this.$store.state.mainlandLogin;
    },
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
.mainlandLogin{
    width:9.9rem;
    // padding: 1rem 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    
    .close{
        top: 0.95rem;
        right: 0.55rem;
    }
    .chooseWay_title{
        width: 70%;
        height: 0.9rem;
        display: flex;
        font-size: 0.48rem;
        color: #FFEFB1;
        background-image: imgUrl("bg_title.png");
        span{
        &:nth-of-type(1),&:nth-of-type(3){
            width: 0.26rem;
            height: 0.26rem;
            display: block;
            background-image: imgUrl("rule_title_deco.png");
        }
        &:nth-of-type(2){
            margin: 0 0.2rem;
        }
    }
    }
    .login_content{
        width: 91%;
        height: 6.3rem;
        margin:0.2rem 0 0 0rem;
        background-image: imgUrl("bg_login.png");
        &.binding{
          height: 6.7rem;
          background-image: imgUrl("bg_binding.png");
        }
        // 输入框placeholder字体颜色
        input::-webkit-input-placeholder {
          /* WebKit browsers */
          color: #94CAF8;
        }
        input:-moz-placeholder {
          /* Mozilla Firefox 4 to 18 */
          color: #94CAF8;
        }
        input::-moz-placeholder {
          /* Mozilla Firefox 19+ */
          color: #94CAF8;
        }
        input:-ms-input-placeholder {
          /* Internet Explorer 10+ */
          color: #94CAF8;
        }
        input{
            width: 6.51rem;
            height: 0.95rem;
            padding: 0 0 0 0.32rem;
            background: #3071A9;
            font-size: 0.4rem;
            color: #94CAF8;
            border: 0.01px solid #EEF7FF;
        }
        & > div{
          width: 100%;
          height: 100%;
          display: flex;
          flex-direction: column;
          align-items: center;
        }
        // 选择登录方式
        .chooseWayLogin{
          margin: 1rem 0 0 0;
          div{
            &.btnGroup_chooseWay{
              width: 50%;
              display: flex;
              justify-content: space-between;
              div{
                &:nth-of-type(1){
                  span{
                    &:nth-of-type(1){
                      background-image: imgUrl("login_phone.png");
                    }
                  }
                }
                &:nth-of-type(2){
                  span{
                    &:nth-of-type(1){
                      background-image: imgUrl("login_account.png");
                    }
                  }
                }
              }
              
            }
            &.btn_check{
              width: 2.68rem;
              height: 0.8rem;
              background-image: imgUrl("btn_check.png");
              margin:0.6rem 0 0 0;
            }
          }
          span{
                &:nth-of-type(1){
                  width: 1.74rem;
                  height: 1.74rem;
                  margin: 0 0 0.2rem 0;
                  display: block;
                  border: 1px solid transparent;
                  &.choose{
                    border: 1px solid #016CA9;
                    border-radius: 0.1rem;
                  }
                }
                &:nth-of-type(2){
                  color: #2A78BB;
                  font-size: 0.4rem;
                }
              }
        }
        // 手机登录1
        .way_phone1{
          margin:0.9rem 0 0 0;
          input{
            .phoneNum{

            }
          }
          .codeGroup{
            display: flex;
            margin:0.4rem 0 0 0;
            .phoneCode{
                width: 3.8rem;
                border-right: none;
              }
            .getCode{
              width: 2.71rem;
              height: 0.95rem;
              font-size: 0.4rem;
              color: #FFFFFF;
              background-color:#4FAEFF;
              border: 0.01px solid #EEF7FF;
              border-left: none;
            }
          }
          span{
            margin: 0.13rem 1.25rem 0 0;
            align-self: flex-end;
            font-size: 0.35rem;
            color: #3071A9;
          }
          .btn_group{
            width: 70%;
            display: flex;
            justify-content: space-around;
            margin:0.4rem 0 0  0;
            div{
              
              &:nth-of-type(1){
                @include btn("bg_btn_blue.png",#fff)
              }
              &:nth-of-type(2){
                @include btn;
              }
            }
          }
        }
        // 手机登录2
        .way_phone2{
          margin:0.9rem 0 0 0;
          input{
            &:nth-of-type(2){
              margin:0.4rem 0 0 0;
            }
            .phoneNum{

            }
          }
          span{
            margin: 0.13rem 1.25rem 0 0;
            align-self: flex-end;
            font-size: 0.35rem;
            color: #3071A9;
          }
          .btn_group{
            width: 70%;
            display: flex;
            justify-content: space-around;
            margin:0.4rem 0 0  0;
            div{
              &:nth-of-type(1){
                @include btn("bg_btn_blue.png",#fff)
              }
              &:nth-of-type(2){
                @include btn;
              }
            }
          }
        }
        // 账号
        .way_account{
          margin:0.9rem 0 0 0;
          input{
            &:nth-of-type(2){
              margin:0.4rem 0 0 0;
            }
            .phoneNum{

            }
          }
          
          .btn_group{
            width: 70%;
            display: flex;
            justify-content: space-around;
            margin:0.85rem 0 0  0;
            div{
              &:nth-of-type(1){
                @include btn("bg_btn_blue.png",#fff)
              }
              &:nth-of-type(2){
                 @include btn;
              }
            }
          }
        }
        // 绑定角色
        .binding_role{
          margin: 0.8rem 0 0 0;
          & > div{
            width: 70%;
            display: flex;
            align-items: center;
            b{
              width: 20%;
              color: #3071A9;
              text-align: left;
              font-size: 0.4rem;
            }
            div{
              width: 5.21rem;
              height: 0.95rem;
              padding:0 0 0 0.3rem;
              position: relative;
              display: flex;
              align-items: center;
              justify-content: flex-start;
              font-size: 0.4rem;
              color: #94CAF8;
              background: #3071A9;
              border: 0.01px solid #EEF7FF;
              span{
                width: 0.32rem;
                height: 0.16rem;
                position:absolute;
                right: 0.2rem;
                display: block;
                background-image: imgUrl("arrow.png");
              }
            }
            &:nth-of-type(2),
            &:nth-of-type(3){
              margin: 0.4rem 0 0 0;
            }
            &:nth-of-type(3){
               span{
                  display: none;
                }
            }
            &:nth-of-type(4){
              margin: 0.63rem;
              border:none;
              @include btn;
            }
          }
        }
    }
    
}


</style>