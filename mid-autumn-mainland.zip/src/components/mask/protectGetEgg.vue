<template>
  <!-- 规则框 -->
  <div class="protectGetEgg">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="protectGetEgg_container">
      <div class="protectGetEgg_content">
        <span>本次消耗幸运币*{{needCoin}}进行保护追加，是否继续？</span>
        <div class="checkBox" @click="protect_tag = !protect_tag">
          <i
            :class="{
              iconfont: true,
              'icon-no-check': protect_tag,
              'icon-check': !protect_tag,
            }"
          ></i
          >今日不再提示
        </div>
        <div class="btn_group">
          <div
            class="innerCenter"
            @click="
              SET_COINTAG(true);
              SET_ISMASKSHOW(false);
            "
          >
            取消
          </div>
          <div class="innerCenter" @click="confirmDraw()">确认</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { getUserInfo, lottery_draw } from "@/api/mainland";
import clickLog from "@/api/toDots.js";
export default {
  name: "ProtectGetEgg",
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_COINTAG",
      "SET_USERMSG",
      "SET_GRAWLIST",
      "SET_DRAWDEFEAT",
      "SET_PROTECTTAG",
      "SET_MAINLANDLOGIN",
      "SET_ISLOGIN",
      "SET_ISBIND"
    ]),
    // 确定花金币抽奖
    confirmDraw() {
      if (this.userMsg.num >= 3) {
        // 金币够
          // this.lottery_draw(3);
          this.$emit("lottery_draw",3)
          clickLog({type:4,state:this.isLogin?1:2});

      } else {
        // 不够
        this.SET_MASKCONTENT("getEggFail");
      }
    },
    // 抽奖 1初始抽奖 2普通抽奖 3保护抽奖
    lottery_draw(type) {
      const time = Date.now();
      const { token } = this.userMsg;
      lottery_draw({ time, token, type }, { time, token }).then((res) => {
        console.log(res);
        if (res.status == 1) {
          // 抽奖成功
          this.SET_GRAWLIST(res.data);
          this.$emit("getUserInfo");
          // this.getUserInfo();
          this.SET_MASKCONTENT("getEggSuccess");
          this.SET_DRAWDEFEAT(false);
        } else {
          // 失败
          if (res.status == 4040) {
            // 登录失效 需要重新登录
            this.$toast.fail("登录过期，请重新登录");
            this.SET_ISLOGIN(false);
            this.SET_ISBIND(false);
            this.SET_ISMASKSHOW(true);
            this.SET_MASKCONTENT("mainland");
            this.SET_MAINLANDLOGIN("chooseWay");
            this.SET_USERMSG({});
          } else if (res.msg == "追加失败，奖励已发，请重新开始游戏") {
            // 追加失败
            this.SET_DRAWDEFEAT(true);
            this.$toast.fail(res.msg);
          } else {
            this.$toast.fail(res.msg);
          }
        }
      });
    },
    // 重新获取用户信息
    getUserInfo() {
      const time = Date.now();
      const { token } = this.userMsg;
      getUserInfo({ time, token }, { time, token }).then((res) => {
        console.log(res);
        if (res.status == 1) {
          // 获取用户信息成功
          this.userMsg = Object.assign({}, this.userMsg, res.data);
          console.log(this.userMsg);
          this.SET_USERMSG(this.userMsg);
        } else {
          this.$toast.fail(res.msg);
        }
      });
    },
  },
  computed: {
    // 登录的用户信息
    userMsg: {
      get() {
        return this.$store.state.userMsg;
      },
      set(n) {
        this.SET_USERMSG(n);
      },
    },
    // 控制是否保护追加弹框是否显示
    protect_tag: {
      set(n) {
        this.SET_PROTECTTAG(n);
      },
      get() {
        return this.$store.state.protect_tag;
      },
    },
    // 抽到的东西
    draw_list() {
      return this.$store.state.draw_list;
    },
    // 需要消耗多少币
    needCoin(){
      let needCoin = 0;
      if(this.draw_list.start == 1){
        needCoin = 1;
      }else if(this.draw_list.start == 2){
        needCoin = 3;
      }else if(this.draw_list.start == 3){
        needCoin = 8;
      }else if(this.draw_list.start == 4){
        needCoin = 26;
      }else if(this.draw_list.start == 5){
        needCoin = 75;
      }else if(this.draw_list.start == 6){
        needCoin = 138;
      }
      return needCoin;
    }
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.protectGetEgg{
    .close{
        top: 0.1rem;
        right: 0.3rem;
        z-index: 2;
    }
    .protectGetEgg_container{
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .protectGetEgg_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
              width: 70%;
              line-height: 0.5rem;
              margin:0.2rem 0 0 0;
            }
            .checkBox{
                display: flex;
                align-items: center;
                margin: 0.6rem 0 0 0;
                font-size: 0.33rem;
                i{
                    font-size:0.4rem;
                    margin: 0 0.2rem 0 0;
                }
            }
            .btn_group{
                width: 90%;
                display: flex;
                justify-content: space-around;
                margin:0.4rem 0 0  0;
                div{
                    &:nth-of-type(1){
                        @include btn("bg_btn_blue.png",#fff)
                    }
                    &:nth-of-type(2){
                        @include btn;
                    }
                }
            }
        }
     }
}
</style>