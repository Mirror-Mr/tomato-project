<template>
  <div class="giftShow">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="giftShow_title innerCenter">
      <span></span>
      <span>星级奖励</span>
      <span></span>
    </div>
    <div class="giftShow_content">
      <div class="content1">
        <div class="content_star">
          <div class="innerCenter">
            <span></span>
          </div>
          <div class="innerCenter">
            <span></span>
            <span></span>
          </div>
        </div>
        <div class="content_gift">
          <div>
            <img :src="`${baseUrl}thing6_2.png`" alt="" />
            <span>{{ gift_list[0][0].desc }}</span>
          </div>
          <div>
            <img :src="`${baseUrl}thing6_2.png`" alt="" />
            <span>{{ gift_list[0][1].desc }}</span>
          </div>
        </div>
      </div>
      <div
        v-for="(item, index) in 3"
        :key="index"
        :class="`content${index + 2}`"
      >
        <!-- 星 -->
        <div class="content_star">
          <div class="innerCenter">
            <span v-for="(item, index1) in index + 3" :key="index1"></span>
          </div>
        </div>
        <!-- 奖励 -->
        <div class="content_gift">
          <div v-for="(item,index1) in gift_list[index+1]" :key="index1">
            <img :src="`${baseUrl}${item.img}`"  />
            <span>{{ item.desc }}</span>
          </div>
        </div>
      </div>
      <div class="content5">
        <div class="content_star">
          <div class="innerCenter">
            <span v-for="(item ,index) in 6" :key="index"></span>
          </div>
          <div class="innerCenter">
            <span v-for="(item ,index) in 7" :key="index"></span>
          </div>
        </div>
        <div class="content_gift">
          <div v-for="(item,index) in gift_list[4]" :key="index">
            <img :src="`${baseUrl}${item.img}`" alt="" />
            <span>{{ item.desc }}</span>
          </div>
          
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
export default {
  name: "GiftShow",
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
      baseUrl1: "https://wcdn.tomatogames.com/static/zjfh/img/",
      gift_list: [
        [
          {
            img: "thing6_2.png",
            desc: "月饼*24",
          },
          {
            img: "thing6_2.png",
            desc: "月饼*64",
          },
        ],
        [
          {
            img: "thing6_2.png",
            desc: "月饼*108",
          },
          // {
          //   img: "thing5_1.png",
          //   desc: "玲珑棋盒",
          // },
          // {
          //   img: "thing5_2.png",
          //   desc: "秦蒙笔*3",
          // },
          // {
          //   img: "thing5_3.png",
          //   desc: "焦尾琴*2",
          // },
        ],
        [
          {
            img: "thing6_2.png",
            desc: "月饼*320",
          },
          // {
          //   img: "thing4_2.png",
          //   desc: "黄铜腰牌*9",
          // },
          // {
          //   img: "thing4_3.png",
          //   desc: "保养油*10",
          // },
        ],
        [
          {
            img: "thing6_2.png",
            desc: "月饼*960",
          },
          // {
          //   img: "thing7_1.png",
          //   desc: "头像框",
          // },
          // {
          //   img: "thing7_2.png",
          //   desc: "头像",
          // },
        ],
        [
          // {
          //   img: "thing6_2.png",
          //   desc: "月饼*1440",
          // },
          {
            img: "thing3_2.png",
            desc: "桂花酒*3",
          },
          // {
          //   img: "thing6_2.png",
          //   desc: "月饼*4320",
          // },
          {
            img: "thing3_2.png",
            desc: "桂花酒*9",
          },
        ],
      ],
    };
  },
  methods: {
    ...mapMutations(["SET_ISMASKSHOW"]),
  },
};
</script>
<style lang="scss" scoped>
.giftShow{
    width:9.9rem;
    // padding: 1rem 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    .close{
        top: 0.95rem;
        right: 0.55rem;
    }
    .giftShow_title{
        width: 70%;
        height: 0.9rem;
        display: flex;
        font-size: 0.48rem;
        color: #FFEFB1;
        background-image: imgUrl("bg_title.png");
        span{
        &:nth-of-type(1),&:nth-of-type(3){
            width: 0.26rem;
            height: 0.26rem;
            display: block;
            background-image: imgUrl("rule_title_deco.png");
        }
        &:nth-of-type(2){
            margin: 0 0.2rem;
        }
    }
    }
    .giftShow_content{
        width: 90%;
        height: 17.1rem;
        padding: 0.7rem 0 0 0rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin:0.2rem 0 0 0rem;
        background-image: imgUrl("bg_giftShow_mask.png");
        // background-image: imgUrl("4.png");
        .content1,.content5{
            .content_star{
                display: flex;
                margin: 0 0 0 -0.05rem;
                div{
                    width: 3.52rem;
                    height: 0.89rem;
                    background-image: imgUrl("bg_star1.png");
                    span{
                        width: 0.47rem;
                        height: 0.71rem;
                        margin:0 -0.03rem;
                        display: block;
                        background-image: imgUrl("star_light.png");
                    }
                }
            }
            .content_gift{
                margin:0.3rem 0 0 0;
                display: flex;
                justify-content: space-around;
                div{
                    width: 1.84rem;
                    height: 1.65rem;
                    position: relative;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    background-image: imgUrl("bg_accumPrize.png");
                    img{
                        width:auto;
                        height: 33%;
                        margin: -0.2rem 0 0 0;
                    }
                    span{
                        position: absolute;
                        bottom: 0.28rem;
                        font-size: 0.27rem;
                        color: #4E8DD1;
                    }
                }
            }
            &.content5{
                margin: 0.36rem 0 0 0;
                .content_gift{
                    div{
                        // &:nth-of-type(2),
                        // &:nth-of-type(4){
                        //     img{
                        //         height: 60%;
                        //         margin:-0.2rem 0 0 -0.2rem;
                        //     }
                        // }
                        &:nth-of-type(1),
                        &:nth-of-type(2){
                            img{
                                height: 60%;
                                margin:-0.2rem 0 0 -0.2rem;
                            }
                        }
                        
                    }
                }
            }
        }
        .content2,.content3,.content4{
            display: flex;
            flex-direction: column;
            align-items: center;
            .content_star{
                display: flex;
                margin: 0 0 0 -0.05rem;
                div{
                    width: 7.08rem;
                    height: 0.89rem;
                    background-image: imgUrl("bg_star2.png");
                    span{
                        width: 0.47rem;
                        height: 0.71rem;
                        display: block;
                        background-image: imgUrl("star_light.png");
                    }
                }
            }
            .content_gift{
                margin:0.3rem 0 0 0;
                display: flex;
                justify-content: space-around;
                div{
                    width: 1.84rem;
                    height: 1.65rem;
                    position: relative;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    background-image: imgUrl("bg_accumPrize.png");
                    img{
                        width:auto;
                        height: 33%;
                        margin: -0.2rem 0 0 0;
                        
                    }
                    span{
                        position: absolute;
                        bottom: 0.29rem;
                        font-size: 0.27rem;
                        color: #4E8DD1;
                    }
                }
            }
            &.content2{
                margin: 0.4rem 0 0 0;
                .content_gift{
                    div{
                        &:nth-of-type(2){
                            img{
                                height: 46%;
                                margin:-0.3rem 0 0 0.1rem;
                            }
                        }
                        &:nth-of-type(3){
                            img{
                                height: 48%;
                                margin:-0.3rem 0 0 0.2rem;
                            }
                        }
                        &:nth-of-type(4){
                            img{
                                height: 46%;
                            }
                        }
                    }
                }
                
            }
            &.content3{
                margin: 0.4rem 0 0 0;
                .content_gift{
                    div{
                        &:nth-of-type(2){
                            img{
                                height: 46%;
                            }
                        }
                        &:nth-of-type(3){
                            img{
                                height: 55%;
                                margin:-0.3rem 0 0 0;
                            }
                        }
                    }
                }
            }
            &.content4{
                margin: 0.37rem 0 0 0;
                .content_gift{
                    div{
                        &:nth-of-type(2){
                            img{
                                height: 48%;
                                margin:-0.3rem 0 0 0.01rem;
                            }
                        }
                        &:nth-of-type(3){
                            img{
                                height: 47%;
                                margin:-0.4rem 0 0 0.05rem;
                            }
                        }
                    }
                }
            }
            
        }        
    }
}
</style>