<template>
  <!-- 规则框 -->
  <div class="confirmGetEgg">
    <div class="close" @click="SET_ISMASKSHOW(false)"></div>
    <div class="confirmGetEgg_container">
      <div class="confirmGetEgg_content">
        <span>本次参与需要消耗幸运币*1，是否继续</span>
        <div class="checkBox" @click="coin_tag = !coin_tag">
          <i
            :class="{
              iconfont: true,
              'icon-no-check': coin_tag,
              'icon-check': !coin_tag,
            }"
          ></i
          >今日不再提示
        </div>
        <div class="btn_group">
          <div
            class="innerCenter"
            @click="
              SET_COINTAG(true);
              SET_ISMASKSHOW(false);
            "
          >
            取消
          </div>
          <div class="innerCenter" @click="confirmDraw()">确认</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
import { getUserInfo, lottery_draw } from "@/api/mainland";
import clickLog from "@/api/toDots.js";

export default {
  name: "ConfirmGetEgg",
  props: {
    isFirstDraw: {
      type: Boolean,
      required: true,
    },
  },
  data() {
    return {
      baseUrl: "https://wcdn.tomatogames.com/static/zjfh/img/",
    };
  },
  methods: {
    ...mapMutations([
      "SET_ISMASKSHOW",
      "SET_MASKCONTENT",
      "SET_COINTAG",
      "SET_USERMSG",
      "SET_GRAWLIST",
      "SET_ISLOGIN",
      "SET_ISBIND",
      "SET_DRAWDEFEAT",
      "SET_GENERALTAG"
    ]),
    // 确定花金币抽奖
    confirmDraw() {
      if (this.userMsg.num >= 1) {
        // 金币够
        if (this.isFirstDraw) {
          //第一次抽
          this.$emit("lottery_draw",1)
        } else {
          this.$emit("lottery_draw",3)
          clickLog({type:4,state:this.isLogin?1:2});
        }
      } else {
        // 不够
        this.SET_MASKCONTENT("getEggFail");
      }
    },
  },
  computed: {
    // 是否提示使用金币抽奖
    coin_tag: {
      get() {
        return this.$store.state.coin_tag;
      },
      set(n) {
        this.SET_COINTAG(n);
      },
    },
    // 登录的用户信息
    userMsg: {
      get() {
        return this.$store.state.userMsg;
      },
      set(n) {
        this.SET_USERMSG(n);
      },
    },
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
 @import '../store/goods_img.scss';
.confirmGetEgg{
    .close{
        top: 0.1rem;
        right: 0.3rem;
        z-index: 2;
    }
    .confirmGetEgg_container{
         width:9.9rem;
        // padding: 1rem 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
        .confirmGetEgg_content{
            width: 95%;
            height: 5rem;
            padding: 0.8rem 0 0 0.2rem;
            margin:0.2rem 0 0 0rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.42rem;
            color: #007DC5;
            background-image: imgUrl("bg_chooseWayLogin1.png");
            span{
                margin:0.4rem 0 0 0;
            }
            .checkBox{
                display: flex;
                align-items: center;
                margin: 0.9rem 0 0 0;
                font-size: 0.33rem;
                i{
                    font-size:0.4rem;
                    margin: 0 0.2rem 0 0;
                }
            }
            .btn_group{
                width: 90%;
                display: flex;
                justify-content: space-around;
                margin:0.5rem 0 0  0;
                div{
                    &:nth-of-type(1){
                        @include btn("bg_btn_blue.png",#fff)
                    }
                    &:nth-of-type(2){
                        @include btn;
                    }
                }
            }
        }
     }
}
</style>