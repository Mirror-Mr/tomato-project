import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    // 弹框是否展示
    isMaskShow: false,
    // 弹框内容
    maskContent:null,
    // 是否有用户登录
    isLogin:false,
    // 是否绑定角色
    isBind:false,
    // 登录的用户信息
    userMsg:{
    },
    // 当前用户的全部角色信息
    allRole_list:[],
    // 当前绑定角色信息
    roleMsg:{},
    // 底部弹框是否显示
    isShowPop:{
      status:false,
      type:1
    },
    // 扭蛋使用幸运币提示
    coin_tag:true,
    // 抽到的东西
    draw_list:{},
    // 大陆登录展示什么
    mainlandLogin:"chooseWay",
    // 是否追加失败
    drawDefeat:false,
    // 是否进行普通追加提示
    general_tag:true,
    // 是否进行保护追加提示
    protect_tag:true,
    // 是否显示购买礼包确认框
    purchase_tag:true
  },
  getters:{
    GET_ISMASKSHOW(state){
      return state.isMaskShow
    },
    GET_MASKCONTENT(state){
      return state.maskContent;
    },
    GET_ISLOGIN(state){
      return state.isLogin;
    },
    GET_USERMSG(state){
      return state.userMsg;
    },
    GET_ISSHOWPOP(state){
      return state.isShowPop;
    },
    GET_ROLEMSG(state){
      return state.roleMsg;
    },
    GET_ALLROLELIST(state){
      return state.allRole_list;
    },
    GET_COINTAG(state){
      return state.coin_tag;
    },
    GET_GRAWLIST(state){
      return state.draw_list;
    },
    GET_ISBIND(state){
      return state.isLogin;
    },
    GET_MAINLANDLOGIN(state){
      return state.mainlandLogin;
    },
    GET_DRAWDEFEAT(state){
      return state.drawDefeat;
    },
    GET_GENERALTAG(state){
      return state.general_tag;
    },
    GET_PROTECTTAG(state){
      return state.protect_tag;
    },
    GET_PURCHASE(state){
      return state.purchase_tag;
    },
    
    
  },
  mutations: {
    // 控制弹框关闭展示
    SET_ISMASKSHOW: (state, isMaskShow) => {
      state.isMaskShow = isMaskShow;
    },
     // 控制弹框显示内容
    SET_MASKCONTENT: (state, maskContent) => {
      state.maskContent = maskContent;
    },
    // 更新用户登录状态
    SET_ISLOGIN: (state, isLogin) => {
      state.isLogin = isLogin;
    },
    // 更新登录用户信息
    SET_USERMSG:(state,userMsg)=>{
      state.userMsg = {...userMsg};
    },
    // 控制底部弹框是否显示
    SET_ISSHOWPOP:(state,isShowPop)=>{
      state.isShowPop = {...isShowPop};
    },
    // 设置当前绑定角色信息
    SET_ROLEMSG:(state,roleMsg)=>{
      state.roleMsg = roleMsg.role_id?Object.assign({},state.roleMsg,roleMsg):{platform:roleMsg.platform};
    },
    // 设置当前登录用户所有角色信息
    SET_ALLROLELIST:(state,allRole_list)=>{
      state.allRole_list = allRole_list;
    },
    // 控制抽奖使用金币弹框是否显示
    SET_COINTAG(state,coin_tag){
      state.coin_tag = coin_tag;
    },
    // 更新抽到的东西
    SET_GRAWLIST(state,draw_list){
        state.draw_list = draw_list?Object.assign({},state.draw_list,draw_list):{};
    },
    // 更新是否绑定角色
    SET_ISBIND(state,isBind){
      state.isBind = isBind;
    },
    // 更新大陆登录框显示什么
    SET_MAINLANDLOGIN(state,mainlandLogin){
      state.mainlandLogin = mainlandLogin;
    },
    // 更新追加是否失败
    SET_DRAWDEFEAT(state,drawDefeat){
      state.drawDefeat = drawDefeat;
    },
    // 控制是否普通追加弹框是否显示
    SET_GENERALTAG(state,general_tag){
      state.general_tag = general_tag;
    },
    // 控制是否保护追加弹框是否显示
    SET_PROTECTTAG(state,protect_tag){
      state.protect_tag = protect_tag;
    },
    // 控制是否显示购买礼包确认框
    SET_PURCHASETAG(state,purchase_tag){
      state.purchase_tag = purchase_tag;
    },
  },
  actions: {},
  modules: {},
});
