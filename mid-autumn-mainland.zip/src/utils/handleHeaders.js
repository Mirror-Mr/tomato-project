import md5 from "js-md5";

// 处理请求头
export default function (headersObj) {
  const key = "0391591aafc5db68b08787645b837b4f";
  let str = "";
  for (let k in headersObj) {
    if (Object.prototype.hasOwnProperty.call(headersObj, k)) {
      str += headersObj[k];
    }
  }
  const headers = {};
  headers["Access-s"] = md5(key + str);
  return headers;
}
