<!--
 * @Author: your name
 * @Date: 2021-11-08 10:49:52
 * @LastEditTime: 2021-12-03 11:16:08
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three_year\src\components\Modal.vue
-->
<template lang="pug">
	.mask( v-if="show" @click.self="maskClick")
		.content.column-center(:class="{'long_bg':longBg,'no_bg':noBg}")
			.scroll_container(:class="{'whole_width':wholeWidth}")
				slot
				.btn_box(v-if="surebtn || canclebtn")
					.btn_1(v-if="surebtn" v-debounce="sure") {{ suretext }}
					.btn_2(v-if="canclebtn" @click="close") 取消
			.bg_top(:class="{'no_bg':noBg}")
			.bg_bottom(:class="{'no_bg':noBg}")
			.close_btn(@click.stop="close")


</template>

<script>
// import {mapState} from 'vuex'
export default {
  name: "Modal",
  props: {
    // 控制弹框显示
    show: {
      type: Boolean,
      required: true
    },
    // 是否显示确认按钮
    surebtn: {
      type: Boolean,
      required: false,
      default: false
    },
    suretext: {
      type: String,
      required: false,
      default: "确认"
    },
    // 是否显示取消按钮
    canclebtn: {
      type: Boolean,
      required: false,
      default: false
    },
    // 是否显示更长的背景图
    longBg: {
      type: Boolean,
      required: false,
      default: false
    },
    // 点击mask是否需要关闭
    maskClose: {
      type: Boolean,
      required: false,
      default: false
    },
    // 适用于战令-盼春归
    wholeWidth:{
        type:Boolean,
        required:false,
        default:false
    },
    // 适用于视频播放
    noBg: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  data() {
    return {};
  },
	watch:{
		show(val){
			if(val){
				document.body.style="height:100%;overflow:hidden;"
			}else {
				document.body.style = ''
			}
		}
	},
  methods: {
    maskClick() {
      this.maskClose && this.close();
    },
    close() {
      this.$emit("close");
    },
    sure() {
      this.$emit("sure");
    },
		
  },
  mounted() {}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="stylus">
@import './Modal.styl'
</style>
