<!--
 * @Author: your name
 * @Date: 2021-11-15 16:53:23
 * @LastEditTime: 2021-12-21 15:50:36
 * @LastEditors: Please set LastEditors
 * @Description: 账号或手机号、角色ID登录
 * @FilePath: \three_year\src\components\allModals\login.vue
-->
<template lang="pug">
Mymodal(@close="close", :show="show", :surebtn="true", @sure="toLogin")
  .top_tit {{ loginType == 'phone' ? '手机登录' : '账号登录' }}
  .input_box
    .input_item
      input(
        type="text",
        v-model.trim="loginInfo.phone",
        v-if="loginType == 'phone'",
        placeholder="请输入手机号"
      )
      input(
        type="text",
        v-model="loginInfo.account",
        v-else,
        placeholder="请输入账号"
      )
    .input_item
      //- 手机号验证码登录
      input.code(
        type="text",
        v-model.trim="loginInfo.code",
        maxlength="6",
        placeholder="请输入验证码",
        v-if="!passbyPassWord && loginType == 'phone'"
      )
      .codebtn.fr(
        v-if="!passbyPassWord && loginType == 'phone'",
        @click="sendCode(loginInfo.phone)"
      ) {{ codetxt }}
      //- 手机号密码登录
      input(
        type="password",
        v-model.trim="loginInfo.psword",
        placeholder="请输入账号密码",
        v-if="passbyPassWord || loginType == 'account'"
      )
    .clearfix.toggle_box
      .code_pass.fr(
        v-if="loginType == 'phone'",
        @click="passbyPassWord = !passbyPassWord"
      ) {{ passbyPassWord ? '验证码登录' : '密码登录' }}
</template>
<script>
import { inlandLogin } from "@/request/api.js";
import sendCodeMixin from "./sendcode";
import { mapState } from "vuex";
// import { debounce } from "@/utils/index";
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  mixins: [sendCodeMixin],
  computed: mapState(["loginType", "loginChannel"]),
  data() {
    return {
      // 角色名称
      roleName: "",
      passbyPassWord: "",
      username: "",
      loginInfo: {
        account: "",
        code: "",
        psword: "",
      },
    };
  },
  watch: {
    show(val) {
      if (!val) {
        this.secondtime = 179;
        this.codetxt = "获取验证码";
        this.clearTimer();
      }
    },
  },
  methods: {
    close() {
      this.$store.commit("SETVAL", { login: false, login_type: true });
    },
    // 确认登录
    toLogin() {
      if (
        this.loginType == "phone" &&
        this.passbyPassWord &&
        (!this.loginInfo.phone || !this.loginInfo.psword)
      ) {
        this.$toast("请填写手机号和密码登录");
        return;
      } else if (
        this.loginType == "phone" &&
        !this.passbyPassWord &&
        (!this.loginInfo.phone || !this.loginInfo.code)
      ) {
        this.$toast("请填写手机号和验证码登录");
        return;
      } else if (
        this.loginType == "account" &&
        (!this.loginInfo.account || !this.loginInfo.psword)
      ) {
        this.$toast("请填写账号和密码登录");
        return;
      }
      let account = this.loginInfo[this.loginType];
      let time = parseInt(new Date().getTime());
      let type = this.loginType == "phone" && !this.passbyPassWord ? 2 : 1;
      let access = this.$encrypte([time, account, type]);
      let params = {
        time: time,
        account: account,
        type: type,
        access: access,
        project_id: 32,
      };
      params.type === 2
        ? (params.code = this.loginInfo.code)
        : (params.password = this.loginInfo.psword);
      inlandLogin(params)
        .then((data) => {
          if (data.uid) {
            localStorage.setItem("uid", data.uid);
            this.$store.commit("SETVAL", { login: false, bind_role: true });
          } else {
            this.$toast("无用户ID,请更换账号重试");
          }
        })
        .catch((err) => {
          this.$toast(err.msg || "登录失败，请重试");
        });
    },

    // this.$store.commit('SETVAL',{bind_role:true})
    // }
    // 判断设备是安卓还是ios
    judgeMachine() {
      let ua = window.navigator.userAgent,
        app = window.navigator.appVersion;
      // console.log('浏览器版本: ' + app + '\n' + '用户代理: ' + ua);
      if (ua.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)) {
        // ios端
        return "ios";
      } else if (ua.indexOf("Android") > -1 || ua.indexOf("Adr") > -1) {
        // android端
        return "android";
      }
    },
  },
  mounted() {},
};
</script>
<style scoped lang="stylus"></style>
