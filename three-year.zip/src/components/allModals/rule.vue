<!--
 * @Author: your name
 * @Date: 2021-11-18 17:04:48
 * @LastEditTime: 2021-12-09 18:39:33
 * @LastEditors: Please set LastEditors
 * @Description: 规则弹框
 * @FilePath: \three-year\src\components\allModals\rule.vue
-->
<template lang='pug'>
	Mymodal(:show='show' @close='close' :maskClose="true")
		.box 
			.title 活动规则
			.con_txt 
				span.point 分享红包：
				span 活动期间，可将已解锁的红包分享给好友，每封红包含3个【套装部件卡】奖励可领取
			.con_txt 
				span.point 领取红包：
				span 领取他人分享的红包，每封可获得至多1个【套装部件卡】奖励，每人每天最多通过红包领取3个奖励，兑换的部件卡不纳入限制次数内
			.con_txt 
				span.point 重复奖励转换：
				span 重复获得的【套装部件卡】将按1:1自动转换成【万能卡】，用于兑换商城使用
			.con_txt 
				span.point 万能卡兑换：
				span 在兑换商城使用【万能卡】可兑换部件卡或其它物品（活动结束后，万能卡道具将清空，请小主们及时使用）
			.con_txt 
				span.point 领取套装：
				span 活动期间集齐所有部件的卡片即可领取套装奖励，奖励将会通过游戏内邮件发放（活动结束后将无法领取奖励，请小主们及时领取）
			.con_txt *参与活动需要绑定手机号，每个手机号只能绑定1个角色
</template>
<script>
	export default {
		name: '',
		props: {
    show: {
				type: Boolean,
				default: false
			}
		},
		data() {
			return {};
		},
		methods: {
			close() {
				this.$emit("close");
			},
		},
		mounted() {}
	}
</script>
<style scoped lang='stylus'>
.box
	padding 40px
	.title
		text-align: center
		font-size:30px
		color: rgb(214,53,45)
		line-height:60px
		margin-bottom: 20px
	.con_txt 
		font-size:24px
		line-height:40px
		margin-bottom: 20px
		.point
			color: rgb(214,53,45)
			font-weight: bold
</style>