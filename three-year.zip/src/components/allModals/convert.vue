<!--
 * @Author: your name
 * @Date: 2021-11-12 12:23:32
 * @LastEditTime: 2021-12-15 11:02:02
 * @LastEditors: Please set LastEditors
 * @Description: 兑换弹框
 * @FilePath: \three_year\src\components\allModals\convert.vue
-->
<template lang="pug">
Mymodal(:show="show", @close="close", :longBg="true")
  .info_mod 拥有万能卡：
    span
      img.icon_card(:src="`${imgBaseUrl}/card_all.png`")
      span {{ num || 0 }}
  .tit.convert_tit
  .convert_box
    .conver_item(v-for="item in convertList", :key="item.id")
      img.img_prop(:src="item.img")
      .btn_1(@click="convertTo(item)") 兑换
        img.icon_card(:src="`${imgBaseUrl}/card_all.png`")
        span {{ item.price }}
      .limit {{ `限购(${prize && prize[item.id] ? prize[item.id] : 0}/${item.limit})` }}
  .info_active 1.获得的多余部件卡将自动1:1转化为万能卡，可用于兑换其他物品。
  .info_active 2.活动结束后，万能碎片将过期，请尽快使用。
</template>
<script>
import { mapState } from "vuex";
import { convertList } from "./activity_1_list.js";
// import { getPrizeHistory} from "@/request/api.js";
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    ...mapState({
      num: (state) => state.act1.num,
      prize: (state) => state.act1.prize,
			userInfo:(state) => state.userInfo,
    }),
  },
  data() {
    return {
      imgBaseUrl:
        "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/redEnvelopes",
      convertList: convertList,
    };
  },
  watch: {
    show(val) {
			let token = localStorage.getItem('token')
      if (val && token) {
        this.$store.dispatch("getHistory", 1);
      }
    },
  },
  methods: {
    close() {
      this.$emit("close");
    },
		// 是否绑定过手机
    ifBindPhone() {
      let token = localStorage.getItem("token");
      if (this.userInfo || token) {
        if (this.userInfo.phone) {
          return true;
        } else {
          this.$store.commit("SETVAL", { bind_phone: true });
          return false;
        }
      } else {
        this.$store.commit("SETVAL", { login_type: true });
        return false;
      }
    },
    convertTo(item) {
			if(!this.ifBindPhone()) return
      if (
        this.prize &&
        this.prize[item.id] &&
        this.prize[item.id] >= item.limit
      ) {
        this.$toast("超过兑换次数");
        return;
      }else if(item.price > this.num){
				this.$toast("万能卡不足")
				return
			}
      this.$emit("convertTo", item);
    },
  },
  mounted() {},
};
</script>
<style scoped lang="stylus">
.tit.convert_tit
  // width: 442px !important
  width: 442px
  background: bg('common/convert_tit.png')
  background-size: 100% 100%
.convert_box
  width: 580px
  display: flex
  justify-content: space-between
  flex-wrap: wrap
  position: relative
  z-index: 1
  margin: 0 auto 50px
  .conver_item
    width: 191px
    height: 250px
    color: #fff
    .img_prop
      width: 191px
      height: 191px
  .btn_1, .btn_2
    width: 174px
    height: 50px
    line-height: 50px
    text-align: center
    background: bg('common/btn_1.png')
    background-size: 100% 100%
    color: #fff
    font-size: 22px
    margin: 0 auto
    position: relative
    top: -35px
    .icon_card
      margin-left: 10px
    span
      font-size: 18px
  .limit
    position: relative
    top: -35px
    text-align: center
    font-size: 18px
    color: #CA5E3D
    margin-top: 10px
.info_active
  color: #CA5E3D
  font-size: 22px
  padding: 0 40px
  margin-bottom: 10px
</style>
