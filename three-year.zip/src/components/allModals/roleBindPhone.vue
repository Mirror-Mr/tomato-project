<!--
 * @Author: your name
 * @Date: 2021-11-15 17:49:00
 * @LastEditTime: 2021-12-01 18:05:38
 * @LastEditors: Please set LastEditors
 * @Description: 角色-手机号绑定
 * @FilePath: \three_year\src\components\allModals\bindphone.vue
-->
<template lang="pug">
	Mymodal( @close="close" :show="show" :canclebtn="status !== 'error'" :surebtn="true"  @sure="tobind")
		.top_tit  角色-手机号绑定
		template(v-if="!status")
			.tip_txt 亲爱的玩家，为了更方便地参与活动，
			.tip_txt 请先将角色与手机号进行绑定。
			.tip_txt_s 注：一个手机号只能绑定一个角色，且绑定后不再能够切换角色，请仔细确认绑定角色信息后再进行绑定！
			.input_box
				.input_item.pl {{userInfo ? userInfo.role_name: ''}}
				.input_item
					input( type="text" v-model.trim="params.mobile" placeholder="请输入绑定手机号")
				.input_item
					input( type="text" v-model.trim="params.code" maxlength="6" class="code" placeholder="请输入验证码" )
					.codebtn.fr(@click="sendCode(params.mobile)") {{codetxt}}
		//- 手机号验证失败
		template(v-else-if="status == 'error'")
			.tip_txt.txt_center 亲爱的玩家，您的手机号已绑定过角色
			.tip_txt {{`当前绑定角色为：${roleInfo.server_name}-${roleInfo.role_name} 。请使用其它手机号进行绑定`}}
			.tip_txt_s 注：一个手机号只能绑定一个角色，且绑定后不再能够切换角色，请仔细确认绑定角色信息后再进行绑定！
		//- 手机号验证成功，再次确认 
		template(v-else-if="status == 'success'")
			.tip_txt.txt_center 绑定手机：12345678900
			.tip_txt.txt_center 绑定角色：XX区 XX角色名
			.tip_txt_s.txt_center 绑定后将无法更改或取消绑定，确认绑定？
</template>
<script>
import { bindPhone } from "@/request/api.js";
import sendCodeMixin from "./sendcode";
import { mapState } from "vuex";
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  mixins: [sendCodeMixin],
  computed: mapState(["userInfo"]),
  data() {
    return {
      params: {
        rolename: "",
        mobile: "",
        code: ""
      },
      // 绑定手机号进度 初始，验证完成，验证失败
      status: "",
      // 手机号绑定过的信息
      roleInfo: {
        server_name: "",
        role_name: ""
      }
    };
  },
  watch: {
    show(val) {
      if (!val) {
        this.roleInfo = {
          server_name: "",
          role_name: ""
        };
        this.secondtime = 59;
        this.codetxt = "获取验证码";
        this.clearTimer();
      }
    }
  },
  methods: {
    close() {
      this.$store.commit("SETVAL", { bind_phone: false });
    },
    tobind() {
      if (this.status == "error") {
        this.status = "";
        return;
      }
      if (!this.params.mobile) {
        this.$toast("请先填写手机号");
        return;
      }
      if (!this.params.code) {
        this.$toast("请先填写验证码");
        return;
      }
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token]);
      let params = {
        time: time,
        token: token,
        phone: this.params.mobile,
        code: this.params.code,
        access: access,
        project_id: 32
      };
      bindPhone(params)
        .then(data => {
          this.$toast("绑定手机号成功");
          // localStorage.setItem('loginChannel',this.loginChannel)
          this.$store.dispatch("getInfo", 1);
          // 是否有受邀请的红包
          let redId = this.$route.query.red_id;
          if (redId) {
            this.$store.commit("SETVAL", { invite_red: true });
          }
          this.close();
        })
        .catch(err => {
          // 手机已绑定过角色
          if (err?.status == 2) {
            this.status = "error";
            this.roleInfo = err.data;
          } else {
            this.$toast(err.msg || "角色绑定手机号失败");
          }
        });
    }
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.tip_txt
	font-size 22px
	color #D5755B
	font-weight bold
	padding 0 40px

.tip_txt_s
	padding 20px 40px
	font-size 18px
	color #E3A38E
.pd20
	padding 0 20px
.txt_center
	text-align center
.pl
	padding 0 calc(0.27 * 75px)
	box-sizing border-box
</style>
