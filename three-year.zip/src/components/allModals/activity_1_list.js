/*
 * @Author: your name
 * @Date: 2021-11-24 21:17:46
 * @LastEditTime: 2021-12-16 18:39:51
 * @LastEditors: Please set LastEditors
 * @Description: 活动一礼包列表
 * @FilePath: \three-year\src\components\allModals\activity_1_list.js
 */
let imgBaseUrl = "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/redEnvelopes/";

export const suitList =[
	{ img: imgBaseUrl + "suit_1.png", price: 15, id: 1,limit:1,name:'耳饰卡'},
	{ img: imgBaseUrl + "suit_2.png", price: 15, id: 2,limit:1,name:'发饰卡' },
	{ img: imgBaseUrl + "suit_3.png", price: 15, id: 3,limit:1,name:'发型卡' },
	{ img: imgBaseUrl + "suit_4.png", price: 15, id: 4,limit:1,name:'背景卡' },
	{ img: imgBaseUrl + "suit_5.png", price: 15, id: 5,limit:1,name:'宠物卡' },
	{ img: imgBaseUrl + "suit_6.png", price: 15, id: 6,limit:1,name:'全身裙卡' },
]

export const convertList = [
	{ img: imgBaseUrl + "d_1.png",contImg:imgBaseUrl + "a1.png", price: 15, id: 1,limit:1,name:'耳饰卡'},
	{ img: imgBaseUrl + "d_2.png",contImg:imgBaseUrl + "a2.png",  price: 15, id: 2,limit:1,name:'发饰卡' },
	{ img: imgBaseUrl + "d_3.png",contImg:imgBaseUrl + "a3.png",  price: 15, id: 3,limit:1,name:'发型卡' },
	{ img: imgBaseUrl + "d_4.png",contImg:imgBaseUrl + "a4.png",  price: 15, id: 4,limit:1,name:'背景卡' },
	{ img: imgBaseUrl + "d_5.png",contImg:imgBaseUrl + "a5.png",  price: 15, id: 5,limit:1,name:'宠物卡' },
	{ img: imgBaseUrl + "d_6.png",contImg:imgBaseUrl + "a6.png",  price: 15, id: 6,limit:1,name:'全身裙卡' },
	{ img: imgBaseUrl + "d_7.png",contImg:imgBaseUrl + "a7.png",  price: 15, id: 7,limit:2,name:'幸运签'},
	{ img: imgBaseUrl + "d_8.png",contImg:imgBaseUrl + "a8.png",  price: 1, id: 8,limit:50,name:'元宝*10' },
	{ img: imgBaseUrl + "d_9.png",contImg:imgBaseUrl + "a9.png",  price: 35, id: 9,limit:1,name:'全套部件卡' },
]

export const all = [...convertList,{ img: imgBaseUrl + "d_0.png", price: 35, id: 0,limit:1,name:'万能卡',contImg:imgBaseUrl + "a0.png",  }]
