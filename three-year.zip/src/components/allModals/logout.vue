<!--
 * @Author: your name
 * @Date: 2021-11-23 15:10:16
 * @LastEditTime: 2021-11-23 15:29:42
 * @LastEditors: Please set LastEditors
 * @Description: 退出登录
 * @FilePath: \three-year\src\components\allModals\logout.vue
-->
<template lang='pug'>
Mymodal(
  :show="show",
  :canclebtn="true",
  :surebtn="true",
  @close="close",
  @sure="logout"
)
  .tip 确认退出此账号？
</template>
<script>
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {};
  },
  methods: {
    close() {
      this.$store.commit("SETVAL", { logout: false });
    },
    logout() {
      this.$store.commit("SETVAL", {
        userInfo: null,
        had_get: [],
        logout: false,
        activty: null,
        lotteryNum: 0,
        specialSignNum: 0,
        currentId: 0,
        historyUpdate: false,
      });
      // 战令红点
      this.resetSetItem("dots", JSON.stringify([0, 0, 0, 0]));
      //
      localStorage.clear();
      sessionStorage.clear();
    },
  },
  mounted() {},
};
</script>
<style scoped lang='stylus'>
.tip
  padding: 100px 20px 80px 40px
  font-size: 40px
  text-align: center
</style>