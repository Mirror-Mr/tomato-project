<!--
 * @Author: your name
 * @Date: 2021-11-12 16:27:30
 * @LastEditTime: 2021-12-21 15:12:15
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three_year\src\components\allModals\shareRedEnv.vue
-->
<template lang="pug">
Mymodal(:show="show", @close="close")
  .tit.share_tit
  .reward_box
    .reward(v-for="(item, index) in 3", :key="item")
      img.reward_img(:src="getImg(list[index])", v-if="list.length >= item")
      img.reward_img(:src="imgbase + 'redEnvelopes/reward_any.png'", v-else)
      .name(v-if="list.length >= item") {{ list[index].server_name }}
      .name(v-if="list.length >= item") {{ list[index].role_name }}
      .name(v-else) 待领取
  .share_btn_box
    .btn_1(v-clipboard:copy="copyVal", v-clipboard:success="onCopy") 复制分享链接
    .btn_2(@click="toshareImg") 生成分享海报
  .tip_txt.pt40 1、每个红包含有3个服装部件,可领取自己分享的红包
  .tip_txt.pb60 2、每个手机号每日可分享一封红包
  //- div 第{{day}}天的红包
</template>
<script>
import { getRedUsers, clickLog } from "@/request/api.js";
import { all } from "./activity_1_list";
import { mapState } from "vuex";
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  components: {
    Poster: (resolve) =>
      require(["@/components/allModals/poster.vue"], resolve),
  },
  computed: mapState(["red_id", "userInfo"]),
  watch: {
    show(val) {
      if (val) {
        if (this.red_id) {
          this.copyVal =
            "送你一个《紫禁繁花》三周年请宴大红包，快看看开出什么时装奖励吧！" +
            location.origin +
            location.pathname +
            "#" +
            this.$route.path +
            "?red_id=" +
            this.red_id;
        }
        this.getdetailInfo();
      } else {
        this.copyVal = "";
        this.list = [];
      }
    },
    // red_id(val){
    // 	debugger
    // 	this.copyVal=location.origin+location.pathname,'#'+this.$route.path+'?red_id='+val
    // 	debugger
    // }
  },
  data() {
    return {
      imgbase:
        "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/",
      copyVal: "",
      list: [],
    };
  },
  methods: {
    getImg(item) {
      let day = all.find((data) => data.id == item.rid);
      if (day && day.img) {
        return day.img;
      }
      return "";
    },
    close() {
      this.$emit("close");
    },
    onCopy() {
      this.$toast("复制成功,快分享给好友吧！");
      let time = Date.now();
      let access1 = this.$encrypte([time]);
      // 复制链接
      clickLog({
        time,
        access: access1,
        type: 3,
        state: 1,
      });
    },
    toshareImg() {
      this.$store.commit("SETVAL", { showPoster: true, red_id: this.red_id });
      // this.$emit('toshareImg')
    },
    // 获取红包领取详情
    getdetailInfo() {
      let red_id = this.red_id;
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token]);
      getRedUsers({
        time: time,
        token: token,
        red_id: red_id,
        access: access,
      })
        .then((data) => {
          this.list = data.list;
          // this.$set(this,'info',data)
          // data && (this.info = data)
        })
        .catch((err) => {
          this.$toast(err.msg || "获取红包领取详情失败！");
        });
    },
  },
  mounted() {},
};
</script>
<style scoped lang="stylus">
.share_tit
  background: bg('common/share_tit.png')
.reward_box
  display: flex
  justify-content: space-around
  padding-bottom: 20px
  margin: 0 10px
  .reward
    width: 191px
    img
      width: 100%
    .name
      text-align: center
.share_btn_box
  display: flex
  justify-content: space-around
  padding: 40px 0 0 0
  margin: 0 20px
  border-bottom: 1px solid rgba(255, 138, 97, 0.3)
.tip_txt
  padding: 0 30px
.pb60
  padding-bottom: 60px
.pt40
  padding-top: 40px
</style>
