/*
 * @Author: your name
 * @Date: 2021-11-16 11:37:35
 * @LastEditTime: 2021-12-10 12:03:41
 * @LastEditors: Please set LastEditors
 * @Description:发送验证码
 * @FilePath: \three_year\src\components\allModals\sendcode.js
 */
import { sendCode} from "@/request/api.js";
export default {
  name: "",
  data() {
    return {
			// 发送验证码的定时器
			codetxt: "获取验证码",
			secondtime: 179,
			timer: null,
		};
  },

  methods: {
		// 发送验证码
		sendCode(phone) {
			if(!phone) {
				this.$toast('请先填写手机号')
				return
			}
			if (this.timer) return;
			let time = parseInt(new Date().getTime());
			let access= this.$encrypte([time,32,phone,1]);
			let params ={
				time:time,
				to_user:phone,
				project_id:32,
				type:1,
				flag:0,
				access:access,
			}
			sendCode(params).then((data) => {
				this.codetxt = this.secondtime + "s后获取";
				this.$toast("短信发送成功，请注意查收");
				this.timer = setInterval(() => {
					this.secondtime--;
					if (this.secondtime <= 0) {
						clearInterval(this.timer);
						this.timer = null;
						this.codetxt = "获取验证码";
						this.secondtime = 180;
						return;
					}
					this.codetxt = this.secondtime + "s后获取";
				}, 1000);
			}).catch(err=>{
				// clearInterval(this.timer);
				// this.timer = null;
				this.$toast(err.msg||'短信发送失败');
			})
		},
		// 清除定时器
		clearTimer(){
			if(this.timer) {
				clearInterval(this.timer);
				this.timer = null;
			}
		}
  },
  mounted() {},
	destroyed(){
		
	}
};
