<!--
 * @Author: your name
 * @Date: 2021-11-15 17:47:50
 * @LastEditTime: 2021-12-09 20:10:34
 * @LastEditors: Please set LastEditors
 * @Description:  绑定角色弹框
 * @FilePath: \three_year\src\components\allModals\bindRole.vue
-->
<template lang="pug">
//- 绑定区服信息
Mymodal(@close="close", :show="show", :surebtn="true", @sure="sure")
  .tit.bind_role(v-if="loginChannel != 2")
  .form_box(v-if="loginChannel != 2")
    .form_item.mb20
      span 区服:
      .my_select.ellipsis(@click="showpicker('showServer')") {{ chooseOne.server_name }}
        .triangle
      van-popup(v-model="showServer", position="bottom", get-container="body")
        van-picker(
          show-toolbar,
          :columns="list",
          value-key="server_name",
          @cancel="showServer = false",
          @confirm="onConfirm($event, 'showServer')"
        )
    .form_item.clearfix
      span 角色:
      .my_select.ellipsis(@click="showpicker('showRole')") {{ chooseOne.role_name }}
        .triangle
      van-popup(v-model="showRole", position="bottom", get-container="body")
        van-picker(
          show-toolbar,
          :columns="list",
          value-key="role_name",
          @cancel="showRole = false",
          @confirm="onConfirm($event, 'showRole')"
        )
  .top_tit(v-if="loginChannel == 2") 角色ID登录
  .input_box(v-if="loginChannel == 2")
    .input_item
      input.ellipsis(
        type="text",
        v-model.trim="roleId",
        @change="getServerRole",
        placeholder="请输入您的角色ID"
      )
    .input_item.server_role.ellipsis {{ chooseOne.role_name ? chooseOne.server_name + ' ' + chooseOne.role_name : '区服+角色名（输入ID后查询)' }}
      //- 角色ID登录
      //- input(readonly v-model.trim="chooseOne.role_name" placeholder="区服+角色名（输入ID后查询）" )
</template>
<script>
import { getRoleInfo, bindRole, getQDRoleInfo } from "@/request/api.js";
import { mapState } from "vuex";
import { debounce } from "@/utils/index";
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    ...mapState(["loginType", "loginChannel", "userInfo"])
  },
  data() {
    return {
      roleId: "",
      showServer: false,
      showRole: false,
      list: [],
      chooseOne: {
        server_name: "",
        role_name: ""
      },
      flag: true,
    };
  },
  watch: {
    show(val) {
      if (val) {
        this.loginChannel != 2 && this.getRole();
      } else {
        this.chooseOne = {
          server_name: "",
          role_name: ""
        };
        this.roleId = "";
        this.list = [];
      }
    }
  },
  methods: {
    close() {
      if (this.loginChannel == 2 || this.userInfo) {
        this.$store.commit("SETVAL", { bind_role: false });
      } else {
        this.$store.commit("SETVAL", { bind_role: false, login_type: true });
      }
    },
    showpicker(type) {
      if (this.list.length < 1) {
        // this.$toast('当前用户还未创建角色，请前往游戏创建！')
        return;
      }
      this[type] = true;
    },
    // 根据角色ID，获取角色名和区服
    getServerRole() {
      this.chooseOne = {
        server_name: "",
        role_name: ""
      };
      if (/^[0-9]{6,12}$/.test(this.roleId)) {
        let time = parseInt(new Date().getTime());
        let access = this.$encrypte([time]);
        getQDRoleInfo({
          time: time,
          role_id: this.roleId,
          access: access
        })
          .then(data => {
            if (data.server_id) {
              this.chooseOne = data;
            } else {
              this.$toast("未查询到该角色信息");
            }
          })
          .catch(err => {
            this.$toast(err.msg || "获取角色信息失败--");
          });
      } else {
        this.roleId !== "" && this.$toast("请输入6-12位数字ID");
      }
    },
    // 获取角色信息
    getRole() {
      let uid = localStorage.getItem("uid");
      if (!uid) {
        this.$store.commit("SETVAL", { login_type: true, bind_role: false });
        return;
      }
      let time = parseInt(new Date().getTime());
      let access = this.$encrypte([time, uid]);
      let loginChannel =
        this.loginChannel || localStorage.getItem("loginChannel");
      getRoleInfo({
        time: time,
        channel: loginChannel,
        xyid: uid,
        access: access
      })
        .then(data => {
          this.list = data;
        })
        .catch(err => {
          this.list = [];
          if (err?.status == 0) {
            this.$toast("当前用户还未创建角色，请前往游戏创建！");
          } else {
            this.$toast(err.msg || "获取角色信息失败");
          }
        });
    },

    onConfirm(el, type) {
      this[type] = false;
      el && (this.chooseOne = el);
    },
    // 绑定区服角色信息
    sure() {
      if (!this.chooseOne.role_name) return;
      if (!this.flag) return;
      this.flag = false;
      // let uid = localStorage.getItem("uid");
      let time = parseInt(new Date().getTime());
      // console.log('encrypte',[time,this.loginChannel,this.chooseOne.role_id])\
      let loginChannel =
        this.loginChannel || localStorage.getItem("loginChannel");

      let access = this.$encrypte([time, loginChannel, this.chooseOne.role_id]);
      let params = {
        time: time,
        channel: loginChannel,
        sid: this.chooseOne.server_id, //区服id
        sname: this.chooseOne.server_name, //区服名称
        rolename: this.chooseOne.role_name, //角色id
        rid: this.chooseOne.role_id, //角色名称
        // xyid: uid,
        access: access
      };
      bindRole(params)
        .then(data => {
          this.flag = true;
          localStorage.setItem("token", data.token);
          localStorage.setItem("userId", data.uid);
          // localStorage.setItem('loginChannel',loginChannel)
          this.$store.commit("SETVAL", {
            bind_role: false,
            login_type: false,
            loginChannel: loginChannel
          });
          this.$toast("角色绑定成功");
          let type = "";
          switch (this.$route.path.toLowerCase()) {
            case "/":
            case "/redenvelope":
              type = 1;
              break;
            case "/asksign":
              type = 2;
              break;
            case "/wishlist1":
            case "/wishlist2":
              type = 3;
              break;
            case "/wishlist3":
              type = 4;
              break;
            case "/warorder":
              type = 5;
              break;
            default:
              type = 1;
          }
          this.$store.dispatch("getInfo", type);
          this.resetSetItem('dots',JSON.stringify([1,1,1,1]))
          // 是否有受邀请的红包
          let red_id = this.$route.query.red_id;
          if (red_id) {
            this.$store.dispatch("getReddetailInfo", red_id).then(data => {
              if (data.is_get == 1) {
                this.$store.commit("SETVAL", { congratulation: true });
              } else {
                this.$store.commit("SETVAL", { invite_red: true });
              }
            });
            // this.$store.commit("SETVAL", { invite_red: true });
          }
          this.resetSetItem('dots',JSON.stringify([1,1,1,1]))
        })
        .catch(err => {
          this.flag = true;
          this.$toast(err.msg || "绑定角色失败");
        });
    }
  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.bind_role
  background: bg('common/bindRole.png')
.form_item
  display: flex
  justify-content: space-between
  line-height: 60px
  margin: 0 20px
  span
    flex: 0 0 120px
    text-align: left
    color: #CA5E3D
    font-size: 30px
  .my_select
    flex: 1
    height: 60px
    line-height: 60px
    border: 1px solid #F47959
    position: relative
    padding: 0 40px 0 20px
    .triangle
      position: absolute
      width: 0
      height: 0
      border-left: 16px solid transparent
      border-right: 16px solid transparent
      border-top: 20px solid #E3A38E
      right: 10px
      top: 20px
.mb20
  margin-bottom: 20px
.server_role
  padding: 0 calc(0.27 * 75px)
</style>
