<template lang="pug">
Mymodal(:show="show", @close="close", :longBg="true")
  .rewardOverview.column-center
    .tit-reward.bg-c
    .content-reward.column-center
      .content-spring.bg-c.column-center
        .tit-content.bg-c
        .reward-list
          .reward-item.bg-c.inner-center(v-for="item in rewardList_spring_show")
            img(:src="`https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/warOrder/icon/${item.id * 1 + 50}.png`")
            .reward-desc.bg-c.inner-center {{ item.name }}*{{ item.num }}
      .content-winter.bg-c.column-center
        .tit-content.bg-c
        .reward-list
          .reward-item.bg-c.inner-center(v-for="item in rewardList_winter_show")
            img(
              :src="`https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/warOrder/icon/${item.id}.png`"
            )
            .reward-desc.bg-c.inner-center {{ item.name }}*{{ item.num }}
</template>
<script>
import {
  rewardList_winter,
  rewardList_spring,
  rewardList_winter_show,
  rewardList_spring_show,
} from "./rewardList.js";
export default {
  name: "rewardOverview",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      rewardList_winter: rewardList_winter,
      rewardList_spring: rewardList_spring,
      rewardList_winter_show: rewardList_winter_show,
      rewardList_spring_show: rewardList_spring_show,
    };
  },
  methods: {
    close() {
      this.$emit("close");
    },
  },
  mounted() {},
};
</script>
<style scoped lang='stylus'>
.rewardOverview
  margin: 20px 0 0 0
  .tit-reward
    width: 90%
    height: 100px
    background-image: imgUrl('tit-reward.png')
  .content-reward
    width: 100%
    // .content-spring
    // .content-winter
    margin: 10px 0 0 0
    &>div
      width: 90%
      height: 490px
      background-image: imgUrl('bg_content_reward.png')
      margin: 15px 0 0 0
      .tit-content
        width: 20%
        height: 10%
        margin: 17px 0 0 0
      &:nth-of-type(1)
        .tit-content
          background-image: imgUrl('name_spring.png')
      &:nth-of-type(2)
        .tit-content
          background-image: imgUrl('name_winter.png')
      .reward-list
        width: 100%
        height: 350px
        margin: 30px 0 0 0
        display: flex
        justify-content: space-around
        flex-wrap: wrap
        overflow: scroll
      .reward-item
        width: 135px
        height: 135px
        position: relative
        background-image: imgUrl('bg-reward-item.png')
      img
        width: 60%
      .reward-desc
        width: 100%
        height: 30px
        position: absolute
        bottom: 10px
        font-size: 14px
        color: #FDF6E7
        // 文字不换行
        white-space: nowrap
        background-image: imgUrl('bg-reward-desc.png')
</style>