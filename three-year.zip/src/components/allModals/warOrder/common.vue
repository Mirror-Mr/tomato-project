<template lang="pug">
Mymodal(
  :show="show",
  @close="close",
  :surebtn="sureBtn",
  :canclebtn="cancelBtn",
  @sure="sure"
) 
  .common.inner-center(v-if="dialog != 'quickReward'")
    p(v-html="content")
  .quick-container.column-center(v-else)
    .tit-quickReward.bg-c
    .reward-list.inner-center(:class="{ singleReward: rewardList.length < 4 }")
      .reward-item.bg-c.inner-center(v-for="item in rewardList")
        img(
          :src="`https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/warOrder/icon/${item.id}.png`"
        )
        .reward-desc.bg-c.inner-center {{ item.name }}*{{item.num}}
      //- 占位符
      i(v-if="rewardList.length >= 4")
      i(v-if="rewardList.length >= 4")
      i(v-if="rewardList.length >= 4")
      i(v-if="rewardList.length >= 4")
</template>
<script>
export default {
  name: "common",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      dialog: "",
      content: "",
      params: [],
      rewardList: [
        {
          id: 1,
          name: "头饰卡",
          num: 1,
        },
        // {
        //   id: 2,
        //   name: "头饰卡",
        //   num: 1,
        // },
        // {
        //   id: 3,
        //   name: "头饰卡",
        //   num: 1,
        // },

        // {
        //   id: 4,
        //   name: "头饰卡",
        //   num: 1,
        // },
        // {
        //   id: 5,
        //   name: "头饰卡",
        //   num: 1,
        // },
        // {
        //   id: 6,
        //   name: "头饰卡",
        //   num: 1,
        // },
        // {
        //   id: 7,
        //   name: "头饰卡",
        //   num: 1,
        // },
        // {
        //   id: 8,
        //   name: "头饰卡",
        //   num: 1,
        // },
      ],
    };
  },
  methods: {
    sure() {
      if (this.dialog == "maskSureBuyGrade") {
        // 确认要花钱买级
        localStorage.setItem(
          "zl_payMsg",
          JSON.stringify({ good_id: 15, params: this.params[1] })
        );
        this.$emit("pay", { good_id: 15, num: this.params[1] });
        // const obj = { dialog: "buyGraded", params: [this.params[0]] };
        // this.$bus.$emit("showCommon", obj);
      } else if (this.dialog == "makeSureOpenSpring") {
        // 确认要开通盼春归
        localStorage.setItem(
          "zl_payMsg",
          JSON.stringify({ good_id: this.params[2], params: this.params[0] })
        );
        this.$emit("pay", { good_id: this.params[2] });
        // const obj = { dialog: "openSpringSuccess1", params: [this.params[0]] };
        // const obj = { dialog: "openSpringSuccess2", params: [this.params[0]] };
        // this.$bus.$emit("showCommon", obj);
      } else if (
        this.dialog == "openSpringSuccess1" ||
        this.dialog == "openSpringSuccess2" ||
        this.dialog == "buyGraded" ||
        this.dialog == "quickReward"
      ) {
        this.close();
      }
    },
    close() {
      if (this.dialog == "maskSureBuyGrade") {
        this.$emit("openDialog", "buyGrade");
        return;
      }
      if (this.dialog == "makeSureOpenSpring") {
        this.$emit("openDialog", "waitSpring");
        return;
      }
      this.$emit("close");
    },
    changeContent(params) {
      if (this.dialog == "maskSureBuyGrade") {
        this.content = `是否花费 <span>¥${params[0]}</span> 购买 <span>${params[1]}</span>级梅树等级？`;
      } else if (this.dialog == "buyGraded") {
        this.content = `购买成功！梅树等级提升<span>${params[0]}</span>级！`;
      } else if (this.dialog == "makeSureOpenSpring") {
        this.content = `开通<span>“${params[0]}”</span>之后，其他档位将不可开通。<br>是否花费${params[1]}元开通<span>“${params[0]}”</span>？`;
      } else if (
        this.dialog == "openSpringSuccess1" ||
        this.dialog == "openSpringSuccess2"
      ) {
        const temp =
          this.dialog == "openSpringSuccess1"
            ? ""
            : "请到游戏邮箱领取元宝奖励！";
        this.content = `成功开通<span>“${params[0]}”</span>！` + `<br>${temp}`;
      } else if (this.dialog == "quickReward") {
        this.rewardList = [...params];
      }
    },
  },
  computed: {
    sureBtn() {
      const arr = [
        "maskSureBuyGrade",
        "buyGraded",
        "makeSureOpenSpring",
        "openSpringSuccess1",
        "openSpringSuccess2",
        "quickReward",
      ];
      return arr.includes(this.dialog);
    },
    cancelBtn() {
      const arr = ["maskSureBuyGrade", "makeSureOpenSpring"];
      return arr.includes(this.dialog);
    },
  },
  mounted() {
    this.$bus.$off(event).$on("showCommon", (obj) => {
      this.dialog = obj.dialog;
      this.params = [...obj.params];
      this.changeContent(obj.params);
    });
  },
};
</script>
<style scoped lang='stylus'>
.common
  width: 100%
  height: 300px
  color: #D5755B
  margin: 40px 0 -30px 0
  p
    width: 80%
    flex-wrap: wrap
    font-size: 40px
    /deep/ span
      color: #FF6059
.quick-container
  width: 100%
  margin: 40px 0 0 0
.tit-quickReward
  width: 500px
  height: 50px
  background-image: imgUrl('tit-quickReward.png')
.reward-list
  width: 98%
  height: 250px
  margin: 20px 0 0 0
  overflow: scroll
  justify-content: space-around
  flex-wrap: wrap
  &.singleReward
    flex-wrap: nowrap
    .reward-item
      width: 210px
      height: 210px
      .reward-desc
        width: 100%
        height: 40px
        position: absolute
        bottom: 35px
        font-size: 20px
        // 文字不换行
        white-space: nowrap
  .reward-item
    width: 145px
    height: 145px
    position: relative
    background-image: imgUrl('bg-reward-item.png')
    img
      width: 60%
    .reward-desc
      width: 100%
      height: 25px
      position: absolute
      bottom: 20px
      font-size: 16px
      color: #FDF6E7
      // 文字不换行
      white-space: nowrap
      background-image: imgUrl('bg-reward-desc.png')
  i
    width: 145px
</style>