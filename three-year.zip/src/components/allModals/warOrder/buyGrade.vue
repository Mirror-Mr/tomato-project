<template lang="pug">
Mymodal(
  :show="show",
  @close="close",
  :surebtn="true",
  :canclebtn="true",
  @sure="sure"
)
  .buyGrade.column-center
    .tit-buy.bg-c
    .content-container
      .top.inner-center
        span ￥：
        span {{ 6 * value }}
        span 购买等级：
        span {{ value }}
      .bottom
        .btn-del.bg-c.inner-center(@click="changeNum(false)") -
        span 1
        van-slider(
          v-model="value",
          :min="1",
          :max="50 - (activty && activty.lv?activty.lv:0)",
          @change="onChange",
          active-color="#FF6059",
          inactive-color="#febaac"
        )
          template(#button)
            .custom-button.inner-center 
        span {{ 50 - (activty && activty.lv?activty.lv:0)}}
        .btn-add.bg-c.inner-center(@click="changeNum(true)") +
    .btn-group
</template>
<script>
import { mapState } from "vuex";
export default {
  name: "buyGrade",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      value: 1,
    };
  },
  methods: {
    sure() {
      const obj = {
        dialog: "maskSureBuyGrade",
        params: [6 * this.value, this.value],
      };
      this.$bus.$emit("showCommon", obj);
    },
    close() {
      this.$emit("close");
    },
    onChange(value) {},
    // 以1为单位 改变进度条的值
    changeNum(flag) {
      flag && this.value < 50 - this.activty.lv ? ++this.value : "";
      !flag && this.value > 1 ? --this.value : "";
    },
  },
  computed: {
    ...mapState(["activty"]),
  },
};
</script>
<style scoped lang="stylus">
.buyGrade
  .tit-buy
    width: 270px
    height: 45px
    margin: 70px 0 0 0
    background-image: imgUrl('tit-buy.png')
  .content-container
    .top
      margin: 40px 0 0 0
      span
        font-size: 30px
        &:nth-of-type(1), &:nth-of-type(3)
          color: #D5755B
        &:nth-of-type(2), &:nth-of-type(4)
          color: #FF6059
        &:nth-of-type(3)
          margin: 0 0 0 50px
    .bottom
      margin: 40px 0 0 0
      display: flex
      align-items: center
      .btn-del, .btn-add
        width: 30px
        height: 30px
        margin: 0 10px
        color: #fff
        background-image: imgUrl('btn-buy.png')
      span
        color: #D5755B
        font-size: 30px
      .van-slider
        width: 300px
        height: 10px
        margin: 0 20px
        .custom-button
          width: 30px
          height: 30px
          border-radius: 50%
          color: #fff
          font-size: 20px
          background-color: #FF6059
          border: 1px solid #FFF9EA
</style>