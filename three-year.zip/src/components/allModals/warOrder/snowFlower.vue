<template lang="pug">
Mymodal(:show="show", @close="close", :longBg="true")
  .snowFlower.column-center
    .tit-snow.bg-c
    .tag-snow.bg-c
    .task-container
      .task-item(v-for="item in taskList")
        .task-desc {{ item.desc }}
          br
          span 寒梅等级提升{{ item.num/100 }}级
        .btn-task.bg-c.inner-center(
          :class="{ gray: day_task_record[`30${item.id}`] != 1 }",
          v-debounce="()=>{subPrize(item.id)}"
        ) {{ day_task_record[`30${item.id}`] == 2 ? '已领取' : '领取' }}
    .btn-all-task.bg-c.inner-center(
      v-debounce="()=>{subPrize(0)}",
      :class="{ gray: !Object.values(day_task_record).includes(1) }"
    ) 一键领取
</template>
<script>
export default {
  name: "snowFlower",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
    day_task_record: {
      type: Object,
      default: {
        301: 0,
        302: 0,
        303: 0,
        304: 0,
        305: 0,
      },
    },
  },
  data() {
    return {
      taskList: [
        {
          id: 1,
          desc: "每日登录游戏",
          num: 100,
        },
        {
          id: 2,
          desc: "他人领取1次我的请宴红包（活动一）",
          num: 100,
        },
        {
          id: 3,
          desc: "完成办差5次",
          num: 100,
        },
        {
          id: 4,
          desc: "完成书院学习2次",
          num: 100,
        },
        {
          id: 5,
          desc: "完成祈福1次",
          num: 100,
        },
      ],
    };
  },
  methods: {
    close() {
      this.$emit("close");
    },
    // 领取累计登录游戏奖励
    subPrize(id) {
      const rid = id + 300;
      const flag = id ? "" : 1;
      this.$emit("subPrize", { flag, rid });
    },
  },
  mounted() {},
};
</script>
<style scoped lang='stylus'>
.snowFlower
  padding: 20px 0 40px 0
  .tit-snow
    width: 90%
    height: 100px
    background-image: imgUrl('tit-snow.png')
  .tag-snow
    width: 75%
    height: 50px
    align-self: flex-start
    margin: 40px 0 0 30px
    background-image: imgUrl('tag-snow.png')
  .task-container
    width: 85%
    margin: 20px 0 60px 0
    .task-item
      height: 90px
      display: flex
      align-items: center
      padding: 5px 0
      border-bottom: 1px solid rgba(255, 138, 97, 0.2)
      box-sizing: content-box
      // background-color: green
      &:nth-of-type(1)
        border-top: 1px solid rgba(255, 138, 97, 0.2)
      .task-desc
        width: 80%
        font-size: 22px
        // background-color: red
        span
          font-size: 15px
      .btn-task
        width: 174px
        height: 43px
        font-size: 22px
        color: #FEF7EB
        background-image: imgUrl('btn-task.png')
  .btn-all-task
    width: 239px
    height: 68px
    font-size: 26px
    color: #FDF6E7
    text-shadow: 0px 2px 3px rgba(179, 79, 53, 0.64)
    background-image: imgUrl('btn-task.png')
</style>