<template lang="pug">
Mymodal(:show="show", @close="close", :longBg="true")
  .accompany.column-center
    .tit-pany.bg-c
    .tag-container.inner-center
      .tag-pany.bg-c
      span {{ login_days_record.days }}
      span 天
    .task-container
      .task-item(v-for="item in taskList")
        .task-desc 累计游玩{{ item.day }}天
          br
          span 寒梅等级提升{{ item.num/100 }}级
        .btn-task.bg-c.inner-center(
          :class="{ gray: login_days_record.days < item.day || prizeList[`20${item.id}`] }",
          v-debounce="()=>{subPrize(item.id)}"
        ) {{ prizeList[`20${item.id}`] ? '已领取' : '领取' }}
    .btn-all-task.bg-c.inner-center(
      :class="{ gray: login_days_record.days < 30 || Object.keys(prizeList).length == 5 }",
      v-debounce="()=>{subPrize(0)}"
    ) 一键领取
</template>
<script>
import { mapState } from "vuex";
export default {
  name: "accompany",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
    login_days_record: {
      type: Object,
      default: {
        days: 0,
        prize: {},
      },
    },
  },
  data() {
    return {
      taskList: [
        {
          id: 1,
          day: "30",
          num: 100,
        },
        {
          id: 2,
          day: "180",
          num: 100,
        },
        {
          id: 3,
          day: "360",
          num: 100,
        },
        {
          id: 4,
          day: "540",
          num: 100,
        },
        {
          id: 5,
          day: "720",
          num: 200,
        },
      ],
    };
  },
  methods: {
    close() {
      this.$emit("close");
    },
    // 领取累计登录游戏奖励
    subPrize(id) {
      const rid = id + 200;
      const flag = id ? "" : 1;
      this.$emit("subPrize", { flag, rid });
    },
  },
  computed: {
    ...mapState({
      userInfo: "userInfo",
      activty: "activty",
    }),
    prizeList() {
      return this.login_days_record.prize ? this.login_days_record.prize : {};
    },
  },
  mounted() {},
};
</script>
<style scoped lang='stylus'>
.accompany
  padding: 20px 0 40px 0
  .tit-pany
    width: 90%
    height: 100px
    background-image: imgUrl('tit-pany.png')
  .tag-container
    width: 90%
    height: 90px
    .tag-pany
      width: 75%
      height: 34px
      background-image: imgUrl('tag-pany.png')
    span
      font-size: 35px
      color: #F87C5A
  .task-container
    width: 85%
    margin: 50px 0 70px 0
    .task-item
      height: 90px
      display: flex
      align-items: center
      padding: 5px 0
      border-bottom: 1px solid rgba(255, 138, 97, 0.2)
      box-sizing: content-box
      // background-color: green
      &:nth-of-type(1)
        border-top: 1px solid rgba(255, 138, 97, 0.2)
      .task-desc
        width: 80%
        font-size: 22px
        // background-color: red
        span
          font-size: 15px
      .btn-task
        width: 174px
        height: 43px
        font-size: 22px
        color: #FEF7EB
        background-image: imgUrl('btn-task.png')
  .btn-all-task
    width: 239px
    height: 68px
    font-size: 26px
    color: #FDF6E7
    text-shadow: 0px 2px 3px rgba(179, 79, 53, 0.64)
    background-image: imgUrl('btn-task.png')
</style>