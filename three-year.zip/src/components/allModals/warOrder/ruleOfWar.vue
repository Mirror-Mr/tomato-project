<template lang='pug'>
Mymodal(:show="show", @close="close", :longBg="true")
  .ruleOfWar.column-center
    .tit-war.bg-c
    .content-war
      .content1
        b 梅树等级
        br
        span 梅树初始等级为0级，每升1级可领取1档奖励，超过50级后无额外奖励
      .content2
        b 等级提升
        div 
          span 感恩久伴：根据角色过往累计登录天数，可直接领取一定梅树等级奖励，仅限领取1次
          br
          span 踏雪寒梅：活动期间，通过完成每日任务提升梅树等级，任务每日0点刷新
          br
          span 购买等级：购买等级可直接提升梅树等级，6元/级
      .content3
        b 迎冬来
        br
        span 免费奖励线，提升梅树等级可直接领取对应等级奖励
      .content4
        b 盼春归
        br
        span 开通后可解锁”盼春归“奖励线，提升梅树等级可直接领取对应等级奖励
        br
        span 开通盼春归不享受游戏内充值活动
      .content5
        span *寒梅献礼奖励仅可在活动时间内领取，请小主们及时领取
        br
        span *活动最终解释权归《紫禁繁花》官方团队所有
          
</template>
<script>
export default {
  name: "ruleOfWar",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {};
  },
  methods: {
    close() {
      this.$emit("close");
    },
  },
  mounted() {},
};
</script>
<style scoped lang='stylus'>
.ruleOfWar
  padding: 20px 0 20px 0
  .tit-war
      width: 90%;
      height: 100px
      background-image: imgUrl("tit_war.png")
  .content-war
      width: 85%
      margin: 20px 0 0 0
      text-align: justify
      line-height: 35px
      &>div
          margin: 0 0 10px 0
</style>