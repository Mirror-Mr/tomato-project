<!--
 * @Author: your name
 * @Date: 2021-11-11 18:38:01
 * @LastEditTime: 2021-12-21 15:49:33
 * @LastEditors: Please set LastEditors
 * @Description: 登录
 * @FilePath: \three_year\src\components\allModals\bind.vue
-->
<template lang="pug">
Mymodal(:show="show", @close="close")
  .top_tit 登录
  .type_box(v-if="isGt")
    .fb
    .google
    .apple
  .type_box.pt40(v-else-if="!showLoginType")
    .type_item(
      v-for="item in loginPlatList()",
      :key="item.id",
      @click="chosechannel(item)"
    ) 
      img(:src="imgBaseUrl + item.img")
  .type_box.m_between(v-if="showLoginType")
    .type_item(
      v-for="item in loginTYpe()",
      :key="item.id",
      @click="choseLoginType(item)"
    )
      img(:src="imgBaseUrl + item.img")
    //- .back(@click="backTo") <返回上一级
</template>
<script>
import { getActivityTime } from "@/request/api.js";
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      // 是否为港台登录
      isGt: false,
      showLoginType: false,
      imgBaseUrl:
        "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/",
      isEnd: false,
    };
  },
  watch: {
    show(val) {
      val && this.getServerTime();
    },
  },

  methods: {
    close() {
      if (this.showLoginType) {
        this.showLoginType = false;
        return;
      }
      this.$store.commit("SETVAL", { login_type: false });
    },
    // 选择登录渠道
    chosechannel(item) {
      if (this.isEnd) {
        this.$toast("活动已结束！");
        return;
      }
      this.$store.commit("SETVAL", { loginChannel: item.id });
      localStorage.setItem("loginChannel", item.id);
      if (item.id == 2) {
        // 显示角色id登录弹框
        this.$store.commit("SETVAL", { bind_role: true });
      } else {
        // 显示登录方式选择弹框
        this.showLoginType = true;
      }
    },
    // 选择登录类型
    choseLoginType(item) {
      if (this.isEnd) {
        this.$toast("活动已结束！");
        return;
      }
      this.$store.commit("SETVAL", {
        login_type: false,
        loginType: item.id,
        login: true,
      });
    },
    // backTo(){
    // 	this.showLoginType = false
    // },
    loginPlatList() {
      return [
        { txt: "官服", id: "1", img: "common/login_azgf.png" },
        { txt: "IOS", id: "3", img: "common/login_ios.png" },
        { txt: "渠道", id: "2", img: "common/login_azqd.png" },
      ];
    },
    loginTYpe() {
      return [
        { txt: "账号", id: "account", img: "common/login_account.png" },
        { txt: "手机号", id: "phone", img: "common/login_phone.png" },
      ];
    },
    // 获取活动时间
    getServerTime() {
      let time = parseInt(new Date().getTime());
      let access = this.$encrypte([time, 32]);
      getActivityTime({
        time: time,
        project_id: 32,
        access: access,
      })
        .then((data) => {
          //   this.current_time = data.current_time.slice(0, 11).replace(/-/g, "/");
        })
        .catch((err) => {
          if (err.msg.includes("活动结束")) {
            this.isEnd = true;
          }
          this.$toast(err.msg || "获取服务器当前时间失败");
        });
    },
  },
  mounted() {},
};
</script>
<style scoped lang="stylus">
.top_tit
  font($bold)
.type_box
  display: flex
  color: #F87C5A
  justify-content: space-between
  position: relative
  .type_item, .fb, .google, .apple
    width: 190px
    height: 190px
    line-height: 190px
    font-size: 30px
    text-align: center
    // background bg('common/type_btn_bg.png')
    // background-size 100% 100%
    img
      width: 100%
      height: 100%
  .fb
    background: bg('common/fb_btn.png')
    background-size: 100% 100%
  .google
    background: bg('common/google_btn.png')
    background-size: 100% 100%
  .apple
    background: bg('common/apple_btn.png')
    background-size: 100% 100%
.m_between
  margin: 0 70px
.pt40
  padding-top: 40px
.back
  position: absolute
  bottom: -60px
  width: 100%
  text-align: center
</style>
