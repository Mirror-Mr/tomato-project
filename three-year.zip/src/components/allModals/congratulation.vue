<!--
 * @Author: your name
 * @Date: 2021-11-12 19:02:11
 * @LastEditTime: 2021-12-16 18:43:42
 * @LastEditors: Please set LastEditors
 * @Description: 获得奖品弹框
 * @FilePath: \three_year\src\components\allModals\congratulation.vue
-->
<template lang="pug">
	Mymodal(:show="show" @close="close" )
		.tit.congratulation_tit 
		.img_box(v-if="!isEnd && !islimit")
			img.reward(:class="{'ml':!isturn}" :src="gift.img")
			//- img.reward(:class="{'ml':!isturn}" src="https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/redEnvelopes/d_1.png")
			.tip_had(v-if="isturn") 该卡片已拥有<br/>自动转化为
				span.red  万能卡 *1
		.is_end( v-if="isEnd || islimit") 
			span(v-if="isEnd") 该红包奖励已被领完，<br/> 
			span(v-if="islimit") 您今日领取已达上限！
		.txt 集齐6个部件可免费领取火霓鹿呦套装！
		.tip_other
			i.icon_leaf
			span 看看其他人的红包奖励
		.tip_list
			.tip_item(v-for="(item,index) in list" :key="index")
				.item_left.clearfix
					img.fl(:src="getAward(item) ? getAward(item).contImg : ''")
					span.fl {{getAward(item) ? getAward(item).name : ''}}
				.time_right
					div {{`${item.server_name} ${item.role_name}`}}  
					div {{item.createtime}}
</template>
<script>
import { getRedUsers } from "@/request/api.js";
import {all} from './activity_1_list'
import { mapState } from "vuex";
export default {
  name: "",
  props: {
    show: {
      type: Boolean,
      default: false
    },
  },
	watch:{
		show(val){
			if(val){
				this.getdetailInfo()
			} else {
				this.info = null
				this.$store.commit("SETVAL",{red_detail_info:null})
			}
		},
		info:{
			handler(val){
				if(val){
					this.list = val.list || [];
					if(val.is_get != 1) {
						this.isEnd = this.list.length >= 3 && !val.get_info.rid ;
						this.islimit = val.num >= this.red_limit ;
					}
					this.isturn = val.get_info && val.get_info.rid == 0;
					
					if(!this.isEnd  && !this.islimit) {
						let id = val.get_info.rid ==='0'? val.get_info.rrid : val.get_info.rid
						this.gift = all.find(item=> item.id == id)
					}
				}else {
					this.isturn=false
					this.isEnd=false
					this.islimit=false
					this.list=[]
					this.gift={
						img:'',
						name:'',
						id:'',
					}
				}
			},
			deep:true,
			immediate:true
		}
	},
	computed: mapState(["red_limit",]),
  data() {
    return {
			// 是否转为万能卡
			isturn:false,
			// 红包是否被领取完了
			isEnd:false,
			// 当日领取红包数是否达到上限
			islimit:false,
			// 领取列表
			list:[],
			// 当前红包的礼品详情
			gift:{
				img:'',
				name:'',
				id:''
			},
			info:null,
      imgbase:
        "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/",
    };
  },
  methods: {
    close() {
			this.$store.commit("SETVAL", { congratulation: false });
      // this.$emit("close");
    },
		// 获取奖励内容
		getAward(item){
			let award = all.find(data=>data.id == item.rid)
			return award
		},
		// 获取红包领取详情
		getdetailInfo(){
			let red_id = this.$route.query.red_id
			if(!red_id) return
			this.$store.dispatch('getReddetailInfo',red_id).then(data=>{
				this.$router.push(this.$route.path)
				this.$set(this,'info',data)
			})

		// 	let time = parseInt(new Date().getTime());
		// 	let token = localStorage.getItem("token");
		// 	let access = this.$encrypte([time, token]);
		// 	getRedUsers({
		// 		time:time,
		// 		token:token,
		// 		red_id:red_id,
		// 		access:access
		// 	}).then(data=>{

		// 		this.$router.push(this.$route.path)
		// 		// data.get_info.rid = 4
		// 		// data.num = '2'
		// 		this.$set(this,'info',data)
		// 		// data && (this.info = data)
		// 	}).catch(err=>{
		// 		this.$toast(err.msg||'获取红包领取详情失败！')
		// 	})
		},

  },
  mounted() {}
};
</script>
<style scoped lang="stylus">
.congratulation_tit
	background	bg('common/congratulation_tit.png')
	background-size 100% 100%
.img_box
	display flex
	box-sizing border-box
	padding-left 70px
	.tip_had
		padding 60px 0 0 0
	.red
		color #FF6059
.reward
	width 192px
	height 192px
.ml
	margin-left 120px
.is_end
	text-align center
	color #F97F59
	font-size 34px
	font-weight bold
	margin 30px 0
.txt
	font-size 24px
	color #D5755B
	text-align center
	padding-bottom 60px
	border-bottom 1px solid rgba(255, 138, 97, .3)
	margin 0 40px
	font-weight bold
.tip_other
	padding 10px 0 0 40px
	i.icon_leaf
		width 25px
		height 25px
		background	bg('common/icon_leaf.png')
		background-size 100% 100%
		display inline-block
	span
		color #F87C5A
		font-size 24px
.tip_list
	margin 0 40px
	.tip_item
		display flex
		justify-content space-between
		height 84px
		border-bottom 1px dashed rgba(255, 138, 97, .5)
		.item_left
			color #F87C5A
			font-size 22px
			line-height 84px
			padding-top 2px
			img
				width 105px
				height 80px
			span
				margin-left 10px
		.time_right
			color #D5755B
			font-size 20px
			line-height 35px
			padding-top 10px
</style>
