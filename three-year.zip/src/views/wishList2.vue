<template lang="pug">
.wish2
  LoginStatus(ref="login")
  .rule(@click="ruleDialog = true") [活动规则]
  .content-wrapper
    .content-items
      .content-item(v-for="(award,index) in signAward", @click="signIn(award)" ,:key="award.id", :class="{ 'active': canSign(award.id)  }")
          .item-name {{ award.name }}
          .item-img
            img(:src="award.img")
            .item-count *{{ award.count }}
          .item-text 第{{ serialNumber[index] }}天
          //- 已签到遮罩
          .item-shade(:class="{ 'isFinish': isSign(award.id) }")
  Mymodal(:show="dialog" @close="close" @sure="sure" surebtn suretext="好的")
    .msg-box
      .property-box
        .property-icon 
          img(:src="currentAward.img")
        .property-text
          span {{ currentAward.name }}*{{ currentAward.count }}
      p 恭喜您获得 <span class="text">{{  currentAward.name }}</span>
      p 请到游戏内邮箱领取奖励。
  Mymodal(:show="ruleDialog", @close="close", @sure="close", surebtn)
    .msg-box1
      p 1. 活动时间：2021年12月24日-2022年1月6日。
      p 2. 活动开始时，可从奖池中各选择一个心仪的道具和头像框（8选1）。
      p 3. 活动期间，完成累计签到次数即可获取对应的奖励。
      p 4. 最终解释权归《紫禁繁花》官方团队所有。
      p.tips * 心愿道具选择后不可进行更改，请小主们认真挑选哦~
    //- 确认弹框
</template>

<script type="text/javascript">
import { mapState } from "vuex";
import { logLogin } from "@/request/api.js";
import { debounce } from "@/utils/index";
export default {
  name: "wishList1",
  data() {
    return {
      serialNumber: [
        "一",
        "二",
        "三",
        "四",
        "五",
        "六",
        "七",
        "八",
        "九",
        "十",
        "十一",
        "十二",
        "十三",
        "十四"
      ],
      dialog: false,
      currentAward: {},
      ruleDialog: false
    };
  },
  methods: {
    close() {
      this.dialog = false;
      this.ruleDialog = false;
    },
    sure() {
      this.close();
    },
    signIn: debounce(async function(award) {
      console.log("award", award);
      if (this.userInfo) {
        let time = parseInt(new Date().getTime());
        let token = localStorage.getItem("token");
        let access = this.$encrypte([time, token]);
        try {
          const data = await logLogin({
            time,
            token,
            num: award.id + "",
            access
          });
          // 签到成功后修改award.id 对应的状态
          if (data) {
            this.$store.dispatch("getInfo", 3);
            this.currentAward = award;
            this.dialog = true;
          }
        } catch (err) {
          this.$toast("签到失败");
        }
      } else {
        this.$refs.login.showlogin();
      }
    }),
    isSign(id) {
      if (this.activty?.prize) {
        return Object.keys(this.activty.prize).some(item => {
          return id === Number(item);
        });
      }
      return false;
    },
    canSign(id) {
      if (id > Number(this.activty?.days)) {
        return false;
      }
      if (this.activty?.prize) {
        return Object.keys(this.activty.prize).every(item => {
          return id !== Number(item);
        });
      }
      return false;
    }
  },
  computed: {
    ...mapState({
      // 用户信息
      userInfo: "userInfo",
      bind_role: "bind_role",
      // 本活动页的信息
      activty: "activty"
    }),
    ...mapState("wish", {
      propertyWishList: "propertyWishList",
      headWishList: "headWishList",
      signAward: "signAward"
    })
  },
  watch: {
    userInfo(newVal) {
      // 如果userInfo存在，并且已经未选择心愿礼物
      if (newVal && !newVal.choose_rid) {
        this.$router.replace("/wishlist1");
      } else if (newVal) {
        // 如果userInfo存在 则更新当前
        this.$store.commit("wish/setHeadWish", {
          choose_rid: newVal.choose_rid
        });
      } else {
        window.location.reload();
      }
    }
  },
  mounted() {
    let token = localStorage.getItem("token");
    token && this.$store.dispatch("getInfo", 3);
  }
};
</script>

<style lang="stylus" scoped>
// @font-face
//     font-family: FZSHENGSKSJW_JIANTI;
//     src: url(../assets/font/FZSHENGSKSJW_JIANTI.ttf);

.wish2
  position: relative;
  height: 1624px;
  background-image:bg('wishList/wish2-bg.jpg');
  background-size: 100%;
  .login_status
    position: absolute;
    right: 0;
  .rule
    position: absolute;
    top: 148px;
    right: 40px;
    font-size: 20px;
    color: #f83b18;
    text-align: right;
  .content-wrapper
    position: absolute;
    width: 657px;
    height: 1024px;
    top: 211px;
    left: 50%;
    transform: translateX(-50%);
    .content-items
      position: relative;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-evenly;
      margin: 0 13px 0;
      .content-item
        position: relative;
        width: 130px;
        height: 230px;
        background-image: bg('wishList/wish2-icon-normal.png');
        background-size: 100% 100%;
        // font-family: FZSHENGSKSJW_JIANTI;
        pointer-events: none;
        &.active
            background-image: bg('wishList/wish2-icon-active.png');
            pointer-events: auto;
        &:nth-of-type(n + 1)
            height: 228px;
        &:nth-of-type(n + 5)
            margin-top: 37px;
            height: 224px;
        &:nth-of-type(n + 9)
            margin-top: 38px;
            height: 224px;
        &:nth-of-type(n + 13)
            margin-top: 32px
            height: 229px;
        .item-name
          text-align: center;
          font-size: 20px;
          color #db8064;
          margin-top: 54px;
        .item-img
            position: relative;
            width: 69px;
            height: 65px;
            margin: -2px auto 0;
            display: flex;
            justify-content: center;
            align-items: center;
            .item-count
              position: absolute;
              bottom: -4px;
              left: 50%;
              transform: translateX(-50%);
              color #fff;
              font-size: 16px;
              // text-shadow: 0px 0px 3px #fff;
              text-shadow: rgba(227, 82, 37, .47) 1px 0 0,  rgba(227, 82, 37, .47)  0 1px 0,  rgba(227, 82, 37, .47)  -1px 0 0,  rgba(227, 82, 37, .47)  0 -1px 0;
            img
              width:auto;
              height: 80%
        .item-text
          text-align: center;
          font-size: 26px
          color: #fff1c8;
          margin-top: 10px
        .item-shade
          position: absolute;
          top: 0;
          width: 100%;
          height: 100%;
          display: none;
          background-image: bg('wishList/wish2-icon-shade.png');
          background-size: 100% 100%;
          z-index: 5;
          &.isFinish
              display: block;
  .msg-box
    margin-top: 17px;
    .property-box
      position: relative;
      margin: 0 auto;
      width: 242px;
      height: 241px;
      background-image: bg('wishList/tk-daoju-bg.png');
      background-size: 100% 100%;
      .property-text
        position: absolute;
        left: 0;
        right: 0;
        bottom: 30px;
        margin: 0 auto;
        height: 34px;
        background-image: bg('wishList/tk-daoju-text-bg.png');
        background-size: 100% 100%;
        line-height: 34px;
        text-align: center;
        font-size: 30px;
        color #fff;
        span
          opacity: .8;
      .property-icon
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        img
          width: auto;
          height: 120px;
    p
      font-size: 28px;
      text-align: center;
      color: #d5755b;
      .text
        color: #ff6059;
.msg-box1
  margin-top: 100px;
  padding: 0 20px;
  p
    font-size: 26px;
    text-align: left;
    margin-top: 10px;
    color: #d5755b;
    &.tips
      text-align: left;
      color: #ff6059;
</style>
