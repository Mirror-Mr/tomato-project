<template lang="pug">
.wish1
  LoginStatus(ref="login")
  .activity-content
    .rule(@click="ruleDialog = true") [活动规则]
    .content-wrapper
      .content-title
        img(
          src="https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/property-title.png"
        )
      .content-items
        .content-item(
          v-for="(property, index) in propertyWishList",
          :key="property.id"
        )
          .item-img(
            @click="togglePropertyActive(property.id)",
            :class="{ active: currentPropertyActive === property.id }"
          )
            img(:src="property.img")
            .item-count *{{ property.count }}
          p.item-text {{ property.name }}
    .content-wrapper.head-wish
      .content-title
        img(
          src="https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/head-title.png"
        )
      .content-items
        .content-item(v-for="(head, index) in headWishList", :key="head.id")
          .item-img(
            @click="toggleHeadActiveActive(head.id)",
            :class="{ active: currentHeadActive === head.id }"
          )
            img(:src="head.img")
          p.item-text {{ head.name }}
    .ensure-btn(@click="ensure", :class="{ gray: !canSelect }")
      .btn-text 确认选择
    .tip 提示：选择即可签到领取奖励
  Mymodal(:show="dialog", @close="close", @sure="sure", surebtn, canclebtn)
    .msg-box
      p 选定心愿奖励后将不可更改
      p 确认选择该道具及头像框作为心愿奖励吗？
  Mymodal(:show="ruleDialog", @close="close", @sure="close", surebtn)
    .msg-box1
      p 1. 活动时间：2021年12月24日-2022年1月6日。
      p 2. 活动开始时，可从奖池中各选择一个心仪的道具和头像框（8选1）。
      p 3. 活动期间，完成累计签到次数即可获取对应的奖励。
      p 4. 最终解释权归《紫禁繁花》官方团队所有。
      p.tips * 心愿道具选择后不可进行更改，请小主们认真挑选哦~
//- 确认弹框
</template>

<script type="text/javascript">
import { chooseGift, clickLog } from "@/request/api.js";
import { mapState } from "vuex";
import { debounce } from "@/utils/index";
export default {
  name: "wishList1",
  data() {
    return {
      currentPropertyActive: 0,
      currentHeadActive: 0,
      dialog: false,
      ruleDialog: false
    };
  },
  methods: {
    togglePropertyActive(i) {
      if (this.userInfo) {
        this.currentPropertyActive = i;
      } else {
        this.$refs.login.showlogin();
      }
    },
    toggleHeadActiveActive(i) {
      if (this.userInfo) {
        this.currentHeadActive = i;
      } else {
        this.$refs.login.showlogin();
      }
    },
    ensure() {
      if (this.canSelect) {
        this.dialog = true;
      }
    },
    close() {
      this.dialog = false;
      this.ruleDialog = false;
    },
    sure: debounce(async function() {
      const gift = [
        this.currentPropertyActive,
        this.currentHeadActive
      ].toString();
      let time = Date.now();
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token, gift]);

      let access1 = this.$encrypte([time]);
      // 打开弹窗就打点
      clickLog({
        time,
        access: access1,
        type: 4,
        extra: this.currentPropertyActive,
        state: 1
      });
      // 打开弹窗就打点
      clickLog({
        time,
        access: access1,
        type: 5,
        extra: this.currentHeadActive,
        state: 1
      });
      try {
        const data = await chooseGift({ time, token, access, gift });
        if (data) {
          this.$store.commit("wish/setHeadWish", {
            choose_rid: gift
          });
          this.$router.replace("/wishlist2");
        }
      } catch (err) {
        this.$toast(err.msg || "选择失败");
      }
      this.close();
    })
  },
  computed: {
    canSelect() {
      return !!this.currentPropertyActive && !!this.currentHeadActive;
    },
    ...mapState([
      // 用户信息
      "userInfo"
    ]),
    ...mapState("wish", {
      propertyWishList: "propertyWishList",
      headWishList: "headWishList"
    })
  },
  watch: {
    userInfo(newVal, oldVal) {
      if (newVal && newVal.choose_rid) {
        this.$store.commit("wish/setHeadWish", {
          choose_rid: newVal.choose_rid
        });
        this.$router.replace("/wishlist2");
        return;
      }
      if (!newVal) {
        window.location.reload();
        return;
      }
      if (newVal && oldVal) {
        if (newVal.role_id !== oldVal.role_id) {
          window.location.reload();
          return;
        }
      }
    }
  },
  mounted() {
    let token = localStorage.getItem("token");
    token && this.$store.dispatch("getInfo", 3);
  }
};
</script>

<style lang="stylus" scoped>
// @font-face
// font-family: SourceHanSerifCN-Regular;
// src: url(../assets/font/SourceHanSerifCN-Regular.ttf);
// @font-face
//     font-family: FZSHENGSKSJW_CU;
//     src: url(../assets/font/FZSHENGSKSJW_CU.ttf);
.wish1
  position: relative;
  height: 1624px;
  background-image: bg('wishList/wish1-bg.jpg');
  background-size: 100% auto;
  .login_status
    position: absolute;
    right: 0;
  //   font-size: 16px
  //   position: absolute;
  //   right: 10px;
  // >>>.name
  //   display: block;
  //   margin-left: 0;
  //   padding-bottom: 5px;
  //   & + span
  //     margin-left: 20px;
  .activity-content
    position: absolute;
    width: 558px;
    height: 960px;
    top: 240px;
    left: 50%;
    transform: translateX(-50%);
    .rule
      font-size: 20px;
      color: #f83b18;
      text-align: right;
    .content-wrapper
      &.head-wish
          margin-top: 40px
        .content-items
          .content-item
            margin-top: 20px;
      .content-title
        width: 558px;
        height: 54px;
        margin: 0 auto;
        img
          width: 100%;
          height: 100%;
      .content-items
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        // font-family: SourceHanSerifCN-Regular;
        font-weight: 200;
        .content-item
          flex: 1;
          margin-top: 20px;
          min-width: 139.5px;
          .item-img
            position: relative;
            width: 106px;
            height: 96px;
            background-image: bg('wishList/normal-icon.png');
            background-size: 100% 100%;
            margin: 0 auto;
            display: flex;
            justify-content: center;
            align-items: center;
            &.active
              background-image: bg('wishList/active-icon.png');
            img
              width: 80%;
            .item-count
              position: absolute;
              bottom: 2px;
              right: 14px;
              color #686868;
              font-size: 18px;
              // text-shadow: rgba(227, 82, 37, .47) 1px 0 0,  rgba(227, 82, 37, .47)  0 1px 0,  rgba(227, 82, 37, .47)  -1px 0 0,  rgba(227, 82, 37, .47)  0 -1px 0;
          .item-text
            margin-top: 12px;
            font-size: 20px;
            color #202021;
            text-align: center;
    .ensure-btn
      position: relative;
      width: 359px;
      height: 137px;
      // background-image: bg('wishList/wish1-ensure-btn-disabled.png');
      background-image: bg('wishList/wish1-ensure-btn.png');
      background-size: 100% 100%;
      margin: 12px auto 0;
      text-align: center;
      line-height: 170px;
      color: #fff;
      font-size: 48px;
      .btn-text
        // font-family: FZSHENGSKSJW_CU;
        // background: linear-gradient(to bottom, #fdffb7 30%, #fff 100%);
        // text-shadow: 0 0 1px #fdffb7;
        // -webkit-background-clip: text;
        // color: transparent;
        color: #fdffb7;
    .tip
      text-align: center;
      margin-top: 12px;
      font-size: 24px;
      color: #202021;
  .msg-box
    margin-top: 100px;
    padding: 0 25px;
    p
      font-size: 28px;
      text-align: center;
      &:nth-of-type(1)
        color: #ff6059;
      &:nth-of-type(2)
        color: #d5755b;
  .msg-box1
    margin-top: 100px;
    padding: 0 20px;
    p
      font-size: 26px;
      text-align: left;
      margin-top: 10px;
      color: #d5755b;
      &.tips
        text-align: left;
        color: #ff6059;
</style>
