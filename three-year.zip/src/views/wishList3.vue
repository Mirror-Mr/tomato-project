<template lang="pug">
.wish3
  LoginStatus(ref="login")
  //- 左右按钮和swiper需要在容器外，所以加一层盒子
  .swiper-container__wapper
    .rule(@click="ruleDialog = true") [活动规则]
    .swiper-container
      .swiper-wrapper
        .swiper-slide(v-for="(item,index) in clothingList", :key="item.id")
          .clothing-name
            .name-text {{item.name}}
          img(:src="item.img")
      .clothing-front
      .clothing-tips 选择一套您喜欢的往期套装购买
    .swiper-button-prev
    .swiper-button-next
  //- 分页器单独在一个盒子
  .swiper-pagination
  .ensure-btn(@click="ensure"  :class="{'gray': isPay}") 
    .btn-text 
      p {{  isPay ? '已购买' : '￥328' }}
      p.discount 三周年感恩优惠价
  .limit 限购 {{  isPay ? 1 : 0 }}/1次
  //- 确认弹框
  Mymodal(:show="dialog" @close="close" @sure="sure" surebtn :canclebtn="!isPayCallBack")
    .msg-box
      p {{ msg }}
      p {{ msg1 }}
  Mymodal(:show="ruleDialog", @close="close", @sure="close", surebtn)
    .msg-box1
      p 1. 活动时间：2021年12月24日-2022年1月6日。
      p 2. 活动期间, 可从奖池 中选择一套心仪的服装（11选1）进行购买。
      p 3. 心愿服装每位用户限购一次。
      p 4. 最终解释权归《紫禁繁花》官方团队所有。
      p.tips * 服装购买后，该活动内其他服装将不可再次购买，请小主们认真挑选哦~
</template>

<script type="text/javascript">
import Swiper from "swiper";
import "swiper/dist/css/swiper.min.css";
import { pay, getOrderStatus, clickLog } from "@/request/api.js";
import { mapState } from "vuex";
import { debounce, getQueryValue, isWeChat } from "@/utils/index";
export default {
  name: "wishList1",
  data() {
    return {
      dialog: false,
      isDisable: true,
      swiper: null,
      clothingList: [
        {
          id: 1,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/clothing/1.jpg",
          name: "绮罗套装",
          mainlandPrice: 328,
          hkAndMacaoPrice: 49.99,
          kind: 95
        },
        {
          id: 2,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/clothing/2.jpg",
          name: "点绛唇",
          mainlandPrice: 328,
          hkAndMacaoPrice: 49.99,
          kind: 95
        },
        {
          id: 3,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/clothing/3.jpg",
          name: "金宵折枝",
          mainlandPrice: 328,
          hkAndMacaoPrice: 49.99,
          kind: 95
        },
        {
          id: 4,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/clothing/4.jpg",
          name: "风华绝代",
          mainlandPrice: 328,
          hkAndMacaoPrice: 49.99,
          kind: 95
        },
        {
          id: 5,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/clothing/5.jpg",
          name: "粉黛",
          mainlandPrice: 328,
          hkAndMacaoPrice: 49.99,
          kind: 95
        },
        {
          id: 6,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/clothing/6.jpg",
          name: "霓裳玉容",
          mainlandPrice: 328,
          hkAndMacaoPrice: 49.99,
          kind: 95
        },
        {
          id: 7,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/clothing/7.jpg",
          name: "骊黄弥霓",
          mainlandPrice: 328,
          hkAndMacaoPrice: 49.99,
          kind: 95
        },
        {
          id: 8,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/clothing/8.jpg",
          name: "帝青空阔",
          mainlandPrice: 328,
          hkAndMacaoPrice: 49.99,
          kind: 95
        },
        {
          id: 9,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/clothing/9.jpg",
          name: "金陵意气",
          mainlandPrice: 328,
          hkAndMacaoPrice: 49.99,
          kind: 95
        },
        {
          id: 10,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/clothing/10.jpg",
          name: "彼岸花",
          mainlandPrice: 328,
          hkAndMacaoPrice: 49.99,
          kind: 95
        },
        {
          id: 11,
          img:
            "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/clothing/11.jpg",
          name: "芷画",
          mainlandPrice: 328,
          hkAndMacaoPrice: 49.99,
          kind: 95
        }
      ],
      currentClothing: 1,
      msg: "购买完成后，其它服装将不可购买。",
      msg1: "是否确认购买？",
      isPayCallBack: false,
      ruleDialog: false
    };
  },
  methods: {
    initSwiper() {
      let that = this;
      this.swiper = new Swiper(".swiper-container", {
        loop: true, // 循环模式选项
        slidesPerView: "auto",
        autoplay: 1000,
        pagination: {
          el: ".swiper-pagination",
          clickable: true
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev"
        },
        observer: true,
        observeParents: true,
        on: {
          slideChangeTransitionStart: function() {
            that.currentClothing = this.realIndex + 1;
          }
        }
      });
    },
    ensure() {
      if (this.userInfo) {
        // 测试
        if (this.isPay) return;
        this.dialog = true;
        let time = parseInt(new Date().getTime());
        let access = this.$encrypte([time]);
        // 打开弹窗就打点
        clickLog({
          time,
          access,
          type: 6,
          extra: this.currentClothing,
          state: 1
        });
      } else {
        this.$refs.login.showlogin();
      }
    },
    close() {
      this.dialog = false;
      this.ruleDialog = false;
    },
    sure: debounce(async function() {
      // 支付成功回调逻辑
      if (this.isPayCallBack) {
        this.dialog = false;
        return;
      } else {
        this.msg = "购买完成后，其它服装将不可购买。";
        this.msg1 = "是否确认购买？";
      }
      // 支付逻辑
      let time = parseInt(new Date().getTime());
      let token = localStorage.getItem("token");
      let access = this.$encrypte([time, token]);
      let wxid = "";
      if (isWeChat()) {
        wxid = sessionStorage.getItem("wxid");
      }
      try {
        const data = await pay({
          time,
          token,
          good_id: this.currentClothing + "",
          num: "1",
          access,
          wxid
        });
        // 调起支付
        if (data) {
          localStorage.setItem("orderId", data.orderid);
          console.log(data.url);
          location.href = data.url;
        }
      } catch (err) {
        console.log("err", err);
        this.$toast("购买失败");
      }
    }),
    // 获取订单状态
    getOrderStatus() {
      let time = parseInt(new Date().getTime());
      const orderid = localStorage.getItem("orderId");
      if (!orderid) {
        return;
      }
      let access = this.$encrypte([time, orderid]);
      return new Promise(resolve => {
        getOrderStatus({
          time,
          orderid,
          access
        }).then(res => {
          resolve(res);
        });
      });
    },
    // 是否支付成功
    async isPaySuccess() {
      const str = location.href.split("?")[1];
      if (str) {
        const orderid = str.split("=")[1];
        if (orderid) {
          const value = sessionStorage.getItem(`${orderid}`);
          if (!value) {
            const data = await this.getOrderStatus();
            if (data?.status > 0) {
              // 支付成功，将orderid 存入sessionStorage中， 避免用户刷新次页面时再次弹窗
              sessionStorage.setItem(`${orderid}`, "1");
              this.handlePaySuccess();
            }
          }
        }
      }
    },
    handlePaySuccess() {
      this.isPayCallBack = true;
      this.msg = "购买成功！";
      this.msg1 = "请到游戏内邮箱领取奖励！";
      this.dialog = true;
    }
  },
  computed: {
    ...mapState({
      // 用户信息
      userInfo: "userInfo",
      activty: "activty"
    }),
    isPay() {
      return (
        this.activty &&
        Object.prototype.hasOwnProperty.call(this.activty, "gid")
      );
    }
  },
  watch: {
    userInfo(newVal) {
      // console.log("userInfo", newVal, oldVal);
      // 如果没有新的newVal说明是退出登录了，重置页面状态
      if (!newVal) {
        window.location.reload();
      }
    }
  },
  created() {
    this.isPaySuccess();
  },
  mounted() {
    this.initSwiper();
    let token = localStorage.getItem("token");
    token && this.$store.dispatch("getInfo", 4);
    // 判断是否为微信环境
    if (isWeChat()) {
      const wxid = getQueryValue("wxid");
      if (wxid) {
        sessionStorage.setItem("wxid", wxid);
      }
      let data = sessionStorage.getItem("wxid");
      if (!data) {
        location.href = `https://api.xianyuyouxi.com/service/activity/zjfh_third_ani/getauth?url=${encodeURIComponent(
          location.href
        )}`;
      }
    }
  }
};
</script>
<style scoped lang="stylus">
.wish3
  position: relative;
  height: 1624px;
  background-image: bg('wishList/wish3-bg.jpg');
  background-size: 100% auto;
  .login_status
    position: absolute;
    right: 0;
  .swiper-container__wapper
    position: relative;
    width: 559px;
    top: 248px;
    margin-left: 104px;
    .rule
      font-size: 20px;
      color: #f83b18;
      text-align: right;
    .swiper-container
      position: relative;
      width: 386px;
      margin-top: 20px;
      .swiper-wrapper
        position: relative;
        width: 386px;
        height: 767px;
        margin: 0 auto;
        .swiper-slide
          width: 100%;
          height: 100%;
          .clothing-name
            position: absolute;
            width: 51px;
            height: 169px;
            right: 17px;
            background-image: bg('wishList/clothing-name-bg.png');
            background-size: 100% 100%;
            color: #fff1c8;
            font-size: 23px;
            text-align: center;
            // font-family: FZSHENGSKSJW_CU;
            .name-text
              position: absolute;
              width: 22px;
              color: #fff1c8;
              margin: auto 0;
              line-height: 26px;
              left: 50%;
              top: 50%;
              transform: translate(-50%, -39%);
          img
              width: 100%;
              height: 100%;
      .clothing-front
        position: absolute;
        top: 0;
        left:0;
        width: 100%;
        height: 100%;
        background-image: bg('wishList/clothing-bg.png');
        background-size: 100% 100%;
        z-index: 11;
      .clothing-tips
        position: absolute;
        left: 0;
        bottom: 2px;
        width 100%;
        height: 41px;
        line-height: 41px;
        background: rgba(0, 0, 0, 1);
        color: #fff;
        opacity: .5;
        font-size: 20px;
        text-align: center;
        z-index: 10;
    .swiper-button-prev
      background-image:  bg('wishList/button-prev.png');
      background-size: 100% 100%;
      width: 48px;
      height: 60px;
      left: 0;
      -webkit-tap-highlight-color: transparent;
      &.swiper-button-disabled
        opacity: .7;
    .swiper-button-next
      background-image: bg('wishList/button-next.png');
      background-size: 100% 100%;
      width: 48px;
      height: 60px;
      right: 0;
      -webkit-tap-highlight-color: transparent;
  .swiper-pagination
    position: absolute;
    left: 50%;
    top: 1060px;
    transform: translate(-50%);
    >>>.swiper-pagination-bullet
      width: 14px;
      height: 14px;
      margin: 0 8px;
      &.swiper-pagination-bullet-active
        background: #ffab3e;
  .limit
    position: absolute;
    top: 1227px;
    left: 104px;
    color: #202021;
    font-size: 22px;
    opacity: .7;
    // font-family: SourceHanSerifCN-Regular;
  .original-cost
    position: absolute;
    left: 308px;
    top: 1227px;
    color: #febead;
    font-size: 24px;
    text-decoration:line-through;
    // font-family: SourceHanSerifCN-Regular;
  .ensure-btn
    position: absolute;
    width: 359px;
    height: 137px;
    background-image:bg('wishList/ensure-btn.png');
    background-size: 100% 100%;
    top: 1090px;
    left: 50%;
    transform: translateX(-50%);
    text-align: center;
    color: #fff;
    font-size: 48px;
    font-family: SourceHanSerifCN-Regular;

    .btn-text
      // background: linear-gradient(to bottom, #fdffb7 30% , #fff 100%);
      // -webkit-background-clip: text;
      text-shadow: 0 0 1px #fdffb7;
      color:  #fdffb7;
      p:nth-of-type(1)
        margin-top: 34px;
      .discount
        line-height: 14px;
        font-size: 18px;
        text-align: center;
        color: #ffeab8;
        opacity: .9;
  .msg-box
    margin-top: 122px;
    p
      font-size: 28px
      text-align: center;
      &:nth-of-type(1)
          color: #ff6059;
      &:nth-of-type(2)
          color: #d5755b;
  .msg-box1
    margin-top: 100px;
    padding: 0 20px;
    p
      font-size: 26px;
      text-align: left;
      margin-top: 10px;
      color: #d5755b;
      &.tips
        text-align: left;
        color: #ff6059;
</style>
