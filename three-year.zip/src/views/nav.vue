<template  lang="pug">
.nav
  .title 临时导航页（导航页设计图还未给到）
  ul
    li(v-for="(item, index) in navList", :key="index" @click="jump(item.path)") {{ item.name }}
  .remark 备注：活动六还在开发中，部分活动规则未配置，可以先不测
</template>
<script>
export default {
  name: "",
  data() {
    return {
      navList: [
        { name: "活动一", path: "redEnvelope" },
        { name: "活动二", path: "askSign" },
        { name: "活动三", path: "wishlist1" },
        { name: "活动四", path: "wishlist3" },
        { name: "活动五", path: "warorder" },
        { name: "活动六", path: "phonereserve" },
      ],
    };
  },
  methods: {
    jump(path) {
      this.$router.push(path)
    }
  },
  mounted() {},
};
</script>
<style scoped lang='stylus'>
.nav
  width: 100%
  height: 100vh
  .title
    width: 100%
    margin: 80px 0
    text-align: center
  ul
    width: 100%
    padding: 0 180px
    line-height: 60px
  .remark
    width: 100%
    text-align: center
    margin-top: 80px
    padding: 0 20px
</style>