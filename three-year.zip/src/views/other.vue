<template lang="pug">
.phoneReserve.bg-c.column-center
  .btn-container
    .btn.bg-c.inner-center(
      v-for="item in btnList",
      :class="{ click: index == item.id }",
      v-html="item.desc",
      @click="index = item.id"
    ) 
  .content-container
    template(v-if="index == 1")
      .order-methods
        span 活动规则：
        span 1. 活动时间：2021年12月24日-2021年12月31日。
        span 2. 每日登录游戏，可通过邮件领取周年登录奖励。
        span *当日奖励仅在当天登录可领取，未登录则无当日邮件奖励
    template(v-if="index == 2")
      .order-methods
        span 活动规则：
        span 1. 活动开始时间：2021年12月24日
        span 2. 元宝充值界面中，首次充值得双倍元宝奖励重置，以往已享受过双倍返利的小主们也可参与。
        span 3. 首次双倍元宝返利请在游戏内邮件查收。
    template(v-if="index == 3")
      .title-box.column-center
        .title 【三周年庆典服】
        .time 开服时间：2021年12月24日 10:00
      .order-methods
        span 参与方式:
        span 【三周年庆典服】现已开启，进入游戏登陆界面，选择服务器列表，找到【三周年庆典服】进入即可
      .welfare-box.column-center
        .title-welfare 【三周年庆典服】专属福利
        .welfare1
          b 第一弹：开服庆典<br>
          span 活动时间：2021年12月24日 - 2022年1月6日<br>
          span 活动规则：登录即可在邮箱中领取价值5000元宝 “庆典服礼包”
        .welfare2
          b 第二弹：限定称号<br>
          span 活动时间：创建角色后7日内<br>
          span 活动规则：参与七日签到活动，即可领取专属称号“三年有你”
        .welfare3
          b 第三弹：新服锦鲤<br>
          span 活动时间：12月24日 - 12月25日<br>
          span 第1波（24号下午3点）：抽取10名幸运玩家送上元宝*8888<br>
          span 第2波（24号下午6点）：抽取8名幸运玩家，送上价值1万元宝的资源大礼包<br>
          span 第3波（25号下午3点）：抽取5名充值过的玩家送上年卡1张（充值任意金额即可参与）
</template>
<script>
export default {
  name: "phoneReserve",
  data() {
    return {
      time: Date.now(),
      index: 1,
      btnList: [
        {
          id: 1,
          desc: `登录<br>福利`,
        },
        {
          id: 2,
          desc: `首充<br>双倍`,
        },
        {
          id: 3,
          desc: `周年<br>庆典服`,
        },
      ],
    };
  },
  methods: {},
  mounted() {},
};
</script>
<style scoped lang='stylus'>
.phoneReserve
  width: 100%
  height: 1869px
  background-image: bg('phoneReserve/bg_other.jpg')
  overflow: hidden
.btn-container
  width: 90%
  display: flex
  justify-content: space-around
  margin: 580px 0 0 0
.btn
  width: 200px
  height: 200px
  text-align: center
  color: #85521B
  font-size: 36px
  font($bold)
  background-image: bg('phoneReserve/btn-nav-noclick.png')
  &.click
    height: 194px
    color: #fff
    background-image: bg('totalNav/btn-nav.png')
.content-container
  width: 86%
  margin: 50px 0 0 0
  .order-methods
    line-height: 40px
    span
      display: block
      font-size: 22px
      &:nth-of-type(1)
        color: #C52A13
        font($bold)
      &:not(:nth-of-type(1))
        color: #714E4B
        font($regular)
  .title-box
    margin: 10px 0 20px 0
    font-size: 19.02px
    color: #C52A13
    line-height: 39px
    font($bold)
  .welfare-box
    margin: 20px 0 0 0
    font-size: 22px
    align-items: flex-start
    b, .title-welfare
      color: #C52A13
      font($bold)
    .title-welfare
      margin: 20px 0
    span
      color: #714E4B
      line-height: 42px
      font($regular)
</style>