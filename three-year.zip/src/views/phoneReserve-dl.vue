<template lang="pug">
.phoneReserve.bg-c.column-center
  .top-desc-container
    .order-time 
      span 预约时间：
      span 2021年12月17日 - 2021年12月23日
    .order-methods
      span 预约方法：
      span 1.输入手机号进行预约
      span 2.通过预约手机号码收取服装兑换码（12月24日起陆续发送短信）
      span 3.在【三周年庆典服】创建新角色后，即可在【设置】-【兑换码】中兑换“红袖添香”套装
      span （该兑换码仅限【三周年庆典服】角色使用）
  .main-order
    input(type="tel", placeholder="请输入手机号码", v-model="phone")
    .btn-reserve.bg-c.inner-center(@click="appoint") 立即预约
  .btm-desc-container.column-center
    .title-box.column-center
      .title 【三周年庆典服】专属福利
      .time 开服时间：2021年12月24日 10:00
    .welfare-box.column-center
      .welfare1
        b 第一弹：开服庆典<br>
        span 活动时间：2021年12月24日 - 2022年1月6日<br>
        span 活动规则：活动期间登录即可在邮箱中领取价值5000元宝 “庆典服礼包”
      .welfare2
        b 第二弹：限定称号<br>
        span 活动时间：创建角色后7日内<br>
        span 活动规则：参与七日签到活动，即可领取专属称号“三年有你”
      .welfare3
        b 第三弹：新服锦鲤<br>
        span 活动时间：12月24日 - 12月25日<br>
        span 第1波（24号下午3点）：抽取10名幸运玩家送上元宝*8888<br>
        span 第2波（24号下午6点）：抽取8名幸运玩家，送上价值1万元宝的资源大礼包<br>
        span 第3波（25号下午3点）：抽取5名充值过的玩家送上年卡1张（充值任意金额即可参与）
  .contact-container.column-center
    .btn-contact.bg-c.inner-center(@click="contactUs") 联系我们
    span 官方保留对活动的解释权
</template>
<script>
import { appoint } from "@/request/api.js";
export default {
  name: "phoneReserve",
  data() {
    return {
      time: Date.now(),
      phone: "",
    };
  },
  methods: {
    appoint() {
      let { time, phone } = this;
      phone = phone.trim();
      if (!this.validatePhone(phone)) {
        this.$toast("请输入正确的手机号");
        return;
      }
      const access = this.$encrypte([time, phone]);
      appoint({ time, phone, access }).then(
        (data) => {
          console.log(data);
          this.$toast("预约成功！请查看手机短信收取兑换码！");
          this.phone = "";
        },
        (err) => {
          this.$toast(err.msg);
        }
      );
    },
    validatePhone(phone) {
      const reg = /^(?:(?:\+|00)86)?1[3-9]\d{9}$/;
      return reg.test(phone);
    },
    contactUs() {
      window.open("https://wpa1.qq.com/tYyC2BmQ?_type=wpa&qidian=true");
      // window.open("https://www.facebook.com/zijinfanhua")
    },
  },
  mounted() {},
};
</script>
<style scoped lang='stylus'>
.phoneReserve
  width: 100%
  height: 1960px
  background-image: bg('phoneReserve/bg_phone_reserve.jpg')
  overflow: hidden
.top-desc-container
  width: 86%
  margin: 700px 0 0 0
  .order-time
    span
      font-size: 22px
      &:nth-of-type(1)
        color: #C52A13
        font($bold)
      &:nth-of-type(2)
        color: #714E4B
        font($regular)
  .order-methods
    line-height: 40px
    span
      display: block
      font-size: 22px
      &:nth-of-type(1)
        color: #C52A13
        font($bold)
      &:not(:nth-of-type(1))
        color: #714E4B
        font($regular)
.main-order
  width: 100%
  margin:  40px 0 40px 0
  display: flex
  position: relative
  input
    width: 462px
    height: 74px
    margin: 0 0 0 35px
    padding: 20px
    background: #FFFFFF
    border: 1px solid #F47959
    opacity: 0.99
    flex-shrink: 0
    font($regular)
  input::-webkit-input-placeholder /* WebKit browsers */
    color: #E4B19E
  input:-moz-placeholder /* Mozilla Firefox 4 to 18 */
    color: #E4B19E
  input::-moz-placeholder /* Mozilla Firefox 19+ */
    color: #E4B19E
  input:-ms-input-placeholder /* Internet Explorer 10+ */
    color: #E4B19E
  .btn-reserve
    width: 274px
    height: 79px
    position: absolute
    top: -3px
    left: 450px
    font-size: 40px
    color: #FDFBB3
    background-image: bg('phoneReserve/btn-reserve.png')
    flex-shrink: 0
    font($bold)
.btm-desc-container
  width: 86%
  .title-box
    font-size: 19.02px
    color: #C52A13
    line-height: 39px
    font($bold)
  .welfare-box
    margin: 20px 0 20px 0
    font-size: 22px
    align-items: flex-start
  b
    color: #C52A13
    font($bold)
  span
    color: #714E4B
    line-height: 42px
    font($regular)
.contact-container
  .btn-contact
    width: 298px
    height: 84px
    font-size: 32.71px
    color: #FDF6E7
    background-image: imgUrl('btn-task.png')
    font($bold)
  span
    font-size: 19.02px
    color: #585858
    margin: 10px 0 0 0
    font($regular)
</style>