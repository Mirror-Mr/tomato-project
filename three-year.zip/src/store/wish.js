const wish = {
  namespaced: 'wish',
  state: {
    propertyWishList: [
      {
        id: 1,
        actualId: 987,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/property/1.png",
        name: "特级天赋书",
        count: 2,
        kind: 1
      },
      {
        id: 2,
        actualId: 1204,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/property/2.png",
        name: "天日白月匣",
        count: 2,
        kind: 1
      },
      {
        id: 3,
        actualId: 4003,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/property/3.png",
        name: "福卷",
        count: 10,
        kind: 1
      },
      {
        id: 4,
        actualId: 1205,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/property/4.png",
        name: "秦蒙笔",
        count: 10,
        kind: 1
      },
      {
        id: 5,
        actualId: 2003,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/property/5.png",
        name: "天衣券",
        count: 20,
        kind: 1
      },
      {
        id: 6,
        actualId: 169,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/property/6.png",
        name: "翡翠指环",
        count: 1,
        kind: 1
      },
      {
        id: 7,
        actualId: 170,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/property/7.png",
        name: "翡翠腰牌",
        count: 1,
        kind: 1
      },
      {
        id: 8,
        actualId: 171,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/property/8.png",
        name: "灵宝剑",
        count: 1,
        kind: 1
      }
    ],
    headWishList: [
      {
        id: 1,
        actualId: 8,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/head/1.png",
        name: "冬日雪人",
        count: 1,
        kind: 94
      },
      {
        id: 2,
        actualId: 11,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/head/2.png",
        name: "雪夜星空",
        count: 1,
        kind: 94
      },
      {
        id: 3,
        actualId: 18,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/head/3.png",
        name: "猪事顺利",
        count: 1,
        kind: 94
      },
      {
        id: 4,
        actualId: 19,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/head/4.png",
        name: "粉红记忆",
        count: 1,
        kind: 94
      },
      {
        id: 5,
        actualId: 21,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/head/5.png",
        name: "慕锦流凰",
        count: 1,
        kind: 94
      },
      {
        id: 6,
        actualId: 214,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/head/6.png",
        name: "一世繁花",
        count: 1,
        kind: 94
      },
      {
        id: 7,
        actualId: 215,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/head/7.png",
        name: "朱辉玉映",
        count: 1,
        kind: 94
      },
      {
        id: 8,
        actualId: 216,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/head/8.png",
        name: "省扇金屏",
        count: 1,
        kind: 94
      }
    ],
    signAward: [
      {
        id: 1,
        actualId: 1,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/1.png",
        name: "元宝",
        count: 100,
        kind: 1
      },
      {
        id: 2,
        actualId: 1201,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/2.png",
        name: "百变千机盒",
        count: 1,
        kind: 1
      },
      {
        id: 3,
        actualId: 4003,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/property/1.png",
        name: "特级天赋书",
        count: 1,
        kind: 1
      },
      {
        id: 4,
        actualId: 157,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/4.png",
        name: "黄铜腰牌",
        count: 3,
        kind: 1
      },
      {
        id: 5,
        actualId: 1,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/1.png",
        name: "元宝",
        count: 200,
        kind: 1
      },
      {
        id: 6,
        actualId: 128,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/6.png",
        name: "保养油",
        count: 1,
        kind: 1
      },
      {
        id: 7,
        actualId: null,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/head/1.png",
        name: "冬日雪人",
        count: 1,
        kind: 1
      },
      {
        id: 8,
        actualId: "",
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/8.png",
        name: "幸运签",
        count: 1,
        kind: 1
      },
      {
        id: 9,
        actualId: 1200,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/9.png",
        name: "招募令",
        count: 3,
        kind: 1
      },
      {
        id: 10,
        actualId: 2004,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/10.png",
        name: "天衣令",
        count: 5,
        kind: 1
      },
      {
        id: 11,
        actualId: 1205,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/11.png",
        name: "秦蒙笔",
        count: 3,
        kind: 1
      },
      {
        id: 12,
        actualId: 1,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/1.png",
        name: "元宝",
        count: 300,
        kind: 1
      },
      {
        id: 13,
        actualId: 1206,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/13.png",
        name: "焦尾琴",
        count: 3,
        kind: 1
      },
      {
        id: 14,
        actualId: 132,
        img:
          "https://wcdn.tomatogames.com/web/guonei/zjfh/activity/thirdAnniversary/wishList/signAward/14.png",
        name: "高级保养油",
        count: 2,
        kind: 1
      }
    ],
    currentPropertyWish: 0,
    currentHeadWish: 0,
  },
  mutations: {
    setHeadWish(state, { choose_rid }) {
      const  [ propertyId,  headWishId ] = choose_rid.split(',');
      // 获取道具奖品的对应数据
      const propertyInfo = state.propertyWishList[Number(propertyId)-1];
      const headWishInfo = state.headWishList[Number(headWishId)-1];
      // 替换第三天的签到奖励为 对应的道具
      state.signAward.splice(2, 1, {...propertyInfo, id: 3})
      // 替换第七天的签到奖励为 对应的头像
      state.signAward.splice(6, 1, {...headWishInfo, id: 7})
    }
  },
  getters: {},
  actions: {}
};
export default wish;
