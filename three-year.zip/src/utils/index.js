/*
 * @Author: your name
 * @Date: 2021-11-29 16:54:31
 * @LastEditTime: 2021-12-08 10:21:31
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three-year\src\utils\index.js
 */
export function getDeviceType() {
  const userAgent = navigator.userAgent.toLowerCase();
  const isIos =
    userAgent.match(/iphone os/i) == "iphone os" ||
    userAgent.match(/ipad/i) == "ipad";
  const isAndroid = userAgent.match(/android/i) == "android";
  if (isIos) {
    return 1;
  }
  if (isAndroid) {
    return 2;
  }
  return 3;
}

/**
 * 函数防抖
 */

export function debounce(func, wait = 2000, immediate = true) {
  let timer;

  return function(...args) {
    //this指向debounce
    let context = this;

    //如果timer不为null, 清除定时器
    if (timer) clearTimeout(timer);

    //如果是立即执行
    if (immediate) {
      //定义callNow = !timer
      var callNow = !timer;
      //定义wait时间后把timer变为null
      //即在wait时间之后事件才会有效
      timer = setTimeout(() => {
        timer = null;
      }, wait);
      //如果callNow为true,即原本timer为null
      //那么执行func函数
      if (callNow) func.apply(context, args);
    } else {
      //如果是不立即执行
      //那就是每次重新定时
      timer = setTimeout(function() {
        func.apply(context, args);
      }, wait);
    }
  };
}

// 获取url中指定参数的值 variable：想要获取的参数名
export function getQueryValue(variable) {
  if (window.location.href.indexOf(variable) == -1) {
    return null;
  }
  var arr = window.location.href.split("?");
  var query = arr[arr.length - 1];
  var vars = query.split("&");
  for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0] == variable) {
      return pair[1];
    }
  }
  return null;
}
// 是否为微信
export function isWeChat() {
  //window.navigator.userAgent属性包含了浏览器类型、版本、操作系统类型、浏览器引擎类型等信息，这个属性可以用来判断浏览器类型
  var ua = window.navigator.userAgent.toLowerCase(); //通过正则表达式匹配ua中是否含有MicroMessenger字符串
  return ua.match(/MicroMessenger/i) == "micromessenger";
}

// 获取url参数
export function getUrlParams(url) {
  // 用JS拿到URL，如果函数接收了URL，那就用函数的参数。如果没传参，就使用当前页面的URL
  var queryString = url ?
    url.split("?")[1] :
    window.location.search.slice(1);
  // 用来存储我们所有的参数
  var obj = {};
  // 如果没有传参，返回一个空对象
  if (!queryString) {
    return obj;
  }
  // stuff after # is not part of query string, so get rid of it
  queryString = queryString.split("#")[0];
  // 将参数分成数组
  var arr = queryString.split("&");
  for (var i = 0; i < arr.length; i++) {
    // 分离成key:value的形式
    var a = arr[i].split("=");
    // 将undefined标记为true
    var paramName = a[0];
    var paramValue = typeof a[1] === "undefined" ? true : a[1];
    // 如果调用对象时要求大小写区分，可删除这两行代码
    // paramName = paramName.toLowerCase();
    // if (typeof paramValue === "string")
    // paramValue = paramValue.toLowerCase();
    // 如果paramName以方括号结束, e.g. colors[] or colors[2]
    if (paramName.match(/\[(\d+)?\]$/)) {
      // 如果paramName不存在，则创建key
      var key = paramName.replace(/\[(\d+)?\]/, "");
      if (!obj[key]) obj[key] = [];
      // 如果是索引数组 e.g. colors[2]
      if (paramName.match(/\[\d+\]$/)) {
        // 获取索引值并在对应的位置添加值
        var index = /\[(\d+)\]/.exec(paramName)[1];
        obj[key][index] = paramValue;
      } else {
        // 如果是其它的类型，也放到数组中
        obj[key].push(paramValue);
      }
    } else {
      // 处理字符串类型
      if (!obj[paramName]) {
        // 如果如果paramName不存在，则创建对象的属性
        obj[paramName] = paramValue;
      } else if (obj[paramName] && typeof obj[paramName] === "string") {
        // 如果属性存在，并且是个字符串，那么就转换为数组
        obj[paramName] = [obj[paramName]];
        obj[paramName].push(paramValue);
      } else {
        // 如果是其它的类型，还是往数组里丢
        obj[paramName].push(paramValue);
      }
    }
  }
  return obj;
}
