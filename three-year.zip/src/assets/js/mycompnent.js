/*
 * @Author: your name
 * @Date: 2021-11-08 10:49:52
 * @LastEditTime: 2021-11-23 15:55:33
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three_year\src\assets\js\mycompnent.js
 */
import Vue from "vue";
import Modal from "@/components/Modal.vue"; //引入组件
import LoginStatus from "@/components/loginStatus.vue"; //引入组件
// import footerBottom from "components/footer.vue"   //引入组件
// import product from "components/product.vue"   //引入组件
// import double from "components/double.vue"   //引入组件
// import mhead from "components/mhead.vue"   //引入组件
// import agree from "components/agreement.vue"   //引入组件

Vue.component("Mymodal", Modal);
Vue.component("LoginStatus", LoginStatus);
// Vue.component("MyMhead",mhead);
// Vue.component("Myfoot",footerBottom);
// Vue.component("Myproduct",product);
// Vue.component("Mydouble",double);
// Vue.component("Myagree",agree);
