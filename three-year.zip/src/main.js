/*
 * @Author: your name
 * @Date: 2021-11-08 10:49:52
 * @LastEditTime: 2021-12-02 11:07:24
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three_year\src\main.js
 */
import Vue from "vue";
import App from "./App.vue";
import "./assets/js/common.js";
import "./assets/js/mycompnent.js";
import "./assets/js/judg.js";
// import "assets/js/newRem.js";
import md5 from "js-md5";
import "./assets/js/vant.js";
import router from "./router";
import store from "./store/index";
import { Lazyload, Toast } from "vant";
import VueClipboard from "vue-clipboard2";
import 'animate.css';
// import Vconsole from 'vconsole';
// new Vconsole();
Vue.use(VueClipboard);
Vue.use(Lazyload);
Vue.use(Toast);
Vue.prototype.$md5 = md5;
Vue.prototype.baseUrl = "https://api.xianyuyouxi.com/service/sezg/Oneyear/";

Vue.prototype.$bus = new Vue();

Vue.directive("debounce", {
  inserted: function(el, binding) {
    let timer;
    el.addEventListener("click", () => {
      if (timer) {
        clearTimeout(timer);
      }
      //定义callNow = !timer
      var callNow = !timer;
      //定义wait时间后把timer变为null
      //即在wait时间之后事件才会有效
      timer = setTimeout(() => {
        timer = null;
      }, 500);
      //如果callNow为true,即原本timer为null
      //那么执行func函数
      if (callNow) binding.value();
      // timer = setTimeout(() => {
      //   binding.value();
      // }, 500);
    });
  },
});
Vue.prototype.resetSetItem = function(key, newVal) {
  if (key === "dots") {
    // 创建一个StorageEvent事件
    var newStorageEvent = document.createEvent("StorageEvent");
    const storage = {
      setItem: function(k, val) {
        sessionStorage.setItem(k, val);

        // 初始化创建的事件
        newStorageEvent.initStorageEvent(
          "setItem",
          false,
          false,
          k,
          null,
          val,
          null,
          null
        );

        // 派发对象
        window.dispatchEvent(newStorageEvent);
      },
    };
    return storage.setItem(key, newVal);
  }
};
// 路由跳转回滚至页面顶部
router.afterEach((to, from, next) => {
    window.scrollTo(0, 0);
  
    // 或
  
    // window.scroll(0, 0);
  });
Vue.config.productionTip = false;
new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount("#app");
