/*
 * @Author: your name
 * @Date: 2021-11-16 16:34:10
 * @LastEditTime: 2021-12-21 17:14:06
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \three-year\src\request\api.js
 */
import { get, post } from "./http";
import { getDeviceType } from "@/utils/index";
// export const serverlist = p => get('serverlist', p)
// export const price = p => get('getprice', p)
// export const checkuser = p => get('userinfo', p)
// export const pay = p => post('pay', p)

const salt = "0391591aafc5db68b08787645b837b4f";
/*
 * 国内登录
 */
export const inlandLogin = (p) => {
  return post("activity/zjfh_third_ani/login", p);
};
/*
 * 快捷登录
 */
export const fastLogin = (p) => {
  return post("activity/zjfh_third_ani/xy_login", p);
};

/*
 * 获取活动1_获取红包开放时间
 */
export const getRedTimes = (p) => {
    return get("activity/zjfh_third_ani/get_red_times", p);
};

/*
 * 获取活动时间
 */
export const getActivityTime = (p) => {
	return get("activity/zjfh_third_ani/getActivityTime", p);
};

/*
 * 获取角色信息
 */
export const getRoleInfo = (p) => {
  return post("activity/zjfh_third_ani/getRoleInfo", p);
};

/*
 * 绑定角色（实际的登录）
 */
export const bindRole = (p) => {
  return post("activity/zjfh_third_ani/bindRole", p);
};

/*
 * 绑定角色（实际的登录）
 */
export const getUserInfo = (p) => {
  return post("activity/zjfh_third_ani/getUserInfo", p);
};

/*
 * 海外登录
 */
export const outsideLogin = (p) => {
  return post("activity/zjfh_third_ani/login", p);
};

/*
 * 活动1_绑定手机号
 */
export const bindPhone = (p) => {
  return post("activity/zjfh_third_ani/bindPhone", p);
};

/*
 * 获取渠道角色id对应信息
 */
export const getQDRoleInfo = (p) => {
  return post("activity/zjfh_third_ani/get_role_info", p);
};

/*
 * 活动1_点击分享许可
 */
export const sharePermis = (p) => {
  return post("activity/zjfh_third_ani/get_share_permis", p);
};

/*
 * 活动1_获取分享红包的来源
 */
export const getRedDesc = (p) => {
  return post("activity/zjfh_third_ani/get_red_desc", p);
};

/*
 * 活动1_获取红包领取详情
 */
export const getRedUsers = (p) => {
  return post("activity/zjfh_third_ani/get_red_users", p);
};

/*
 * 活动1_兑换记录
 */
export const getPrizeHistory = (p) => {
  return post("activity/zjfh_third_ani/getPrizeHistory", p);
};

/*
 * 领红包/领奖/兑换
 */
export const subPrize = (p) => {
  return post("activity/zjfh_third_ani/subPrize", p);
};

/*
 * 获取验证码
 */
export const sendCode = (p) => {
  return post("common/sendcode/sendCode", p);
};
/**
 * @description 选择道具
 * @param {*} p
 * @returns
 */
export const chooseGift = (p) => {
  return post("activity/zjfh_third_ani/choose_gift", p);
};
/**
 * @description 签到
 * @param {*} p
 * @returns
 */
export const logLogin = (p) => {
  return post("activity/zjfh_third_ani/log_login", p);
};
/**
 * @description 支付接口
 * @param {*} p
 * @returns
 */
export const pay = (p) => {
  return post("activity/zjfh_third_ani/pay", p);
};
/**
 * @description 微信授权
 * @param {*} p
 * @returns
 */
export const getauth = (p) => {
  return post("activity/zjfh_third_ani/getauth", p);
};

/**
 * @description 获取订单状态
 * @param {*} p
 * @returns
 */
export const getOrderStatus = (p) => {
  return post("activity/zjfh_third_ani/get_order_status", p);
};

/**
 * @description 公共打点
 * @param {*} p
 * @returns
 */
export const clickLog = (p) => {
	let uid = localStorage.getItem('uid')|| ''
  p = {
    project_id: 32,
    project: "紫禁繁花",
    type: 1,
    from: 1,
    dev: getDeviceType(),
    page_index: 1,
    state: "",
    tag: "",
    uid: uid,
    extra: null,
    ...p,
  };
  return post("common/clicklog/click", p);
};
/**
 * 活动五 - 战令 - 获取历史登录及领奖记录
 */
export const loginDays = (p) => {
  return post("activity/zjfh_third_ani/login_days", p);
};
/**
 * 活动五 - 战令 - 获取每天任务及领奖记录
 */
export const finishDays = (p) => {
  return post("activity/zjfh_third_ani/finish_days", p);
};
/**
 * 活动二 - 抽奖 - 抽签奖励
 */
export const lotteryDraw = (p) => {
  return post("activity/zjfh_third_ani/lottery_draw", p);
};
/**
 * 活动二 - 兑换 - 兑换奖励或者签
 */
export const subLotteryPrize = (p) => {
  return post("activity/zjfh_third_ani/sub_lottery_prize", p);
};
/**
 * 活动六 - 预约 - 发送手机号预约
 */
export const appoint = (p) => {
  return post("activity/zjfh_third_ani/appoint", p);
};
