<!--
 * @Author: your name
 * @Date: 2021-02-24 10:32:01
 * @LastEditTime: 2021-05-26 18:30:47
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\Carousel.vue
-->
<template>
  <div class="carousel">
    <!-- Swiper -->
    <div class="swiper-container swiper-container_1">
      <div class="swiper-wrapper">
        <div
          class="swiper-slide slide01"
          style="
            backgroundImage: url(https://wcdn.tomatogames.com/web/haiwai/tomato/img/m-banner0.png);
            backgroundSize: 100%;
            backgroundPosition:0 0.5rem;
          "
        >
        </div>
        <div
          class="swiper-slide slide02"
          style="
            backgroundImage: url(https://wcdn.tomatogames.com/web/haiwai/tomato/img/m-banner1.png);
            backgroundSize: 100%;
          "
        >
        </div>
        <div
          class="swiper-slide slide03"
          style="
            backgroundImage: url(https://wcdn.tomatogames.com/web/haiwai/tomato/img/m-banner2.png);
            backgroundSize: 100%;
          "
        >
        </div>
      </div>
    </div>
    <!-- 左上角文字说明 -->
    <div class="desc">
      <h2 class="desc1">{{ $t("x.carousel.desc[0][0]") }}</h2>
      <span class="desc2" v-html="$t('x.carousel.desc[0][1]')">  </span>
    </div>
    <!-- 左侧按钮 -->
    <div class="buttonInLeft">
      <a href="#" class="toRight" @click.prevent="toRight()"
        ><i class="el-icon-arrow-right"></i
      ></a>
      <a href="#" class="toLeft" @click.prevent="toLeft()"
        ><i class="el-icon-arrow-left"></i
      ></a>
    </div>
    <!-- 点点 -->
    <div class="dots">
      <a
        href="#"
        v-for="(item, i) in 3"
        :key="i"
        :class="{ active: page == i }"
        @click.prevent="swiper1.slideTo(i + 1)"
      ></a>
    </div>
    <span href="#" class="toBottom"></span>

    <!-- 右下角面板 -->
    <!-- <div class="panel">
      <div class="box">
        <b
          ><span>0{{ page + 1 }}</span
          >/03</b
        >
        <a href="#" class="toLeft" @click.prevent="toLeft()"
          ><i class="el-icon-arrow-left"></i
        ></a>
        <a href="#" class="toRight" @click.prevent="toRight()"
          ><i class="el-icon-arrow-right"></i
        ></a>
      </div>
    </div> -->
    <!-- 动效面板 -->
    <span class="dyna"></span>
  </div>
</template>
<script>
import Swiper from "swiper";
import "swiper/dist/css/swiper.css";

export default {
  name: "Carousel",

  data() {
    return {
      swiper1: null,
      //当前轮播图
      page: 0
    };
  },
  methods: {
    createSwiper() {
      let that = this;
      this.swiper1 = new Swiper(".swiper-container_1", {
        loop: true,
        speed: 500,
        autoplay: true,
        simulateTouch: false, //禁止鼠标模拟
        on: {
          transitionStart() {
            that.page = this.realIndex;
          },
          transitionEnd() {}
        }
      });
    },
    toLeft() {
      this.swiper1.slidePrev();
    },
    toRight() {
      this.swiper1.slideNext();
    }
  },
  mounted() {
    this.createSwiper();
  }
};
</script>
<style scoped>
.carousel {
  position: relative;
  width: 100%;
  height: 13.34rem;
  overflow: hidden;
}
.swiper-container_1 {
  width: 100%;
  height: 100%;
}

.swiper-container_1 .swiper-slide {
  text-align: center;
  /* Center slide text vertically */
  display: -webkit-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  -webkit-justify-content: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  -webkit-align-items: center;
  align-items: center;
  transition-delay: 2s;
}

@keyframes common-run {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}

/* 点点 */
.dots {
  position: absolute;
  bottom: 0.4rem;
  left: 4.3rem;
  /* margin: 0 auto; */
  animation: common-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2s;
  z-index: 2;
  opacity: 0;
}
.dots a {
 width: 0.4rem;
  height: 0.05rem;
  display: inline-block;
  background: #fff;
  margin: 0.05rem;
}
.dots .active {
  background: #ff7915;
}

.desc {
  width: 5.7rem;
  height: 2.08rem;
  position: absolute;
  top: 0;
  left: 0;
  text-align: left;
  font-family: Microsoft YaHei;
  background: #ffffff;
  border-radius: 0rem 0rem 1rem 0rem;
  animation: desc-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 3s;
  z-index: 2;
  opacity: 0;
}
@keyframes desc-run {
  0% {
    top: -2rem;
    opacity: 0;
  }
  100% {
    top: 0.99rem;
    opacity: 0.8;
  }
}
.desc1 {
  width: 2rem;
  margin: 0.3rem 0 0 0.7rem;
  font-size: 0.22rem;
  font-weight: 300;
  color: #666666;
}
.en .desc1{
  width: 1.9rem;
  margin: 0.3rem 0 0 0.7rem;
}
.desc2 {
  width: 4.09rem;
  margin: 0.1rem 0 0 0.7rem;
  font-size: 0.37rem;
  font-weight: 400;
  color: #333333;
  line-height: 0.52rem;
}
.en .desc2{
  width: 4.31rem;
  margin: 0.15rem 0 0 0.7rem;
}
.panel {
  width: 5rem;
  height: 0.9rem;
  position: absolute;
  bottom: 0rem;
  right: 0;
  text-align: left;
  background: #ffffff;
  /* animation: panel-run 1s; */
  animation-fill-mode: forwards;
  animation-delay: 2s;
  z-index: 2;
}
@keyframes panel-run {
  0% {
    bottom: -0.5rem;
  }
  100% {
    bottom: 0;
  }
}
.panel .box {
  width: 100%;
  height: 100%;
  /* margin-top: 0.1rem; */
  /* animation: box-run 1s; */
  animation-fill-mode: forwards;
  animation-delay: 3s;
  /* opacity: 0; */
}
@keyframes box-run {
  0% {
    margin-top: 0.1rem;
    opacity: 0;
  }
  100% {
    margin-top: 0;
    opacity: 1;
  }
}
.panel b {
  margin: 0 0 0 0.5rem;
  vertical-align: middle;
  font-size: 0.2rem;
  line-height: 0.9rem;
  font-family: SourceHanSansCN;
  font-weight: 400;
}
.panel span {
  display: inline;
  font-size: 0.2rem;
  color: #ff7915;
}
.panel a {
  vertical-align: middle;

  display: inline-block;
  font-size: 0.2rem;
  line-height: 0.9rem;
  margin: 0 0 0 0.4rem;
}
.panel i {
  vertical-align: middle;
}
.panel .toRight {
  color: #ff7915;
}
/* 动效 */
.dyna {
  width: 150%;
  height: 100%;
  position: absolute;
  top: 0;
  left: -1rem;
  background: #ff7915;
  animation: dyna-run 2s;
  animation-fill-mode: forwards;
  z-index: 2;
}
@keyframes dyna-run {
  0% {
    left: -100%;
  }
  100% {
    left: 100%;
  }
}
</style>
