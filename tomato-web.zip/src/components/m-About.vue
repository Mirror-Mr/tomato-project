<!--
 * @Author: your name
 * @Date: 2021-02-25 11:39:46
 * @LastEditTime: 2021-05-26 17:19:30
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\About.vue
-->
<template>
  <div class="about active" id="about">
    <div class="orange">
      <!-- 切换的内容部分 -->
      <div
        :class="['box', { run: change }, { run1: change1 }]"
        :style="{ display: change ? 'block' : 'none' }"
      >
        <template v-if="msgIndex == 0">
          <div class="part">
            <span class="number">{{ $t("x.about.orange.special[0]") }}</span>
            <span class="thing">{{ $t("x.about.orange.special[1]") }}</span>
          </div>
          <div class="part">
            <span class="number">{{ $t("x.about.orange.special[2]") }}</span>
            <span class="thing">{{ $t("x.about.orange.special[3]") }}</span>
          </div>
          <div class="part">
            <span class="number">{{ $t("x.about.orange.special[4]") }}</span>
            <span class="thing">{{ $t("x.about.orange.special[5]") }}</span>
          </div>
        </template>
        <template v-else>
          <!-- 内容标题 -->
          <span class="title">{{
            $t("x.about.orange.aboutTitle[" + msgIndex + "]")
          }}</span>
          <!-- 内容主体 -->
          <ul>
            <li
              v-for="(item, i) in $t(
                'x.about.orange.aboutMsg[' + msgIndex + ']'
              )"
              :key="i"
            >
              {{ item }}
            </li>
          </ul>
        </template>
      </div>
      <!-- 切换内容按钮 -->
      <!-- <a href="#" class="prev" @click.prevent="prevMsg()"
        ><i class="el-icon-arrow-left"></i
      ></a> -->
      <a href="#" class="next" @click.prevent="nextMsg()"
        ><i class="el-icon-arrow-right"></i
      ></a>
    </div>
    <div class="white">
      <div class="box">
        <h2>{{ $t("x.about.white.title") }}</h2>
        <span
          >{{ $t("x.about.white.content[0]") }}
          <!-- <br />
          {{ $t("x.about.white.content[1]") }} -->
        </span>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "About",
  data() {
    return {
      screenHeight: document.documentElement.clientHeight,

      //   关于我们信息号
      msgIndex: 1,
      change: true,
      change1: false
    };
  },
  methods: {
    prevMsg() {
      this.msgIndex =
        // this.msgIndex == 0 ? this.aboutTitle.length - 1 : this.msgIndex - 1;
        this.msgIndex == 0 ? 6 : this.msgIndex - 1;
    },
    nextMsg() {
      this.msgIndex = this.msgIndex == 6 ? 1 : this.msgIndex + 1;
    }
  },
  watch: {
    msgIndex(newName, oldName) {
      this.change = false;
      this.change1 = true;
      setTimeout(() => {
        this.change = true;
      }, 10);
    }
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true);
  }
};
</script>
<style scoped>
.about {
  width: 100%;
  height: 21.31rem;
  position: relative;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/m-about.png") 50% 25%;
  /* background: url("/img/m-about.png") 50% 25%; */
  background-size: 100%;
  text-align: left;
  overflow: hidden;
}
.en .about {
  height: 28.05rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/en-m-about.png");
  background-size: 100%;
}
.white {
  width: 7.64rem;
  height: 100%;
  background: rgba(255, 255, 255, 0.8);
  position: absolute;
  top: 100%;
  /* top: -50%; */
  left: 0;
}
.active .white {
  animation: white-run 1.7s linear;
  animation-fill-mode: forwards;
}
@keyframes white-run {
  0% {
    top: 100%;
  }
  100% {
    top: -60.5%;
  }
}
.white .box {
  width: 6.4rem;
  margin: 3.3rem 0 0 0.63rem;
  opacity: 0;
}
.white .box {
  width: 6.01rem;
}
.active .white .box {
  animation: wbox-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2.3s;
}
.en .active .white .box {
  animation: en-wbox-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2.3s;
}
@keyframes wbox-run {
  0% {
    margin: 7.9rem 0 0 0.63rem;
    opacity: 0;
  }
  100% {
    margin: 14rem 0 0 0.63rem;
    opacity: 1;
  }
}
@keyframes en-wbox-run {
  0% {
    margin: 7.9rem 0 0 0.8rem;
    opacity: 0;
  }
  100% {
    margin: 18rem 0 0 0.8rem;
    opacity: 1;
  }
}
.white h2 {
  font-size: 0.48rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
  line-height: 0.89rem;
}
.en .white h2 {
  font-family: Arial;
}
.white span {
  margin-top: 0.2rem;
  font-size: 0.37rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  text-align: justify;
  color: #666666;
  line-height: 0.67rem;
}
.en .white span {
  font-family: Arial;
  line-height: 0.6rem;
}
.orange {
  width: 7.64rem;
  height: 100%;
  background: rgba(255, 122, 21, 0.7);
  position: absolute;
  top: -100%;
  /* top: 50%; */
  left: 0;
}
.active .orange {
  animation: orange-run 1.7s linear;
  animation-fill-mode: forwards;
  animation-delay: 1.2s;
}
@keyframes orange-run {
  0% {
    top: -100%;
  }
  100% {
    top: 39.5%;
  }
}
.orange .box {
  margin-top: -0.3rem;
  opacity: 0;
  text-align: justify;
}
.active .orange .box.run {
  animation: obox-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2.9s;
}
.active .orange .box.run1 {
  animation: obox-run 1s;
  animation-fill-mode: forwards;
}
@keyframes obox-run {
  0% {
    margin-top: -0.3rem;
    opacity: 0;
  }
  100% {
    margin-top: 0rem;
    opacity: 1;
  }
}
/* 切换按钮 */
.orange a {
  width: 0.81rem;
  height: 0.81rem;
  text-align: center;
  position: absolute;
  top: 11rem;
  display: inline-block;
  color: #fff;
  vertical-align: baseline;
  border: 0.02rem solid #fff;
  border-radius: 50%;
  opacity: 0;
}
.en .orange a{
  top: 15rem;
}
/* .orange .prev {
  left: 0.1rem;
} */
.orange .next {
  left: 5.7rem;
  animation: obox-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2.9s;
}

.next i {
  height: 100%;
  line-height: 0.81rem;
  vertical-align: top;
  font-size: 0.4rem;
}

.orange .title {
  width: 4rem;
  margin: 1.3rem 0 0 0.77rem;
  color: #fff;
  font-size: 0.48rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  line-height: 0.32rem;
}
.en .orange .title {
  width:6rem;
}
.orange ul {
  width: 6rem;
  margin: 0.49rem 0 0 0.77rem;
  list-style-type: disc;
  font-size: 0.37rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
  line-height: 0.67rem;
}
.en .orange ul{
  width: 6.3rem;
  font-family: Arial;
  
line-height: 0.6rem;
}
/* 包括每个带个数的工作是啥的 */
.orange .part {
  width: 2rem;
  display: inline-block;
  margin: 1.3rem 0 0 1.4rem;
  vertical-align: top;
}
/* 关于我们 数目 */
.orange .number {
  display: block;
  font-size: 0.9rem;
  font-family: Arial;
  font-weight: bold;
  color: #ffffff;
  line-height: 0.13rem;
}
/* 关于我们 工作室啥的 */
.orange .thing {
  width: 1.4rem;
  margin: 0.5rem 0 0 0;
  font-size: 0.3rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
  line-height: 0.5rem;
}
</style>
