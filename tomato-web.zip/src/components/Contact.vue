<!--
 * @Author: your name
 * @Date: 2021-02-26 15:41:00
 * @LastEditTime: 2021-05-31 16:08:55
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\Contact.vue
-->
<template>
  <div class="contact" id="toContact">
    <h3>{{ $t("x.contact.title") }}</h3>
    <span class="note1">{{ $t("x.contact.note[0]") }}</span>
    <span class="note2" v-html="$t('x.contact.note[1]')"></span>
    <div class="boxs" :class="{ active: isActive }">
      <div
        class="box"
        v-for="(item, i) in $t('x.contact.boxMsg')"
        :key="i"
        :class="'box' + (i + 1)"
        @click="showMask(i)"
      >
        <div>
          <span class="icon"></span>
        </div>
        <span class="theme">{{ item[0] }}</span>
        <span class="web">{{ item[1] }}{{ item[2] }} </span>
      </div>
    </div>
    <MaskBox :isShow="isShow" @close="closeMask" :num="num" />
  </div>
</template>
<script>
import MaskBox from "./MaskBox";
import "../assets/css/animate.css";

export default {
  name: "Contact",
  components: {
    MaskBox
  },
  data() {
    return {
      isShow: false,
      screenHeight: document.documentElement.clientHeight,
      isActive: false,
      num: 4
    };
  },
  methods: {
    showMask(num) {
      this.isShow = true;
      console.log(num);
      this.num = num;
    },
    closeMask(show) {
      this.isShow = show;
    },
    handleScroll(e) {
      var scrollTop =
        e.target.documentElement.scrollTop || e.target.body.scrollTop;
        
      if (scrollTop > this.screenHeight + 800) {
        this.isActive = true;
      }
    }
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true);
  }
};
</script>
<style scoped>
.contact {
  width: 100%;
  height: 3.98rem;
  position: relative;
  padding-top: 0.01rem;
  background: #f4f4f4;
}
h3 {
  margin: 0.38rem 0 0 0;
  font-size: 0.26rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.35rem;
}
.en h3 {
  font-family: Arial;
  font-weight: bold;
}
span {
  display: block;
  margin: 0 auto;
}

.note1 {
  width: 1.36rem;
  height: 0.27rem;
  margin-top: 0.15rem;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  line-height: 0.16rem;
  color: #ff7915;
}
.en .note1 {
  width: 1.81rem;
  height: 0.26rem;
  margin-top: 0.1rem;
  font-family: Arial;
}
.note2 {
  /* width: 2.51rem; */
  height: 0.2rem;
  margin-top: 0.1rem;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666666;
  line-height: 0.15rem;
}
.en .note2 {
  width: 2.61rem;
  height: 0.19rem;
  font-family: Arial;
}
.boxs {
  margin: 0.4rem 0 0 0;
}
.box {
  width: 1.82rem;
  height: 1.56rem;
  vertical-align: top;
  margin: 0.3rem 0.1rem 0;
  display: inline-block;
  background: #ffffff;
  border-radius: 0.05rem;
  transition: all 1s;
  opacity: 0;
  cursor: pointer;
}
.active .box {
  animation: box-run 1s;
  animation-fill-mode: forwards;
}
.active .box2 {
  animation-delay: 0.2s;
}
.active .box3 {
  animation-delay: 0.4s;
}
.active .box4 {
  animation-delay: 0.6s;
}
@keyframes box-run {
  0% {
    margin: 0.3rem 0.07rem 0;
    opacity: 0;
  }
  100% {
    margin: 0 0.07rem 0;
    opacity: 1;
  }
}
.box:hover {
  background: #ff7915;
}
.box:hover .theme,
.box:hover .web {
  color: #fff;
}
.box div{
  height: 0.3rem;
}
.theme {
  margin: 0.1rem 0 0 0;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
}
.web {
  margin: 0.05rem 0 0 0;
  font-size: 0.08rem;
  font-family: Arial;
  font-weight: 400;
  color: #666666;
}

.box1 .icon {
  width: 0.32rem;
  height: 0.35rem;
  margin: 0.4rem auto 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/cicon0.png");
  background-size: 100%;
}
.box1:hover .icon {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/cicon00.png");
  background-size: 100%;
}
.box2 .icon {
  width: 0.32rem;
  height: 0.295rem;
  margin: 0.4rem auto 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/cicon1.png");
  background-size: 100%;
}
.box2:hover .icon {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/cicon01.png");
  background-size: 100%;
}
.box3 .icon {
  width: 0.4rem;
  height: 0.296rem;
  margin: 0.4rem auto 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/cicon2.png");
  background-size: 100%;
}
.box3:hover .icon {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/cicon02.png");
  background-size: 100%;
}
.box4 .icon {
  width: 0.39rem;
  height: 0.334rem;
  margin: 0.4rem auto 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/cicon3.png");
  background-size: 100%;
}
.box4:hover .icon {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/cicon03.png");
  background-size: 100%;
}
.toXingHe {
  display: inline;
  transition: all 0.3s;
}
.toXingHe:hover {
  color: blue;
}
</style>
