<!--
 * @Author: your name
 * @Date: 2021-03-02 18:15:13
 * @LastEditTime: 2021-05-28 17:24:12
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\Mask.vue
-->
<template>
  <div class="mmaskBox" :style="{ display: isShow && show ? 'block' : 'none' }">
    <!-- <div class="maskBox" :style="{opacity:isShow?0:1,zIndex:isShow?-1:2}"> -->
    <div class="box">
      <i class="el-icon-close close" @click.prevent="close"></i>
      <div class="col-3 input-effect name" :class="{ err: nameNone }">
        <span class="tag">{{ $t("x.maskBox.name[0]") }}：</span>
        <input
          class="effect-14"
          type="text"
          :placeholder="$t('x.maskBox.name[1]')"
          @blur="inputBlur"
          v-model="contactMsg.name"
        />
        <span class="focus-bg"></span>
      </div>
      <div class="col-3 input-effect email" :class="{ err: emailNone }">
        <span class="tag ">{{ $t("x.maskBox.email[0]") }}：</span>
        <input
          class="effect-14"
          type="text"
          :placeholder="$t('x.maskBox.email[1]')"
          @blur="inputBlur"
          v-model="contactMsg.email"
        />
        <span class="focus-bg"></span>
      </div>
      <div class="col-3 input-effect subject" :class="{ err: subjectNone }">
        <span class="tag ">{{ $t("x.maskBox.subject[0]") }}：</span>
        <input
          class="effect-14"
          type="text"
          :placeholder="$t('x.maskBox.subject[1]')"
          @blur="inputBlur"
          v-model="contactMsg.subject"
        />
        <span class="focus-bg"></span>
      </div>
      <div class="col-3 input-effect content">
        <span class="tag ">{{ $t("x.maskBox.content[0]") }}：</span>
        <textarea
          class="effect-14"
          type="text"
          rows="2"
          :placeholder="$t('x.maskBox.content[1]')"
          v-model="contactMsg.content"
        ></textarea>
      </div>
      <!-- <div class=" content fl"  >
        <textarea
          class="effect-14"
          type="text"
          rows="2"
          :placeholder="$t('x.maskBox.content')"
          v-model="contactMsg.content"
        ></textarea>
        <span class="focus-bg">
        </span>
      </div> -->
      <a href="#" class="submit" @click.prevent="sendMsg()">{{
        $t("x.maskBox.send[0]")
      }}</a>
    </div>
  </div>
</template>
<script>
export default {
  name: "MMaskBox",
  props: {
    isShow: {
      type: Boolean,
      required: true
    },
    num: {
      type: Number,
     default:4
    }
  },
  data() {
    return {
      contactMsg: {
        name: "",
        email: "",
        subject: "",
        content: ""
      },
      show: true,
      // input是否为空
      nameNone: false,
      emailNone: false,
      subjectNone: false,
      key: "0391591aafc5db68b08787645b837b4f",
      // 时间戳
      timer: parseInt(Date.parse(new Date()) / 1000)
    };
  },
  methods: {
    inputBlur(e) {
      let val = e.target.value;
      if (val) {
        e.target.classList.add("has-content");
      } else {
        e.target.classList.remove("has-content");
      }
    },
    sendMsg() {
      let msg = this.contactMsg;
      if (!msg.name) {
        this.nameNone = true;
        return;
      } else if (!msg.email) {
        this.emailNone = true;
        return;
      } else if (!msg.subject) {
        this.subjectNone = true;
        return;
      }
      console.log(this.contactMsg);
      // 。。。
      this.$axios({
        method: "post",
        url: "https://hw.xianyuyouxi.com/service/Tomato_webhome/sendEmail",
        headers: {
          "Access-s": this.$md5(
            `${this.key}${this.timer}${this.contactMsg.email}${this.to_email}`
          )
        },
        data: {
          time: this.timer,
          realName: this.contactMsg.name,
          email: this.contactMsg.email,
          title: this.contactMsg.subject,
          content: this.contactMsg.content,
          to_email: this.to_email,
          company: 1
        }
      }).then(res => {
        if(res.data.code == 1){
          this.$message.success("发送成功！")
        }else{
          this.$message.error(res.data.msg);
        }
      });
    },
    close() {
      this.show = false;
      this.$emit("close", false);
      this.contactMsg = {
        name: "",
        email: "",
        subject: "",
        content: ""
      };
      this.show = true;
      document.getElementsByClassName("mmaskBox")[0].style.display = "none";
    }
  },
  watch: {
    contactMsg: {
      handler(newValue) {
        if (newValue.name) {
          this.nameNone = false;
        }
        if (newValue.email) {
          this.emailNone = false;
        }
        if (newValue.subject) {
          this.subjectNone = false;
        }
      },
      deep: true
    }
  },
  computed: {
    to_email() {
      if (this.num == 0) {
        return "qdhz@tomatogames.com";
      } else if (this.num == 1) {
        return "mthz@tomatogames.com";
      } else if (this.num == 2) {
        return "cpyr@tomatogames.com";
      } else if (this.num == 3) {
        return "gghz@tomatogames.com";
      }
    }
  }
};
</script>
<style scoped>
.mmaskBox {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 102;
}
.box {
  width: 8rem;
  height: 9.5rem;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: #ffffff;
  border-radius: 0.2rem;
}
.en .box {
  width: 8.5rem;
}
.close {
  width: 0.4rem;
  height: 0.4rem;
  font-size: 0.5rem;
  position: absolute;
  top: 0.2rem;
  right: 0.3rem;
  color: #ddd;
}

.input-effect label {
  text-align: left;
}
.name,
.email,
.subject,
.content {
  width: 5.84rem;
  height: 0.77rem;
  position: absolute;
}
.name {
  top: 0.9rem;
  left: 1.5rem;
}
.en .name,
.en .email,
.en .subject,
.en .content {
  left: 2rem;
}
.email {
  top: 2.2rem;
  left: 1.5rem;
}
.subject {
  top: 3.5rem;
  left: 1.5rem;
}
.content {
  top: 4.8rem;
  left: 1.5rem;
}

.name input,
.email input,
.subject input {
  height: 0.9rem;
  border-radius: 0.1rem;
  background: #f7f7f7;
  vertical-align: top;
  font-size: 0.4rem;
}
.content {
  height: 2.5rem;
}
.content textarea {
  width: 100%;
  height: 100%;
  font: 15px/24px "Lato", Arial, sans-serif;
  color: #333;
  font-size: 0.4rem;
  border-radius: 0.1rem;
  background: #f7f7f7;
  resize: none;
  /* 设置为怪异盒子模型 width/height = content + padding + border */
  box-sizing: border-box;
}
.box input::-webkit-input-placeholder,
.content textarea::-webkit-input-placeholder {
  font-size: 0.35rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #e1e1e1;
}

.tag {
  vertical-align: top;
  position: absolute;
  top: 50%;
  left: 0;
  font-size: 0.35rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.38rem;
  transform: translate(-100%, -60%);
}
.content .tag {
  transform: translate(-100%, -280%);
}
.submit {
  width: 2.5rem;
  height: 0.7rem;
  position: absolute;
  left: 50%;
  bottom: 0.75rem;
  transform: translateX(-50%);
  font-size: 0.3rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
  line-height: 0.7rem;
  background: #ff7915;
  border-radius: 1rem;
}
.col-3 {
  margin: 0;
}
.err::after {
  color: red;
  position: absolute;
  top: 0.89rem;
  left: 0.4rem;
  font-size: 0.3rem;
}
.name.err:after {
  content: "请输入姓名";
}
.email.err:after {
  content: "请输入邮箱";
}
.subject.err:after {
  content: "请输入主题";
}
</style>
