<!--
 * @Author: your name
 * @Date: 2021-02-24 10:32:01
 * @LastEditTime: 2021-06-11 14:20:51
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\Carousel.vue
-->
<template>
  <div class="carousel">
    <!-- Swiper -->
    <div class="swiper-container swiper-container_1">
      <div class="swiper-wrapper">
        <!-- <div
          class="swiper-slide slide04"
          style="
            backgroundImage: url(https://wcdn.tomatogames.com/web/haiwai/tomato/img/banner3.jpg);backgroundSize:100%;backgroundPosition:0 0rem;
              100%;
          "
        ></div> -->
        <div
          class="swiper-slide slide05"
          style="
            backgroundImage: url(https://wcdn.tomatogames.com/web/haiwai/tomato/img/banner4.jpg);backgroundSize:100%;backgroundPosition:0 0rem;
              100%;
          "
        ></div>
        <div
          class="swiper-slide slide01"
          style="
            backgroundImage: url(https://wcdn.tomatogames.com/web/haiwai/tomato/img/banner0.png);backgroundSize:100%;backgroundPosition:0 -0.2rem;
          "
        ></div>
        <div
          class="swiper-slide slide02"
          style="
            backgroundImage: url(https://wcdn.tomatogames.com/web/haiwai/tomato/img/banner1.png);backgroundSize:100%;backgroundPosition:0 -0.55rem;
              
          "
        ></div>
        <div
          class="swiper-slide slide03"
          style="
            backgroundImage: url(https://wcdn.tomatogames.com/web/haiwai/tomato/img/banner2.png);backgroundSize:100%;backgroundPosition:0 -0.5rem;
              100%;
          "
        ></div>
      </div>
    </div>
    <!-- 左上文字说明 -->
    <div class="desc">
      <h2 class="desc1">{{ $t("x.carousel.desc[0][0]") }}</h2>
      <span class="desc2" v-html="$t('x.carousel.desc[0][1]')"> </span>
    </div>
    <!-- 左侧按钮 -->
    <!-- <div class="buttonInLeft">
      <a href="#" class="toRight" @click.prevent="toRight()"
        ><i class="el-icon-arrow-right"></i
      ></a>
      <a href="#" class="toLeft" @click.prevent="toLeft()"
        ><i class="el-icon-arrow-left"></i
      ></a>
    </div> -->
    <!-- 点点 -->
    <div class="dots">
      <a
        href="#"
        v-for="(item, i) in 4"
        :key="i"
        :class="{ active: page == i }"
        @click.prevent="swiper1.slideTo(i)"
      ></a>
    </div>
    <!-- 指向下面的箭头框 -->
    <div class="bottomBox">
      <span href="#" class="toBottom"></span>
    </div>

    <!-- 右下角面板 -->
    <!-- <div class="panel">
      <div class="box">
        <b
          ><span>0{{ page + 1 }}</span
          >/03</b
        >
        <a href="#" class="toLeft" @click.prevent="toLeft()"
          ><i class="el-icon-arrow-left"></i
        ></a>
        <a href="#" class="toRight" @click.prevent="toRight()"
          ><i class="el-icon-arrow-right"></i
        ></a>
      </div>
    </div> -->
    <!-- 动效面板 -->
    <span class="dyna"></span>
  </div>
</template>
<script>
import Swiper from "swiper";
import "swiper/dist/css/swiper.css";

export default {
  name: "Carousel",

  data() {
    return {
      swiper1: null,
      //当前轮播图
      page: 0
    };
  },
  methods: {
    createSwiper() {
      let that = this;
      this.swiper1 = new Swiper(".swiper-container_1", {
        loop: true,
        speed: 1000,
        autoplay: {
          disableOnInteraction: false,
          delay: 2000
        },
        slidesPerView: "auto",
        simulateTouch: false, //禁止鼠标模拟
        on: {
          transitionStart() {
            that.page = this.realIndex;
          },
          transitionEnd() {}
        }
      });
    },
    toLeft() {
      this.swiper1.slidePrev();
    },
    toRight() {
      this.swiper1.slideNext();
    }
  },
  mounted() {
    this.createSwiper();
  }
};
</script>
<style scoped>
.carousel {
  position: relative;
  margin-top: 0.46rem;
  width: 100%;
  height: 4.6rem;
  overflow: hidden;
}
.swiper-container_1 {
  width: 100%;
  height: 100%;
}

.swiper-container_1 .swiper-slide {
  width: 100% !important;
  text-align: center;
  /* Center slide text vertically */
  display: -webkit-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  -webkit-justify-content: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  -webkit-align-items: center;
  align-items: center;
  transition-delay: 2s;
}

@keyframes common-run {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
/* 左侧的切换按钮 */
/* .buttonInLeft {
  position: absolute;
  top: 50%;
  left: 0;
  transform: translateY(-50%);
  animation: common-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2s;
  z-index: 2;
  opacity: 0;
}
.buttonInLeft a {
  width: 0.26rem;
  height: 0.26rem;
  display: block;
}
.buttonInLeft a i {
  font-size: 0.1rem;
  font-weight: bolder;
  line-height: 0.26rem;
}
.buttonInLeft .toRight {
  background: #ff7915;
}
.buttonInLeft .toRight i {
  color: #fff;
}
.buttonInLeft .toLeft {
  background: #fff;
}
.buttonInLeft .toLeft i {
  color: #ff7915;
} */
/* 点点 */
.dots {
  position: absolute;
  bottom: 0.3rem;
  right: 0.7rem;
  animation: common-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2s;
  z-index: 2;
  opacity: 0;
}
.dots a {
  width: 0.05rem;
  height: 0.05rem;
  display: inline-block;
  background: #fff;
  margin: 0.1rem;
  border-radius: 0.5rem;
}
.dots .active {
  background: #ff7915;
}
.bottomBox {
  width: 0.5rem;
  height: 0.5rem;
  position: absolute;
  bottom: 0rem;
  left: 50%;
  transform: translateX(-50%);
  animation: common-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2s;
  z-index: 2;
  opacity: 0;
}
.toBottom {
  width: 0.14rem;
  height: 0.36rem;
  position: absolute;
  bottom: 0.1rem;
  left: 50%;
  transform: translateX(-50%);
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/toBottom.png");
  background-size: 100%;
  animation: toBottom-run 1.5s linear infinite;
}
@keyframes toBottom-run {
  0% {
    bottom: 0.2rem;
  }
  50% {
    bottom: 0.3rem;
  }
  100% {
    bottom: 0.2rem;
  }
}
/* 左上角文字说明 
   .en 英文版*/
.desc {
  width: 3.6rem;
  height: 1.57rem;
  position: absolute;
  top: 0;
  left: 0;
  text-align: left;
  font-family: Microsoft YaHei;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 0rem 0rem 1rem 0rem;
  animation: desc-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2s;
  z-index: 2;
  opacity: 0;
}
@keyframes desc-run {
  0% {
    top: -1.46rem;
    opacity: 0;
  }
  100% {
    top: 0rem;
    opacity: 1;
  }
}
.en .desc {
  font-family: Arial;
}
.desc1 {
  margin: 0.27rem 0 0 0.5rem;
  font-size: 0.16rem;
  font-weight: 300;
  color: #666666;
}
.en .desc1 {
  font-size: 0.16rem;
  font-weight: 400;
}
.desc2 {
  width: 3rem;
  margin: 0.1rem 0 0 0.5rem;
  font-size: 0.26rem;
  font-weight: 400;
  color: #333333;
  line-height: 0.36rem;
}
.en .desc2 {
  font-size: 0.21rem;
  font-weight: bold;
  line-height: 0.27rem;
}
.panel {
  width: 3.52rem;
  height: 0.5rem;
  position: absolute;
  bottom: -0.5rem;
  right: 0;
  text-align: left;
  background: #ffffff;
  animation: panel-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2.5s;
  z-index: 2;
  transition: all 1s;
}

@keyframes panel-run {
  0% {
    bottom: -0.5rem;
  }
  100% {
    bottom: 0;
  }
}
.panel .box {
  margin-top: 0.1rem;
  animation: box-run 1s;
  animation-fill-mode: forwards;
  animation-delay: 2.7s;
  opacity: 0;
}
@keyframes box-run {
  0% {
    margin-top: 0.1rem;
    opacity: 0;
  }
  100% {
    margin-top: 0;
    opacity: 1;
  }
}
.panel b {
  margin: 0 0 0 0.3rem;
  font-size: 0.08rem;
  line-height: 0.5rem;
  font-family: SourceHanSansCN;
  font-weight: 700;
}
.panel span {
  display: inline;
  font-size: 0.08rem;
  font-weight: 700;
  color: #ff7915;
}
.panel a {
  display: inline-block;
  margin: 0 0 0 0.4rem;
}
.panel i {
  vertical-align: middle;
}
.panel .toRight {
  color: #ff7915;
}
/* 动效 */
.dyna {
  width: 150%;
  height: 100%;
  position: absolute;
  top: 0;
  left: -1rem;
  background: #ff7915;
  animation: dyna-run 2s;
  animation-fill-mode: forwards;
  z-index: 2;
}
@keyframes dyna-run {
  0% {
    left: -100%;
  }
  100% {
    left: 100%;
  }
}
</style>
