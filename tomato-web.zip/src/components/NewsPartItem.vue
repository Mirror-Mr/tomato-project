<!--
 * @Author: your name
 * @Date: 2021-02-26 11:35:52
 * @LastEditTime: 2021-05-27 16:04:28
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\NewsItem.vue
-->
<template>
  <div class="newsPartItem" @click="showNews">
    <el-card :body-style="{ padding: '0px' }" shadow="hover">
      <span class="image" :style="{backgroundImage:'url('+news.icon+')',backgroundSize:'cover',backgroundPosition:'center'}"  ></span>
      <div class="content">
        <span class="time">{{ start_time }}</span>
        <span class="title">{{ news.title }}</span>
        <span class="desc">{{ news.desc }}</span>
      </div>
    </el-card>
  </div>
</template>
<script>
export default {
  name: "NewsPartItem",
  props: {
    news: {
      type: Object,
      require: true
    }
  },
  data() {
    return {
      currentDate: new Date(),
      key: "0391591aafc5db68b08787645b837b4f",
      // 时间戳
      timer: parseInt(Date.parse(new Date()) / 1000)
    };
  },
  methods: {
    showNews() {
      // 将id和type传递给下一个新闻详情页
      // this.$router.push({
      //   name: "SingleNews",
      //   query: {
          
      //     id:this.news.id,
      //     type:this.news.type
      //   }
      // });
      // });
    }
  },
  computed: {
    area: function() {
      return localStorage.getItem("isEn") == "true" ? 0 : 1;
    },
    start_time() {
      // return this.news.start_time.replace(/(\/)/g, "-");
      return this.news.start_time.replace(/-/g, "/");
    }
  }
 
};
</script>
<style scoped>
.newsPartItem {
  width: 1.99rem;
  height: 2.53rem;
  text-align: left;
  cursor: pointer;
}
.newsPartItem:hover .title {
  text-decoration: underline;
}
.el-card {
  width: 100%;
  height: 100%;
  border-radius: 0.05rem;
}
.el-card:hover {
  box-shadow: 0rem 0.01rem 0.1rem 0.04rem rgb(0 0 0 / 10%);
  transform: scale(1.01);
}
.image {
  width: 1.99rem;
  height: 1.24rem;
  display: block;
}
.content {
  width: 1.99rem;
  height: 1.29rem;
  background: #ffffff;
  box-shadow: 0rem 0rem 0rem 0rem rgba(231, 133, 60, 0.1);
}
.time {
  /* width: 0.54rem; */
  height: 0.13rem;
  padding: 0 0.04rem;
  line-height: 0.13rem;
  text-align: center;
  font-size: 0.1rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  margin: 0.15rem 0 0 0.11rem;
  color: #fb5e00;
  background: rgba(255, 122, 21, 0.3);
  border-radius: 0.03rem;
}
.title {
  width: 1.76rem;
  display: block;
  margin: 0.15rem auto 0;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.16rem;
  /* 超出部分内容显示省略号 以下5行 */
  overflow: hidden;
  /* 超出部分设为... */
  text-overflow: ellipsis;
  /* 盒子模型 */
  display: -webkit-box;
  /* 2行文本 */
  -webkit-line-clamp: 2;
  /* 从顶部向底部垂直布置子元素 */
  -webkit-box-orient: vertical;
}
.en .title {
  font-family: Arial;
}
.desc {
  width: 1.68rem;
  margin: 0.09rem auto 0;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666666;
  line-height: 0.12rem;
  /* 超出部分内容显示省略号 以下5行 */
  overflow: hidden;
  /* 超出部分设为... */
  text-overflow: ellipsis;
  /* 盒子模型 */
  display: -webkit-box;
  /* 2行文本 */
  -webkit-line-clamp: 2;
  /* 从顶部向底部垂直布置子元素 */
  -webkit-box-orient: vertical;
}
.en .desc {
  font-family: Arial;
}
</style>
