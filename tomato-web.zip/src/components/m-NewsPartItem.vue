<!--
 * @Author: your name
 * @Date: 2021-03-01 16:34:40
 * @LastEditTime: 2021-05-26 17:17:57
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\NewsPItem.vue
-->
<template>
  <div class="mnewsPartItem" shadow="hover" @click="showNews">
    <span class="time">{{ start_time }}</span>
    <div class="content">
      <div class="bottom">
        <h2>{{ news.title }}</h2>
        <span class="desc">{{ news.desc }}</span>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "MNewsPartItem",
  props: {
    news: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      key: "0391591aafc5db68b08787645b837b4f",
      // 时间戳
      timer: parseInt(Date.parse(new Date()) / 1000)
    };
  },
  methods: {
    showNews() {
      // 将id和type传递给下一个新闻详情页
      this.$router.push({
        name: "MSingleNews",
        query: {
          id: this.news.id,
          type: this.news.type
        }
      });
    },
    // 监听滚动条
    handleScroll(e) {
      var scrollTop =
        e.target.documentElement.scrollTop || e.target.body.scrollTop;
      if (scrollTop > this.screenHeight + 200) {
        this.isActive = true;
      }
    }
  },
  computed: {
    area: function() {
      return localStorage.getItem("isEn") == "true" ? 0 : 1;
    },
    start_time() {
      // return this.news.start_time.replace(/(\/)/g, "-");
      return this.news.start_time.replace(/-/g, "/");
    }
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true);
  }
};
</script>
<style scoped>
.mnewsPartItem {
  width: 93%;
  height: 3.84rem;
  margin: 0 auto 0.52rem;
  box-shadow: 0rem 0rem 0.1rem 0.05rem rgba(184, 184, 184, 0.18);

  cursor: pointer;
}
.mnewsPItem:nth-child(even) {
  background: #f8f8f8;
}
.time {
  height: 0.33rem;
  margin: 0.56rem 0 0 0.49rem;
  padding: 0 0.15rem;
  text-align: center;
  font-size: 0.2rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  line-height: 0.33rem;
  color: #ff7915;
  background: rgba(255, 122, 21, 0.3);
  border-radius: 0.1rem;
  float: left;
}
.content {
  width: 8.25rem;
  margin: 0.35rem 0 0 0.49rem;
  text-align: left;
  float: left;
}
.bottom {
  height: 1rem;
}

h2 {
  width: 8rem;
  font-size: 0.37rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.41rem;
  /* 关键代码 ！！！！ 以下5行 */
  overflow: hidden;
  /* 超出部分设为... */
  text-overflow: ellipsis;
  /* 盒子模型 */
  display: -webkit-box;
  /* 最多2行文本 多余部分隐藏*/
  -webkit-line-clamp: 2;
  /* 从顶部向底部垂直布置子元素 */
  -webkit-box-orient: vertical;
}
.desc {
  width: 8.21rem;
  margin: 0.31rem 0 0 0;
  font-size: 0.29rem;
  font-family: Microsoft YaHei;
  text-align: justify;
  font-weight: 400;
  color: #666666;
  line-height: 0.45rem;
  /* 关键代码 ！！！！ 以下5行 */
  overflow: hidden;
  /* 超出部分设为... */
  text-overflow: ellipsis;
  /* 盒子模型 */
  display: -webkit-box;
  /* 最多2行文本 多余部分隐藏*/
  -webkit-line-clamp: 2;
  /* 从顶部向底部垂直布置子元素 */
  -webkit-box-orient: vertical;
}
</style>
