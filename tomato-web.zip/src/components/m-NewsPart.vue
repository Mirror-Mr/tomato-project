<!--
 * @Author: your name
 * @Date: 2021-02-23 10:57:53
 * @LastEditTime: 2021-05-15 18:25:30
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\News.vue
-->
<template>
  <div class="mnewsPart">
    <div class="container">
      <div class="theme">
        <h2 :class="{ active: newsActive }">{{ $t("x.newsPart.title") }}</h2>
        <!-- <div class="right">
          <a href="#">See more <i class="el-icon-arrow-right"></i></a>
        </div> -->
      </div>

      <div class="tabsBox">
        <!-- label是展示的导航栏内容 -->
        <MNewsPartItem v-for="(item, i) in filterNews" :key="i" :news="item" />
      </div>
    </div>
    <a href="#" class="seemore" @click.prevent="toNewsPage">
      <template v-if="newsList.length != 0">
        {{ $t("x.newsPage.seeMore") }}
        <i
          class="el-icon-arrow-right
"
        ></i>
      </template>
      <template v-else>
        暂无相新闻信息
      </template>
    </a>
  </div>
</template>
<script>
import MNewsPartItem from "@/components/m-NewsPartItem.vue";
export default {
  name: "mnewsPart",
  components: {
    MNewsPartItem
  },
  data() {
    return {
      // 标题动画效果
      newsActive: false,

      // 当前看的是哪类消息 0-最新 1-新闻 2-通知 3-活动
      newsType: 0,
      // 最新消息开始页数
      newestIndex: 0,
      // 新闻开始页数
      newsIndex: 0,
      // 通知开始页数
      noticeIndex: 0,
      // 活动开始页数
      activityIndex: 0,
      key: "0391591aafc5db68b08787645b837b4f",
      timer: parseInt(Date.parse(new Date()) / 1000),
      newsList: []
    };
  },
  computed: {
    filterNewest() {
      return this.$t("x.newsPage.newest").slice(
        this.newestIndex * 3,
        (this.newestIndex + 1) * 3
      );
    },
    // filterNews() {
    //   return this.$t("x.newsPage.news").slice(
    //     this.newsIndex * 3,
    //     (this.newsIndex + 1) * 3
    //   );
    // },
    filterNews() {
      return this.newsList.slice(this.newsIndex * 3, (this.newsIndex + 1) * 3);
    },
    filterNotice() {
      return this.$t("x.newsPage.notice").slice(
        this.noticeIndex * 3,
        (this.noticeIndex + 1) * 3
      );
    },
    filterActivity() {
      return this.$t("x.newsPage.activity").slice(
        this.activityIndex * 3,
        (this.activityIndex + 1) * 3
      );
    },
    area: function() {
      return localStorage.getItem("isEn") == "true" ? 2 : 1;
    }
  },
  methods: {
    changeTab(vue, event) {
      if (event.target.id == "tab-0") {
        this.newsType = 0;
      } else if (event.target.id == "tab-1") {
        this.newsType = 1;
      } else if (event.target.id == "tab-2") {
        this.newsType = 2;
      } else {
        this.newsType = 3;
      }
    },
    toNewsPage() {
      if(this.newsList.length == 0){
        return;
      }
      this.$router.push("/m/newsPage");
    },
    handleScroll(e) {
      var scrollTop =
        e.target.documentElement.scrollTop || e.target.body.scrollTop;
      if (scrollTop > 400) {
        this.newsActive = true;
      }
    }
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true);
    // 首页获取最新新闻
    this.$axios({
      method: "get",
      url: "https://hw.xianyuyouxi.com/service/Tomato_webhome/getNews",
      headers: {
        "Access-s": this.$md5(`${this.key}${this.timer}`)
      },
      params: {
        time: this.timer,
        area: this.area,
        company: 1
      }
    }).then(res => {
      // console.log(res);
      if (res.status == 200) {
        // 获取新闻成功
        this.newsList = res.data.data;
      } else {
        this.$message.error("获取首页新闻数据失败");
      }
    });
  }
};
</script>
<style scoped>
.mnewsPart {
  width: 100%;
  min-height: 16rem;
}
.container {
  width: 100%;
}
.theme {
  width: 85%;
  height: 0.75rem;
  margin: 0.57rem auto 0;
}
.theme::after {
  content: "";
  display: block;
  clear: both;
}
.theme h2 {
  display: inline-block;
  margin: 0.7rem 0 0 0;
  font-size: 0.48rem;
  font-family: Arial;
  font-weight: bold;
  color: #333333;
  line-height: 0.3rem;
  transition: all 1s;
}
h2.active {
  margin: 0.3rem 0 0 0;
}
.right a {
  margin: 0.4rem 0 0 0rem;
  font-size: 0.11rem;
  font-family: Arial;
  font-weight: 400;
  color: #999999;
  line-height: 0.3rem;
  float: right;
  transition: all 0.2s;
}
.right a:hover {
  color: #ff7915;
}

.tabsBox {
  width: 100%;
  margin: 0.7rem 0 0 0;
}
.seemore {
  width: 2.6rem;
  height: 0.77rem;
  margin: 0.15rem 0 0.4rem 0;
  /* background: #ff7915; */
  border-radius: 0.4rem;
  font-size: 0.37rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  /* color: #ffffff; */
  line-height: 0.77rem;
}
.seemore i {
  /* font-size: 0.3rem; */
}
</style>
