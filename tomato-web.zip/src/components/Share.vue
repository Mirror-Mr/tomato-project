<!--
 * @Author: your name
 * @Date: 2021-03-25 19:31:15
 * @LastEditTime: 2021-05-17 17:15:07
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\ShareEn.vue
-->
<template>
  <div class="share">
    <div class="icon">
      <span>{{ $t("x.newsPage.share") }}</span>
      <div class="wBox" :class="{ wShow: isWShow }">
        <span>{{ $t("x.newsPage.icon[0]") }}</span>
        <canvas class="canvas" id="canvas" ref="canva"> </canvas>
      </div>
      <a href="#" @click.prevent.stop="clickIcon(1)" class="share1"></a>
      <a href="#" @click.prevent.stop="clickIcon(2)" class="share2"></a>
      <a href="#" @click.prevent.stop="clickIcon(3)" class="share3"></a>
    </div>
  </div>
</template>
<script>
import QRCode from "qrcode";

export default {
  name: "Share",
  props: {
    news: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      qrcode: "",
      isWShow: false
    };
  },
  methods: {
    clickIcon(type) {
      let url = location.href;
      // console.log(location.host)
      if (this.$route.path == "/newsPage") {
        url ='http://' + location.host + "/singleNews?id="+ this.news.id + "&type="+this.news.type;
        console.log(url)
      }else{
        console.log(url)
      }
      if (type == 1) {
        // 微信
        this.isWShow = !this.isWShow;
        this.createQRcode(url);
      } else if (type == 2) {
        //  微博
        window.open(
          "http://v.t.sina.com.cn/share/share.php?pic=" +
            this.news.icon +
            "&title=" +
            this.news.title +
            "&url=" +
            url
        );
      } else if (type == 3) {
        // qq好友
        window.open(
          "http://connect.qq.com/widget/shareqq/index.html?url=" +
            encodeURIComponent(url) +
            "?sharesource=qzone&title=" +
            this.news.title +
            "&pics=" +
            this.news.icon +
            "&summary= " +
            this.news.title
        );
      }
      // qq空间
      //  window.open('https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url='+location.href+'&sharesource=qzone&title=你的分享标题&pics=你的分享图片&summary=你的分享描述信息')
    },
    // 动态生成二维码
    createQRcode(url) {
      let canvas = this.$refs.canva;
      QRCode.toCanvas(canvas, url, { margin: 1.5 }, function(error) {
        if (error) console.error(error);
      });
      canvas.style.display = "block"; //隐藏掉canvas
      this.qrcode = canvas.toDataURL("image/png");
      console.log(this.qrcode);
    }
  }
};
</script>
<style scoped>
.share {
  position: absolute;
  bottom: 0.15rem;
  right: 0.3rem;
  z-index: 2000;
}
.en .share {
  bottom: 0.3rem;
}
/* 三个标签 */
.icon {
  display: inline-block;
  float: right;
  position: relative;
}

.icon span {
  margin: 0 0.07rem 0 0;
  vertical-align: middle;
  font-size: 0.07rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #999999;
}
/* 微信扫码div */
.icon .wBox {
  display: inline-block;
  position: absolute;
  top: 0.2rem;
  left: 0.08rem;
  opacity: 0;
}
.icon .wShow {
  opacity: 1;
}
.canvas {
  width: 0.5rem !important;
  height: 0.5rem !important;
}
.icon a {
  margin: 0 0.06rem;
  vertical-align: middle;
}
.en .icon a {
  margin: 0 0.07rem;
}
.share1 {
  width: 0.095rem;
  height: 0.083rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/wechat0.png");
  background-size: 100%;
  transition: all 0.1s;
}
.en .share1 {
  width: 0.08rem;
  height: 0.08rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/ins0.png");
}
.share1:hover {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/wechat1.png");
  background-size: 100%;
}
.en .share1:hover {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/ins1.png");
  background-size: 100%;
}
.share2 {
  width: 0.1rem;
  height: 0.084rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/weibo0.png");
  background-size: 100%;
  transition: all 0.1s;
}
.en .share2 {
  width: 0.09rem;
  height: 0.09rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/twitter0.png");
  background-size: 100%;
}
.share2:hover {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/weibo1.png");
  background-size: 100%;
}
.en .share2:hover {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/twitter1.png");
  background-size: 100%;
}
.share3 {
  width: 0.07rem;
  height: 0.08rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/qq0.png");
  background-size: 100%;
  transition: all 0.1s;
}
.en .share3 {
  width: 0.06rem;
  height: 0.09rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/face0.png");
  background-size: 100%;
}
.share3:hover {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/qq1.png");
  background-size: 100%;
}
.en .share3:hover {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/face1.png");
  background-size: 100%;
}
</style>
