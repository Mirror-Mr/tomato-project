<!--
 * @Author: your name
 * @Date: 2021-03-01 16:34:40
 * @LastEditTime: 2021-05-26 17:17:14
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\NewsPItem.vue
-->
<template>
  <div class="mnewsPageItem" shadow="hover" @click="showNews">
    <span
      class="image"
      :style="{
        backgroundImage: 'url(' + news.icon + ')',
        backgroundSize: '100%'
      }"
    ></span>
    <span class="time">{{ start_time }}</span>
    <div class="content">
      <h2>{{ news.title }}</h2>
      <span class="desc">{{ news.desc }}</span>
    </div>
  </div>
</template>
<script>
export default {
  name: "mnewsPageItem",
  props: {
    news: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      key: "0391591aafc5db68b08787645b837b4f",
      // 时间戳
      timer: parseInt(Date.parse(new Date()) / 1000)
    };
  },
  methods: {
    showNews() {
      // 将id和type传递给下一个新闻详情页
      this.$router.push({
        name: "MSingleNews",
        query: {
          id: this.news.id,
          type: this.news.type
        }
      });
    }
  },
  computed: {
    area: function() {
      return localStorage.getItem("isEn") == "true" ? 0 : 1;
    },
    start_time() {
      return this.news.start_time.replace(/-/g, "/");
    }
  }
};
</script>
<style scoped>
.mnewsPageItem {
  width: 8.4rem;
  margin: 0 auto;
  text-align: left;
}
.image {
  width: 8.4rem;
  height: 4.61rem;
  border-radius: 0.2rem;
}
.time {
  /* width: 1.39rem; */
  height: 0.33rem;
  margin: 0.69rem 0 0 0;
  padding: 0.01rem 0.1rem;
  /* display: block; */
  text-align: center;
  font-size: 0.21rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #fb5e00;
  line-height: 0.3rem;
  background: rgba(255, 122, 21, 0.3);
  border-radius: 0.09rem;
}
/* 内容区域 */
.content {
  width: 100%;
  margin: 0.25rem 0 0 0;
  text-align: left;
}

h2 {
  width: 100%;
  margin: 0 0 0.3rem 0;
  font-size: 0.43rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ff7915;
  line-height: 0.68rem;
  /* 关键代码 ！！！！ 以下5行 */
  overflow: hidden;
  /* 超出部分设为... */
  text-overflow: ellipsis;
  /* 盒子模型 */
  display: -webkit-box;
  /* 最多2行文本 多余部分隐藏*/
  -webkit-line-clamp: 2;
  /* 从顶部向底部垂直布置子元素 */
  -webkit-box-orient: vertical;
}
.desc {
  width: 100%;
  margin: 0 0 1.5rem 0;
  font-size: 0.35rem;
  font-family: Microsoft YaHei;
  text-align: justify;
  font-weight: 400;
  color: #666666;
  line-height: 0.49rem;
  /* 关键代码 ！！！！ 以下5行 */
  overflow: hidden;
  /* 超出部分设为... */
  text-overflow: ellipsis;
  /* 盒子模型 */
  display: -webkit-box;
  /* 最多2行文本 多余部分隐藏*/
  -webkit-line-clamp: 4;
  /* 从顶部向底部垂直布置子元素 */
  -webkit-box-orient: vertical;
}
</style>
