<!--
 * @Author: your name
 * @Date: 2021-02-23 10:57:53
 * @LastEditTime: 2021-05-25 11:03:05
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\HelloWorld.vue
-->
<template>
  <div class="header" id="header" :class="{ isHide: hide }">
    <router-link to="/" style="display:inline"
      ><img :src="$t('x.logo')" alt="logo"
    /></router-link>
    <!-- 切换中英文 -->
    <!-- <el-dropdown trigger="click" @command="handleCommand">
      <span class="el-dropdown-link">
        {{ $t("x.header.currentLang")
        }}<i class="el-icon-caret-bottom el-icon--right"></i>
      </span>
      <el-dropdown-menu slot="dropdown" class="menu">
        <el-dropdown-item command="c">{{
          $t("x.header.lang[0]")
        }}</el-dropdown-item>
        <el-dropdown-item command="e">{{
          $t("x.header.lang[1]")
        }}</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown> -->
    <ul class="nav">
      <li>
        <router-link to="/">{{ $t("x.header.nav[0]") }}</router-link>
      </li>
      <li>
        <router-link to="/games">{{ $t("x.header.nav[1]") }}</router-link>
      </li>
      <li>
        <router-link to="/newsPage">{{ $t("x.header.nav[2]") }}</router-link>
      </li>
      <li>
        <a class="toContact" @click.prevent="toContact">{{ $t("x.header.nav[3]") }}</a>
        <!-- <router-link to="#toContact">{{ $t("x.header.nav[3]") }}</router-link> -->
      </li>
      <li>
        <a class="toContact" target="_blank" href="https://app.mokahr.com/social-recruitment/tomatogames/39549#/">{{ $t("x.header.nav[4]") }}</a>
        <!-- <router-link target="_blank" to="https://app.mokahr.com/social-recruitment/tomatogames/39549#/" >{{
          $t("x.header.nav[4]")
        }}</router-link> -->
      </li>
    </ul>
    <MaskBox :isShow="isShow" @close="closeMask" />
  </div>
</template>

<script>
import MaskBox from "./MaskBox";
export default {
  name: "Header",
  components: {
    MaskBox
  },
  data() {
    return {
      isShow: false,
      //记录上一次滚动条距离
      lastSpace: 0,
      // 是否隐藏
      hide: false
    };
  },
  methods: {
    handleCommand(command) {
      if (command == "c") {
        this.$i18n.locale = "zh-CN"; // 切换成中文
        localStorage.setItem("isEn", false);
      } else {
        this.$i18n.locale = "en-US"; // 切换成英文
        localStorage.setItem("isEn", true);
      }
      location.reload();
    },
    // 跳转到主页联系我们部分
    toContact() {
      // console.log(this.$route.path);
      // 当前页面跳转
      if (this.$route.path == "/") {
        // 所有元素加载完执行
        this.$nextTick(() => {
          let contactTop = document.getElementById("toContact").offsetTop;
          document.documentElement.scrollTop = contactTop;
          // this.isShow = true;
        });
      } else {//其他页面跳转
        this.$router.push({
          name: "Home",
          params: {
            toContact: "true"
          }
        });
      }

    },
  
    closeMask(show) {
      this.isShow = show;
    },
    handleScroll(e) {
      var scrollTop =
        e.target.documentElement.scrollTop || e.target.body.scrollTop;
      if (scrollTop > this.lastSpace) {
        this.hide = true;
      } else {
        this.hide = false;
      }
      this.lastSpace = scrollTop;
    }
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true);
  }
};
</script>
<style scoped>
.header {
  width: 100%;
  min-width: 8rem;
  height: 0.46rem;
  position: fixed;
  top: 0;
  left: 0;
  background: #ff7915;
  padding-top: 0.01rem;
  z-index: 2001;
  transition: all 0.7s;
}
.header.isHide {
  top: -0.46rem;
}
.header img {
  width: 0.95rem;
  height: 0.27rem;
  display: block;
  margin: 0.08rem 0 0 0.63rem;
  float: left;
}
/* 下拉框 */
.el-dropdown {
  height: 100%;
  margin: 0 0 0 0.36rem;
  line-height: 0.46rem;
  float: left;
}
.el-dropdown-link {
  cursor: pointer;
  font-size: 0.11rem;
  font-family: SourceHanSansCN;
  font-weight: 400;
  color: #ffffff;
}
.el-dropdown-link i {
  font-size: 0.07rem;
}
.el-dropdown-menu {
  width: 0.63rem;
  top: 0.3rem !important;
  left: 1.86rem !important;
}
.el-dropdown-menu__item {
  width: 100%;
  height: 0.18rem;
  line-height: 0.18rem;
  padding: 0;
  font-size: 0.1rem;
  font-family: SourceHanSansCN;
  font-weight: 400;
  color: #ff7915;
  text-align: center;
}

.menu >>> .popper__arrow,
.menu >>> .popper__arrow::after {
  display: none !important;
}
.el-dropdown-menu__item {
  color: #ff7a15;
}
.el-dropdown-menu__item:focus,
.el-dropdown-menu__item:not(.is-disabled):hover {
  background: #ffe4d1;
  color: #ff7a15;
}
/* 右侧导航 */
.nav {
  height: 100%;
  line-height: 0.46rem;
  margin: 0 0.6rem 0 0;
  font-size: 0.08rem;
  font-family: SourceHanSansCN;
  font-weight: 400;
  float: right;
}
.nav li {
  height: 100%;
  display: inline-block;
  margin-left: 0.3rem;
}

.nav li a {
  position: relative;
  color: #fff;
}
.nav li a:hover {
  color: #e1e1e1;
}
/* .nav li a::after {
  content: "";
  display: block;
  width: 100%;
  height: 0.01rem;
  position: absolute;
  top: 0.4rem;
  left: 0;
  background: #fff;
  opacity: 0;
  transition: all 0.6s;
}
.nav li a:hover::after {
  top: 0.34rem;
  opacity: 1;
} */
.toContact{
  cursor: pointer;
}
</style>
