<!--
 * @Author: your name
 * @Date: 2021-03-02 18:15:13
 * @LastEditTime: 2021-05-28 17:25:30
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\Mask.vue
-->
<template>
  <div class="maskBox" :style="{ display: isShow && show ? 'block' : 'none' }">
    <!-- <div class="maskBox" :style="{opacity:isShow?0:1,zIndex:isShow?-1:2}"> -->
    
    <div class="box">
      <a href="#" class="close" @click.prevent="close"
        ><i class="el-icon-close"></i
      ></a>
      <div class="col-3 input-effect name" :class="{ err: nameNone }">
        <span class="tag red">*</span>
        <input
          class="effect-16"
          type="text"
          @blur="inputBlur"
          v-model="contactMsg.name"
        />
        <label>{{ $t("x.maskBox.name[0]") }}</label>
        <span class="focus-border"></span>
      </div>
      <div class="col-3 input-effect email " :class="{ err: emailNone }">
        <span class="tag red">*</span>
        <input
          class="effect-16"
          type="text"
          @blur="inputBlur"
          v-model="contactMsg.email"
        />
        <label>{{ $t("x.maskBox.email[0]") }}</label>
        <span class="focus-border"></span>
      </div>
      <div class="col-3 input-effect subject" :class="{ err: subjectNone }">
        <span class="tag red">*</span>
        <input
          class="effect-16"
          type="text"
          @blur="inputBlur"
          v-model="contactMsg.subject"
        />
        <label>{{ $t("x.maskBox.subject[0]") }}</label>
        <span class="focus-border"></span>
      </div>
      <div class="col-3 input-effect content" >
        <textarea
          class="effect-8"
          type="text"
          :placeholder="$t('x.maskBox.content[0]')"
          v-model="contactMsg.content"
        ></textarea>
        <span class="focus-border">
          <i></i>
        </span>
      </div>
      <a href="#" class="submit" @click.prevent="sendMsg()">{{
        $t("x.maskBox.send[0]")
      }}</a>
    </div>
  </div>
</template>
<script>
import "../assets/css/input-style.css";
export default {
  name: "MaskBox",
  props: {
    isShow: {
      type: Boolean,
      required: true
    },
    num:{
      type:Number,
      default:4
    }
  },
  data() {
    return {
      contactMsg: {
        name: "",
        email: "",
        subject: "",
        content: ""
      },
      show: true,
      // input是否为空
      nameNone: false,
      emailNone: false,
      subjectNone: false,
      key: "0391591aafc5db68b08787645b837b4f",
      // 时间戳
      timer:parseInt(Date.parse(new Date()) / 1000),
    };
  },
  methods: {
    inputBlur(e) {
      let val = e.target.value;
      if (val) {
        e.target.classList.add("has-content");
      } else {
        e.target.classList.remove("has-content");
      }
    },
    sendMsg() {
      let msg = this.contactMsg;
      if (!msg.name) {
        this.nameNone = true;
        return;
      } else if (!msg.email) {
        this.emailNone = true;
        return;
      } else if (!msg.subject) {
        this.subjectNone = true;
        return;
      }
      console.log(this.contactMsg);
      // 。。。
      this.$axios({
        method:"post",
        url:"https://hw.xianyuyouxi.com/service/Tomato_webhome/sendEmail",
        headers:{
          "Access-s":this.$md5(`${this.key}${this.timer}${this.contactMsg.email}${this.to_email}`)
        },
        data:{
          time:this.timer,
          realName:this.contactMsg.name,
          email:this.contactMsg.email,
          title:this.contactMsg.subject,
          content:this.contactMsg.content,
          to_email:this.to_email,
          company:1
        }
      }).then(res=>{
        if(res.data.code == 1){
          this.$message.success("发送成功！")
        }else{
          this.$message.error(res.data.msg);
        }
      })
    },
    close() {
      this.show = false;
      this.$emit("close", false);
      (this.contactMsg = {
        name: "",
        email: "",
        subject: "",
        content: ""
      }),
        (this.show = true);
        document.getElementsByClassName("maskBox")[0].style.display = "none"
    }
  },
  watch:{
    contactMsg:{
      handler(newValue){
        if(newValue.name){
          this.nameNone = false;
        }
        if(newValue.email){
          this.emailNone = false;
        }
        if(newValue.subject){
          this.subjectNone = false;
        }
      },
      deep:true
    }
  },
  computed:{
    to_email(){
      if(this.num == 0){
        return "qdhz@tomatogames.com"
      }else if(this.num == 1){
        return "mthz@tomatogames.com";
      }else if(this.num == 2){
        return "cpyr@tomatogames.com";
      }else if(this.num == 3){
        return "gghz@tomatogames.com";
      }
    }
  }
};
</script>
<style scoped>
.maskBox {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 102;
}
.box {
  width: 4.97rem;
  /* height: 2.92rem; */
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: #ffffff;
  border-radius: 0.1rem;
}
.close {
  margin-top: 0.07rem;
  color: #ddd;
}
.close i {
  font-size: 0.2rem;
}
.input-effect label {
  text-align: left;
}
.name,
.email {
  width: 41%;
}
.err::after {
  color: red;
  position: absolute;
  top: 0.25rem;
  left: 0;
}
.name {
  margin: 0.3rem 0 0 0.4rem;
}
.name.err:after {
  content: "请输入姓名";
}
.email.err:after {
  content: "请输入邮箱";
}
.subject.err:after {
  content: "请输入主题";
}


.email {
  margin: 0.3rem 0 0 0.1rem;
}
.subject {
  width: 84%;
  margin: 0.2rem 0 0 0.4rem;
}
.content {
  width: 84%;
  height: 1.3rem;
  margin: 0.15rem 0 0 0.4rem;
  /* border: 0.01rem solid red; */
}
.content textarea {
  width: 100%;
  height: 100%;
  font: 15px/24px "Lato", Arial, sans-serif;
  color: #333;
  border: none;
  border-bottom: 0.01rem solid #ccc;
  resize: none;
  transition: all 0.4s;
  box-sizing: border-box;
  transition: all 0.3s;
}
textarea:focus {
  padding: 1%;
}
.content textarea::-webkit-input-placeholder {
  color: #aaa;
}
.tag {
  position: absolute;
  top: 50%;
  left: 0;
  transform: translate(-200%, -40%);
}
.submit {
  width: 0.67rem;
  height: 0.2rem;
  margin: 0.15rem 0 0.15rem 3.5rem;
  font-size: 0.09rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
  line-height: 0.2rem;
  background: #ff7915;
  border-radius: 0.1rem;
}
</style>
