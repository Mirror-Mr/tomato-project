<!--
 * @Author: your name
 * @Date: 2021-03-22 11:37:04
 * @LastEditTime: 2021-05-31 19:00:26
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\jobs\Overlay.vue
-->

<template>
  <div class="joverlay" :class="{campus:campus}">
    <div class="center">
      <span class="title"></span>
      <span class="logo"></span>
      <!-- 输入框 -->
      <div class="inputBox">
        <el-input
          :placeholder="$t('y.overlay.placeholder')"
          prefix-icon="el-icon-search"
          v-model="keyword"
          class="search-button"
          @keyup.enter.native="searchPost"
        >
        </el-input>
        <a href="#" class="search" @click.prevent="searchPost">{{
          $t("y.overlay.search")
        }}</a>
      </div>
    </div>
    <!-- 向下的箭头 -->
    <div class="bottomBox">
      <span href="#" class="toBottom"></span>
    </div>
  </div>
</template>
<script>
export default {
  name: "JOverlay",
  props: {
    campus: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      keyword: ""
    };
  },
  methods: {
    searchPost() {
      this.$router.push({
        name: "AllPost",
        query: { keyword: this.keyword, campus: this.campus }
      });
    }
  }
};
</script>
<style scoped>
.joverlay {
  width: 100%;
  /* min-width: 6rem; */
  height: 5.1rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/employ_bg.png")
    no-repeat;
  background-size: 100%;
  position: relative;
}
.joverlay.campus{
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/campus_bg.png");
  background-size: 100%;
}
.center {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.en h1 {
  letter-spacing: 0.005rem;
}
h1 {
  margin: 0 0 0.16rem 0;
  font-size: 0.26rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  font-style: italic;
  letter-spacing: 0.035rem;
  color: #ffffff;
}
.title {
  width: 3.2rem;
  height: 0.34rem;
  margin: 0 0 0.1rem 0;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/over_title.png");
  background-size: 100%;
}
.en .title {
  width: 2.81rem;
  height: 0.24rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/en_overlay_title.png");
  background-size: 100%;
}
.logo{
  width: 3.2rem;
  height: 0.13rem;
  margin: 0 0 0.2rem 0;
  background: url('https://wcdn.tomatogames.com/web/haiwai/tomato/img/employ_logo.png');
  background-size:100% ;
}
.inputBox {
  width: 3rem;
  margin: 0 auto;
  position: relative;
  display: flex;
  align-items: center;
}
.inputBox >>> .el-input input {
  width: 100%;
  height: 0.3rem;
  background: #ffffff;
  border: 0;
  border-radius: 0.2rem;
}
.inputBox >>> .el-input--prefix .el-input__inner {
  padding: 0 0 0 0.3rem;
}
.inputBox >>> .el-input input:focus {
  outline: none;
}
.inputBox >>> .el-input__prefix {
  margin: 0 0 0 0.04rem;
}
.inputBox >>> .el-input__icon {
  line-height: 0.28rem;
}
.search-button {
  border: 1px solid transparent;
}
.search-button:hover {
  /* border: 1px solid #FF7915; */
  /* border-radius: 30px;
  display: flex;
  align-items: center; */
}

.search {
  width: 0.63rem;
  height: 0.3rem;
  line-height: 0.3rem;
  position: absolute;
  top: 1px;
  right: 0rem;
  color: #fff;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  background: #ff7915;
  border-radius: 0.2rem;
}
.search:hover {
  background: #ff872b;
}
.bottomBox {
  width: 0.5rem;
  height: 0.5rem;
  position: absolute;
  bottom: 0rem;
  left: 50%;
  transform: translateX(-50%);
  z-index: 2;
}
.toBottom {
  width: 0.14rem;
  height: 0.36rem;
  position: absolute;
  bottom: 0.1rem;
  left: 50%;
  transform: translateX(-50%);
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/toBottom.png");
  background-size: 100%;
  animation: toBottom-run 1.5s linear infinite;
}
@keyframes toBottom-run {
  0% {
    bottom: 0.1rem;
  }
  50% {
    bottom: 0.2rem;
  }
  100% {
    bottom: 0.1rem;
  }
}
</style>
