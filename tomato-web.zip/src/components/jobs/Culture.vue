<!--
 * @Author: your name
 * @Date: 2021-03-23 17:26:20
 * @LastEditTime: 2021-05-27 14:09:43
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\jobs\Cutrure.vue
-->
<template>
  <div class="culture">
    <!-- Swiper -->
    <div class="swiper-container swiper-container_1">
      <div class="swiper-wrapper">
        <div
          class="swiper-slide"
          :class="['slide0' + item.id, { active: active }]"
          v-for="item in $t('y.culture.pageList')"
          :key="item.id"
          :style="{
            zIndex: pageIndex + 1 == item.id ? 2000 : -1,
            opacity: pageIndex + 1 == item.id ? 1 : 0
          }"
        >
          <span class="page">0{{ item.id }}</span>
          <span class="left_bottom"></span>
          <span
            class="right_top"
            :style="{
              backgroundImage:
                'url(https://wcdn.tomatogames.com/web/haiwai/tomato/img/page0' +
                item.id +
                '_r.png)',
              backgroundSize: '100%'
            }"
          ></span>
          <div class="center">
            <h2>{{ item.title }}</h2>
            <i class="hr"></i>
            <p>{{ item.content1 }}</p>
            <br />
            <p>{{ item.content2 }}</p>
            <div class="dots">
              <span :class="{ active: pageIndex == 0 }"></span>
              <span :class="{ active: pageIndex == 1 }"></span>
              <span :class="{ active: pageIndex == 2 }"></span>
            </div>
            <div class="toRight" @click="nextPage">
              <i class="el-icon-arrow-right"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="pagination">
      <span class="pag01" :class="{ active: pageIndex == 0 }">01</span>
      <span class="pag02" :class="{ active: pageIndex == 1 }">02</span>
      <span class="pag03" :class="{ active: pageIndex == 2 }">03</span>
    </div>
  </div>
</template>
<script>
import Swiper from "swiper";
import "swiper/dist/css/swiper.css";
export default {
  name: "Culture",
  data() {
    return {
      swiper: null,
      pageIndex: 0,
      // 轮播图动效
      active: false,
      timer: null,
      timer1:null,
    };
  },
  methods: {
    createSwiper() {
      let that = this;
      this.swiper = new Swiper(".swiper-container_1", {
        observer: true, //修改swiper自己或子元素时，自动初始化swiper
        observeParents: true, //修改swiper的父元素时，自动初始化swiper
        loop: true,
        speed: 300,
        // allowTouchMove: false,
        effect: "fade",

        pagination: {
          el: ".swiper-pagination"
        },
        on: {
          slideChangeTransitionStart: function() {
            that.pageIndex = this.realIndex;
          },
          slideChangeTransitionEnd() {},

          tap: function(e) {
            let name = e.target.className;
            console.log("tap" + name);
            if (name == "toRight" || name == "el-icon-arrow-right") {
              that.nextPage();
            }
          }
        }
      });
    },
    nextPage() {
      if (this.timer) {
        clearInterval(this.timer);
      }
      if (this.timer1) {
        clearInterval(this.timer1);
      }
      this.active = true;
      this.timer = setTimeout(() => {
        this.pageIndex = this.pageIndex == 2 ? 0 : ++this.pageIndex;
      }, 1000);
       this.timer1 = setTimeout(() => {
        this.active = false;
      }, 1120);
    }
  },
  mounted() {
    // this.createSwiper();
  }
};
</script>
<style scoped>
.culture {
  width: 100%;
  height: 5.2rem;
  position: relative;
  text-align: left;
}
.swiper-container_1 {
  width: 100%;
  height: 100%;
}
.swiper-container_1 .swiper-wrapper {
  position: relative;
}
.swiper-container_1 .swiper-slide {
  position: absolute;
  top: 0;
  left: 0;
  background: #fff;
  background-position: center;
  background-size: cover;
  pointer-events: auto;
  transition: all 1s;
}

.swiper-slide .page {
  display: inline;
  margin: 0.15rem 0 0 0.63rem;
  font-size: 0.74rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #fafafa;
}
.swiper-slide .left_bottom {
  width: 5.46rem;
  height: 3.96rem;
  position: absolute;
  bottom: 0;
  left: 0.63rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/page01_l.png");
  background-size: 100%;
  z-index: 2;
}
.swiper-slide .right_top {
  width: 5.24rem;
  height: 4.7rem;
  position: absolute;
  top: 0;
  right: 0;
  transition: all 1s;
}
.slide02 .right_top {
  background-position: -0.7rem -0.5rem;
  background-size: 150% !important;
}
.slide03 .right_top {
  background-position: -0.5rem 0rem;
  background-size: 110% !important;
}
.center {
  width: 3.49rem;
  height: 2.34rem;
  position: absolute;
  top: 0.8rem;
  left: 2.6rem;
  background: #f9f9f9;
  z-index: 3;
  overflow: hidden;
  transition: opacity 0.5s, width 1s;
}
.active .center {
  width: 0rem;
  opacity: 0;
}
.center h2 {
  width: 2.64rem;
  margin: 0.45rem 0 0 0.44rem;
  font-size: 0.26rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.center .hr {
  width: 2.64rem;
  height: 0.000001rem;
  display: block;
  margin: 0.23rem 0 0 0.44rem;
  border-bottom: 0.00001rem solid #666666;
}
.center p {
  width: 2.59rem;
  margin: 0.24rem 0 0 0.44rem;
  font-size: 0.09rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.17rem;
}
.en .center p {
  width: 2.54rem;
  font-family: Arial;
}
.center p:nth-of-type(2) {
  margin-top: -0.07rem;
}
.dots {
  position: absolute;
  bottom: 0.44rem;
  left: 0.44rem;
}
.dots span {
  width: 0.02rem;
  height: 0.02rem;
  display: block;
  float: left;
  margin: 0 0.1rem 0 0;
  background: #999999;
  border-radius: 100%;
}
.dots span.active {
  background: #ff7915;
}
.toRight {
  width: 0.2rem;
  height: 0.2rem;
  line-height: 0.2rem;
  position: absolute;
  bottom: 0.35rem;
  right: 0.46rem;
  text-align: center;
  background: #ff7915;
  border-radius: 50%;
  cursor: pointer;
}
.toRight:hover {
  background-color: #ff872b;
}

.toRight i {
  vertical-align: top;
  line-height: 0.21rem;
  color: #fff;
  font-weight: bolder;
  font-size: 0.1rem;
}

.pagination {
  position: absolute;
  bottom: 0.21rem;
  right: 0.63rem;
  z-index: 2;
}
.pagination span {
  margin: 0 0 0 0.12rem;
  font-size: 0.06rem;
  font-family: Microsoft YaHei;
  color: #333333;
  font-weight: 400;
  transition: all 0.2s;
}
.pagination span.active {
  font-weight: bolder;
}
.pagination span::before {
  content: "";
  display: inline-block;
  width: 0rem;
  height: 0.00001rem;
  position: relative;
  bottom: 0.02rem;
  right: 0.055rem;
  border-top: 0.00001rem solid #333;
  transition: all 0.2s;
}
.pagination span.active::before {
  width: 0.3rem;
}
</style>
