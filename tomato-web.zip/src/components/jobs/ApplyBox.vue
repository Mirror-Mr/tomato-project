<!--
 * @Author: your name
 * @Date: 2021-03-02 18:15:13
 * @LastEditTime: 2021-05-28 18:37:58
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\Mask.vue
-->
<template>
  <div
    class="applyBox"
    :style="{ display: isShow && show ? 'block' : 'none' }"
    :class="{ isIP: isIP }"
  >
    <div class="box">
      <!-- {{ applyMsg }} -->
      <a href="#" class="close" @click.prevent="close"
        ><i class="el-icon-close"></i
      ></a>
      <span class="post-title">{{ post_title }}</span>
      <div class="form">
        <div class="name" :class="{ err: nameNone }">
          <span class="theme">{{ $t("y.applyBox.name[0]") }} :</span>
          <input
            type="text"
            v-model="applyMsg.name"
            :placeholder="$t('y.applyBox.name[1]')"
          />
        </div>
        <div class="sex" @click="chooseSex">
          <span class="theme">{{ $t("y.applyBox.sex[0]") }} :</span>
          <span class="man" :class="{ choose: applyMsg.sex == 'man' }">
            {{ $t("y.applyBox.sex[1]") }}</span
          >
          <span class="woman" :class="{ choose: applyMsg.sex == 'woman' }">
            {{ $t("y.applyBox.sex[2]") }}</span
          >
        </div>
        <div class="phone" :class="{ err: phoneNone }">
          <span class="theme">{{ $t("y.applyBox.phone[0]") }} :</span>
          <input
            type="text"
            :placeholder="$t('y.applyBox.phone[1]')"
            v-model="applyMsg.phone"
          />
        </div>
        <div class="code" :class="{ err: codeNone }">
          <span class="theme"> {{ $t("y.applyBox.code[0]") }} :</span>
          <input
            type="number"
            oninput="if(value.length>6)value=value.slice(0,6)"
            :placeholder="$t('y.applyBox.code[1]')"
            v-model="applyMsg.code"
          />
          <template v-if="codeTime == 0">
            <span class="getCode" @click="getCode">{{
              $t("y.applyBox.code[2]")
            }}</span>
          </template>
          <template v-else>
            <span class="getCode delNum"> {{ codeTime }}s </span>
          </template>
        </div>
        <div class="email" :class="{ err: emailNone }">
          <span class="theme"> {{ $t("y.applyBox.email[0]") }} :</span>
          <input
            type="text"
            :placeholder="$t('y.applyBox.email[1]')"
            v-model="applyMsg.email"
          />
        </div>
        <div class="resume" :class="{ err: resumeNone }">
          <span class="theme">{{ $t("y.applyBox.resume[0]") }} :</span>
          <input type="text" v-model="fileName" />

          <span class="look" @click="showResume">{{
            $t("y.applyBox.resume[1]")
          }}</span>
          <span class="tag">{{ $t("y.applyBox.resume[2]") }}</span>
        </div>
      </div>
      <a href="#" class="submit" @click.prevent="sendMsg()">{{
        $t("y.applyBox.sendApply")
      }}</a>
      <el-upload
        class="upload-demo"
        style="display:none"
        :action="
          'https://hw.xianyuyouxi.com/service/Tomato_webhome/uploadFile?time=' +
            this.timer
        "
        accept=".pdf,.doc,.zip,.docx"
        :on-change="fileChange"
        :on-success="fileSuccess"
        :data="fileData"
        :headers="headers"
      >
        <el-button size="small" type="primary" class="chooseFile"
          >点击上传</el-button
        >
      </el-upload>
    </div>
  </div>
</template>
<script>
export default {
  name: "ApplyBox",
  props: {
    // 该框是否显示
    isShow: {
      type: Boolean,
      required: true
    },
    // 职位名称
    post_title: {
      type: String,
      required: true
    },
    job_id: {
      type: String,
      required: true
    },
    // 是否是手机端
    isIP: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      applyMsg: {
        name: "",
        sex: "",
        phone: "",
        code: "",
        email: "",
        resume: ""
      },
      timer: parseInt(Date.parse(new Date()) / 1000),
      show: true,
      fileName: "",
      key: "0391591aafc5db68b08787645b837b4f",
      nameNone: false,
      phoneNone: false,
      codeNone: false,
      emailNone: false,
      resumeNone: false,
      codeTime: 0
    };
  },
  computed: {
    fileData: function() {
      return {
        timer: this.timer
      };
    },
    headers: function() {
      return {
        "Access-s": this.$md5(`${this.key}${this.timer}`)
      };
    },
    area: function() {
      return localStorage.getItem("isEn") == "true" ? 0 : 1;
    }
  },
  methods: {
    sendMsg() {
      let msg = this.applyMsg;
      if (!msg.name) {
        this.nameNone = true;
        return;
      } else if (!msg.phone) {
        this.phoneNone = true;
        return;
      } else if (!msg.code) {
        this.codeNone = true;
        return;
      } else if (!msg.email) {
        this.emailNone = true;
        return;
      } else if (!msg.resume) {
        this.resumeNone = true;
        return;
      }
      console.log("msg:");
      console.log(this.applyMsg);
      console.log("area:" + this.area);
      console.log("jobId:" + this.job_id);
      console.log("key:" + this.key);
      // 发送职位申请
      this.$axios({
        method: "post",
        url: "http://hw.xianyuyouxi.com/service/Tomato_webhome/sub_apply",
        headers: {
          "Access-s": this.$md5(
            `${this.key}${this.timer}${this.area}${this.applyMsg.name}${this.job_id}`
          )
        },
        data: {
          time: this.timer,
          area: this.area,
          job_id: this.job_id,
          name: this.applyMsg.name,
          phone: this.applyMsg.phone,
          email: this.applyMsg.email,
          code: this.applyMsg.code,
          url: this.applyMsg.resume,
          flag: 0
        }
      }).then(res => {
        console.log(res.data);
        // 出错
        if (res.data.code != 1) {
          this.$message.error(res.data.msg);
        } else {
          this.$message.success("申请已发送~");
        }
      });
    },
    close() {
      this.show = false;
      this.$emit("close", false);
      (this.applyMsg = {
        name: "",
        sex: "",
        phone: "",
        code: "",
        email: "",
        resume: ""
      }),
        (this.show = true);
    },
    // 获取验证码
    getCode() {
      if (!this.applyMsg.phone) {
        this.phoneNone = true;
        return;
      }
      this.$axios({
        method: "get",
        url: "http://hw.xianyuyouxi.com/service/Tomato_webhome/sendCode",
        headers: {
          "Access-s": this.$md5(
            `${this.key}${this.timer}${this.applyMsg.phone}`
          )
        },
        params: {
          time: this.timer,
          phone: this.applyMsg.phone
        }
      }).then(res => {
        console.log(res.data);
        if (res.data.code == "1") {
          //发送成功
          this.$message.success("验证码已发送~")
          this.codeTime = 180;
          let time = setInterval(() => {
            this.codeTime--;
            if (this.codeTime == 0) {
              clearInterval(time);
            }
          }, 1000);
        } else {
          this.phoneNone = true;
        }
        // this.filterCondition = res.data.data;
      });
    },
    // 浏览简历文件
    showResume() {
      document.getElementsByClassName("chooseFile")[0].click();
    },
    // 选择性别
    chooseSex(e) {
      if (e.target.className == "man" || e.target.className == "woman") {
        this.applyMsg.sex = e.target.className;
      }
    },
    // 选择文件时获取文件名
    fileChange(file) {
      this.fileName = file.name;
    },
    // 文件上传成功
    fileSuccess(res, file) {
      if (res.msg == "success") {
        this.applyMsg.resume = res.data;
      } else {
        this.$message.error("文件上传失败");
      }
      // console.log(this.applyMsg)
    }
  },
  mounted() {},
  watch: {
    applyMsg: {
      handler(newValue) {
        if (newValue.name) {
          this.nameNone = false;
        }
        if (newValue.phone) {
          this.phoneNone = false;
        }
        if (newValue.code) {
          this.codeNone = false;
        }
        if (newValue.email) {
          this.emailNone = false;
        }
        if (newValue.resume) {
          this.resumeNone = false;
        }
      },
      // 对对象内部深度监听
      deep: true
    }
  }
};
</script>
<style scoped>
/* 主框+背景 */
.applyBox {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 102;
}
/* 展示内容主体框 */
.box {
  width: 3.28rem;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: #ffffff;
  border-radius: 0.1rem;
}
.isIP .box {
  width: 9.36rem;
  border-radius: 0.3rem;
}
.close {
  position: absolute;
  top: 0.13rem;
  right: 0.13rem;
  color: #ddd;
}
.isIP .close {
  width: 0.5rem;
  height: 0.5rem;
  top: 0.4rem;
  right: 0.36rem;
}
.isIP .close >>> .el-icon-close{
  vertical-align: top;
}
.close i {
  font-size: 0.15rem;
}
.isIP .close i {
  font-size: 0.5rem;
}
.post-title {
  display: block;
  padding: 0.2rem 0;
  font-size: 0.16rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
  line-height: 0.13rem;
  border-bottom: 0.001rem solid #ddd;
}
.isIP .post-title {
  font-size: 0.45rem;
  line-height: 0.9rem;
}

/* 表单内容 */
.form {
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.15rem;
  text-align: left;
}
.isIP .form {
  font-size: 0.32rem;
  line-height: 0.38rem;
}
/* 表单每个选项 */
.form div {
  margin: 0 0 0 0.2rem;
}
.isIP .form div {
  margin: 0 0 0 1rem;
}
/* 每个选项的种类 */
.form .theme {
  width: 0.5rem;
  text-align: right;
}

.isIP .form .theme {
  width: 1.5rem;
}

.form input {
  width: 1.67rem;
  height: 0.21rem;
  padding: 0 0 0 0.18rem;
  margin: 0.16rem 0 0 0.1rem;
  background: #f8f8f8;
  border: none;
  border-radius: 0.1rem;
  border: 0.01rem solid transparent;
}
input:focus {
  outline: none;
  border: 0.01rem solid #ff7915;
}
.isIP .form input {
  width: 5.33rem;
  height: 0.77rem;
  margin: 0.43rem 0 0 0.2rem;
  padding: 0 0 0 0.35rem;
  border-radius: 0.5rem;
  font-size: 0.3rem;
}
.form .name input {
  /* margin: 0.43rem 0 0 0.1rem; */
}
.isIP .form .email input {
  margin: 0.23rem 0 0 0.2rem;
}
.en .form .sex {
  display: none;
}
.form .sex span:not(:nth-of-type(1)) {
  width: 0.45rem;
  height: 0.21rem;
  margin: 0.16rem 0 0 0.1rem;
  line-height: 0.2rem;
  text-align: center;
  color: #999;
  background: #f8f8f8;
  border-radius: 0.1rem;
  cursor: pointer;
}
.isIP .form .sex span:not(:nth-of-type(1)) {
  width: 1.4rem;
  height: 0.77rem;
  margin: 0.44rem 0 0 0.2rem;
  line-height: 0.77rem;
  border-radius: 0.4rem;
}
.form .sex span:not(:nth-of-type(1)).choose {
  color: #fff;
  background: #ff7915;
}
.en .form .code {
  display: none;
}

.getCode {
  margin: 0 0 0 0.05rem;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ff7915;
  line-height: 0.15rem;
  cursor: pointer;
}
.isIP .getCode {
  font-size: 0.27rem;
  margin: 0.2rem 0 0 2.1rem;
}
.delNum {
  margin: 0 0 0 0.25rem;
}
.resume {
  position: relative;
}
.resume input {
  width: 2.22rem;
}

.resume .look {
  width: 0.58rem;
  height: 0.21rem;
  line-height: 0.2rem;
  position: absolute;
  top: 0.16rem;
  right: 0.25rem;
  color: #666666;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  background: #e8e8e8;
  border-radius: 0.1rem;
  text-align: center;
  cursor: pointer;
}
.isIP .resume .look {
  width: 1.61rem;
  height: 0.77rem;
  line-height: 0.77rem;
  font-size: 0.32rem;
  color: #333333;
  top: 0.42rem;
  right: 1.3rem;
  border-radius: 0.5rem;
}
.resume .tag {
  margin: 0.05rem 0 0 0.6rem;
  font-size: 0.07rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #d4d4d4;
  line-height: 0.15rem;
}
.isIP .resume .tag {
  width: 5.4rem;
  line-height: 0.5rem;
  font-size: 0.21rem;
  color: #e1e1e1;
  margin: 0.16rem 0 0.68rem 1.85rem;
}
.submit {
  width: 0.81rem;
  height: 0.2rem;
  line-height: 0.2rem;
  margin: 0.15rem auto 0.2rem;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
  background: #ff7915;
  border-radius: 0.1rem;
}
.isIP .submit {
  width: 7.03rem;
  height: 0.77rem;
  margin: 0 0 0.56rem 0;
  font-size: 0.32rem;
  line-height: 0.77rem;
  border-radius: 0.4rem;
}
/* 提交申请验证 */
.name,
.phone,
.code,
.email,
.resume {
  position: relative;
}
.err input {
  border: 0.001rem solid red;
}
.name.err::after {
  content: "请输入姓名";
  position: absolute;
  top: 0.385rem;
  left: 0.78rem;
  color: red;
}
.isIP .name.err::after {
  top: 1.2rem;
  left: 2.1rem;
  font-size: 0.27rem;
}
.phone.err::after {
  content: "请输入正确的手机号";
  position: absolute;
  top: 0.375rem;
  left: 0.78rem;
  color: red;
}
.isIP .phone.err::after {
  top: 1.21rem;
  left: 2.1rem;
  font-size: 0.27rem;
}
.code.err::after {
  content: "请输入验证码";
  position: absolute;
  top: 0.375rem;
  left: 0.78rem;
  color: red;
}
.isIP .code.err::after {
  top: 1.26rem;
  left: 5rem;
  font-size: 0.27rem;
}
.email.err::after {
  content: "请输入正确的邮箱号";
  position: absolute;
  top: 0.375rem;
  left: 0.78rem;
  color: red;
}
.isIP .email.err::after {
  top: 1.03rem;
  left: 2.1rem;
  font-size: 0.27rem;
}
.resume.err::after {
  content: "请选择要上传的文件";
  position: absolute;
  top: 0.375rem;
  left: 0.78rem;
  color: red;
}
.isIP .resume.err::after {
  top: 1.21rem;
  left: 2.1rem;
  font-size: 0.27rem;
}
</style>
