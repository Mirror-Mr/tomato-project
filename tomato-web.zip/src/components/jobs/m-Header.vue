<!--
 * @Author: your name
 * @Date: 2021-02-23 10:57:53
 * @LastEditTime: 2021-05-25 11:03:49
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\HelloWorld.vue
-->
<template>
  <div
    class="header"
    :class="{ post: !home }"
    :style="{ backgroundColor: home ? '' : '#fff',position:home?'absolute':'fixed' }"
  >
    <template v-if="home">
      <img :src="$t('x.logo')" alt="logo" class="logo" />
      <img class="tag" :src="$t('y.header.tag')" />
    </template>
    <template v-else>
      <img class="logo" :src="$t('x.clogo')" alt="logo" />
      <span
        class="tag"
        :style="{
          backgroundImage: 'url(' + $t('y.header.ctag') + ')',
          backgroundSize: '100%'
        }"
      ></span>
    </template>

    <!-- 中英文切换 -->
    <!-- <el-dropdown trigger="click" @command="handleCommand">
      <span class="el-dropdown-link">
        {{ $t("x.header.currentLang")
        }}<i class="el-icon-arrow-down el-icon--right"></i>
      </span>
      <el-dropdown-menu slot="dropdown" class="menu">
        <el-dropdown-item command="c">{{
          $t("x.header.lang[0]")
        }}</el-dropdown-item>
        <el-dropdown-item command="e">{{
          $t("x.header.lang[1]")
        }}</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown> -->
    <!-- 展开导航栏标志 -->
    <div class="spread" @click="spreadNav">
      <i></i>
      <i></i>
      <i></i>
    </div>
    <div class="navBox" :class="{ noSpread: isSpread }">
      <span class="close" @click="spreadNav">
        <i class="el-icon-close"></i>
      </span>
      <ul class="nav">
        <li>
          <template v-if="campus">
            <router-link :to="{ name: 'MEmploy', query: { campus: true } }">{{
              $t("y.header.nav[0]")
            }}</router-link>
          </template>
          <template v-else>
            <router-link :to="{ name: 'MEmploy', query: { campus: false } }">{{
              $t("y.header.nav[0]")
            }}</router-link>
          </template>
        </li>
        <li>
          <router-link :to="{name:'MAllPost',query:{campus:campus}}">{{ $t("y.header.nav[1]") }}</router-link>
        </li>
        <li>
          <router-link to="/m/games">{{ $t("y.header.nav[2]") }}</router-link>
        </li>
        <!-- <li>
          <a href="#" @click.prevent="toContact">{{ $t("x.header.nav[3]") }}</a>
        </li> -->
        <li>
          <template v-if="campus">
            <router-link :to="{ name: 'MEmploy', query: { campus: false } }">{{
              $t("y.header.nav[4]")
            }}</router-link>
          </template>
          <template v-else>
            <router-link :to="{ name: 'MEmploy', query: { campus: true } }">{{
              $t("y.header.nav[3]")
            }}</router-link>
          </template>
        </li>
      </ul>
    </div>

  </div>
</template>

<script>

export default {
  name: "Header",
  components: {
    // MMaskBox
  },
  props: {
    home: {
      type: Boolean,
      default: false
    },
    campus: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      isShow: false,
      isSpread: false
    };
  },
  methods: {
    handleCommand(command) {
      if (command == "c") {
        this.$i18n.locale = "zh-CN"; // 切换成中文
        localStorage.setItem("isEn", false);
      } else {
        this.$i18n.locale = "en-US"; // 切换成英文
        localStorage.setItem("isEn", true);
      }
      location.reload();
    },

    closeMask(show) {
      this.isShow = show;
    },
    // 展开导航栏
    spreadNav() {
      this.isSpread = !this.isSpread;
    }
  },
  mounted() {},
  watch: {
    $route() {
      location.reload();
    }
  }
};
</script>
<style scoped>
.header {
  width: 100%;
  height: 1rem;
  position: fixed;
  top: 0;
  left: 0;
  /* background: #ff7a15; */
  padding-top: 0.01rem;
  z-index: 100;
}
.logo {
  width: 1.79rem;
  height: 0.51rem;
  display: block;
  margin: 0.2rem 0 0 0.32rem;
  float: left;
}
.tag {
  width: 0.76rem;
  height: 0.28rem;
  display: inline-block;
  float: left;
  margin: 0.3rem 0 0 0.1rem;
}
/* 下拉框 */
.el-dropdown {
  /* height: 100%; */
  margin: 0 0 0 0.45rem;
  line-height: 0.9rem;
  float: left;
}
.post .el-dropdown{
  line-height: 1rem;
}
.el-dropdown-link {
  font-size: 0.28rem;
  font-family: SourceHanSansCN;
  font-weight: 400;
  cursor: pointer;
  color: #fff;
}
.post .el-dropdown-link {
  color: #333;
}
.el-dropdown-menu {
  top: 0.5rem !important;
  left: 3.2rem !important;
  border-radius: 0.1rem;
  padding: 0;
}
.el-dropdown-menu__item {
  padding: 0.1rem 0.3rem;
  font-size: 0.27rem;
  font-family: SourceHanSansCN;
  font-weight: 400;
  line-height: 0.58rem;
  color: #ff7915;
  text-align: center;
}
.el-icon-arrow-down:before {
  content: "\25BC";
  font-size: 0.15rem;
  margin: 0 0 0 0.05rem;
}
.el-icon-arrow-down {
}
.menu >>> .popper__arrow,
.menu >>> .popper__arrow::after {
  display: none !important;
}
/* 展开导航栏标志 */
.spread {
  float: right;
  margin: 0.32rem 0.32rem 0 0;
}
.spread i {
  width: 0.27rem;
  height: 0.03rem;
  margin: 0 0 0.1rem 0;
  display: block;
  background: #ffffff;
}
.post .spread i {
  background: #492729;
}
/* 右侧导航 */
.navBox {
  width: 0;
  height: 0;
  position: absolute;
  top: 0;
  right: 0;
  background: #fff;
  border-radius: 0rem 0rem 0rem 2rem;
  opacity: 0;
  transition: all 0.3s;
}
.navBox.noSpread {
  width: 6.19rem;
  height: 8.33rem;
  opacity: 1;
}
.close {
  position: absolute;
  top: 0.2rem;
  right: 0.4rem;
  font-size: 0.5rem;
}
.nav {
  margin: 1.4rem 0 0 0;
  line-height: 1.07rem;
  font-size: 0.37rem;
  font-family: SourceHanSansCN;
  font-weight: 400;
  color: #333333;
}
.nav li {
}
.nav li a {
  position: relative;
}
.el-dropdown-menu__item {
  color: #ff7a15;
}
.el-dropdown-menu__item:focus,
.el-dropdown-menu__item:not(.is-disabled):hover {
  background: #ffe4d1;
  color: #ff7a15;
}
</style>
