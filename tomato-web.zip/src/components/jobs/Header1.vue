<!--
 * @Author: your name
 * @Date: 2021-03-22 11:27:33
 * @LastEditTime: 2021-05-25 11:03:31
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\jobs\Header.vue
-->
<template>
  <div class="jheader">
    <template v-if="campus">
      <router-link :to="{ name: 'Employ', query: { campus: true } }"
        ><img class="logo" :src="$t('x.clogo')" alt=""
      /></router-link>
    </template>
    <template v-else>
      <router-link :to="{ name: 'Employ', query: { campus: false } }"
        ><img class="logo" :src="$t('x.clogo')" alt=""
      /></router-link>
    </template>

    <span
      class="tag"
      :style="{
        backgroundImage: 'url(' + $t('y.header.ctag') + ')',
        backgroundSize: '100%'
      }"
    ></span>
    <!-- <el-dropdown trigger="click" @command="handleCommand">
      <span class="el-dropdown-link">
        {{ $t("x.header.currentLang")
        }}<i class="el-icon-caret-bottom el-icon--right"></i>
      </span>
      <el-dropdown-menu slot="dropdown" class="menu">
        <el-dropdown-item command="c">{{
          $t("x.header.lang[0]")
        }}</el-dropdown-item>
        <el-dropdown-item command="e">{{
          $t("x.header.lang[1]")
        }}</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown> -->
    <ul class="nav">
      <li>
        <template v-if="campus">
          <router-link :to="{ name: 'Employ', query: { campus: true } }">{{
            $t("y.header.nav[0]")
          }}</router-link>
        </template>
        <template v-else>
          <router-link :to="{ name: 'Employ', query: { campus: false } }">{{
            $t("y.header.nav[0]")
          }}</router-link>
        </template>
      </li>
      <li>
        <router-link :to="{ name: 'AllPost', query: { campus } }">{{ $t("y.header.nav[1]") }}</router-link>
      </li>
      <li>
        <router-link to="/games">{{ $t("y.header.nav[2]") }}</router-link>
      </li>
      <li>
        <template v-if="campus">
          <router-link
            target="_blank"
            :to="{ name: 'Employ', query: { campus: false } }"
            >{{ $t("y.header.nav[4]") }}</router-link
          >
        </template>
        <template v-else>
          <router-link
            target="_blank"
            :to="{ name: 'Employ', query: { campus: true } }"
            >{{ $t("y.header.nav[3]") }}</router-link
          >
        </template>
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  name: "JHeader",
  props: {
    campus: {
      type: Boolean,
      required: true
    }
  },
  methods: {
    handleCommand(command) {
      if (command == "c") {
        this.$i18n.locale = "zh-CN"; // 切换成中文
        localStorage.setItem("isEn", false);
      } else {
        this.$i18n.locale = "en-US"; // 切换成英文
        localStorage.setItem("isEn", true);
      }
      location.reload();
    }
  },
  // 监听路由
  watch: {
    $route() {
      location.reload();
    }
  },
};
</script>
<style scoped>
.jheader {
  width: 100%;
  height: 0.45rem;
  position: absolute;
  top: 0;
  left: 0;
  /* background: pink; */
  text-align: left;
  background: #fff;
  border: 0.001rem solid #eee;
}
.logo {
  width: 0.96rem;
  height: 0.27rem;
  display: inline-block;
  margin: 0.08rem 0 0 0.63rem;
}
.tag {
  width: 0.32rem;
  height: 0.115rem;
  display: inline-block;
  margin: 0.15rem 0 0 0.05rem;
  vertical-align: top;
}
/* 下拉框 */
.el-dropdown {
  height: 100%;
  margin: 0.16rem 0 0 0.36rem;
  vertical-align: top;
}
.el-dropdown-link {
  cursor: pointer;
  font-size: 0.1rem;
  font-family: SourceHanSansCN;
  font-weight: 400;
}
.el-dropdown-link i {
  font-size: 0.07rem;
}
.el-dropdown-menu {
  width: 0.63rem;
  top: 0.3rem !important;
  left: 2.24rem !important;
}
.el-dropdown-menu__item {
  width: 100%;
  height: 0.18rem;
  line-height: 0.18rem;
  padding: 0;
  font-size: 0.1rem;
  font-family: SourceHanSansCN;
  font-weight: 400;
  color: #ff7915;
  text-align: center;
}

.menu >>> .popper__arrow,
.menu >>> .popper__arrow::after {
  display: none !important;
}
.el-dropdown-menu__item {
  color: #ff7a15;
}
.el-dropdown-menu__item:focus,
.el-dropdown-menu__item:not(.is-disabled):hover {
  background: #ffe4d1;
  color: #ff7a15;
}
.nav {
  display: inline-block;
  margin: 0 0.62rem 0 0;
  float: right;
}
.nav li {
  margin: 0.16rem 0 0 0.35rem;

  float: left;
}
li a {
  color: #333333;
  font-size: 0.08rem;
  font-family: SourceHanSansCN;
  font-weight: 400;
  font-weight: bolder;
  transition: all 0.2s;
}
li:hover a {
  color: #ff7915;
}
</style>
