<!--
 * @Author: your name
 * @Date: 2021-03-23 20:15:13
 * @LastEditTime: 2021-05-12 18:22:46
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\jobs\Welfare.vue
-->
<template>
  <div class="welfare">
    <!-- 左边/上边 -->
    <div class="left">
      <h2>{{ $t("y.welfare.left.title") }}</h2>
      <p class="content content1">
        <span>{{ $t("y.welfare.left.content[0][0]") }}</span>
        <span>{{ $t("y.welfare.left.content[0][1]") }}</span>
      </p>
      <p class="content content2">
        <span>{{ $t("y.welfare.left.content[1][0]") }}</span>
        <span>{{ $t("y.welfare.left.content[1][1]") }}</span>
        <span>{{ $t("y.welfare.left.content[1][2]") }}</span>
      </p>
      <p class="content content3">
        <span>{{ $t("y.welfare.left.content[2][0]") }}</span>
        <span>{{ $t("y.welfare.left.content[2][1]") }}</span>
      </p>
    </div>
    <!-- 右边轮播图 -->
    <div class="right">
      <!-- Swiper -->
      <div class="swiper-container_3">
        <div class="swiper-wrapper">
          <div
            class="swiper-slide"
            v-for="item in $t('y.welfare.right.welfares')"
            :key="item.id"
          >
            <span
              class="pic"
              :class="'pic' + item.id"
              :style="{
                backgroundImage: 'url(' + item.pic + ')',
                backgroundSize: '100%'
              }"
            ></span>
            <span class="title">{{ item.title }}</span>
            <span class="specific">{{ item.specific }}</span>
          </div>
        </div>
      </div>
      <!-- 滚动条 -->
      <!-- <div class="line" :style="{ width: length + 'rem' }">
        <span
          class="slip"
          :style="{
            width: length / 9 + 'rem',
            left: index * (length / 9) + 'rem'
          }"
        ></span>
      </div>
      <div class="toLeft" @click="toLeft">
        <i class="el-icon-arrow-right"></i>
      </div> -->
    </div>
  </div>
</template>
<script>
import Swiper from "swiper";
import "swiper/dist/css/swiper.css";
export default {
  name: "Welfare",
  data() {
    return {
      swiper: null,
      // 底部滚动条整体长度
      length: 6.22,
      // 第几张图
      index: 0
    };
  },
  methods: {
    createSwiper() {
      let that = this;
      this.swiper = new Swiper(".swiper-container_3", {
        slidesPerView: "auto",
        // allowTouchMove: false,
        spaceBetween: 80,
        freeMode: true,
        loop: true,
        initialSlide :1,
        slidesOffsetBefore: 23,
        pagination: {
          el: ".swiper-pagination",
          clickable: true
        },
        on: {
          slideChangeTransitionStart: function() {
            that.index = this.realIndex;
          }
        }
      });
    },
    toLeft() {
      this.swiper.slideNext();
    }
  },
  mounted() {
    this.createSwiper();
  }
};
</script>
<style scoped>
.welfare {
  width: 100%;
  text-align: left;
  margin-bottom: 1rem;
}

.left {
  width: 100%;
  padding-top: 0.001rem;
  text-align: center;
}
.left h2 {
  margin: 0.95rem 0 0 0;
  font-size: 0.48rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
}
.en .left h2 {
  font-size: 0.67rem;
  font-family: Arial;
  font-weight: 900;
}
.content {
  width: 6.3rem;
  margin: 0.24rem auto 0;
  font-size: 0.37rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.7rem;
}
.en .content {
  width: 7.8rem;
  margin: 0.53rem auto 0;
  font-family: Arial;
  line-height: 0.6rem;
}
.content2 {
  margin-top: 0.8rem;
}
.content3 {
  margin-top: 0.8rem;
}

.right {
  width: 100%;
  position: relative;
  margin: 0.87rem 0 0 0;
}
.swiper-container_3 {
  width: 100%;
  /* height: 3.9rem; */
  /* border-bottom: 0.01rem solid #666; */
  overflow: hidden;
}

.swiper-container_3 .swiper-slide {
  width: 8.71rem;
  height: 8.38rem;
  position: relative;
  background: #fff;
  box-shadow: 0rem 0rem 0.1rem 0.05rem rgba(184, 184, 184, 0.18);
}

.en .swiper-container_3 .swiper-slide {
  width: 85%;
  height: 9.4rem;
}
.pic {
  width: 8.71rem;
  height: 4.15rem;
  display: block;
}
.pic1 {
  background-size: 100% !important;
}
.pic3 {
  background-size: 100% !important;
}
.pic4 {
  background-position: 0rem 7rem;
  background-size: 100% !important;
}
.pic6 {
  background-position: -0.08rem 0rem;
  background-size: 106% !important;
}
.pic7 {
  background-position: 0rem 0rem;
  background-size: 106% !important;
}
.pic8 {
  background-position: 0rem 0rem;
  background-size: 107% !important;
}
.title {
  width: 85%;
  display: block;
  margin: 0.64rem auto 0;
  padding-bottom: 0.3rem;
  font-size: 0.44rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  border-bottom: 0.01rem solid #666;
}
.en .title {
  font-family: Arial;
  font-weight: bold;
}
.specific {
  margin: 0.3rem 0 0 0.6rem;
  font-size: 0.39rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666666;
  line-height: 0.62rem;
}
.en .specific {
  font-family: Arial;

  color: #999999;
}
/* .line {
  height: 0.001rem;
  position: relative;
  display: inline-block;
  margin: 0.29rem 0 0 0.44rem;
  padding-top: 1px;
  border-bottom: 0.001rem solid #666666;
}
.slip {
  height: 0.02rem;
  position: absolute;
  top: -0.005rem;
  background: #ff7915;
  transition: all 0.4s;
}
.toLeft {
  width: 0.2rem;
  height: 0.2rem;
  vertical-align: top;
  margin: 0.18rem 0 0 0.18rem;
  display: inline-block;
  line-height: 0.2rem;
  text-align: center;
  font-size: 0.12rem;
  font-weight: bolder;
  color: #fff;
  background: #ff7915;
  border-radius: 50%;
  cursor: pointer;
}
.toLeft:hover {
  background-color: #ff872b;
} */
</style>
