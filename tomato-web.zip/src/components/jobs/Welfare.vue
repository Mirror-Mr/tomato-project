<!--
 * @Author: your name
 * @Date: 2021-03-23 20:15:13
 * @LastEditTime: 2021-06-10 10:55:13
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\jobs\Welfare.vue
-->
<template>
  <div class="welfare">
    <!-- 左边固定不动 -->
    <div class="left">
      <h2>{{ $t("y.welfare.left.title") }}</h2>
      <i class="hr"></i>
      <p class="content content1">
        <span>{{ $t("y.welfare.left.content[0][0]") }}</span>
        <span>{{ $t("y.welfare.left.content[0][1]") }}</span>
      </p>
      <p class="content content2">
        <span>{{ $t("y.welfare.left.content[1][0]") }}</span>
        <span>{{ $t("y.welfare.left.content[1][1]") }}</span>
        <span>{{ $t("y.welfare.left.content[1][2]") }}</span>
      </p>
      <p class="content content3">
        <span>{{ $t("y.welfare.left.content[2][0]") }}</span>
        <span>{{ $t("y.welfare.left.content[2][1]") }}</span>
      </p>
      <!-- 装饰的点点 -->
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
    <!-- 右边轮播图 -->
    <div class="right">
      <!-- Swiper -->
      <div class="swiper-container_3">
        <div
          class="swiper-wrapper"
          style="transform: translate3d(0.4rem, 0px, 0px);"
        >
          <div
            class="swiper-slide"
            v-for="item in $t('y.welfare.right.welfares')"
            :key="item.id"
          >
            <span class="title">{{ item.title }}</span>

            <img class="icon" :src="item.icon" />
            <span
              class="pic"
              :class="'pic' + item.id"
              :style="{
                backgroundImage: 'url(' + item.pic + ')',
                backgroundSize: '100%'
              }"
            ></span>

            <span class="specific">{{ item.specific }}</span>
          </div>
        </div>
      </div>
      <!-- 滚动条 -->
      <!-- <div class="line" :style="{ width: length + 'rem' }"> -->
      <!-- <span
          class="slip"
          :style="{
            width: length / 9 + 'rem',
            left: index * (length / 9) + 'rem',
          }"
        ></span> -->
      <!-- <div class="slip">
          <div class="arrow">
            <span class="arrow1"></span>
            <span class="arrow2"></span>
            <span class="arrow3"></span>
          </div>
        </div>
      </div> -->

      <div class="block">
        <span class="demonstration"></span>
        <el-slider v-model="value" :show-tooltip="false" @input="changeSlide">
        </el-slider>
        <div class="back" :style="{ left: left - 3.6 + '%' }">
          <div class="arrow">
            <span class="arrow1"></span>
            <span class="arrow2"></span>
            <span class="arrow3"></span>
          </div>
        </div>
      </div>
      <!-- {{ value }} -->
      <!-- <div class="toLeft" @click="toLeft">
        <i class="el-icon-arrow-right"></i>
      </div> -->
    </div>
  </div>
</template>
<script>
import Swiper from "swiper";
import "swiper/dist/css/swiper.css";
export default {
  name: "Welfare",
  data() {
    return {
      swiper: null,
      // 底部滚动条整体长度
      length: 6.22,
      // 第几张图
      index: 0,
      value: 0,
      left: 1,
      num: 0.4
    };
  },
  methods: {
    createSwiper() {
      let that = this;
      this.swiper = new Swiper(".swiper-container_3", {
        slidesPerView: "auto",
        allowTouchMove: false,
        // spaceBetween: 94,
        freeMode: true,
        mousewheel: true,
        // loop: true,
        // slidesOffsetBefore: 88,
        pagination: {
          el: ".swiper-pagination",
          clickable: true
        },
        on: {
          slideChangeTransitionStart: function() {
            that.index = this.realIndex;
          },
          progress: function(swiper, prrgress) {
            that.value = this.progress * 100;
          }
        }
      });
    },
    toLeft() {
      this.swiper.slideNext();
    },
    formatTooltip(val) {
      return val / 100;
    },
    changeSlide(val) {
      this.left = val;
      this.num = -1 * 21.8 * (val / 100);
      document
        .getElementsByClassName("swiper-container_3")[0]
        .getElementsByClassName("swiper-wrapper")[0].style.transform =
        "translate3d(" + this.num + "rem,0px,0px)";
    }
  },
  mounted() {
    this.createSwiper();
    
  }
};
</script>
<style scoped>
.welfare {
  width: 100%;
  height: 5.21rem;
  display: flex;
  text-align: left;
}
.left {
  width: 2.71rem;
  height: 100%;
  padding-top: 0.001rem;
  border-right: 0.001rem solid #666;
}
.left h2 {
  margin: 0.95rem 0 0 0.62rem;
  font-size: 0.26rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.left i {
  width: 1.7rem;
  height: 0.00001rem;
  display: block;
  margin: 0.23rem 0 0 0.61rem;
  border-top: 0.0001rem solid #666;
}
.content {
  margin: 0.24rem 0 0 0.61rem;
  font-size: 0.09rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.en .content {
  width: 1.66rem;
  font-family: Arial;
}
.dots {
  margin: 0.98rem 0 0 0.63rem;
}
.en .dots {
  margin: 0.4rem 0 0 0.63rem;
}
.dots span {
  width: 0.02rem;
  height: 0.02rem;
  border-radius: 50%;
  margin: 0 0.05rem 0 0;
}
.dots span:nth-of-type(1) {
  background: #ff7915;
}
.dots span:nth-of-type(2) {
  background: #d48850;
}
.dots span:nth-of-type(3) {
  background: #999999;
}
.right {
  width: 7.18rem;
  height: 100%;
  position: relative;
}
.swiper-container_3 {
  width: 100%;
  height: 4.1rem;
  border-bottom: 0.01rem solid #666;
  overflow: hidden;
}

.swiper-container_3 .swiper-slide {
  width: 2.78rem;
  position: relative;
  margin: 0 0.4rem 0 0;
}
.swiper-container_3 .swiper-slide:first-of-type {
  /* width: 2.78rem; */
  /* position: relative; */
  margin-left: 0.4rem;
}

.title {
  display: inline-block;
  position: absolute;
  top: 0.7rem;
  left: 0.01rem;
  padding-bottom: 0.1rem;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666666;
  border-bottom: 0.01rem solid #666;
}
.icon {
  width: 0.21rem;
  height: 0.21rem;
  position: absolute;
  top: 0.71rem;
  right: 0.01rem;
  vertical-align: top;
}
.pic {
  width: 2.78rem;
  height: 1.97rem;
  margin: 1.12rem 0 0 0;
  display: block;
}
.pic1 {
  background-size: 107% !important;
}
.pic3 {
  background-size: 107% !important;
}
.pic4 {
  background-position: 0rem -1.7rem;
  background-size: 100% !important;
}
.pic6 {
  background-position: -0.08rem 0rem;
  background-size: 106% !important;
}
.pic7 {
  background-position: -0.08rem 0rem;
  background-size: 106% !important;
}
.pic8 {
  background-position: -0.08rem 0rem;
  background-size: 107% !important;
}
.specific {
  margin: 0.15rem 0 0 0;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
  line-height: 0.23rem;
}
/* 拖动滑块 */
.right >>> .block {
  position: relative;
  width: 6.22rem;
  height: 0.3rem;
  margin: 0.29rem 0 0 0.44rem;
}
.right >>> .el-slider {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  line-height: 0.3rem;
}
.right >>> .el-slider__runway {
  /* width: 6.22rem; */
  height: auto;
  position: relative;
  display: inline-block;
  margin: 0;
  /* padding-top: 1px; */
  border-bottom: 0.02rem solid #eee;
}
.right >>> .el-slider__bar {
  opacity: 0;
}
.right >>> .el-slider__button-wrapper {
  width: auto;
  height: auto;
  top: -0.15rem;
  opacity: 0;
  z-index: 1001;
}
.right >>> .el-slider__button {
  width: 0.45rem;
  height: 0.261rem;
  background-image: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/slip_btn.png");
  background-size: 100%;
  background-color: transparent;
  /* transition: all 0.4s; */
  border: none;
  border-radius: 0;
  cursor: pointer;
}
.right .back {
  width: 0.45rem;
  height: 0.261rem;
  position: absolute;
  top: -0.01rem;
  left: 0rem;
  background-image: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/slip_btn.png");
  background-size: 100%;
  background-color: transparent;
  /* transition: all 0.4s; */
  border: none;
  border-radius: 0;
}
.right >>> .el-slider__button:hover,
.right >>> .el-slider__button.dragging {
  transform: none;
}
.arrow {
  width: 0.22rem;
  height: 0.2rem;
  line-height: 0.2rem;
  position: absolute;
  top: 0.069rem;
  left: 0.24rem;
  text-align: center;
}
.arrow span {
  width: 0.047rem;
  height: 0.07rem;
  background-image: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/arrow.png");
  background-size: 100%;
}
.arrow1 {
  animation: arrow-run 1s infinite;
}
.arrow2 {
  animation: arrow-run 1s infinite;
  animation-delay: 0.1s;
}
.arrow3 {
  animation: arrow-run 1s infinite;
  animation-delay: 0.2s;
}
@keyframes arrow-run {
  0% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
.toLeft {
  width: 0.2rem;
  height: 0.2rem;
  vertical-align: top;
  margin: 0.18rem 0 0 0.18rem;
  display: inline-block;
  line-height: 0.2rem;
  text-align: center;
  font-size: 0.12rem;
  font-weight: bolder;
  color: #fff;
  background: #ff7915;
  border-radius: 50%;
  cursor: pointer;
}
.toLeft:hover {
  background-color: #ff872b;
}
</style>
