<!--
 * @Author: your name
 * @Date: 2021-03-01 16:34:40
 * @LastEditTime: 2021-05-18 10:54:04
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\NewsPItem.vue
-->
<template>
  <div
    class="newsPageItem"
    shadow="hover"
    @click="showNews"
    :class="{ special: special }"
  >
    <div class="image">
      <span
        :style="{
          backgroundImage: 'url(' + news.icon + ')',
          backgroundSize: '100%'
        }"
      ></span>
    </div>
    <div class="content">
      <div class="top">
        <h2>{{ news.title }}</h2>
        <span class="desc">{{ news.desc }}</span>
      </div>
      <div class="bottom">
        <span class="time" :class="{ type: news.type == 1 }">{{
          news.start_time
        }}</span>
        <template v-if="!special">
          <Share :news="news" />
        </template>
      </div>
    </div>
  </div>
</template>
<script>
import Share from "@/components/Share.vue";
export default {
  name: "newsPageItem",
  components: {
    Share
  },
  props: {
    news: {
      type: Object,
      required: true
    },
    special: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      scrollTop: 0,

      key: "0391591aafc5db68b08787645b837b4f",
      // 时间戳
      timer: parseInt(Date.parse(new Date()) / 1000)
    };
  },
  methods: {
    showNews() {
      // 将id和type传递给下一个新闻详情页
      this.$router.push({
        name: "SingleNews",
        query: {
          id: this.news.id,
          type: this.news.type
        }
      });

      // let timer = setInterval(()=>{
      //   let speed = Math.floor(-that.scrollTop/5);
      //   document.documentElement.scrollTop = document.body.scrollTop = that.scrollTop + speed;
      //   if(that.scrollTop === 0){
      //     clearInterval(timer)
      //   }
      // })
    },
    // 监听滚动条
    handleScroll(e) {
      this.scrollTop =
        e.target.documentElement.scrollTop || e.target.body.scrollTop;
    }
  },
  computed: {
    area: function() {
      return localStorage.getItem("isEn") == "true" ? 0 : 1;
    }
  },

  watch: {
    $route() {
      location.reload();
    },
    news() {
      this.news.start_time = this.news.start_time.replace(/-/g, "/");
    }
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true);
    // console.log(this.news)
  },
  destroyed() {
    window.removeEventListener("scroll", this.handleScroll);
  }
};
</script>
<style scoped>
.newsPageItem {
  width: 6.43rem;
  height: 1.88rem;
  position: relative;
  margin: 0 auto;
  cursor: pointer;
  border-radius: 0.02rem;
}
.newsPageItem.special {
  height: 1.7rem;
}
.newsPageItem:hover {
  background: #f8f8f8;
}
.newsPageItem.special:hover {
  background: none;
}

.newsPageItem:hover .image span {
  transform: scale(1.05);
}

.image {
  width: 2.19rem;
  height: 1.21rem;
  margin: 0.33rem 0 0 0.24rem;
  border-radius: 0.03rem;
  float: left;
  overflow: hidden;
}
.special .image {
  margin: 0.15rem 0 0 0rem;
}
.image span {
  width: 100%;
  height: 100%;
  transition: all 0.5s;
}

/* 右侧内容区域 */
.content {
  width: 3.6rem;
  margin: 0.4rem 0 0 0.2rem;
  text-align: left;
  float: left;
}
.special .content {
  margin: 0.2rem 0 0 0.2rem;
}
/* 右侧上部 */
.top {
}
h2 {
  width: 3.51rem;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ff7915;
  line-height: 0.18rem;
  /* 关键代码 ！！！！ 以下5行 */
  overflow: hidden;
  /* 超出部分设为... */
  text-overflow: ellipsis;
  /* 盒子模型 */
  display: -webkit-box;
  /* 最多2行文本 多余部分隐藏*/
  -webkit-line-clamp: 2;
  /* 从顶部向底部垂直布置子元素 */
  -webkit-box-orient: vertical;
}

.desc {
  width: 3.51rem;
  margin: 0.1rem 0 0 0;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666;
  line-height: 0.17rem;
  /* 关键代码 ！！！！ 以下5行 */
  overflow: hidden;
  /* 超出部分设为... */
  text-overflow: ellipsis;
  /* 盒子模型 */
  display: -webkit-box;
  /* 最多2行文本 多余部分隐藏*/
  -webkit-line-clamp: 4;
  /* 从顶部向底部垂直布置子元素 */
  -webkit-box-orient: vertical;
}

.time {
  /* width: 0.54rem; */
  height: 0.13rem;
  padding: 0 0.05rem;
  margin: 0.12rem 0 0 0;
  text-align: center;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  line-height: 0.13rem;
  color: #fa5f00;
  background: #ffd7b6;
  border-radius: 0.03rem;
}
/* .time.type {
  color: #0076fb;
  background: #b8e3ff;
} */
</style>
