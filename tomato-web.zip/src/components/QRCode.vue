<!--
 * @Author: your name
 * @Date: 2021-03-25 11:49:01
 * @LastEditTime: 2021-06-10 19:29:27
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\QRCode.vue
-->
<template>
  <div class="qrcode">
    <el-popover placement="top-start" trigger="hover" popper-class="wechat ">
      <img
        src="https://wcdn.tomatogames.com/web/haiwai/tomato/img/wx_code.jpg"
        alt=""
      />
      <span>{{ $t("x.footer.icon[0]") }}</span>
      <el-button slot="reference" class=""
        ><span class="wechatIcon" href="#"></span
      ></el-button>
    </el-popover>
    <el-popover placement="top-start" trigger="hover" popper-class="weibo ">
      <img
        src="https://wcdn.tomatogames.com/web/haiwai/tomato/img/wb_code.png"
        alt=""
      />
      <span>{{ $t("x.footer.icon[1]") }}</span>
      <el-button slot="reference"
        ><span href="#" class="weiboIcon"></span
      ></el-button>
    </el-popover>
    <el-popover placement="top-start" trigger="hover" popper-class="qq ">
      <template v-if="type">
        <img
          class="qqs"
          src="https://wcdn.tomatogames.com/web/haiwai/tomato/img/qqs_code.png"
          alt=""
        />
        <span>{{ $t("x.footer.icon[3]") }}</span>
      </template>
      <template v-else>
        <img
          class="qq"
          src="https://wcdn.tomatogames.com/web/haiwai/tomato/img/qq_code.png"
          alt=""
        />
        <span>{{ $t("x.footer.icon[2]") }}</span>
      </template>

      <el-button slot="reference"
        ><span href="#" class="qqIcon"></span
      ></el-button>
    </el-popover>
  </div>
</template>
<script>
export default {
  name: "QRCode",
  props: {
    type: Boolean,
    default: false
  }
};
</script>
<style scoped>
.qrcode {
  display: inline-block;
}
.wechat img {
  width: 0.7rem !important;
  height: 0.7rem !important;
}
.wechatIcon {
  width: 0.1rem;
  height: 0.09rem;
  display: block;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/wechat.png");
  background-size: 100%;
}
.weibo img {
  width: 0.7rem !important;
  height: 0.7rem !important;
}
.weiboIcon {
  width: 0.1rem;
  height: 0.09rem;
  display: block;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/weibo.png");
  background-size: 100%;
}
.qq img.qq {
  width: 0.7rem !important;
  height: 0.7rem !important;
}
.qq img.qqs {
  width: 0.7rem !important;
  height: 0.7rem !important;
}
.qqIcon {
  width: 0.08rem;
  height: 0.08rem;
  display: block;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/qq.png");
  background-size: 100%;
}
.el-button {
  padding: 0;
  margin: 0 0 0 0.1rem;
  background: transparent;
  border: none;
}
</style>
<style>
.el-popover {
  /* width: 0.6rem; */
  min-width: 0.1rem !important;
  text-align: center;
}
.el-popover.wechat {
  left: 0.6rem !important;
}
.el-popover.wechat .popper__arrow {
  left: 0.38rem !important;
}
.el-popover.weibo {
  left: 0.8rem !important;
}
.el-popover.weibo .popper__arrow {
  left: 0.39rem !important;
}
.el-popover.qq {
  left: 1rem !important;
}
.el-popover.qq .popper__arrow {
  left: 0.38rem !important;
}
.el-popover img {
  display: block;
  margin: 0 auto;
}
.el-popover span {
  margin: 0.05rem 0 0 0;
  font-size: 0.07rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.06rem;
}
</style>
