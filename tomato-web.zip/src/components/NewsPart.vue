<!--
 * @Author: your name
 * @Date: 2021-02-25 17:17:33
 * @LastEditTime: 2021-06-11 14:12:53
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\components\News.vue
-->
<template>
  <div class="newsPart" :class="{ active: isActive }">
    <div class="box">
      <h2>{{ $t("x.newsPart.title") }}</h2>
    </div>
    <div class="swiperBox">
      <!-- Swiper -->
      <div class="swiper-container swiper-container_2">
        <div class="swiper-wrapper">
          <div class="swiper-slide" v-for="item in newsList" :key="item.id">
            <NewsPartItem :news="item" />
          </div>
          <!-- <div class="swiper-slide" v-for="item in $t('x.newsPage.newest')" :key="item.id">
            <NewsPartItem :news="item" />
          </div> -->
        </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
      </div>
    </div>
  </div>
</template>
<script>
import NewsPartItem from "@/components/NewsPartItem.vue";
import Swiper from "swiper";
import "swiper/dist/css/swiper.css";

export default {
  name: "newsPart",
  components: {
    NewsPartItem
  },
  data() {
    return {
      swiper: null,
      effect: 0,
      screenHeight: document.documentElement.clientHeight,
      isActive: false,
      left: 0,
      key: "0391591aafc5db68b08787645b837b4f",
      timer: parseInt(Date.parse(new Date()) / 1000),
      newsList: []
    };
  },
  methods: {
    createSwiper() {
      let that = this;
      this.swiper = new Swiper(".swiper-container_2", {
        observer: true, //修改swiper自己或子元素时，自动初始化swiper
        observeParents: true, //修改swiper的父元素时，自动初始化swiper
        autoplay: {
          delay: 0,
          stopOnLastSlide: false,
          disableOnInteraction: false
        },
        allowTouchMove: false,
        loop: true,
        speed: 12000,
        slidesPerView: "auto",
        // spaceBetween: 30,
        centeredSlides: true,
        // watchSlidesProgress: true,
        preventClicks: false,
        preventClicksPropagation: false,

        on: {
          // 点击事件
          tap: function(e) {
            let clickIndex = this.clickedSlide.getAttribute(
              "data-swiper-slide-index"
            );
            that.$router.push({
              name: "SingleNews",
              query: {
                id: that.newsList[clickIndex].id,
                type: that.newsList[clickIndex].type
              }
            });
          }
        }
      });
      // 存放鼠标悬浮时的transform属性（行内属性）
      let nextTransForm = "";
      // 轮播图从暂停位置移动到原本应到的位置所用的时间
      let nextTime = 0;

      // 鼠标悬浮暂停轮播
      this.swiper.el.onmouseenter = function() {
        nextTransForm = document
          .getElementsByClassName("swiper-container_2")[0]
          .getElementsByClassName("swiper-wrapper")[0].style.transform;
        // 轮播图原本应移动到的位置
        let nextTransPosition =
          -1 *
          parseInt(
            document
              .getElementsByClassName("swiper-container_2")[0]
              .getElementsByClassName("swiper-wrapper")[0]
              .style.transform.split("translate3d(")[1]
              .split("px")[0]
          );

        // 鼠标悬浮时时轮播图位置
        let nowTransPosition =
          -1 *
          parseInt(
            window
              .getComputedStyle(
                document
                  .getElementsByClassName("swiper-container_2")[0]
                  .getElementsByClassName("swiper-wrapper")[0],
                false
              )
              ["transform"].split("1, ")[2]
              .split(",")[0]
          );
        // 存放鼠标悬浮时轮播图的真实transform属性（非行内属性）
        let nowTransForm = window.getComputedStyle(
          document
            .getElementsByClassName("swiper-container_2")[0]
            .getElementsByClassName("swiper-wrapper")[0],
          false
        )["transform"];

        nextTime = 5500 * ((nextTransPosition - nowTransPosition) / 200);
        // 改变行内transform属性
        document
          .getElementsByClassName("swiper-container_2")[0]
          .getElementsByClassName(
            "swiper-wrapper"
          )[0].style.transform = nowTransForm;
        // 不写也没关系
        document
          .getElementsByClassName("swiper-container_2")[0]
          .getElementsByClassName(
            "swiper-wrapper"
          )[0].style.transitionDuration = "0ms";
        this.swiper.autoplay.stop();
      };
      // 鼠标离开轮播图开始轮播
      this.swiper.el.onmouseleave = function() {
        // 恢复原样
        document
          .getElementsByClassName("swiper-container_2")[0]
          .getElementsByClassName(
            "swiper-wrapper"
          )[0].style.transform = nextTransForm;
        document
          .getElementsByClassName("swiper-container_2")[0]
          .getElementsByClassName(
            "swiper-wrapper"
          )[0].style.transitionDuration = nextTime + "ms";
        this.swiper.autoplay.start();
      };
    },
    // 监听滚动条
    handleScroll(e) {
      var scrollTop =
        e.target.documentElement.scrollTop || e.target.body.scrollTop;
      if (scrollTop > this.screenHeight + 200) {
        this.isActive = true;
      }
    }
    // 点击新闻
    // clickNews(e) {
    //   this.$router.push({
    //     path: "/singleNews",
    //     // query: { news: that.$t('x.newsPart.news['+this.clickedIndex+']') },
    //     query: { news: this.$t("x.newsPart.news[0]") },
    //   });
    // },
  },
  computed: {
    area: function() {
      return localStorage.getItem("isEn") == "true" ? 0 : 1;
    }
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true);
    // 首页获取最新新闻
    this.$axios({
      method: "get",
      url: "https://hw.xianyuyouxi.com/service/Tomato_webhome/getNews",
      headers: {
        "Access-s": this.$md5(`${this.key}${this.timer}`)
      },
      params: {
        time: this.timer,
        area: this.area,
        company: 1
      }
    }).then(res => {
      // console.log(res);
      if (res.status == 200) {
        // 获取新闻成功
        this.newsList = res.data.data;
        this.$nextTick(() => {
          this.createSwiper();
        });
      } else {
        this.$message.error("获取首页新闻数据失败");
      }
    });
  }
};
</script>
<style scoped>
.newsPart {
  padding-top: 0.01rem;
  /* background: #eee; */
  font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
  font-size: 14px;
  overflow: hidden;
}
.box {
  height: 0.9rem;
  padding-top: 0.01rem;
}
h2 {
  margin: 0.5rem 0 0 0;
  font-size: 0.26rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  float: none;
  color: #333333;
  transition: all 0.5s;
}
.en h2 {
  font-family: Arial;
  font-weight: bold;
}
.active h2 {
  margin: 0.36rem 0 0 0;
}

.box i {
  font-size: 0.2rem;
}
.swiperBox {
  width: 100%;
  height: 2.8rem;
  margin: 0.1rem 0 0.3rem 0;
  position: relative;
  overflow: hidden;
}
.swiper-container_2 {
  width: 100%;
}

.swiper-container_2 .swiper-wrapper {
  /* 匀速播放 */
  transition-timing-function: linear;
}
.swiper-container_2 .swiper-slide {
  width: 1.99rem !important;
  height: 2.8rem !important;
  margin: 0 0.18rem 0 0;
  background: #fff;
  float: left;

  /* Center slide text vertically */
  display: -webkit-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  -webkit-justify-content: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  -webkit-align-items: center;
  align-items: center;
}
</style>
