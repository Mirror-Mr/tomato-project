/*
 * @Author: your name
 * @Date: 2021-02-23 10:57:53
 * @LastEditTime: 2021-05-15 14:10:05
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\main.js
 */
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
// import '../public/js/rem.js'
import VueAwesomeSwiper from 'vue-awesome-swiper';
import VueI18n from 'vue-i18n';
import axios from 'axios';
import md5 from 'js-md5';

// import $ from 'jquery';
// import "../public/js/jquery-2.1.1.min.js"
// import "../public/js/jquery-qrcode-0.18.0.min.js"




Vue.prototype.$md5 = md5;
// 给Vue这个实例对象设置一个名为$axios的属性
Vue.prototype.$axios = axios;
//将post请求是数据转化为formdata格式
axios.defaults.transformRequest = [
  function (data) {
    let ret = "";
    for (let it in data) {
      ret += encodeURIComponent(it) + "=" + encodeURIComponent(data[it]) + "&";
    }
    return ret;
  }
];
// router.afterEach((to, from, next) => {
//   window.scrollTo(0, 0);
// })

Vue.config.productionTip = false
Vue.use(ElementUI);
Vue.use(VueAwesomeSwiper);
Vue.use(VueI18n)
const i18n = new VueI18n({
  locale:'zh-CN',//定义默认中文
  messages:{
    'zh-CN':require('./lang/zh'),//中文语言包
    'en-US':require('./lang/en')//英文语言包
  }
})
new Vue({
  i18n,
  router,
  render: h => h(App)
}).$mount('#app')
