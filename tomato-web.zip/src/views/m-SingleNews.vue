<!--
 * @Author: your name
 * @Date: 2021-03-10 19:16:44
 * @LastEditTime: 2021-05-28 18:16:50
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\SingleNews.vue
-->
<template>
  <div class="singleNews">
    <MHeader />
    <el-page-header
      @back="goBack"
      content=""
      :title="$t('x.singleNews.return')"
    ></el-page-header>
    <div
      v-loading="true"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      v-show="isLoading"
      class="mask"
    ></div>
    <div class="container" v-show="!isLoading">
      <div class="main">
        <span class="time">{{ news.start_time }}</span>

        <span class="title">{{ news.title }}</span>
        <span class="content" v-html="news.content"></span>
        <!-- <span
        class="image"
        :style="{
          backgroundImage: 'url(' + news.icon + ')',
          backgroundSize: '100%'
        }"
      ></span> -->
      </div>

      <!-- <div class="icon">
        <a href="#" class="share"></a>
        <a href="#" class="twitter"></a>
        <a href="#" class="face"></a>
      </div> -->
      <div class="morePart">
        <span class="more">{{ $t("x.singleNews.more") }}</span>
        <template v-if="JSON.stringify(beforeNews) != '[]'">
          <div @click="showNews(beforeNews)">
            <span
              class="image"
              :style="{
                backgroundImage: 'url(' + beforeNews.icon + ')',
                backgroundSize: 'cover'
              }"
            ></span>
            <span class="title">{{ beforeNews.title }}</span>
            <span class="time" :class="{ type: beforeNews.type == 1 }">{{
              beforeNews.start_time
            }}</span>
          </div>
        </template>
        <template v-if="JSON.stringify(afterNews) != '[]'">
          <div @click="showNews(afterNews)">
            <span
              class="image"
              :style="{
                backgroundImage: 'url(' + afterNews.icon + ')',
                backgroundSize: 'cover'
              }"
            ></span>
            <span class="title">{{ afterNews.title }}</span>
            <span class="time" :class="{ type: afterNews.type == 1 }">{{
              afterNews.start_time
            }}</span>
          </div>
        </template>
      </div>
    </div>
    <MFooter />
  </div>
</template>
<script>
import MHeader from "@/components/m-Header.vue";
import MFooter from "@/components/m-Footer.vue";
export default {
  name: "SingleNews",
  components: {
    MHeader,
    MFooter
  },
  data() {
    return {
      news: {
        title: "",
        time: "",
        content: "",
        image: ""
      },
      beforeNews: {},
      afterNews: {},
      key: "0391591aafc5db68b08787645b837b4f",
      // 时间戳
      timer: parseInt(Date.parse(new Date()) / 1000),
      isLoading: true
    };
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    showNews(nextNews) {
      // 获取数据后传递给下一个新闻详情页
      this.$router.push({
        name: "MSingleNews",
        query: {
          id: nextNews.id,
          type: nextNews.type
        }
      });
    }
  },
  computed: {
    area: function() {
      return localStorage.getItem("isEn") == "true" ? 0 : 1;
    }
  },
  watch: {
    $route() {
      location.reload();
    },
    news(newV, oldV) {
      this.news.start_time = this.news.start_time
        .split(" ")[0]
        .replace(/-/g, "/");
    },
    beforeNews(newV, oldV) {
      this.beforeNews.start_time = this.beforeNews.start_time
        .split(" ")[0]
        .replace(/-/g, "/");
    },
    afterNews(newV, oldV) {
      this.afterNews.start_time = this.afterNews.start_time
        .split(" ")[0]
        .replace(/-/g, "/");
    }
  },
  updated() {},
  mounted() {
    this.$axios({
      method: "get",
      url: "https://hw.xianyuyouxi.com/service/Tomato_webhome/getNewsInfo",
      headers: {
        "Access-s": this.$md5(`${this.key}${this.timer}`)
      },
      params: {
        time: this.timer,
        area: this.area,
        type: this.$route.query.type, //新闻类型
        id: this.$route.query.id //新闻id
      }
    }).then(res => {
      this.news = res.data.data.data;
      this.beforeNews = res.data.data.before;
      this.afterNews = res.data.data.after;
      this.isLoading = false;
    });
  }
};
</script>
<style scoped>
.singleNews >>> .el-page-header {
  margin: 1.5rem 0 0 0.8rem;
}
.singleNews >>> .el-icon-back:before {
  content: "\e6ea";
  font-size: 0.3rem;
  font-weight: 400;
  color: #999;
  line-height: 0.6rem;
}
.singleNews >>> .el-page-header__title {
  margin: 0 0 0 0.1rem;
  font-size: 0.3rem;
  font-family: Arial;
  font-weight: 400;
  color: #999;
  line-height: 0.6rem;
}

.container {
  width: 83%;
  margin: 0 auto 1rem;
  text-align: left;
}
.main .title {
  width: 100%;
  margin: 0.5rem 0 0 0;
  font-size: 0.43rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
  /* line-height: 0.93rem; */
}

.time {
  /* width: 1.39rem; */
  height: 0.33rem;
  padding: 0 0.1rem;
  margin: 0.1rem 0 0 0;
  text-align: center;
  font-size: 0.21rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  line-height: 0.33rem;
  color: #fb5e00;
  background: rgba(255, 122, 21, 0.3);
  border-radius: 0.1rem;
}
.main .content {
  width: 100%;
  margin: 0.5rem 0 0.5rem 0;
  font-size: 0.35rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666666;
  line-height: 0.55rem;
  text-align: Justify;
}
.main .container::after {
  content: "";
  display: block;
  clear: both;
}
.main .image {
  width: 100%;
  height: 5rem;
  display: block;
  margin: 0 auto;
  border-radius: 0.2rem;
}
.icon {
  display: inline-block;
  margin: 0.2rem 0 0.3rem 0;
  float: right;
}

.icon a {
  margin: 0 0.2rem;
}
.share {
  width: 0.4rem;
  height: 0.4rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/share0.png");
  background-size: 100%;
  transition: all 0.1s;
}
.share:hover {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/share1.png");
  background-size: 100%;
}
.twitter {
  width: 0.4rem;
  height: 0.4rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/twitter0.png");
  background-size: 100%;
  transition: all 0.1s;
}
.twitter:hover {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/twitter1.png");
  background-size: 100%;
}
.face {
  width: 0.29rem;
  height: 0.4rem;
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/face0.png");
  background-size: 100%;
  transition: all 0.1s;
}
.face:hover {
  background: url("https://wcdn.tomatogames.com/web/haiwai/tomato/img/face1.png");
  background-size: 100%;
}
.morePart {
  padding: 0.5rem 0 0 0;
  border-top: 0.01rem solid #999999;
}

.morePart .more {
  margin: 0 0 0.59rem 0;
  font-size: 0.4rem;
  font-family: Microsoft YaHei;
  font-weight: bolder;
  color: #333333;
}
.morePart div::after {
  content: "";
  display: block;
  clear: both;
}
.morePart div {
  width: 100%;
  margin: 0 0 1rem 0;
}
.morePart .image {
  width: 3.33rem;
  height: 2.27rem;
  border-radius: 0.1rem;
  float: left;
  background-position: center;
}
.morePart .title {
  width: 4.56rem;
  vertical-align: top;
  margin: 0 0 0 0.36rem;
  line-height: 0.55rem;
  font-size: 0.35rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ff7915;
}
.morePart .time {
  margin: 0.3rem 0 0 0.36rem;
}
/* 正在加载 */
.singleNews >>> .el-loading-spinner{
  top: 25%;
}

.singleNews >>> .el-loading-spinner i,
.singleNews >>> .el-loading-spinner .el-loading-text {
  font-size: 0.4rem;
  color: #ff7915;
}
.singleNews >>> .el-loading-spinner .path {
  stroke: #ff7915;
}
.mask >>> .el-loading-mask {
  min-height: 70vh;
  position: relative;
}
</style>
