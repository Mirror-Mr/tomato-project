<!--
 * @Author: your name
 * @Date: 2021-03-30 16:20:36
 * @LastEditTime: 2021-05-28 19:23:44
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\jobs\AllPost.vue
-->
<template>
  <div class="detail">
    <Header :campus="campus" />
    <span class="banner"> </span>
    <div class="container">
      <div class="title">
        <p>{{ jobInfo.post_name }}</p>
        <span class="request"
          >{{ jobInfo.city }} - {{ jobInfo.post_type }} 
          <!-- - 经验{{
            jobInfo.work_time
          }}年 -->
           / {{ jobInfo.createtime.split(" ")[0] }}</span
        >
        <div class="share">
          <span class="prompt" @click="toShare"
            >{{ $t("y.detail.share[0]") }}
            <i class="el-icon-arrow-down"></i>
          </span>
          <div class="shareBox" :class="{isShare:isShare}">
            <div class="wBox box">
              <canvas class="canvas" id="canvas" ref="canva"> </canvas>
              <span>{{ $t("y.detail.share[1]") }}</span>
            </div>
            <!-- <div class="qBox box">
              <span>{{ $t("y.detail.share[2]") }}</span>
            </div> -->
          </div>
        </div>
      </div>

      <div class="content">
        <div class="des-left">
          <div class="description">
            <div class="public-title">{{ $t("y.detail.postDesc") }}</div>
            <div class="des-words" v-html="jobInfo.content"></div>
          </div>
          <div class="requirements">
            <div class="public-title">{{ $t("y.detail.postRequest") }}</div>
            <div class="des-words" v-html="jobInfo.need"></div>
          </div>
          <button @click="showApplyBox(true)">
            {{ $t("y.detail.applyPost") }}
          </button>
        </div>
        <div class="des-right">
          <div class="public-title public-title-new">
            {{ $t("y.detail.newPost") }}
          </div>
          <ul>
            <li
              v-for="item in newJobList"
              :key="item.id"
              @click="checkDetails(item.id)"
            >
              <div class="job-title">{{ item.post_name }}</div>
              <span
                >{{ item.city }} - {{ item.post_type }}
                 <!-- - 经验{{
                  item.work_time
                }}年 -->
                 / {{ item.createtime.split(" ")[0] }}更新</span
              >
              <!-- <span>深圳 - 市场岗 - 经验3-5年 / 2021-03-17更新</span> -->
            </li>
          </ul>
        </div>
      </div>
    </div>
    <ApplyBox
      :isShow="isShow"
      @close="showApplyBox"
      :post_title="jobInfo.post_name"
      :job_id="this.$route.query.id"
    />
    <Footer :type="true"></Footer>
  </div>
</template>
<script>
import Header from "@/components/jobs/Header1.vue";
import Footer from "@/components/Footer.vue";
import ApplyBox from "@/components/jobs/ApplyBox.vue";
import QRCode from "qrcode";

export default {
  name: "AllPost",
  components: {
    Header,
    Footer,
    ApplyBox
  },
  data() {
    return {
      controlSwitch: true,
      cityIndex: 0,
      professionIndex: 0,
      natureIndex: 0,
      key: "0391591aafc5db68b08787645b837b4f",
      jobInfo: {
        createtime: "",
        post_name: ""
      },
      newJobList: [],
      // 申请职位框是否显示
      isShow: false,
      campus: false,
      isShare:false
    };
  },
  methods: {
    tabSwitch() {
      this.controlSwitch = !this.controlSwitch;
    },
    // 获取只工作详情
    getJobeInfo() {
      // time  lang  1中文 2英语  3法语  catogery1自研 2发行 keyword搜索词
      // city 城市id  post_type职能id  job_type 1全职2兼职   type 1社招2校招
      this.$axios({
        method: "get",
        url: "https://hw.xianyuyouxi.com/service/tomato_webhome/get_job_info",
        headers: {
          "Access-s": this.$md5(
            `${this.key}${parseInt(Date.parse(new Date()) / 1000)}`
          )
        },
        params: {
          lang: "1",
          time: parseInt(Date.parse(new Date()) / 1000),
          id: this.$route.query.id
        }
      }).then(res => {
        console.log(res.data.data);
        this.jobInfo = res.data.data.data;
        this.newJobList = res.data.data.recommen;
      });
    },
    // 展示/隐藏申请框
    showApplyBox(n) {
      this.isShow = n;
    },
    // 点击查看详情
    checkDetails(id) {
      this.$router.push({
        path: "/detail",
        query: { id: id, campus: this.campus }
      });
    },
    // 动态生成二维码
    createQRcode(url) {
      let canvas = this.$refs.canva;
      QRCode.toCanvas(canvas, url, { margin: 1.5 }, function(error) {
        if (error) console.error(error);
      });
      canvas.style.display = "block"; //隐藏掉canvas
      this.qrcode = canvas.toDataURL("image/png");
    },
    // 分享
    toShare() {
      this.createQRcode(location.href);
      this.isShare = !this.isShare;
    }
  },
  mounted() {
    this.getJobeInfo();
    this.campus = JSON.parse(this.$route.query.campus);
  }
};
</script>
<style scoped>
.detail {
  background: #fafafa;
}
.container {
  width: 58%;
  margin: 0 auto;
  padding: 0.75rem 0 0.92rem;
  text-align: left;
}
.title {
  position: relative;
  padding-bottom: 0.16rem;
  border-bottom: 1px solid #999999;
}
.en .title {
  font-family: Arial;
}
.title p {
  color: #333333;
  font-size: 0.16rem;
  font-weight: bold;
}
.title .request {
  font-size: 0.08rem;
  margin-top: 0.06rem;
  color: #999999;
}
.content {
  display: flex;
  justify-content: space-between;
}
.description {
}
.des-words {
  margin-top: 0.05rem;
  line-height: 0.15rem;
  color: #666666;
  font-size: 0.08rem;
}
.en .des-words {
  font-family: Arial;
}
.requirements {
}
.des-left {
  padding-right: 0.2rem;
}
.public-title {
  margin-top: 0.26rem;
  font-weight: bold;
  font-size: 0.1rem;
}
.en .public-title {
  font-family: Arial;
}
.public-title-new {
  width: 1.66rem;
  padding-bottom: 0.1rem;
  border-bottom: 1px solid #999999;
  color: #333333;
}
/* 分享 */
.share {
  position: absolute;
  position: absolute;
  top: 0.06rem;
  right: 0;
}
.share .prompt {
  /* width: 0.36rem; */
  padding: 0 0.02rem;
  height: 0.14rem;
  line-height: 0.13rem;
  text-align: center;
  border: 0.01rem solid #d2d2d2;
  border-radius: 0.02rem;
  cursor: pointer;
  font-size: 0.06rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666666;
}
.share .shareBox {
  position: absolute;
  top: 0.2rem;
  left: -0.1rem;
  background: #fff;
  padding: 0.05rem;
  text-align: center;
  box-shadow: 0rem 0rem 0rem 0rem rgba(184, 184, 184, 0.14);
  opacity: 0;
  transition: all 0.3s;
}
.shareBox.isShare{
  opacity: 1;
}
.shareBox .box{
  margin: 0 0.05rem;
}
.box span{
  white-space:nowrap;
  vertical-align: top;
  margin: 0.03rem 0 0 0;
  font-size: 0.05rem;
  
}
.canvas {
  width: 0.5rem !important;
  height: 0.5rem !important;
  margin: 0 auto;
}
.content ul {
  margin-top: 0.05rem;
}
.content li {
  margin: 0;
  line-height: 0.15rem;
}
.content button {
  width: 0.81rem;
  height: 0.2rem;
  margin-top: 0.29rem;
  background: #ff7915;
  border-radius: 0.1rem;
  border: none;
  font-size: 0.08rem;
  color: #ffffff;
  outline-style: none;
  cursor: pointer;
}
.content button:hover {
  background: #ff872b;
}
.des-right .job-title {
  font-size: 0.07rem;
  font-weight: 700;
  color: #333333;
}
.des-right span {
  font-size: 0.06rem;
  color: #999999;
}
.des-right li {
  margin-bottom: 0.08rem;
  line-height: 20px;
  cursor: pointer;
}
</style>
