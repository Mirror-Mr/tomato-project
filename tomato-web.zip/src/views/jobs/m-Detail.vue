<!--
 * @Author: your name
 * @Date: 2021-03-30 16:20:36
 * @LastEditTime: 2021-05-25 12:22:49
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\jobs\AllPost.vue
-->
<template>
  <div class="detail">
    <Header :campus="campus"/>
    <span class="banner"> </span>
    <div class="container">
      <div class="title">
        <p>{{ jobInfo.post_name }}</p>
        <span
          >
          {{ jobInfo.city }} - {{ jobInfo.post_type }} 
          <!-- - 经验{{
            jobInfo.work_time
          }}年  -->
          / {{ jobInfo.createtime.split(" ")[0] }}
          </span
        >
      </div>
      <div class="content">
        <div class="des-left">
          <div class="description">
            <div class="public-title">{{ $t("y.detail.postDesc") }}</div>
            <div class="des-words" v-html="jobInfo.content"></div>
          </div>
          <div class="requirements">
            <div class="public-title">{{ $t("y.detail.postRequest") }}</div>
            <div class="des-words" v-html="jobInfo.need"></div>
          </div>
          <button @click="showApplyBox(true)">
            {{ $t("y.detail.applyPost") }}
          </button>
        </div>
        <!-- 最新岗位 -->
        <div class="des-right">
          <div class="public-title public-title-new">
            {{ $t("y.detail.newPost") }}
          </div>

          <div class="right-list">
            <div
              class="public-list"
              v-for="(item, index) in newJobList"
              :key="index"
              @click="checkDetails(item.id)"
            >
              <div class="job-title">
                <p>{{ item.post_name }}</p>
                <span>{{ item.createtime.split(" ")[0] }}更新</span>
              </div>
              <div class="job-city">
                {{ item.city }} - {{ item.post_type }}
                 <!-- - 经验
                {{ item.work_time }} 年 -->
              </div>
              <!-- <div
                class="job-des"
                v-html="item.content"
                style="font-size: 0.07rem"
              >
                
              </div> -->
            </div>
          </div>
        </div>
      </div>
    </div>
    <ApplyBox
      :isShow="isShow"
      @close="showApplyBox"
      :post_title="jobInfo.post_name"
      :job_id="this.$route.query.id"
      :isIP="true"
    />
    <Footer :type="true"></Footer>
  </div>
</template>
<script>
import Header from "@/components/jobs/m-Header.vue";
import Footer from "@/components/m-Footer.vue";
import ApplyBox from "@/components/jobs/ApplyBox.vue";
export default {
  name: "AllPost",
  components: {
    Header,
    Footer,
    ApplyBox
  },
  data() {
    return {
      controlSwitch: true,
      cityIndex: 0,
      professionIndex: 0,
      natureIndex: 0,
      key: "0391591aafc5db68b08787645b837b4f",
      // 当前岗位信息
      jobInfo: "",
      // 最新岗位
      newJobList: [],
      // 申请职位框是否显示
      isShow: false,
      campus:false
    };
  },
  methods: {
    tabSwitch() {
      this.controlSwitch = !this.controlSwitch;
    },
    // 获取只工作详情
    getJobeInfo(id) {
      // time  lang  1中文 2英语  3法语  catogery1自研 2发行 keyword搜索词
      // city 城市id  post_type职能id  job_type 1全职2兼职   type 1社招2校招
      this.$axios({
        method: "get",
        url: "https://hw.xianyuyouxi.com/service/tomato_webhome/get_job_info",
        headers: {
          "Access-s": this.$md5(
            `${this.key}${parseInt(Date.parse(new Date()) / 1000)}`
          )
        },
        params: {
          lang: "1",
          time: parseInt(Date.parse(new Date()) / 1000),
          id: id
        }
      }).then(res => {
        console.log(res);
        this.jobInfo = res.data.data.data;
        this.newJobList = res.data.data.recommen;
        console.log(this.newJobList);
      });
    },
    // 展示/隐藏申请框
    showApplyBox(n) {
      this.isShow = n;
    },
    // 点击查看详情
    checkDetails(id) {
      

      this.getJobeInfo(id);
      this.$router.push({
        path: "/m/detail",
        query: { id: id }
      });
      // location.reload()
      // this.$router.go(0)
    }
  },
  mounted() {
    this.getJobeInfo(this.$route.query.id);
    this.campus = JSON.parse(this.$route.query.campus);
  }

  
};
</script>
<style scoped>
.detail {
  background: #fafafa;
}
.container {
  width: 93%;
  margin: 0 auto;
  padding: 1.3rem 0 0.92rem;
  text-align: left;
}
.title {
  padding-bottom: 0.16rem;
  border-bottom: 1px solid #999999;
}
.en .title {
  font-family: Arial;
}
.title p {
  font-size: 0.48rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
}
.title span {
  font-size: 0.32rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  margin-top: 0.1rem;
}
.content {
  /* display: flex; */
  /* justify-content: space-between; */
}
.description {
}
.des-words {
  margin-top: 0.33rem;

  line-height: 0.48rem;
  font-size: 0.27rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.en .des-words {
  font-family: Arial;
}
.requirements {
}
.des-left {
  width: 100%;
  padding-right: 0.2rem;
}
.public-title {
  margin-top: 0.26rem;
  font-weight: bold;
  font-size: 0.35rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
}
.en .public-title {
  font-family: Arial;
}
.public-title-new {
  margin: 1.64rem 0 0 0;
  padding-bottom: 0.3rem;
  border-bottom: 1px solid #999999;
  font-size: 0.48rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.content ul {
  margin-top: 0.05rem;
}
.content li {
  margin: 0;
  line-height: 0.15rem;
}
.content button {
  width: 3.31rem;
  height: 0.83rem;
  margin-top: 0.59rem;
  background: #ff7915;
  border-radius: 1rem;
  border: none;
  font-size: 0.35rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
  line-height: 0.51rem;
  outline-style: none;
  cursor: pointer;
}
.content button:hover {
  background: #ff872b;
}
.des-right .job-title {
  font-size: 0.07rem;
  font-weight: 700;
  color: #333333;
}
.des-right span {
  font-size: 0.06rem;
  color: #999999;
}
.des-right li {
  margin-bottom: 0.08rem;
  line-height: 20px;
  cursor: pointer;
}
.right-list {
  padding-top: 0.3rem;
}
.public-list {
  width: 100%;
  height: 2.06rem;
  margin: 0 auto;
  background: #ffffff;
  box-shadow: 0rem 0.01rem 0.05rem 0.01rem rgb(184 184 184 / 18%);
  border-radius: 0.05rem;
  margin-bottom: 0.1rem;
  cursor: pointer;
  /* box-sizing: border-box; */
}
.public-list:hover {
  box-shadow: 0rem 0.01rem 0.05rem 0.01rem rgb(184 184 184 / 60%);
  transform: scale(1.01);
  transition: 0.2s;
}
.public-list:hover p {
  color: #ee7012;
}
.job-new {
  color: #ee7012;
}
.job-title {
  display: flex;
  justify-content: space-between;
}
.job-title p {
  margin: 0.36rem 0 0 0.59rem;
  font-size: 0.48rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
}
.job-title span {
  margin: 0.36rem 0.45rem 0 0;
  font-size: 0.27rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #666666;
}
.job-city {
  font-size: 0.32rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  margin: 0.35rem 0 0 0.57rem;
}
.job-des {
  /* max-height: 0.2rem; */
  /* overflow: hidden; */
  font-size: 0.07rem;
  color: #999999;
  -webkit-box-orient: vertical;
  text-overflow: ellipsis;
  overflow: hidden;
  word-break: break-all;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  display: none;
}
.job-des p {
  font-size: 0.07rem !important;
  text-overflow: -o-ellipsis-lastline;
  overflow: hidden;
}
</style>
