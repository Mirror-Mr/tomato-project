<!--
 * @Author: your name
 * @Date: 2021-02-23 10:57:53
 * @LastEditTime: 2021-05-17 16:10:45
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\News.vue
-->
<template>
  <div class="mnewsPage">
    <MHeader />
    <div class="theme">
      <h2 :class="{ active: newsActive }">{{ $t("x.newsPage.m_theme") }}</h2>
    </div>
    <div class="container">
      <MNewsPageItem
        v-for="(item, i) in filterNewest"
        :key="i"
        :news="filterNewest[i]"
      />
      <!-- 没得新闻 -->
      <template v-if="newsList.length == 0">
        <span class="noMore">暂无相关新闻</span>
      </template>
      <!-- 加载完 -->
      <template
        v-else-if="!isLoading && newsList.length != filterNewest.length"
      >
        <a href="#" class="seemore" @click.prevent="moreNews"
          >{{ $t("x.newsPage.seeMore") }} <i class="el-icon-arrow-down"></i>
        </a>
      </template>
      <!-- 没有更多内容 -->
      <template v-else-if="!isLoading">
        <span class="noMore">没有更多内容了</span>
      </template>
      <!-- 正在加载 -->
      <template v-else>
        <span
          class="loading"
          v-loading="isLoading"
          background="#ff7915"
          text="ss"
        ></span>
      </template>
    </div>

    <MFooter />
  </div>
</template>
<script>
import MHeader from "@/components/m-Header.vue";
import MFooter from "@/components/m-Footer.vue";
import MNewsPageItem from "@/components/m-NewsPageItem.vue";
export default {
  name: "mnewsPage",
  components: {
    MHeader,
    MFooter,
    MNewsPageItem
  },
  data() {
    return {
      // 标题动画效果
      newsActive: false,
      // 是否正在加载
      isLoading: false,

      // 最新消息开始页数
      newestIndex: 0,
      // 消息总条数
      length: this.$t("x.newsPage.newest").length,
      key: "0391591aafc5db68b08787645b837b4f",
      // 时间戳
      timer: parseInt(Date.parse(new Date()) / 1000),
      // 展示的新闻
      newsList: []
    };
  },
  computed: {
    // filterNewest() {
    //   return this.$t("x.newsPage.newest").slice(0, (this.newestIndex + 1) * 4);
    // },
    filterNewest() {
      return this.newsList.slice(0, (this.newestIndex + 1) * 4);
    },
    area: function() {
      return localStorage.getItem("isEn") == "true" ? 2 : 1;
    }
  },
  methods: {
    moreNews() {
      this.isLoading = true;
      setTimeout(() => {
        this.newestIndex++;
        this.isLoading = false;
      }, 1000);
    }
  },
  mounted() {
    this.newsActive = true;
    // 进入默认加载最新第一页的新闻
    this.$axios({
      methods: "get",
      url: "https://hw.xianyuyouxi.com/service/Tomato_webhome/getNewsList/1",
      headers: {
        "Access-s": this.$md5(`${this.key}${this.timer}`)
      },
      params: {
        time: this.timer,
        area: this.area,
        // area:1,
        company: 1,
        // type:this.newsType
        type: 0
      }
    }).then(res => {
      // console.log(res)
      // res.data.data.data  新闻列表
      this.newsList = res.data.data.data;
    });
  }
};
</script>
<style scoped>
.container {
  margin: 0 0 0.3rem 0;
  min-height: 7.5rem;
}
.theme {
  width: 85%;
  height: 0.75rem;
  margin: 1.5rem auto 0.3rem;
}

.theme h2 {
  font-size: 0.48rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
  line-height: 0.76rem;
  transition: all 0.5s;
  float: none;
}
h2.active {
  margin: 0.3rem 0 0 0;
}

.btn {
  margin: -0.2rem 0 0 0.7rem;
  float: left;
}
.prevP {
  width: 0.14rem;
  height: 0.14rem;
  line-height: 0.14rem;
  background: #ffffff;
  border: 0.01rem solid #ff7915;
}
.prevP i {
  font-size: 0.01rem;
  color: #ff7915;
  font-weight: bold;
}
.nextP {
  width: 0.16rem;
  height: 0.16rem;
  line-height: 0.16rem;
  background: #ff7915;
}
.nextP i {
  font-size: 0.01rem;
  color: #fff;
  font-weight: bold;
}
.seemore,
.noMore {
  margin: 0 0 0.6rem 0;
  font-size: 0.43rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 1rem;
}
/* 正在加载 */
.loading {
  margin: 0.93rem 0 0.6rem 0;
  width: 100%;
}
.mnewsPage >>> .el-loading-spinner {
  /* margin: 0; */
}
.mnewsPage >>> .el-loading-spinner i,
.mnewsPage >>> .el-loading-spinner .el-loading-text {
  color: #ff7915;
}
.mnewsPage >>> .el-loading-spinner .path {
  stroke: #ff7915;
}
.mnewsPage >>> .el-loading-spinner .circular {
  width: 0.8rem;
  height: 0.8rem;
}
.mnewsPage >>> .el-loading-mask {
  top: -1.3rem;
}
</style>
