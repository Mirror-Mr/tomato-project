<!--
 * @Author: your name
 * @Date: 2021-03-10 19:16:44
 * @LastEditTime: 2021-06-10 11:25:21
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\views\SingleNews.vue
-->
<template>
  <div class="singleNews" v-cloak>
    <Header />

    <el-page-header
      @back="goBack"
      content=""
      :title="$t('x.singleNews.return')"
    ></el-page-header>
    <div
      v-loading="true"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      v-show="isLoading"
      class="mask"
    ></div>
    <div class="container" v-cloak v-show="!isLoading">
      <!-- 主要文章 -->
      <div class="main">
        <span class="title">{{ news.title }}</span>
        <span class="time">{{ news.start_time }}</span>
        <span class="content" v-html="news.content"></span>
        <!-- <img class="image" :src="news.icon " /> -->
        <Share class="share" :news="news" />
      </div>
      <!-- 更多文章 -->
      <div class="morePart">
        <span class="more">{{ $t("x.singleNews.more") }}</span>
      </div>
      <template v-if="JSON.stringify(beforeNews) != '[]'">
        <NewsPageItem :news="beforeNews" :special="true" />
      </template>
      <!-- <NewsPageItem :news="news" :special="true" /> -->
      <template v-if="JSON.stringify(afterNews) != '[]'">
        <NewsPageItem :news="afterNews" :special="true" />
      </template>

      <!-- <NewsPageItem :news="news" :special="true" /> -->
    </div>
    <Footer />
  </div>
</template>
<script>
import Header from "@/components/Header.vue";
import Share from "@/components/Share.vue";
import Footer from "@/components/Footer.vue";
import NewsPageItem from "@/components/NewsPageItem.vue";

export default {
  name: "SingleNews",
  components: {
    Header,
    Share,
    Footer,
    NewsPageItem
  },
  data() {
    return {
      news: {
        title: "",
        start_time: "",
        content: "",
        icon: "",
        id: ""
      },
      beforeNews: {},
      afterNews: {},
      key: "0391591aafc5db68b08787645b837b4f",
      // 时间戳
      timer: parseInt(Date.parse(new Date()) / 1000),
      isLoading:true
    };
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    }
  },
  computed: {
    area: function() {
      return localStorage.getItem("isEn") == "true" ? 0 : 1;
    }
  },
  mounted() {
    
    this.$axios({
      method: "get",
      url: "https://hw.xianyuyouxi.com/service/Tomato_webhome/getNewsInfo",
      headers: {
        "Access-s": this.$md5(`${this.key}${this.timer}`)
      },
      params: {
        time: this.timer,
        area: this.area,
        type: this.$route.query.type, //新闻类型
        id: this.$route.query.id //新闻id
      }
    }).then(res => {
      this.news = res.data.data.data;
      this.beforeNews = res.data.data.before;
      this.afterNews = res.data.data.after;
      this.isLoading = false;
    });
  },
  watch: {
    news() {
      this.news.start_time = this.news.start_time.replace(/-/g, "/");
    }
  }
};
</script>
<style scoped>
.singleNews >>> .el-page-header {
  margin: 0.8rem 0 0 1.15rem;
}
.singleNews >>> .el-icon-back:before {
  content: "‹";
  font-size: 0.2rem;
  font-weight: 400;
  color: #666666;
  line-height: 0.1rem;
}
.singleNews >>> .el-page-header__title {
  margin: 0 0 0 0.08rem;
  font-size: 0.11rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}
.singleNews >>> .el-page-header__left::after {
  display: none;
}
/* 主体 */
.container {
  width: 5.83rem;
  margin: 0 auto;
  text-align: left;
}
/* 主要内容 */
.main {
  padding: 0 0 0.52rem 0;
  border-bottom: 0.001rem solid #d6d6d6;
}
.main::after {
  content: "";
  display: block;
  clear: both;
}
.title {
  width: 100%;
  margin: 0.22rem 0 0 0;
  padding: 0 0 0.17rem 0;
  font-size: 0.26rem;
  font-family: Microsoft YaHei;
  font-weight: bold;
  color: #333333;
  line-height: 0.36rem;
  border-bottom: 0.001rem solid #d6d6d6;
}

.time {
  /* width: 0.54rem; */
  height: 0.13rem;
  padding: 0 0.05rem;
  margin: 0.24rem 0 0.24rem 0;
  text-align: center;
  font-size: 0.08rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  line-height: 0.13rem;
  color: #fb5e00;
  background: rgba(255, 122, 21, 0.3);
  border-radius: 0.03rem;
}
.en .time {
  margin: 0.25rem 0 0.21rem 0;
}
.content {
  width: 100%;
  margin: 0 0 0.2rem 0;
  font-size: 0.11rem;
  text-align: justify;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
  line-height: 0.21rem;
}

.image {
  width: 100%;
  display: block;
  margin: 0 auto;
}
.share {
  position: relative;
  bottom: 0;
  right: 0;
  margin: 0.3rem 0 0 0;
}
/* 更多内容 */
.morePart .more {
  margin: 0.3rem 0 0 0;
  font-size: 0.16rem;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #333333;
}

/* 正在加载 */

.singleNews >>> .el-loading-spinner i,
.singleNews >>> .el-loading-spinner .el-loading-text {
  font-size: 0.08rem;
  color: #ff7915;
}
.singleNews >>> .el-loading-spinner .path {
  stroke: #ff7915;
}
.mask >>> .el-loading-mask {
  height: 3.5rem;
  position: relative;
}
</style>
