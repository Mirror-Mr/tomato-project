/*
 * @Author: your name
 * @Date: 2021-03-09 10:58:46
 * @LastEditTime: 2021-06-07 15:17:52
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\lang\cn.js
 */
export const x = {
  logo: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/zlogo.png",
  clogo: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/czlogo.png",
  header: {
    currentLang: "简体中文",
    lang: ["简体中文", "English"],
    nav: ["关于我们", "游戏产品", "新闻资讯", "联系我们", "加入我们"]
  },
  carousel: {
    desc: [["我们的使命", "成为全球用户喜爱的<br>互动娱乐公司"]]
  },
  about: {
    white: {
      title: "关于我们",
      content: [
        `深圳市爱的番茄科技有限公司成立于2018年，公司致力于女性向及MMORPG细分精品游戏的研发与全球发行业务，我们为用户提供多元化的产品内容，努力成为全球用户喜爱的互动娱乐公司。`,
        `公司现有员工200多人，在北京、上海、深圳、香港、台湾、新加坡等地区建立多个分公司，我们招揽全球游戏人才，服务公司国际化战略目标。`
      ]
    },
    orange: {
      special: ["05", "研发工作室", "01", "独立编制工作室", "500", "现有员工"],
      aboutTitle: [
        "",
        "协作共赢",
        "正直务实",
        "追求卓越",
        "长期主义",
        "主人翁精神",
        "用户至上"
      ],
      aboutMsg: [
        [],
        [
          "公司全体成员均要有全局观，以公司整体利益为重。 ",
          "杜绝山头主义，杜绝拉帮结派，公司的人才、业务、管理体系均为公司资源，杜绝划分“地盘”的情形。",
          "在与外部合作伙伴合作时，也要秉承持协作共赢的精神，以追求长远可持续发展的良性合作。",
          "我们不单要有主动积极的协作精神，同时也要有专业科学的协同能力，才能达到最终的共赢目的。"
        ],
        [
          "在公司经营过程中，我们要将正直诚信作为基础。",
          "深入实际，以务实严谨的态度对待每一项工作。",
          " 当遇到问题时，不粉饰现状，直面现实，提出改善方案。",
          "当遇到挑战时，积极应对，勇于创新。"
        ],
        [
          "持续提高要求，勇于挑战，不放过任何一个问题，注重事物的关键本质，持续学习与成长。"
        ],
        [
          "用前瞻思维持续构建组织能力及员工能力，用发展的眼光看待我们的事业，不能为了获得一时的短期利益而牺牲长期利益。"
        ],
        [
          "热爱自己的工作，将工作当成自己的事业对待。",
          "工作要有热情及高度的责任感。",
          "开展工作要从全局思考并权衡最优实施方案。",
          "用长线思维思考并规划工作，要有前瞻性及开拓创新精神。"
        ],
        [
          "一切以用户的需求作为我们的行动纲领。",
          "以帮助用户提升核心价值为根本目的，时刻审视我们的核心竞争力是否可以帮助用户提升其核心价值。",
          "每一位同事均要有“用户至上”的理念。用户分为外部用户、内部用户，用户评价是检验工作价值的重要手段。"
        ]
      ]
    }
  },
  newsPart: {
    title: "新闻资讯",
    news: [
      {
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        start_time: "2020/08/01",
        title: `希望能给全世界的AVG游戏爱好者
          提供更多更精品的AVG手机游戏希望能给全世界的AVG游戏爱好者
          提供更多更精品的AVG手机游戏希望能给全世界的AVG游戏爱好者
          提供更多更精品的AVG手机游戏`,
        desc:
          "公司现有员工500多人，且在北上深、香港、台湾、新加坡、等地区建立多个分公司。公司现有员工500多人，且在北上深、香港、台湾、新加坡、等地区建立多个分公司。"
      }
    ]
  },
  contact: {
    title: "联系我们",
    note: [
      "在“爱的番茄游戏”网站上 对我们有任何疑问或评论",
      "请填写以下信息与我们取得联系，我们会认真阅读您的每封电子邮件。"
    ],
    boxMsg: [
      ["渠道合作", "qdhz@", "tomatogames.com"],
      ["媒体合作", "mthz@", "tomatogames.com"],
      ["产品引入", "cpyr@", "tomatogames.com"],
      ["广告合作", "gghz@", "tomatogames.com"]
    ]
  },
  footer: {
    title: ["联系我们","招聘信息"],
    icon: ["微信", "微博",  "QQ","QQ群"],
    about: ["关于我们", "企业文化", "游戏产品"],
    news: ["新闻资讯", "新闻资讯"],
    contact: ["联系我们", "客户服务", "合作洽谈"],
    join: ["加入我们", "社会招聘", "校园招聘", "内部推荐"],
    attention: "关注我们"
  },
  games: {
    theme: "游戏产品",
    gamesList: [
      {
        id: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon0.png",
        title: "踏马江湖",
        content: `国风与水墨漫画风融合在一起，开启恣意豪迈的江湖人生。精品江湖AVG养成手游，寻知音、觅红颜，《踏马江湖》与你一同书写属于自己的武林传奇。`,
        pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_tm_p.png"
      },

    //   {
    //     id: 1,
    //     icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon1.png",
    //     title: "盛唐烟雨",
    //     content: `一款女性向3D古风恋爱换装手游，游戏内展现了盛唐时期的繁华风貌，以朝代更迭、宝藏秘闻与身世秘密为线索展开游戏剧情~高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩! 3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有!`,
    //     pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_st_p1.png"
    //   },
    //   {
    //     id: 2,
    //     title: "花开易梦阁",
    //     icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon2.png",
    //     content: `易梦阁 — 记忆交换希望与梦想的地方，在这里可以与6位不同款帅气男神拥有深入的恋爱发展，从主线剧情到场景交互，再至好感培养，让你沉浸式体验恋爱剧情！主线剧情丰富，更有多达12种不同结局，由你自由发挥！超百套服饰任你挑选！发型、五官、妆容任你定，上衣、下装、配饰个性搭配，打造专属于你的定制形象。异梦世界，何去何从，皆在你一念之间！`,
    //     pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_hk_p.png"
    //   },
    //   {
    //     id: 3,
    //     title: "武炼巅峰之武道",
    //     icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon3.png",
    //     content: `《武炼巅峰之武道》是一款东方魔幻题材的3DMMO战斗手游，获得畅销榜首同名小说IP正版授权，玩家在游戏中扮演一个偶入异世界的神秘之人，随着剧情的展开，开启一段奇妙的冒险之旅...`,
    //     pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_wl_p.png"
    //   },
    //   {
    //     id: 4,
    //     title: "葫芦娃各显神通",
    //     icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon4.png",
    //     content: `《葫芦娃各显神通》是一款国风手绘风格的休闲放置手游，由上海美术电影制片厂正版授权，极致还原动画片《葫芦兄弟》原作剧情及设定，同时融入符合东方美学特色的国风手绘风格，力求复刻8090年代的国民记忆，带给玩家们毫无杂质的童趣与纯粹快乐。`,
    //     pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_lh_p.png"
    //   }
    ],
    more: "了解更多信息，请访问：",
    website: [
      [
        "#",
        "https://www.tomato.com/"
      ],
      ["#", "https://www.tomato.com/"],
      ["#", "https://www.tomato.com/"],
      ["https://wldf.tomatogames.com/", "https://wldf.tomatogames.com/"],
      ["https://hlw.tomatogames.com", "https://hlw.tomatogames.com"]
    ]
  },
  newsPage: {
    seeMore: "查看更多",
    share: "分享",
    theme: "新闻",
    m_theme: "新闻资讯",
    tabsLabel: ["最新", "新闻", "通知", "活动"],
    icon:["微信扫一扫分享"],
    newest: [
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "这是一个有打有笑的武侠世界",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/10/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      },
      {
        // type将新闻分为两类
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏",
        desc: `深圳市爱的番茄科技有限公司成立于2020年，公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的...`,
        start_time: "2020/10/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "恋世界全新2.0版本，一款民国风乙女向恋爱游戏",
        desc: `恋世界全新2.0版本，一款民国风乙女向恋爱游戏。讲述了北平新时代少女逃婚进入名为“易梦阁”的药店，并展开了一场奇幻之旅的故事~知名声优助阵、多结局走向剧情、沉浸式互玩玩法...`,
        start_time: "2020/11/01"
      },
      
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      }
    ],
    news: [
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "222222希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏",
        desc: `深圳市爱的番茄科技有限公司成立于2020年，公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的...`,
        start_time: "2020/10/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "恋世界全新2.0版本，一款民国风乙女向恋爱游戏",
        desc: `恋世界全新2.0版本，一款民国风乙女向恋爱游戏。讲述了北平新时代少女逃婚进入名为“易梦阁”的药店，并展开了一场奇幻之旅的故事~知名声优助阵、多结局走向剧情、沉浸式互玩玩法...`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "一款女性向3D古风恋爱换装手游，游戏内展现了盛唐时期的繁华风貌",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/07/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "深圳市爱的番茄科技有限公司成立于2020年",
        desc: `公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏`,
        start_time: "2020/07/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "这是一个有打有笑的武侠世界",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/10/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      }
    ],
    notice: [
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "33333希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏",
        desc: `深圳市爱的番茄科技有限公司成立于2020年，公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的...`,
        start_time: "2020/10/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "恋世界全新2.0版本，一款民国风乙女向恋爱游戏",
        desc: `恋世界全新2.0版本，一款民国风乙女向恋爱游戏。讲述了北平新时代少女逃婚进入名为“易梦阁”的药店，并展开了一场奇幻之旅的故事~知名声优助阵、多结局走向剧情、沉浸式互玩玩法...`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "一款女性向3D古风恋爱换装手游，游戏内展现了盛唐时期的繁华风貌",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/07/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "深圳市爱的番茄科技有限公司成立于2020年",
        desc: `公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏`,
        start_time: "2020/07/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "这是一个有打有笑的武侠世界",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/10/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      }
    ],
    activity: [
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "44444希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏",
        desc: `深圳市爱的番茄科技有限公司成立于2020年，公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的...`,
        start_time: "2020/10/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "恋世界全新2.0版本，一款民国风乙女向恋爱游戏",
        desc: `恋世界全新2.0版本，一款民国风乙女向恋爱游戏。讲述了北平新时代少女逃婚进入名为“易梦阁”的药店，并展开了一场奇幻之旅的故事~知名声优助阵、多结局走向剧情、沉浸式互玩玩法...`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "一款女性向3D古风恋爱换装手游，游戏内展现了盛唐时期的繁华风貌",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/07/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "深圳市爱的番茄科技有限公司成立于2020年",
        desc: `公司致力于精品AVG游戏的研发与全球发行业务。我们在北京、上海、深圳成立了 5 个研发工作室， 1 个独立的编剧工作室，希望能给全世界的AVG游戏爱好者提供更多更精品的AVG手机游戏`,
        start_time: "2020/07/01"
      },
      {
        type: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "这是一个有打有笑的武侠世界",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/10/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      },
      {
        type: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "守护童年，伙伴出山",
        desc: `高度自由化的捏脸换装、百款华裳妆容任你选择、海量动作互动沉浸式剧情、4位性格迥异的男主等你来撩！3D精致古风手游《盛唐烟雨》，你喜欢的样子，我都有！`,
        start_time: "2020/11/01"
      }
    ]
  },
  maskBox: {
    name: ["姓名", "请输入姓名"],
    email: ["邮箱", "请输入邮箱号"],
    subject: ["主题", "请输入主题"],
    content: ["内容", "请输入内容"],
    send: ["发送"]
  },
  singleNews: {
    return: "返回",
    more: "更多文章"
  }
};
export const y = {
  header: {
    tag: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/employ.png",
    ctag:"https://wcdn.tomatogames.com/web/haiwai/tomato/img/employ-details.png",
    nav: ["主页", "职位", "游戏产品", "校园招聘","社会招聘"]
  },
  overlay: {
    title: "让我们改变世界",
    placeholder: "搜索工作岗位",
    search: "搜索"
  },
  gamejob: {
    campus: [
      {
        id: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step1.png",
        content: "网申"
      },
      {
        id: 2,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step2.png",
        content: "线上笔试"
      },
      {
        id: 3,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step3.png",
        content: "面试"
      },
      {
        id: 4,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step4.png",
        content: "发放offer"
      }
    ],
    m_campus: [
      {
        id: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step1.png",
        content: "网申"
      },
      {
        id: 2,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step2.png",
        content: "线上笔试"
      },

      {
        id: 3,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step4.png",
        content: "发放offer"
      },
      {
        id: 4,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step3.png",
        content: "面试"
      }
    ],

    game: {
      title:
        "截至目前爱的番茄产品已覆盖超过100个国家和地区，为2000万全球玩家创造了快乐",
      gameList: [
        {
          id: 1,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon0.png",
          name: "踏马江湖",
          desc1: "国风与水墨漫画风融合<br>精品江湖AVG<br>养成手游",
          desc2: ""
        },
        {
          id: 2,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon1.png",
          name: "盛唐烟雨",
          desc1: "一款展现了盛唐时期<br>繁华风貌的女性向<br>3D古风恋爱<br>换装手游",
          desc2: ""
        },
        {
          id: 3,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon2.png",
          name: "花开易梦阁",
          desc1: "主线剧情丰富<br>打造专属于<br>你的定制形象<br>让你沉浸式体验<br>恋爱剧情",
          desc2: ""
        },
        {
          id: 4,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon3.png",
          name: "武炼巅峰之武道",
          desc1: "东方魔幻题材<br>3DMMO战斗手游<br>畅销榜首同名小说<br>IP正版授权",
          desc2: ""
        },
        {
          id: 5,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon4.png",
          name: "葫芦娃各显神通",
          desc1: "国风手绘风格<br>休闲放置手游<br>上海美术电影制片厂<br>正版授权",
          desc2: ""
        }
      ],
      m_gameList: [
        {
          id: 1,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon0.png",
          name: "踏马江湖",
          desc1: "国风与水墨漫画风融合精品江湖AVG养成手游",
          desc2: ""
        },
        {
          id: 2,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon1.png",
          name: "盛唐烟雨",
          desc1: "一款展现了盛唐时期繁华风貌的女性向3D古风恋爱换装手游",
          desc2: ""
        },
        {
          id: 3,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon2.png",
          name: "花开易梦阁",
          desc1: "主线剧情丰富，打造专属于你的定制形象，让你沉浸式体验恋爱剧情",
          desc2: ""
        },
        {
          id: 4,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon3.png",
          name: "武炼巅峰之武道",
          desc1: "东方魔幻题材3DMMO战斗手游，畅销榜首同名小说IP正版授权",
          desc2: ""
        },
        {
          id: 5,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon4.png",
          name: "葫芦娃各显神通",
          desc1: "国风手绘风格休闲放置手游，上海美术电影制片厂正版授权",
          desc2: ""
        }
      ]
    },
    job: {
      title: "探寻你的工作",
      jobList: [
        {
          id: 1,
          name: "技术研发"
        },
        {
          id: 2,
          name: "美术表现"
        },
        {
          id: 3,
          name: "游戏运营"
        },
        {
          id: 4,
          name: "游戏策划"
        },
        {
          id: 5,
          name: "市场商务"
        },
        {
          id: 6,
          name: "综合职能"
        }
      ],
      look: "查看岗位",
      more: "更多岗位"
    }
  },
  culture: {
    pageList: [
      {
        id: 1,
        title: "开放文化",
        content1:
          "使你朝气蓬勃，可唐装、可汉服、可cosplay；撸猫、撸狗。",
        content2: "你喜欢的，这里都可以有。"
      },
      {
        id: 2,
        title: "丰富的社团活动",
        content1:
          "各类社团活动，让你丰富多彩:篮球社、足球社、羽毛球社、游泳社、健身社、电竞社、桌游社。",
        content2: "你热爱的，这里也都有。"
      },
      {
        id: 3,
        title: "办公环境",
        content1:
          "轻松舒适的办公氛围，打造自主创新，积极投身国际化的平台。",
        content2: "助你不惧疲惫、守护梦想。"
      }
    ]
  },
  welfare: {
    left: {
      title: "企业福利",
      content: [
        ["高于行业市场标准的薪资", "每年两次职级评审及调薪机会"],
        [
          "执行“按贡献分配”的原则，",
          "用绩效说话：【项目奖】【绩效奖】",
          "【评优奖】【年度服务奖】【专项奖】"
        ],
        ["坚持以“公平竞争”“动态激励”", "做为薪酬管理的基本原则"]
      ]
    },
    right: {
      welfares: [
        {
          id: 1,
          title: "关于健康",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon1.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare01.png",
          specific: "商业保险/年度体检"
        },
        {
          id: 2,
          title: "工作时间",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon2.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare02.png",
          specific: "弹性上班/周末双休"
        },
        {
          id: 3,
          title: "吃喝玩乐",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon3.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare03.png",
          specific:
            "不定期团建/年度旅游/节假日礼物及创意活动/餐补/零食下午茶/撸猫撸狗/社团活动/办公室健身/崇尚生活工作两平衡"
        },
        {
          id: 4,
          title: "员工关怀",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon4.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare04.png",
          specific: "生日惊喜/红白事慰问"
        },
        {
          id: 5,
          title: "通勤便利",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon5.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare05.png",
          specific: "便利的办公位置/企业滴滴"
        },
        {
          id: 6,
          title: "安居才能乐业",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon6.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare06.png",
          specific: "核心人才50W无息贷款"
        },
        {
          id: 7,
          title: "关于假期",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon7.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare07.png",
          specific: "入职即可享有年假/每月1天全薪病假"
        },
        {
          id: 8,
          title: "人才补贴",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon8.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare08.png",
          specific: "及时为员工申请 各类政府补助"
        },
        {
          id: 9,
          title: "与大咖一起",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon9.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare09.png",
          specific: "电竞大咖（伍声/若风）不想见见吗"
        }
      ]
    }
  },
  allPost: {
    left: {
      title: "筛选条件",
      clear: "清除",
      path: ["自研线", "发行线"],
      address: {
        title: "工作地点",
        list: ["不限", "深圳", "北京", "上海"]
      },
      type: {
        title: "岗位类别",
        list: [
          "技术研发",
          "美术表现",
          "游戏运营",
          "游戏策划",
          "市场商务",
          "综合职能"
        ]
      },
      nature: {
        title: "工作性质",
        list: ["不限", "全职", "实习"]
      }
    },
    right: {
      title: ["共发现", "个岗位"],
      new: "最新发布岗位"
    }
  },
  applyBox: {
    name: ["姓名", "请输入姓名"],
    sex: ["性别", "男", "女"],
    phone: ["电话", "请输入手机号"],
    code: ["验证码", "请输入短信验证码", "获取短信验证码"],
    email: ["邮箱", "请输入邮箱号"],
    resume: ["上传简历", "浏览", "支持doc、pdf、zip文件，大小10M以内的附件"],
    sendApply: "提交申请"
  },
  detail: {
    postDesc: "岗位描述",
    postRequest: "岗位要求",
    applyPost: "申请岗位",
    newPost: "最新岗位",
    share:["分享到","微信/QQ","QQ"]
  }
};
