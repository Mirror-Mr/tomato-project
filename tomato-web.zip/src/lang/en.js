/*
 * @Author: your name
 * @Date: 2021-03-09 10:58:37
 * @LastEditTime: 2021-05-17 14:08:42
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\lang\en.js
 */
export const x = {
  logo: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/elogo.png",
  clogo: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/celogo.png",
  header: {
    currentLang: "English",
    lang: ["简体中文", "English"],
    nav: ["About Us", "Games", "News", "Contact", "Join Us"]
  },
  carousel: {
    desc: [
      [
        "Our Mission",
        "Become a global user favorite interactive entertainment company"
      ]
    ]
  },
  about: {
    white: {
      title: "About Us",
      content: [
        `Shenzhen Tomato Of Love Technology Co., Ltd. is committed to the research and
        development of high-quality AVG games and global distribution business, which is
        founded in 2020. We have set up five R&D studios and one independent screenwriter
        studio in Beiing, Shanghai and Shenzhen respectively. Our goal is providing more and
        high-quality AVG mobile games to AVG game lovers all over the world.`,
        ""
      ]
    },
    orange: {
      special: [
        "05",
        "R&D studios",
        "01",
        "Independent screenwriter studio",
        "500",
        "Employees"
      ],
      aboutTitle: [
        "",
        "Win win cooperation",
        "Honest and pragmatic",
        "Pursuit of excellence",
        "Long-termism",
        "Master spirit",
        "User first"
      ],
      aboutMsg: [
        [],
        [
          "All members of the company must have an overall view and focus on the overall interests of the company. ",
          `Eliminate hilltopism and gang formation. The company's talents, business, and management system are all company resources, and the situation of dividing "territories" is eliminated.`,
          "When working with external partners, we must also uphold the spirit of collaboration and win-win, in order to pursue long-term sustainable benign cooperation. ",
          "We must not only have a proactive and active spirit of collaboration, but also professional and scientific collaboration capabilities in order to achieve the ultimate win-win goal."
        ],
        [
          "In the course of the company's operation, we must take integrity as the foundation.",
          "Go deep into reality and treat every job with a pragmatic and rigorous attitude. ",
          "When encountering problems, do not whitewash the status quo, face the reality and propose improvement plans.",
          "When encountering challenges, actively respond and be brave to innovate."
        ],
        [
          "Continuously raise requirements, dare to challenge, never let go of any problem,pay attention to the key nature of things,and continue to learn and grow."
        ],
        [
          "Use forward-looking thinking to continuously build organizational capabilities and employee capabilities, and look at our business with a developmental perspective.You cannot sacrifice long-term benefits in order to obtain temporary short-term benefits."
        ],
        [
          "Love your job and treat it as your own career.",
          "Work must have enthusiasm and a high sense of responsibility.",
          "To carry out work, consider the overall situation and weigh the best implementation plan.",
          "Use long-term thinking to think and plan work, and be forward-looking and pioneering and innovative."
        ],
        [
          "AlI take the needs of users as our action plan.",
          "With the fundamental purpose of helping users improve their core values, we always examine whether our core competitiveness can help users improve their core values.",
          `Every colleague must have a "customer first" concept. Users are divided into external users and internal users, and user evaluation is an important means to test the value of work.`
        ]
      ]
    }
  },
  newsPart: {
    title: "News",
    news: [
      {
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        start_time: "2020/08/01",
        title: `希望能给全世界的AVG游戏爱好者
          提供更多更精品的AVG手机游戏希望能给全世界的AVG游戏爱好者
          提供更多更精品的AVG手机游戏希望能给全世界的AVG游戏爱好者
          提供更多更精品的AVG手机游戏`,
        desc:
          "公司现有员工500多人，且在北上深、香港、台湾、新加坡、等地区建立多个分公司。公司现有员工500多人，且在北上深、香港、台湾、新加坡、等地区建立多个分公司。"
      }
    ]
  },
  contact: {
    title: "Contact",
    note: [
      "Got a question or comment for us at Tomato of love games?",
      "Please Till in the tollowing flelds to contact our team一we read everyemail we get. For quick questions and comments, you may also contact"
    ],
    boxMsg: [
      ["Channel Cooperation", "qdhz@tomatogames.com"],
      ["Media cooperation", "mthz@tomatogames.com"],
      ["Product Introduction", "cpyr@tomatogames.com"],
      ["Advertising Cooperation", "gghz@tomatogames.com"]
    ]
  },
  footer: {
    title: ["Follow Us", ""],
    icon: ["微信", "微博", "QQ", "QQ群"],
    about: ["About Us", "Culture", "Games"],
    news: ["News", "News"],
    contact: ["Contact", "Customer Services", "Partnership"],
    join: [
      "Join Us",
      "Tomato Careers",
      "Campus Recruitment",
      "Global Recruitment"
    ],
    attention: "Follow Us"
  },
  games: {
    theme: "GAMES",
    gamesList: [
      {
        id: 0,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon0.png",
        title: "Wandering the Jianghu",
        content: `The combination of the national style and the ink-cartoon style opens up the willful and heroic life in the ancient society. Typical Chinese style AVG develops mobile travel, seeks friends and beauties, and "Wandering the Jianghu" writes its own Kungfu legend with you.`,
        pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_tm_p.png"
      },

      {
        id: 1,
        icon:
          "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon1.png",

        title: "Rain in the Tang Dynasty",
        content: `A woman-approach 3D Chinese ancient style love-and-changing mobile game. This game shows the prosperous style of the Tang Dynasty, with the change of dynasties, treasure secrets and life experience secrets as the clues to launch the game plot ~ highly free pinching face changing, 100 kinds of Chinese dress makeup for you to choose, massive action interactive immersive plot, 4 men with different personalities to flirt with! The 3D exquisite ancient style mobile game "Rain in the Tang Dynasty". I have all the looks that you like!`,
        pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_st_p.png"
      },
      {
        id: 2,
        title: "Blossom Dream",
        icon:
          "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon2.png",

        content: `The latest 2.0 version of Love the World is a Republic style love-game. It portrays the story of a Beiping's young girl escaping marriage and entering the drugstore named "Blossom Dream" in the new era. Then, she starts a fantastic journey. With the help of famous voice actors, the immersive game experience with various endings, and many handsome guys waiting for you to meet! The Republic of China's aestheticism mobile game "Love the World" waiting for you to enter the "Blossom Dream", and wake up the love in your deep memory.`,

        pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_hk_p.png"
      },
      {
        id: 3,
        title: "Legend of Queens",
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon3.png",
        content: `The latest 2.0 version of Love the World is a Republic style love-game. It portrays the story of a Beiping's young girl escaping marriage and entering the drugstore named "Blossom Dream" in the new era. Then, she starts a fantastic journey. With the help of famous voice actors, the immersive game experience with various endings, and many handsome guys waiting for you to meet! The Republic of China's aestheticism mobile game "Love the World" waiting for you to enter the "Blossom Dream", and wake up the love in your deep memory.`,
        pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_wl_p.png"
      },
      {
        id: 4,
        title: "Gourd baby",
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon4.png",
        content: `The latest 2.0 version of Love the World is a Republic style love-game. It portrays the story of a Beiping's young girl escaping marriage and entering the drugstore named "Blossom Dream" in the new era. Then, she starts a fantastic journey. With the help of famous voice actors, the immersive game experience with various endings, and many handsome guys waiting for you to meet! The Republic of China's aestheticism mobile game "Love the World" waiting for you to enter the "Blossom Dream", and wake up the love in your deep memory.`,
        pic: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/m_lh_p.png"
      }
    ],
    more: "For more information, please visit",
    website: [
      ["#", "https://www.tomato.com/"],
      ["#", "https://www.tomato.com/"],
      ["#", "https://www.tomato.com/"],
      ["https://wldf.tomatogames.com/", "https://wldf.tomatogames.com/"],
      ["https://hlw.tomatogames.com", "https://hlw.tomatogames.com"]
    ]
  },
  newsPage: {
    seeMore: "See more",
    share: "Share",
    theme: "News",
    m_theme: "News",
    tabsLabel: ["Newest", "News", "Notice", "Activity"],
    icon:["微信扫一扫分享"],
    newest: [
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "2Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/10/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "3Is committed to the research and development of high-quality AVG games and global distribution",
        content: `Our goal is providing more and high-quality AVG mobile games to AVG game lovers all over the world.`,
        time: "2020/11/01"
      },
      {
        sign: 0,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "4Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/07/01"
      },
      {
        sign: 0,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "5Senior Citizens Tackle Esports in Upcoming Ubisoft Film Project",
        content: `On April 21st, you can dive into the world of The Division 2 and take
          back Washington D.C. from hostile factions with the free trial. Group
          up to complete activities, take back control points and complete both
          main and side missions to progress in the story campaign.`,
        time: "2020/07/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "6Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/10/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "7Is committed to the research and development of high-quality AVG games and global distribution",
        content: `Our goal is providing more and high-quality AVG mobile games to AVG game lovers all over the world.`,
        time: "2020/11/01"
      }
    ],
    news: [
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "2Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/10/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "3Is committed to the research and development of high-quality AVG games and global distribution",
        content: `Our goal is providing more and high-quality AVG mobile games to AVG game lovers all over the world.`,
        time: "2020/11/01"
      },
      {
        sign: 0,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "4Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/07/01"
      },
      {
        sign: 0,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "5Senior Citizens Tackle Esports in Upcoming Ubisoft Film Project",
        content: `On April 21st, you can dive into the world of The Division 2 and take
          back Washington D.C. from hostile factions with the free trial. Group
          up to complete activities, take back control points and complete both
          main and side missions to progress in the story campaign.`,
        time: "2020/07/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "6Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/10/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "7Is committed to the research and development of high-quality AVG games and global distribution",
        content: `Our goal is providing more and high-quality AVG mobile games to AVG game lovers all over the world.`,
        time: "2020/11/01"
      }
    ],
    notice: [
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "2Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/10/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "3Is committed to the research and development of high-quality AVG games and global distribution",
        content: `Our goal is providing more and high-quality AVG mobile games to AVG game lovers all over the world.`,
        time: "2020/11/01"
      },
      {
        sign: 0,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "4Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/07/01"
      },
      {
        sign: 0,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "5Senior Citizens Tackle Esports in Upcoming Ubisoft Film Project",
        content: `On April 21st, you can dive into the world of The Division 2 and take
          back Washington D.C. from hostile factions with the free trial. Group
          up to complete activities, take back control points and complete both
          main and side missions to progress in the story campaign.`,
        time: "2020/07/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "6Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/10/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "7Is committed to the research and development of high-quality AVG games and global distribution",
        content: `Our goal is providing more and high-quality AVG mobile games to AVG game lovers all over the world.`,
        time: "2020/11/01"
      }
    ],
    activity: [
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "2Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/10/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "3Is committed to the research and development of high-quality AVG games and global distribution",
        content: `Our goal is providing more and high-quality AVG mobile games to AVG game lovers all over the world.`,
        time: "2020/11/01"
      },
      {
        sign: 0,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "4Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/07/01"
      },
      {
        sign: 0,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "5Senior Citizens Tackle Esports in Upcoming Ubisoft Film Project",
        content: `On April 21st, you can dive into the world of The Division 2 and take
          back Washington D.C. from hostile factions with the free trial. Group
          up to complete activities, take back control points and complete both
          main and side missions to progress in the story campaign.`,
        time: "2020/07/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title: "6Our goal is providing more and high-quality AVG mobile games ",
        content: `On April 21st, you can dive into the world of The Division 2 and take back Washington D.C. from hostile factions with the free trial. Group up to complete activities, take back control points and complete both main and side missions to progress in the story campaign.`,
        time: "2020/10/01"
      },
      {
        sign: 1,
        img: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/news0.png",
        title:
          "7Is committed to the research and development of high-quality AVG games and global distribution",
        content: `Our goal is providing more and high-quality AVG mobile games to AVG game lovers all over the world.`,
        time: "2020/11/01"
      }
    ]
  },
  maskBox: {
    name: ["Name", "Please enter your name"],
    email: ["Email", "Please enter your email number"],
    subject: ["Subject", "Please enter the subject"],
    content: ["Content", "Please enter the content"],
    send: ["Send"]
  },
  singleNews: {
    return: "Return",
    more: "More articles"
  }
};
export const y = {
  header: {
    tag: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/en-employ.png",
    ctag:
      "https://wcdn.tomatogames.com/web/haiwai/tomato/img/en-employ-details.png",
    nav: [
      "Home",
      "Position",
      "Games",
      "Campus Recruitment",
      "Social Recruitment"
    ]
  },
  overlay: {
    title: "Let's change the world",
    placeholder: "Search jobs",
    search: "Find jobs"
  },
  gamejob: {
    campus: [
      {
        id: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step1.png",
        content: "Online application"
      },
      {
        id: 2,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step2.png",
        content: "Online written test"
      },
      {
        id: 3,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step3.png",
        content: "Interview"
      },
      {
        id: 4,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step4.png",
        content: "Offer"
      }
    ],
    m_campus: [
      {
        id: 1,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step1.png",
        content: "Online application"
      },
      {
        id: 2,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step2.png",
        content: "Online written test"
      },

      {
        id: 3,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step4.png",
        content: "Offer"
      },
      {
        id: 4,
        icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/step3.png",
        content: "Interview"
      }
    ],

    game: {
      title: `Up to now, Love's tomato products have covered more than 100 countries and regions, 
        creating happiness for 20 million players around the world`,
      gameList: [
        {
          id: 1,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon0.png",
          name: `Wandering
          the Jianghu`,
          desc1: "Chinese style ink cartoon wind",
          desc2: "AVG develop mobile game"
        },
        {
          id: 2,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon1.png",
          name: `Rain in the
          Tang Dynasty`,
          desc1: "Women to 3D ancient love",
          desc2: "change mobile game"
        },
        {
          id: 3,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon2.png",
          name: "Blossom Dream",
          desc1: "Women to Republic of China ",
          desc2: "wind B female to love game"
        },
        {
          id: 4,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon3.png",
          name: "Legend of the Queen",
          desc1: "Women to Republic of China",
          desc2: "wind B female to love game"
        },
        {
          id: 5,
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/gicon4.png",
          name: "Gourd baby",
          desc1: "Chinese style ink cartoon wind",
          desc2: "AVG develop mobile game"
        }
      ]
    },
    job: {
      title: "Explore your work",
      jobList: [
        {
          id: 1,
          name: "Technology Research And Development"
        },
        {
          id: 2,
          name: "The Art Performance"
        },
        {
          id: 3,
          name: "Game Operations"
        },
        {
          id: 4,
          name: "The Game Plan"
        },
        {
          id: 5,
          name: "Market Business"
        },
        {
          id: 6,
          name: "Comprehensive Functions"
        }
      ],
      look: "View the Post",
      more: "VIEW MORE JOBS"
    }
  },
  culture: {
    pageList: [
      {
        id: 1,
        title: "Open Culture",
        content1: `Make you full of youthful spirit, can be Tang suit, hanfu, cosplay; Pitch a cat, pet a dog, you like, you can have it here.`,
        content2: ""
      },
      {
        id: 2,
        title: "Rich Club Activities",
        content1:
          "All kinds of club activities make you rich and colorful: basketball club, football club, badminton club, swimming club, fitness club, e-sports club, board game club.",
        content2: "It's got everything you love."
      },
      {
        id: 3,
        title: "Office Environment",
        content1:
          "Easy and comfortable office atmosphere, to create independent innovation, actively participate in the international platform. Help you not be afraid of exhaustion, guard the dream.",
        content2: ""
      }
    ]
  },
  welfare: {
    left: {
      title: `Corporate
      Welfare`,
      content: [
        [
          "Salary above industry market standard Two annual rank review and salary adjustment opportunities",
          ""
        ],
        [
          `Implementing the principle of "distribution by contribution",`,
          "Talk in terms of performance :(project award) (performance award)",
          "(Excellence Award) (Annual Service Award) (Special Award)"
        ],
        [
          `Adhere to "fair competition" and "dynamic incentives"`,
          "As the basic principle of compensation management"
        ]
      ]
    },
    right: {
      welfares: [
        {
          id: 1,
          title: "About Health",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon1.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare01.png",
          specific:
            "Supplementary medical care/accident insurance/annual physical examination"
        },
        {
          id: 2,
          title: "Working Time",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon2.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare02.png",
          specific: "Flexible working/double weekends off"
        },
        {
          id: 3,
          title: "Beer And Skittles",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon3.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare03.png",
          specific:
            "Irregular group building / annual tourism / holiday gifts and creative activities / meal supplement / snack afternoon tea / cat and dog / club activities / Office fitness / advocating balance between life and work"
        },
        {
          id: 4,
          title: "Employees Care",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon4.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare04.png",
          specific: "Birthday surprise/red and white condolences"
        },
        {
          id: 5,
          title: "Commuting Convenience",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon5.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare05.png",
          specific: "Convenient office location/corporate didi"
        },
        {
          id: 6,
          title: "live And Work In Peace",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon6.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare06.png",
          specific: "50W interest free loan for core talents"
        },
        {
          id: 7,
          title: "About The Holiday",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon7.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare07.png",
          specific:
            "Annual leave in advance / 1 day full pay sick leave per month"
        },
        {
          id: 8,
          title: "Talent Subsidies",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon8.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare08.png",
          specific:
            "Timely apply for all kinds of government subsidies for employees"
        },
        {
          id: 9,
          title: "With The Big Guns",
          icon: "https://wcdn.tomatogames.com/web/haiwai/tomato/img/wicon9.png",
          pic:
            "https://wcdn.tomatogames.com/web/haiwai/tomato/img/welfare09.png",
          specific: "Esports big coffee (Wu Sheng/if wind) don't want to meet"
        }
      ]
    }
  },
  allPost: {
    left: {
      title: "Filter by",
      clear: "Remove",
      path: ["Self Research Line", "Distribution Line"],
      address: {
        title: "Working Place",
        list: ["All", "Shenzhen", "Beijing", "Shanghai"]
      },
      type: {
        title: "Job Categories",
        list: [
          "Technology Research And Development",
          "The Art Performance",
          "Game Operations",
          "The game plan",
          "Market Business",
          "Comprehensive Functions"
        ]
      },
      nature: {
        title: "Nature Ff Work",
        list: ["All", "Full Time", "Internship"]
      }
    },
    right: {
      title: ["A total of", "jobs were found"],
      new: "Latest Post"
    }
  },
  applyBox: {
    name: ["Name", "Please enter your name"],
    sex: ["Sex", "男", "女"],
    phone: ["Phone", "Please enter your cell phone number"],
    code: ["Code", "请输入短信验证码", "获取短信验证码"],
    email: ["Eamil", "Please enter email number"],
    resume: [
      "Resume",
      "Upload",
      "Support DOC, PDF, ZIP files, size within 10M attachments"
    ],
    sendApply: "Apply"
  },
  detail: {
    postDesc: "Job Descriptions",
    postRequest: "Post Requirements",
    applyPost: "Apply",
    newPost: "The Latest Post",
    share:["Share with","WeChat/QQ","QQ"]
  }
};
