/*
 * @Author: your name
 * @Date: 2021-02-23 10:57:53
 * @LastEditTime: 2021-05-17 11:10:10
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web-masterc:\Users\leishan\Desktop\tomato\tomato-web\src\router\index.js
 */
import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

// router文件夹下等index.js文件中写入
//解决编程式路由往同一地址跳转时会报错的情况
const originalPush = VueRouter.prototype.push;
const originalReplace = VueRouter.prototype.replace;
//push
VueRouter.prototype.push = function push(location, onResolve, onReject) {
  if (onResolve || onReject)
    return originalPush.call(this, location, onResolve, onReject);
  return originalPush.call(this, location).catch(err => err);
};
//replace
VueRouter.prototype.replace = function push(location, onResolve, onReject) {
  if (onResolve || onReject)
    return originalReplace.call(this, location, onResolve, onReject);
  return originalReplace.call(this, location).catch(err => err);
};

const routes = [
  {
    path: "/",
    name: "Home",
    component: () => import("../views/Home.vue")
  },
  {
    path: "/m",
    name: "MHome",
    component: () => import("../views/m-Home.vue")
  },

  {
    path: "/newsPage",
    name: "NewsPage",
    component: () => import("../views/NewsPage.vue")
  },
  {
    path: "/m/newsPage",
    name: "MNewsPage",
    component: () => import("../views/m-NewsPage.vue")
  },

  {
    path: "/games",
    name: "Games",
    component: () => import("../views/Games.vue")
  },
  {
    path: "/m/games",
    name: "MGames",
    component: () => import("../views/m-Games.vue")
  },
  {
    path: "/singleNews",
    name: "SingleNews",
    component: () => import("../views/SingleNews.vue")
  },
  {
    path: "/m/singleNews",
    name: "MSingleNews",
    component: () => import("../views/m-SingleNews.vue")
  },
  {
    path: "/employ",
    name: "Employ",
    component: () => import("../views/jobs/Employ.vue")
  },
  {
    path: "/m/employ",
    name: "MEmploy",
    component: () => import("../views/jobs/m-Employ.vue")
  },

  {
    path: "/allPost",
    name: "AllPost",
    component: () => import("../views/jobs/AllPost.vue"),
    
  },
  {
    path: "/m/allPost",
    name: "MAllPost",
    component: () => import("../views/jobs/m-AllPost.vue"),
    
  },
  {
    path: "/detail",
    name: "Detail",
    component: () => import("../views/jobs/Detail.vue")
  },
  {
    path: "/m/detail",
    name: "MDetail",
    component: () => import("../views/jobs/m-Detail.vue")
  }
];
// 路由跳转后页面在最顶端
const router = new VueRouter({
  mode:"history",
  routes,
  scrollBehavior(to, from, saveTop) {
    if (saveTop) {
      return saveTop;
    } else {
      return { x: 0, y: 0 };
    }
  }
});

export default router;
